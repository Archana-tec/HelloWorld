import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Dataset
import argparse
from azureml.core import Run
from pyspark.sql.types import IntegerType, DoubleType, StructField, StructType, TimestampType, LongType, StringType, BooleanType


start_time = datetime.datetime.now()

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--fptu")
parser.add_argument("--environment")
parser.add_argument("--output_dir")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")

print(f"[{datetime.datetime.now()}] Input Mount point from arguments: {args.fptu}")
print(f"[{datetime.datetime.now()}] Output Mount point from arguments: {args.output_dir}")

input_mount_point = args.fptu
output_dir = args.output_dir.replace('.blob.', '.dfs.')
output_dir = output_dir.replace('wasbs', 'abfss')

sdf_fptu2 = None
try:
    print(f"[{datetime.datetime.now()}] Reading the latest date from previous data load ...")
    current_ts_file = spark.read.parquet(output_dir+'/fptu')
    current_ts_max_date = current_ts_file.select(max('ModifiedAt')).first()[0]
    period_start_utc = current_ts_max_date - datetime.timedelta(days=1)
    sdf_fptu2 = current_ts_file.alias('sdf_fptu2')
except:
    period_start_utc = datetime.datetime(2022,7,1) # default to start of July if no file is found

# The pipeline runs every day at 5AM
period_end_utc = datetime.datetime.now()

# this part is used to handle sync delay between prod and dev
if args.environment=='DEV':
    if period_end_utc.hour < 6:
        period_end_utc = period_end_utc.replace(hour=0, minute=0, second=0, microsecond=0) - datetime.timedelta(seconds=1)

print(f'[{datetime.datetime.now()}] Start Date: {period_start_utc.strftime("%Y-%m-%d")}')
print(f'[{datetime.datetime.now()}] End Date: {period_end_utc.strftime("%Y-%m-%d")}')

# Create hdfs date range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
print(f'[{datetime.datetime.now()}] FPTU schedule date range: {date_range}')

# Load FPTU and append to previous iterations
dr = (date_range.replace("{","").replace("}","").replace("*","")).split(",")
sources =  [ input_mount_point + sub + "*" for sub in dr] # replace * with / for parquet source
sources = [x.replace('blob', 'dfs') for x in sources]
sources = [x.replace('wasbs', 'abfss') for x in sources]
print(f'[{datetime.datetime.now()}] Sources: {sources}')

sdf_fptu = None

# print(f"[{datetime.datetime.now()}] Going to read parquet files ...")
# for pq_source in sources:
#     print(f"[{datetime.datetime.now()}] Going to read parquet file {pq_source} ...")
#     try:
#         if sdf_fptu is None:
#             sdf_fptu = spark.read.parquet(pq_source)
#         else:
#             sdf_fptu_temp = sspark.read.parquet(pq_source)
#             sdf_fptu.union(sdf_fptu_temp)
#     except Exception as e:
#         print(f"[{datetime.datetime.now()}] Failed to read parquet file {pq_source}: {e}")
#
# print(f"[{datetime.datetime.now()}] Finished reading parquet files ... ")
for source in sources:
    print(f"[{datetime.datetime.now()}] Going to read json file {source} ...")
    try:
        if sdf_fptu is None:
            sdf_fptu_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_fptu_temp = load_ADA_data.NormaliseJsonSpark(sdf_fptu_temp).normalise_fptu_spark()
            sdf_fptu = sdf_fptu_temp.alias('sdf_fptu')
        else:
            sdf_fptu_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_fptu_temp = load_ADA_data.NormaliseJsonSpark(sdf_fptu_temp).normalise_fptu_spark()
            sdf_fptu = sdf_fptu.union(sdf_fptu_temp)
    except Exception as e:
        print(f"[{datetime.datetime.now()}] Failed to read json file {source}: {e}")
print(f"[{datetime.datetime.now()}] Finished reading json files ... ")


sdf_fptu = sdf_fptu.withColumn("SourceIdentifier", col("SourceIdentifier").cast(LongType()))
sdf_fptu = sdf_fptu.withColumn("Shift_SK", col("Shift_SK").cast(LongType()))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageEventStart", to_timestamp("FixedPlantTimeUsageEventStart"))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageEventFinish", to_timestamp("FixedPlantTimeUsageEventFinish"))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageGroupEventStart", to_timestamp("FixedPlantTimeUsageGroupEventStart"))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageGroupEventFinish", to_timestamp("FixedPlantTimeUsageGroupEventFinish"))
sdf_fptu = sdf_fptu.withColumn("cTimeUsageGroupEvent", col("cTimeUsageGroupEvent").cast(BooleanType()))
sdf_fptu = sdf_fptu.withColumn("sTimeUsage", col("sTimeUsage").cast(LongType()))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageComments", col("FixedPlantTimeUsageComments").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("FixedPlantTimeUsageExplanation", col("FixedPlantTimeUsageExplanation").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("FixedPlantAssetCode", col("FixedPlantAssetCode").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("FixedPlantAssetDescription", col("FixedPlantAssetDescription").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("SubEquipment", col("SubEquipment").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TPPSEquipmentCode", col("TPPSEquipmentCode").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("CauseFixedPlantAssetCode", col("CauseFixedPlantAssetCode").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("CauseFixedPlantAssetDescription", col("CauseFixedPlantAssetDescription").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("CauseArea", col("CauseArea").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("Cause", col("Cause").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("Effect", col("Effect").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TPPSTrainId", col("TPPSTrainId").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM0Code", col("TUM0Code").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM0DisplayName", col("TUM0DisplayName").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM1Code", col("TUM1Code").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM1DisplayName", col("TUM1DisplayName").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM5Code", col("TUM5Code").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("TUM5DisplayName", col("TUM5DisplayName").cast(StringType()))
sdf_fptu = sdf_fptu.withColumn("SourceUpdatedAt", to_timestamp("SourceUpdatedAt"))
sdf_fptu = sdf_fptu.withColumn("ModifiedAt", to_timestamp("ModifiedAt"))
sdf_fptu = sdf_fptu.withColumn("file_timestamp", col("file_timestamp").cast(StringType()))

if sdf_fptu2 is None:
    print(f"[{datetime.datetime.now()}] Going to read the old fptu data ...")
    sdf_fptu2 = spark.read.parquet(output_dir+'/fptu')
    print(f"[{datetime.datetime.now()}] Finished reading the old fptu data ...")

sdf_fptu2.createOrReplaceTempView("old_df")
sdf_fptu.createOrReplaceTempView("new_df")

new_data = spark.sql("""
            select n.*
            from  new_df n
            where not exists (
                select * from old_df o 
                where o.SourceIdentifier = n.SourceIdentifier
                    AND o.Shift_SK = n.Shift_SK
                    AND o.FixedPlantTimeUsageEventStart = n.FixedPlantTimeUsageEventStart
                    AND o.FixedPlantTimeUsageEventFinish = n.FixedPlantTimeUsageEventFinish
                    AND o.FixedPlantTimeUsageGroupEventStart = n.FixedPlantTimeUsageGroupEventStart
                    AND o.FixedPlantTimeUsageGroupEventFinish = n.FixedPlantTimeUsageGroupEventFinish
                    AND o.cTimeUsageGroupEvent = n.cTimeUsageGroupEvent
                    AND o.sTimeUsage = n.sTimeUsage
                    AND o.FixedPlantTimeUsageComments = n.FixedPlantTimeUsageComments
                    AND o.FixedPlantTimeUsageExplanation = n.FixedPlantTimeUsageExplanation
                    AND o.FixedPlantAssetCode = n.FixedPlantAssetCode
                    AND o.FixedPlantAssetDescription = n.FixedPlantAssetDescription
                    AND o.SubEquipment = n.SubEquipment
                    AND o.TPPSEquipmentCode = n.TPPSEquipmentCode
                    AND o.CauseFixedPlantAssetCode = n.CauseFixedPlantAssetCode
                    AND o.CauseFixedPlantAssetDescription = n.CauseFixedPlantAssetDescription
                    AND o.CauseArea = n.CauseArea
                    AND o.Cause = n.Cause
                    AND o.Effect = n.Effect
                    AND o.TPPSTrainId = n.TPPSTrainId
                    AND o.TUM0Code = n.TUM0Code
                    AND o.TUM0DisplayName = n.TUM0DisplayName
                    AND o.TUM1Code = n.TUM1Code
                    AND o.TUM1DisplayName = n.TUM1DisplayName
                    AND o.TUM5Code = n.TUM5Code
                    AND o.TUM5DisplayName = n.TUM5DisplayName
                    AND o.SourceUpdatedAt = n.SourceUpdatedAt
                    AND o.ModifiedAt = n.ModifiedAt
           )
""")

print(f"[{datetime.datetime.now()}] Going to append the new data into the FTPU data ...")
new_data.write.mode('append').parquet(f'{output_dir}/fptu')

print(f'[{datetime.datetime.now()}] Optimization - Start reading parquet...')
df = spark.read.parquet(f'{output_dir}/fptu')
df = df.dropDuplicates(["SourceIdentifier", "Shift_SK", "FixedPlantTimeUsageEventStart", "FixedPlantTimeUsageEventFinish",
             "FixedPlantTimeUsageGroupEventStart", "FixedPlantTimeUsageGroupEventFinish",
             "cTimeUsageGroupEvent", "sTimeUsage", "FixedPlantTimeUsageComments", "FixedPlantTimeUsageExplanation",
             "FixedPlantAssetCode", "FixedPlantAssetDescription", "SubEquipment",
             "TPPSEquipmentCode", "CauseFixedPlantAssetCode", "CauseFixedPlantAssetDescription", "CauseArea", "Cause",
             "Effect", "TPPSTrainId", "TUM0Code", "TUM0DisplayName", "TUM1Code",
             "TUM1DisplayName", "TUM5Code", "TUM5DisplayName", "SourceUpdatedAt", "ModifiedAt"])


print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df.repartition(50).write.mode('overwrite').parquet(f'{output_dir}_temp/fptu')

print(f'[{datetime.datetime.now()}] Optimization - Moving to actual table ...')
df2 = spark.read.parquet(f'{output_dir}_temp/fptu')

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df2.repartition(50).write.mode('overwrite').parquet(f'{output_dir}/fptu')

print(f"[{datetime.datetime.now()}] FPTU load complete.")
end_time = datetime.datetime.now()
print(f"[{datetime.datetime.now()}] DONE in {(end_time-start_time)}...")



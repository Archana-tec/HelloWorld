import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import argparse

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--train_schedule")
parser.add_argument("--FPTU")
parser.add_argument("--alarms")
parser.add_argument("--output_dir")
parser.add_argument("--period_start")
parser.add_argument("--period_end")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder \
                .appName('app_name') \
                .master('local[*]') \
                .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                .config('spark.sql.session.timeZone', 'UTC') \
                .config('spark.driver.memory','32G') \
                .config('spark.ui.showConsoleProgress', True) \
                .config('spark.sql.repl.eagerEval.enabled', True) \
                .config('spark.driver.maxResultSize','32G')\
                .getOrCreate()


# End date is either dynamic or fixed
if args.period_end =='default':
    period_end_utc_string = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1), '%Y-%m-%d')
    period_end_utc_ext = datetime.datetime.now()
else:
    period_end_utc_string = args.period_end
    period_end_utc_ext = datetime.datetime.strptime(args.period_end,'%Y-%m-%d') + datetime.timedelta(days=1)

if args.period_start =='default':
    period_start_utc = period_end_utc_ext - datetime.timedelta(days=97)
else:
    period_start_utc = datetime.datetime.strptime(args.period_start,'%Y-%m-%d')

print(f"[{datetime.datetime.now()}] period_start: {str(period_start_utc)}")
print(f"[{datetime.datetime.now()}] period_end: {str(period_end_utc_ext)}")

uc1_tags_list = os.path.join(os.path.dirname(__file__), 'UC1_Tags.txt')
tag_list = []
with open(uc1_tags_list) as f:
    tag_list = f.read().splitlines() 
f.close()

print(f'[{datetime.datetime.now()}] Tag load starts.')
sdf_tags = spark.read.parquet(args.PCS_tags)
sdf_tags = sdf_tags[sdf_tags.tagid.isin(tag_list)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start_utc, period_end_utc_ext+datetime.timedelta(days=1))]
sdf_tags.write.parquet(args.output_dir+'/PCS_tags')
print(f'[{datetime.datetime.now()}] Tag load complete.')

print(f'[{datetime.datetime.now()}] Tag pivot starts.')
sdf_tags_pivot = sdf_tags.groupBy('time_rio').pivot('tagid').agg(first('value_rio'))
df_tags_pivot = sdf_tags_pivot.toPandas()
# lq added - sort the 'time_rio' column in ascending order before fillna by forward filling
df_tags_pivot = df_tags_pivot.sort_values(['time_rio'])
df_tags_pivot = df_tags_pivot.set_index('time_rio')
df_tags_pivot = df_tags_pivot.fillna(method='ffill')
df_tags_pivot = df_tags_pivot.loc[period_start_utc:period_end_utc_string]
df_tags_pivot = df_tags_pivot.resample('T').ffill()
df_tags_pivot = df_tags_pivot.dropna(how='all')
df_tags_pivot.to_parquet(args.output_dir+'/PCS_tags_pivot')
print(f'[{datetime.datetime.now()}] Tag pivot complete.')

# Load Train Schedule
print(f'[{datetime.datetime.now()}] Train Schedule load starts.')
sdf_ts = spark.read.parquet(args.train_schedule)
sdf_ts = sdf_ts[sdf_ts.UPDATED_ON_UTC.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))]
sdf_ts.write.parquet(args.output_dir+'/train_schedule')
print(f'[{datetime.datetime.now()}] Train Schedule load complete.')

# Load Alarms
print(f'[{datetime.datetime.now()}] Alarms load starts.')
sdf_alarms = spark.read.parquet(args.alarms)
sdf_alarms = sdf_alarms.withColumn('vt_start', to_timestamp('vt_start'))
sdf_alarms = sdf_alarms[sdf_alarms.vt_start.between(period_start_utc, period_end_utc_ext+datetime.timedelta(days=1))]
sdf_alarms.write.parquet(args.output_dir+'/alarms')
print(f'[{datetime.datetime.now()}] Alarms load complete.')

# Load FPTU
print(f'[{datetime.datetime.now()} FPTU load starts.')
sdf_fptu = spark.read.parquet(args.FPTU)
sdf_fptu = sdf_fptu[sdf_fptu.ModifiedAt.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))] # check with erwin why use "modifiedAt" column to filter
sdf_fptu = sdf_fptu.orderBy("FixedPlantTimeUsageEventStart")
sdf_fptu = sdf_fptu[sdf_fptu.TUM5Code.isin(['ULO','ULF','OD','OS'])]
sdf_fptu = sdf_fptu[sdf_fptu.FixedPlantAssetCode == 'Train Loadout 1']
sdf_fptu = sdf_fptu[~sdf_fptu.Effect.isin(['Wait Train', 'Clearing Train', 'Present Train', 'Placing Train'])] # These are normal parts of the process and not delays we are trying to identify
sdf_fptu.write.parquet(args.output_dir+'/FPTU')
print(f'[{datetime.datetime.now()} FPTU load complete.')

# FPTU - Delay Time Series
print(f'[{datetime.datetime.now()}] FPTU time series transformation starts.')
dt_start_awst = period_start_utc + datetime.timedelta(hours=8)
dt_end_awst = period_end_utc_ext + datetime.timedelta(hours=8)
delta = dt_end_awst - dt_start_awst
delta_mins = delta.total_seconds()/60
num_periods = delta_mins + 1    # Number of 1 minute periods
datetime_range = pd.date_range(dt_start_awst, periods=num_periods, freq='1T') 

df_fptu = sdf_fptu.toPandas()
df_fptu = df_fptu[df_fptu['FixedPlantTimeUsageEventStart'].between(dt_start_awst,dt_end_awst)]
# lq edit- missed variable assignment
df_fptu = df_fptu.sort_values('FixedPlantTimeUsageEventFinish').drop_duplicates(subset = ['SourceIdentifier','Cause','Effect','FixedPlantTimeUsageEventStart'],keep='last')

delay_in_progress=[]
for ts in datetime_range:
    delay = 0 
    fptu = df_fptu[(df_fptu['FixedPlantTimeUsageEventStart'] <= ts) & (df_fptu['FixedPlantTimeUsageEventFinish'] > ts)]
    if len(fptu) > 0: 
        delay = 1
    else:
        delay = 0
    delay_in_progress.append(delay)

df_fptu_ts = pd.DataFrame(index=datetime_range,data=delay_in_progress,columns=['delay_in_progress'])
df_fptu_ts.to_parquet(args.output_dir+'/FPTU_delay_ts')
print(f'[{datetime.datetime.now()}] FPTU time series transformation complete.')

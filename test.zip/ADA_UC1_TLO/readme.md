# ADA Use Case 1: Train Load-Out Forecasting
<br>
MVP model code for Gudai-Darri Advanced Data Analytics <b>Use Case 1: Train Load-Out Forecasting.</b>
<br><br>
Model files consist of training pipeline steps, inference code and 
utility functions and reference files used by both training and inference.
<br><br>

##<b>Training Pipeline</b><br>

The UC1 training pipeline consists of 4 steps:
<br>
1. <b>uc1_pipeline_dataprep.py:</b> Data preparation step for the PCS Tag, Alarm, Train Schedule and Fixed Plant Time Usage input data<br>
2. <b>uc1_pipeline_train.py:</b> Training step which trains three separate components of the solution:<br>
    - Expected delay event duration based on full history of Gudai-Darri data<br>
    - Machine Learning model to identify if a delay event is in progress or not. Training date range is based on the training_start and training_end arguments<br>
    - Expected duration of the train to pass through each stage of the TLO process, based on the last 4 weeks of data<br>
3. <b>uc1_pipeline_register.py:</b> Registers the trained components of the UC1 model to the Models section of the ML Workspace, along with the model source code<br>
4. <b>uc1_pipeline_test.py:</b> Test step which generates model outputs at every 3-minute time step in the date range provided by the test_start and test_end arguments
<br>

The Training Pipeline is intended to deployed in Azure Machine Learning by DevOps pipeline, see the ADA_ADO folder for deployment scripts, which contain the data input references.
Manual deployments via Notebook are also possible. <br>
<br>
Pipeline data inputs are as follows:<br>
-	<b>PCS Tags:</b> Input is the Parquet file of consolidated and normalized Json PCS Tag data files, which is the output of the Daily Data Load pipeline. This greatly reduces the pipeline run time compared to access the Json files directly due to the size of the PCS Tag dataset<br>
-	<b>Alarms:</b> As above, Input is the Parquet file of consolidated and normalized Json Alarms data files<br>
-	<b>Train Schedule:</b> Accessed directly from the Landed Data Storage container<br>
-	<b>Fixed Plant Time Usage:</b> Accessed directly from the Landed Data Storage container<br>

The date range arguments take the format ‘yyyy-mm-dd’. To allow for dynamic pipelines, the preferred approach is for the following arguments take the value ‘default’ as follows:<br>
-	Period_end = ‘default’: Current date minus 1<br>
-	training_end = ‘default’: Current date minus 8<br>
-	test_start = ‘default’: Current date minus 7<br>
-	test_end = ‘default’: Current date minus 1<br>
<br>

##<b>Inference Code</b><br>

<b>uc1_model.py:</b> Unifying function which pulls together all component parts of the solution to produce the required output. This file contains 2 separate functions:<br>
-	uc1_tlo_model_inference: Produces the output for a single timestamp, designed to be used for Production inference<br>
-	uc1_tlo_model_backtest: Produces the output for a range of timestamps, to be used in development for testing, optimizing and debugging<br>

<b>uc1_inference_pipeline.py:</b> Python script step for the UC1 Inference pipeline, which runs the uc1_tlo_model_inference function at 3-minute intervals<br>
<br>

##<b>Common Libraries</b><br>

- <b>uc1_delay.py:</b> Library of Delay Identification<br> and Classification functions, and functions to attribute the Delay duration (used in uc1_model and uc1_pipeline_test)<br>
- <b>uc1_tlo_forecast.py:</b> Logic for calculation of the TLO forecast timings (used in uc1_model and uc1_pipeline_test)<br>
- <b>uc1_data_preparation.py:</b> Common data pre-processing steps (used in uc1_model, uc1_pipeline_train and uc1_pipeline_test)<br>
- <b>uc1_utils.py:</b> Utility functions used by multiple use case Python files<br>
<br><br>


##<b>Reference Files</b><br>

- <b>UC1_Tags.txt:</b> Full list of all tags used in UC1, for filtering of the PCS Tags data load<br>
- <b>UC1_Alarms.txt:</b> Full list of Alarms relevant for UC1, for filtering of the Alarms data load<br>

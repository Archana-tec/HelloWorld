import os
# from pyspark.sql import SparkSession
from azureml.core import Run
import datetime
import pandas as pd
import numpy as np
import shutil
import argparse

import ADA_UC1_TLO.uc1_utils as uc1
import ADA_UC1_TLO.uc1_data_preparation as uc1_data_preparation
import ADA_UC1_TLO.uc1_delay as uc1_delay
import ADA_UC1_TLO.uc1_tlo_forecast as uc1_tlo_forecast

# os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

parser = argparse.ArgumentParser()
parser.add_argument("--input_dataset_dir")
parser.add_argument("--model_folder")
parser.add_argument("--output_folder")
parser.add_argument("--test_start")
parser.add_argument("--test_end")
parser.add_argument("--env")
args = parser.parse_args()
input_dataset_dir = args.input_dataset_dir
model_folder = args.model_folder
output_folder = args.output_folder
env = args.env

run = Run.get_context()

print(f"[{datetime.datetime.now()}] Start UC1 Pipeline Test Script ....")
print(f"[{datetime.datetime.now()}] args.test_start = {args.test_start}")
print(f"[{datetime.datetime.now()}] args.test_end = {args.test_end}")
if args.test_start == 'default':
    dt_now = datetime.datetime.now()
    test_start_utc = (dt_now - datetime.timedelta(minutes=dt_now.minute, seconds=dt_now.second,
                                                  microseconds=dt_now.microsecond)) - datetime.timedelta(days=7)
    test_start_utc_string = datetime.datetime.strftime(test_start_utc, '%Y-%m-%d')
else:
    test_start_utc = datetime.datetime.strptime(args.test_start, '%Y-%m-%d')
    test_start_utc_string = args.test_start

if args.test_end == 'default':
    dt_now = datetime.datetime.now()
    test_end_utc = (dt_now - datetime.timedelta(minutes=dt_now.minute, seconds=dt_now.second,
                                                microseconds=dt_now.microsecond)) - datetime.timedelta(days=1)
    test_end_utc_string = datetime.datetime.strftime(test_end_utc, '%Y-%m-%d')
else:
    test_end_utc = datetime.datetime.strptime(args.test_end, '%Y-%m-%d')
    test_end_utc_string = args.test_end

print(f"[{datetime.datetime.now()}] test_start_utc = {test_start_utc}")
print(f"[{datetime.datetime.now()}] test_end_utc = {test_end_utc}")
print(f"[{datetime.datetime.now()}] test_start_utc_string = {test_start_utc_string}")
print(f"[{datetime.datetime.now()}] test_end_utc_string = {test_end_utc_string}")

# Copy trained components from model folder into Source Directory
print(f"[{datetime.datetime.now()}] Copying train components ..")
shutil.copytree(model_folder + '/UC1_trained_components', 'UC1_trained_components', dirs_exist_ok=True)

# Start Spark Session
# spark = SparkSession.builder \
#     .appName('app_name') \
#     .master('local[*]') \
#     .config('spark.sql.execution.arrow.pyspark.enabled', True) \
#     .config('spark.sql.session.timeZone', 'UTC') \
#     .config('spark.driver.memory', '32G') \
#     .config('spark.ui.showConsoleProgress', True) \
#     .config('spark.sql.repl.eagerEval.enabled', True) \
#     .config('spark.driver.maxResultSize', '0') \
#     .getOrCreate()

# TRAIN SCHEDULE #
print(f"[{datetime.datetime.now()}] Reading train schedule parquet data ..")
df_trainsched = pd.read_parquet(input_dataset_dir + '/train_schedule/')
# print(f"[{datetime.datetime.now()}] train schedule to Pandas DF ..")
# df_trainsched = trainsched_sdf.toPandas()

# PCS TAGS #
print(f"[{datetime.datetime.now()}] Reading tags parquet data ..")
df_tags = pd.read_parquet(input_dataset_dir + '/PCS_tags/')
# print(f"[{datetime.datetime.now()}] tags to Pandas DF ..")
# df_tags = sdf_tags.toPandas()

# ALARMS #
print(f"[{datetime.datetime.now()}] Reading rms parquet data ..")
df_alarms = pd.read_parquet(input_dataset_dir + '/alarms/')
# print(f"[{datetime.datetime.now()}] rms to Pandas DF ..")
# df_alarms = sdf_alarms.toPandas()

print(f"[{datetime.datetime.now()}] Start uc1_data_preparation.data_preprocessing ..")
df_trainsched, df_tags, df_alarms, df_car_weights = uc1_data_preparation.data_preprocessing(df_trainsched, df_tags,
                                                                                            df_alarms)

## BEGIN MODEL PREDICTION ##

delay_duration_method = 'GD-only'
identify_delay_method = 'ml'
tlo_stage_timing_method = 'GD-historical'

# SET DATETIME RANGE FOR OUTPUT #
dt_start = test_start_utc
dt_end = test_end_utc
delta = dt_end - dt_start
delta_mins = delta.total_seconds() / 60
num_periods = delta_mins / 3 + 1  # Number of 5 minute periods
dt_start_awst = dt_start + datetime.timedelta(hours=8)  # Convert UTC timestamp dt to AWST
datetime_range = pd.date_range(dt_start_awst, periods=num_periods, freq='3T')  # 3 minute intervals across date range

output_col = ['train_id', 'train_status', 'product', 'num_cars', 'cars_remaining',
              'arrival_sched', 'arrival_actual', 'comm_loading_sched', 'comm_loading_forecast',
              'comm_loading_actual', 'comp_loading_sched', 'comp_loading_forecast', 'comp_loading_actual',
              'depart_sched', 'depart_forecast', 'depart_actual', 'train1_comm_loading_delay_model',
              'train1_loading_delay_model', 'train1_departure_delay_model', 'comp_loading_forecast_q1',
              'comp_loading_forecast_q3', 'train1_delay_duration_q1', 'train1_delay_duration_q3',
              'delay_event_in_progress', 'delay_event_type', 'delay_event_cause', 'delay_event_asset',
              'delay_event_start']

# LOOP THROUGH DATETIME RANGE TO PRODUCE OUTPUT #
df_combined = pd.DataFrame()
# Set delay duration method
print(f"[{datetime.datetime.now()}] Set delay duration method ...")
df_delaydur = uc1_delay.delay_duration(delay_duration_method, env)

print(f"[{datetime.datetime.now()}] Loop through datetime range  ..")
for ts in datetime_range:
    print(f"[{datetime.datetime.now()}] - ts = {ts}  ..")
    # For first timestamp in range, create empty dataframe
    if ts == datetime_range[0]:
        df_output = pd.DataFrame(columns=output_col)

    # For all other timestamps, retrieve the final dataframe from the previous timestamp
    else:
        df_output = df

    # Fill in Train Schedule data for the next 5 trains at timestamp ts
    print(f"[{datetime.datetime.now()}] - Fill in Train Schedule data for the next 5 trains at timestamp {ts}  ...")
    df = uc1_data_preparation.next_5trains_output_df(ts, df_trainsched, df_tags)

    # Identify Delay events and forecast delay timings for the current ts
    print(f"[{datetime.datetime.now()}] - Identify Delay events and forecast delay timings for the current {ts} ...")
    df = uc1_delay.identify_delay(ts, df, df_tags, df_alarms, df_car_weights, df_output, df_delaydur,
                                  identify_delay_method)

    # Calculate TLO forecast timings for each stage
    print(f"[{datetime.datetime.now()}] - Calculate TLO forecast timings ...")
    df = uc1_tlo_forecast.calc_forecast_timings(df, ts, tlo_stage_timing_method)

    # Re-order and keep only required columns
    df = df[output_col]

    df_combined = pd.concat([df_combined, df])

# Format Data Type for final output
print(f"[{datetime.datetime.now()}] Format Data Type for final output ...")
df_combined['train1_comm_loading_delay_model'] = df_combined['train1_comm_loading_delay_model'].apply(
    lambda x: x.total_seconds() / 60).round(1).fillna(0)
df_combined['train1_loading_delay_model'] = df_combined['train1_loading_delay_model'].apply(
    lambda x: x.total_seconds() / 60).round(
    1).fillna(0)
df_combined['train1_departure_delay_model'] = df_combined['train1_departure_delay_model'].apply(
    lambda x: x.total_seconds() / 60).round(1).fillna(0)
df_combined['train1_delay_duration_q1'] = df_combined['train1_delay_duration_q1'].apply(
    lambda x: x.total_seconds() / 60).round(
    1).fillna(0)
df_combined['train1_delay_duration_q3'] = df_combined['train1_delay_duration_q3'].apply(
    lambda x: x.total_seconds() / 60).round(
    1).fillna(0)
df_combined['comm_loading_forecast'] = df_combined['comm_loading_forecast'].apply(
    lambda x: x.strftime("%Y-%m-%d %H:%M:%S"))
df_combined['comp_loading_forecast'] = df_combined['comp_loading_forecast'].apply(
    lambda x: x.strftime("%Y-%m-%d %H:%M:%S"))
df_combined['depart_forecast'] = df_combined['depart_forecast'].apply(lambda x: x.strftime("%Y-%m-%d %H:%M:%S"))
df_combined['comp_loading_forecast_q1'] = df_combined['comp_loading_forecast_q1'].apply(
    lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)
df_combined['comp_loading_forecast_q3'] = df_combined['comp_loading_forecast_q3'].apply(
    lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)

# Save outputs
print(f"[{datetime.datetime.now()}] Saving outputs ...")
os.makedirs(output_folder, exist_ok=True)
df_combined.to_csv(output_folder + '/uc1_output_' + test_start_utc_string + '_to_' + test_end_utc_string + '.csv')


## ACCURACY TEST ##

def accuracy_calc(model_output, df_trainsched):
    print(f"[{datetime.datetime.now()}] accuracy_calc - starts ...")
    # Create a subset dataframe removing those which have a status of 'Expected', as trains which haven't arrived are outside our scope for measuring accuracy
    df2 = model_output.loc[model_output.train_status != 'Expected'].reset_index().copy()

    df2 = df2[['datetime', 'train_id', 'num_cars', 'train_status', 'arrival_sched', 'arrival_actual',
               'comm_loading_sched', 'comm_loading_actual', 'comm_loading_forecast',
               'comp_loading_sched', 'comp_loading_actual', 'comp_loading_forecast',
               'depart_sched', 'depart_actual', 'depart_forecast', 'delay_event_in_progress']]

    # Bring Train ID into the index as acccuarcy will be calculated at the Train ID level
    print(
        f"[{datetime.datetime.now()}] accuracy_calc - Bring Train ID into the index as acccuarcy will be calculated at the Train ID level ...")
    df2 = df2.reset_index(drop=False)
    df2 = df2.set_index(['datetime', 'train_id'], drop=True)

    # Drop rows with no forecast (small subset due to missing schedule)
    print(f"[{datetime.datetime.now()}] accuracy_calc - Drop rows with no forecast ...")
    df2 = df2.dropna(subset=['comm_loading_forecast'], axis=0)
    df2 = df2.dropna(subset=['comp_loading_forecast'], axis=0)
    df2 = df2.dropna(subset=['depart_forecast'], axis=0)

    # Fill NAs with very early date so they don't get picked up by the max function
    datetime_cols = ['arrival_sched', 'arrival_actual',
                     'comm_loading_sched', 'comm_loading_forecast', 'comm_loading_actual',
                     'comp_loading_sched', 'comp_loading_forecast', 'comp_loading_actual',
                     'depart_sched', 'depart_forecast', 'depart_actual']
    for i in datetime_cols:
        df2[i] = pd.to_datetime(df2[i].fillna(datetime.datetime(1999, 1, 1)))

    # Add the actual commence loading, complete loading and departure times to all rows for each unique train
    train_ids = df2.index.get_level_values(1).unique()
    # Get Actual Departure Time from Train Schedule (Train departure times mostly get updates in train schedule with a long time lag)
    departs = df_trainsched.groupby('TRAIN_ID').agg({'TD_ACT_DEPMINE': 'max'})

    idx = pd.IndexSlice
    for train_id in train_ids:
        df2.loc[idx[:, train_id], 'final_comm_loading_actual'] = df2.loc[idx[:, train_id], 'comm_loading_actual'].max()
        df2.loc[idx[:, train_id], 'final_comp_loading_actual'] = df2.loc[idx[:, train_id], 'comp_loading_actual'].max()
        df2.loc[idx[:, train_id], 'final_depart_actual'] = departs.loc[train_id, 'TD_ACT_DEPMINE']

    # Caluclate absolute error at each timestamp
    print(f"[{datetime.datetime.now()}] accuracy_calc - Caluclate absolute error at each timestamp ...")
    df2['abs_error_comm_loading'] = (df2['final_comm_loading_actual'] - df2['comm_loading_forecast']).abs()
    df2['abs_error_comp_loading'] = (df2['final_comp_loading_actual'] - df2['comp_loading_forecast']).abs()
    df2['abs_error_departure'] = (df2['final_depart_actual'] - df2['depart_forecast']).abs()

    df2['error_comm_loading'] = (df2['final_comm_loading_actual'] - df2['comm_loading_forecast']) / np.timedelta64(1,
                                                                                                                   'm')
    df2['error_comp_loading'] = (df2['final_comp_loading_actual'] - df2['comp_loading_forecast']) / np.timedelta64(1,
                                                                                                                   'm')
    df2['error_departure'] = (df2['final_depart_actual'] - df2['depart_forecast']) / np.timedelta64(1, 'm')

    # Split into stages
    accuracy_table = df2.reset_index(drop=False)

    # Commence Loading Accuracy
    print(f"[{datetime.datetime.now()}] accuracy_calc - Commence Loading Accuracy ...")
    commloading_acc = accuracy_table[accuracy_table.train_status.isin(['Arrived', 'Pre-Loading'])]
    # Remove trains that never commenced loading during our test period
    print(
        f"[{datetime.datetime.now()}] accuracy_calc - Remove trains that never commenced loading during our test period ...")
    commloading_acc = commloading_acc[commloading_acc.final_comm_loading_actual != datetime.datetime(1999, 1, 1)]

    # Complete Loading Accuracy
    print(f"[{datetime.datetime.now()}] accuracy_calc - Complete Loading Accuracy ...")
    comploading_acc = accuracy_table[accuracy_table.train_status.isin(['Loading', 'Clearing'])]
    # Remove trains that never completed loading during our test period
    print(
        f"[{datetime.datetime.now()}] accuracy_calc - Remove trains that never completed loading during our test period ...")
    comploading_acc = comploading_acc[comploading_acc.final_comp_loading_actual != datetime.datetime(1999, 1, 1)]

    # Departure Time Accuracy
    print(f"[{datetime.datetime.now()}] accuracy_calc - Departure Time Accuracy ...")
    departure_acc = accuracy_table[accuracy_table.train_status.isin(['Loaded', 'Ready for Departure'])]
    # Remove trains that never departed during our test period
    print(f"[{datetime.datetime.now()}] accuracy_calc - Remove trains that never departed during our test period ...")
    departure_acc = departure_acc[departure_acc.final_depart_actual != datetime.datetime(1999, 1, 1)]

    # Remove time before DT identified
    print(f"[{datetime.datetime.now()}] accuracy_calc - Remove time before DT identified ...")
    for train_id in train_ids:
        if commloading_acc[(commloading_acc.train_id == train_id) & (commloading_acc.delay_event_in_progress == 'Y')][
            'delay_event_in_progress'].count() > 0:
            delay_start = commloading_acc[
                (commloading_acc.train_id == train_id) & (commloading_acc.delay_event_in_progress == 'Y')].index.min()
            commloading_acc = commloading_acc.drop(commloading_acc[(commloading_acc['train_id'] == train_id) & (
                    commloading_acc.index < delay_start)].index)

        if comploading_acc[(comploading_acc.train_id == train_id) & (comploading_acc.delay_event_in_progress == 'Y')][
            'delay_event_in_progress'].count() > 0:
            delay_start = comploading_acc[
                (comploading_acc.train_id == train_id) & (comploading_acc.delay_event_in_progress == 'Y')].index.min()
            comploading_acc = comploading_acc.drop(comploading_acc[(comploading_acc['train_id'] == train_id) & (
                    comploading_acc.index < delay_start)].index)

        if departure_acc[(departure_acc.train_id == train_id) & (departure_acc.delay_event_in_progress == 'Y')][
            'delay_event_in_progress'].count() > 0:
            delay_start = departure_acc[
                (departure_acc.train_id == train_id) & (departure_acc.delay_event_in_progress == 'Y')].index.min()
            departure_acc = departure_acc.drop(
                departure_acc[(departure_acc['train_id'] == train_id) & (departure_acc.index < delay_start)].index)

            # Convert abs error to minutes
    print(f"[{datetime.datetime.now()}] accuracy_calc - Convert abs error to minutes ...")
    departure_acc['abs_error_departure_mins'] = departure_acc['abs_error_departure'].apply(
        lambda x: x.total_seconds() / 60)
    comploading_acc['abs_error_comp_loading_mins'] = comploading_acc['abs_error_comp_loading'].apply(
        lambda x: x.total_seconds() / 60)
    commloading_acc['abs_error_comm_loading_mins'] = commloading_acc['abs_error_comm_loading'].apply(
        lambda x: x.total_seconds() / 60)
    # Find abs MAE by train
    print(f"[{datetime.datetime.now()}] accuracy_calc - Find abs MAE by train ...")
    depart_MAE_bytrain = departure_acc.groupby('train_id')['abs_error_departure_mins'].median().reset_index()
    comp_MAE_bytrain = comploading_acc.groupby('train_id')['abs_error_comp_loading_mins'].median().reset_index()
    comm_MAE_bytrain = commloading_acc.groupby('train_id')['abs_error_comm_loading_mins'].median().reset_index()
    MAE_departure_pertrain = depart_MAE_bytrain['abs_error_departure_mins'].median()
    MAE_comploading_pertrain = comp_MAE_bytrain['abs_error_comp_loading_mins'].median()
    MAE_commloading_pertrain = comm_MAE_bytrain['abs_error_comm_loading_mins'].median()

    ### Calculate median absolute error

    MAE_commloading = commloading_acc['abs_error_comm_loading'].median()
    MAE_commloading = np.round(MAE_commloading.total_seconds() / 60.0, 2)
    print('------')
    print('Comm Loading Median Average Error (mins): ' + str(MAE_commloading))
    print('Comm Loading Median Average Error Train Level (mins): ' + str(MAE_commloading_pertrain))
    print('Number of trains in Comm Loading accuracy calc: ' + str(commloading_acc.train_id.nunique()))
    print('Number of forecasts in Comm Loading accuracy calc: ' + str(len(commloading_acc)))
    print('------')

    MAE_comploading = comploading_acc['abs_error_comp_loading'].median()
    MAE_comploading = np.round(MAE_comploading.total_seconds() / 60.0, 2)
    print('------')
    print('Comp Loading Median Average Error (mins): ' + str(MAE_comploading))
    print('Comp Loading Median Average Error Train Level (mins): ' + str(MAE_comploading_pertrain))
    print('Number of trains in Comp Loading accuracy calc: ' + str(comploading_acc.train_id.nunique()))
    print('Number of forecasts in Comp Loading accuracy calc: ' + str(len(comploading_acc)))
    print('------')

    MAE_departure = departure_acc['abs_error_departure'].median()
    MAE_departure = np.round(MAE_departure.total_seconds() / 60.0, 2)
    print('------')
    print('Departure Median Average Error (mins): ' + str(MAE_departure))
    print('Departure Median Average Error Train Level (mins): ' + str(MAE_departure_pertrain))
    print('Number of trains in Departure accuracy calc: ' + str(departure_acc.train_id.nunique()))
    print('Number of forecasts in Departure accuracy calc: ' + str(len(departure_acc)))
    print('------')
    print(f"[{datetime.datetime.now()}] accuracy_calc - ends ...")
    return MAE_commloading, MAE_comploading, MAE_departure, commloading_acc, comploading_acc, departure_acc, MAE_commloading_pertrain, MAE_comploading_pertrain, MAE_departure_pertrain


print(f"[{datetime.datetime.now()}] Accuracy calculation starts ...")
MAE_commloading, MAE_comploading, MAE_departure, commloading_acc, comploading_acc, departure_acc, MAE_commloading_pertrain, MAE_comploading_pertrain, MAE_departure_pertrain = accuracy_calc(
    df_combined, df_trainsched)
print(f"[{datetime.datetime.now()}] Accuracy calculation ends ...")
# Log accuracy score
run.log('Commence Loading MAE (mins)', float(MAE_commloading))
run.log('Loading MAE (mins)', float(MAE_comploading))
run.log('Departure MAE (mins)', float(MAE_departure))

# Log accuracy score (Train Level)
run.log('Commence Loading MAE Train Level (mins)', float(MAE_commloading_pertrain))
run.log('Loading MAE Train Level (mins)', float(MAE_comploading_pertrain))
run.log('Departure MAE Train Level (mins)', float(MAE_departure_pertrain))

# Log number of trains for reference and error analysis
run.log('Commence Loading MAE # Trains', float(commloading_acc.train_id.nunique()))
run.log('Loading MAE # Trains', float(comploading_acc.train_id.nunique()))
run.log('Departure MAE # Trains', float(departure_acc.train_id.nunique()))

print(f"[{datetime.datetime.now()}] Output accuracy calc tables for error analysis ...")
# Output accuracy calc tables for error analysis
commloading_acc.to_csv(
    output_folder + '/commloading_acc_' + test_start_utc_string + '_to_' + test_end_utc_string + '.csv')
comploading_acc.to_csv(
    output_folder + '/comploading_acc_' + test_start_utc_string + '_to_' + test_end_utc_string + '.csv')
departure_acc.to_csv(output_folder + '/departure_acc_' + test_start_utc_string + '_to_' + test_end_utc_string + '.csv')
print(f"[{datetime.datetime.now()}] DONE ....")
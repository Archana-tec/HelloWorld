# -*- coding: utf-8 -*-
"""
Created on 20/06/2022

@author: Ruoyu.Zhao
"""
import pandas as pd
import numpy as np
import pytz
from datetime import date, datetime, timedelta
import configparser
import os
# azureml-core of version 1.0.72 or higher is required
from azureml.core import Workspace, Dataset
from azureml.core.authentication import ServicePrincipalAuthentication

# Get Config Locations and Paths
cfg_path = os.path.join(os.path.dirname(__file__), 'config-gd.ini')
cfg_path = cfg_path.replace('ADA_UC1_TLO/','config/')
config_obj = configparser.ConfigParser()
config_obj.read(cfg_path)

def get_workspace(env='dev'): 

    # Get credentials information of environment
    cred_info = config_obj['credentials'+'_'+env]
    subscription_id = cred_info['subscription_id']
    resource_group = cred_info['resource_group']
    workspace_name = cred_info['workspace_name']
    if env == 'dev':
        # Define Workspace
        workspace = Workspace(subscription_id, resource_group, workspace_name) 
    else:
        # Get Service Principle Credentials from environment variable
        try: # try to autenticate to the workspace using service principals (uat and prd aks)
            sp = ServicePrincipalAuthentication(tenant_id=os.environ.get('adasprdtenantid'),
                                                service_principal_id=os.environ.get('adaspprdclientid'),
                                                service_principal_password=os.environ.get('adaspprdclientsecret'))          

            
            workspace = Workspace.get( name=workspace_name,
                                            auth=sp,
                                            subscription_id=subscription_id,
                                            resource_group=resource_group)
        except: # for uat training pipeline
            workspace = Workspace(subscription_id, resource_group, workspace_name)

    return workspace

def round_to_next_min(ts):
    if (ts.second == 0) & (ts.microsecond == 0):
        ts = ts
    else:
        ts = ts + timedelta(minutes=1) - timedelta(seconds=ts.second,microseconds=ts.microsecond)
    return ts

def find_tag_lag_value(df_tags,tag_name,current_ts,lag_min,default_value=0,value_or_ts = 'value'):
    # find timestamp lag by lag_min
    lag_ts = pd.to_datetime(current_ts-timedelta(minutes=lag_min))
    if value_or_ts == 'value':
        try:
            # find the tag value at lag_ts
            lag_value = df_tags[(df_tags['tagid']==tag_name)&(df_tags['time']<=lag_ts)&(df_tags['next_time']>lag_ts)]['value'].values[0]
            
        except:
            # if the lag value is empty then default value
            lag_value = default_value
    else: 
        try:
            # find the tag last changed timestamp at lag_ts
            lag_value = pd.to_datetime(df_tags[(df_tags['tagid']==tag_name)&(df_tags['time']<=lag_ts)&(df_tags['next_time']>lag_ts)]['time'].values[0])
            
        except:
            # if the lag value is empty then default value
            lag_value = default_value    
                
    return lag_value

# Convert utc timestamp into Local( Default = AWST Perth) timestamp   
def convert_utc_to_local(data,tz='Australia/Perth'):
    time_zone = pytz.timezone(tz)
    offset = time_zone.utcoffset(datetime.now())
    return data + offset

def calc_unloaded_train(train_load_ind,loco_start_ts,tag_load_commence_ts):
    if (train_load_ind == 0) & (loco_start_ts + timedelta(minutes=15) >= tag_load_commence_ts):
        unloaded_train = 1
    # if train loading is 0, and the datetime when the loco was linked to DLC happens before when train loading stops, this indicates that the current train had been loaded
    elif (train_load_ind ==0) & (loco_start_ts +  timedelta(minutes=15) < tag_load_commence_ts):
        unloaded_train = 0
    else: # Loading Train
        unloaded_train = 0

    return unloaded_train

def train_status_logic(current_dt,ts_train_status,ts_total_cars,actual_arrival,train_DLC_linked,train_load_ind,train_loadfinish_ind,train_clearing_ind,cars_loaded,trainsched_loco_id,loco_in_tlo,tag_loco_id,tag_load_complete_ts,tag_load_commence_ts,tag_departure_ts,tag_load_commence_clearing_ts,tag_load_commence_loaded_ts,tag_load_complete_depart_ts,tag_load_commence_depart_ts,unloaded_train,train_present_ind):
    
    actual_load_commence_ts = np.NaN
    actual_load_complete_ts = np.NaN
    actual_departure_ts = np.NaN

    # Logic for deriving train status
    if ts_train_status == 'Expected': # if the train status from Trainschedule is Expected
        train_status = 'Expected' 
    elif ts_train_status == 'Departed': # If the train status from Trainschedule is Departed
        train_status = 'Departed' 
    elif  tag_loco_id == trainsched_loco_id: # the loco id from tag matches with train schedule
        if (train_load_ind == 1) & (train_DLC_linked == 1) & (loco_in_tlo == 1): # Train is loading (train needs to be linked to dlc and the loco must be in tlo circuit)
            train_status = 'Loading'  
        elif (unloaded_train==0)&(train_DLC_linked == 1) & (cars_loaded > 0) & (cars_loaded < ts_total_cars) & (loco_in_tlo == 1): # Train is loading (train needs to be linked to dlc and the loco must be in tlo circuit and cars loaded is between 0 and total cars)
            train_status = 'Loading'
        elif train_clearing_ind == 1: # Train needs to be cleared before complete loading
            train_status = 'Clearing' 
        elif train_loadfinish_ind == 1: # Train load complete
            train_status = 'Loaded'
        elif train_present_ind ==1: # Train is presented (between arrival and loading)
            train_status = 'Pre-Loading'        
        elif (ts_train_status == 'Arrived') & ((train_DLC_linked == 1)|(loco_in_tlo == 1)) & (cars_loaded == 0) & (unloaded_train == 1): # Arrived & (Linked to DLC or train in tlo circuit) & (cars loaded is 0) & (train was never loaded)
            train_status = 'Pre-Loading'
        elif ((train_DLC_linked == 0) |(loco_in_tlo == 0)) & (cars_loaded == ts_total_cars) & (actual_arrival <= tag_load_complete_ts) \
        & (unloaded_train == 0) & (actual_arrival + timedelta(hours = 3) < current_dt): # Train is not linked and in tlo circuit, all cars have been loaded, actual arrival is before car loaded timestamp, train is loaded and current dt is at least 3 hours after actual arrival
            train_status = 'Ready for Departure'
        else: 
            train_status = ts_train_status
    # Approximate to Train Departed
    elif (train_DLC_linked == 0) & (cars_loaded == ts_total_cars) & (tag_loco_id == 0) & (actual_arrival + timedelta(hours = 3) < current_dt)& (actual_arrival <= tag_load_commence_depart_ts):
        # Train not linked to DLC, all cars are loaded, Loco ID from Tag is 0 and current dt is at least 3 hours after the train has arrived and the train is loaded after arrival. 
        train_status = 'Departed'         
    elif  (train_DLC_linked == 1) & (tag_loco_id != trainsched_loco_id) & (actual_arrival + timedelta(hours = 3) < current_dt):
        # A Train is linked to DLC, however the tag loco id doesn't match the loco id from train schedule (DLC moved to the next train) and current dt is at least 3 hours after the train has arrived.
        train_status = 'Departed'        
    else: 
        train_status = ts_train_status

    # Get actual timestamps from tag data
    if train_status not in ['Arrived','Expected']:
        if train_status == 'Loading':
            if train_load_ind == 1:
                actual_load_commence_ts = tag_load_commence_ts
            else:
                actual_load_commence_ts = tag_load_commence_clearing_ts
        elif train_status == 'Clearing':
            actual_load_commence_ts = tag_load_commence_clearing_ts
        elif train_status == 'Loaded':
            actual_load_complete_ts = tag_load_complete_ts
            actual_load_commence_ts = tag_load_commence_loaded_ts
        elif train_status in ['Ready for Departure','Departed']:
            actual_load_complete_ts = tag_load_complete_depart_ts
            actual_load_commence_ts = tag_load_commence_depart_ts
    if train_status ==  'Departed': 
        actual_departure_ts = tag_departure_ts # This is a rough estimate of when the train departs

    return train_status,ts_total_cars,pd.to_datetime(actual_arrival),pd.to_datetime(actual_load_commence_ts),pd.to_datetime(actual_load_complete_ts),pd.to_datetime(actual_departure_ts)



def determine_train_status(df_tags,df,current_dt):

    tag_load_complete_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLD_S',current_dt,0,current_dt,'timestamp')
    tag_load_commence_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLOADING_S',current_dt,0,current_dt,'timestamp') 
    tag_departure_ts =  find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_LNKDTRNID_S',current_dt,0,current_dt,'timestamp')
    # When train is currently in clearing: assume 2 hours from current_dt the train must be loading.
    tag_load_commence_clearing_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLOADING_S',current_dt - timedelta(hours=2),0,current_dt,'timestamp')
    # When train is loaded: assume 2 hours from current_dt the train must be loading.
    tag_load_commence_loaded_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLOADING_S',tag_load_complete_ts - timedelta(hours=2),0,current_dt,'timestamp')
    # When train is "Ready for Departure" or "Departed": 
    # # when train completes load, train loaded tag would be 0, we want to find the train load = 1 timestamp before it is 0. 
    tag_load_complete_depart_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLD_S',tag_load_complete_ts - timedelta(minutes=1),0,current_dt,'timestamp')
    # # Once we find the timestamp for train load complete, assume 2 hours before train load complete, the train would be loading.
    tag_load_commence_depart_ts = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLOADING_S',tag_load_complete_depart_ts - timedelta(hours=2),0,current_dt,'timestamp')

    ts_train_status = df.loc[(current_dt,'Train 1'),'train_status']
    ts_total_cars = df.loc[(current_dt,'Train 1'),'num_cars']
    actual_arrival = df.loc[(current_dt,'Train 1'),'arrival_actual']
    trainsched_loco_id = df.loc[(current_dt,'Train 1'),'First_Loco_ID']   
    train_DLC_linked = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_LNK_S',current_dt,0)
    train_load_ind = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLOADING_S',current_dt,0) 
    train_loadfinish_ind = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLD_S',current_dt,0)  
    train_clearing_ind = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNCLEARING_S',current_dt,0) 
    train_present_ind =  find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNPRESENTED_S',current_dt,0)  
    # train_new_ind = find_tag_lag_value(df_tags,'KD1.PPCS. KD1.PPCS.TL0601_NEWTRAIN',current_dt,0)
    cars_loaded = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,0) 
    loco_in_tlo = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_LOCOIN_S',current_dt,0) 
    tag_loco_id = find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_LNKDTRNID_S',current_dt,0) 
    # Identify when the current loco id was first linked to DLC
    loco_start_ts = tag_departure_ts #find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_LNKDTRNID_S',current_dt,0,current_dt,'timestamp')

    ## Used to differentiate between Ready for Departure/Loaded and Arrival/Pre-Loading ##
    unloaded_train = calc_unloaded_train(train_load_ind,loco_start_ts,tag_load_commence_ts)

    return train_status_logic(current_dt,ts_train_status,ts_total_cars,actual_arrival,train_DLC_linked,train_load_ind,train_loadfinish_ind,train_clearing_ind,cars_loaded,trainsched_loco_id,loco_in_tlo,tag_loco_id,tag_load_complete_ts,tag_load_commence_ts,tag_departure_ts,tag_load_commence_clearing_ts,tag_load_commence_loaded_ts,tag_load_complete_depart_ts,tag_load_commence_depart_ts,unloaded_train,train_present_ind)
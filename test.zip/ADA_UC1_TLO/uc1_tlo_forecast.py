import pandas as pd
import datetime
import pickle
import os

def forecast_parameters(method='fixed'):
    """
    Inputs: 
       method: Method to determine TLO stage timing parameters
            fixed: Fixed timings used
            GD-empirical: Empirically calculated based on historical GD data

    Outputs: Timings of each stage in the TLO process, which are used as forecast parameters
        median_train_gap, median_arrival_to_loading_notrain, median_loading_nodelay, median_loadcomplete_to_departure
    """  
    if method == 'fixed':
        median_train_gap = datetime.timedelta(minutes=24)                                            # For trains that are back-to-back, median time between train 1 departing and train 2 starting loading
        median_arrival_to_loading_notrain = datetime.timedelta(minutes=33)                           # For trains that arrive with no train in front, median time to bein loading
        median_loading_nodelay = datetime.timedelta(hours=3,minutes=0)                               # Median train load time where the is no delay
        median_loadcomplete_to_departure = datetime.timedelta(minutes=23)                            # Median time between completing loading and train departing (across all trains)
    
    elif method == 'GD-historical':
        current_file_path = os.path.join(os.path.dirname(__file__), 'tlo_stage_timings.pkl')
        file_path = current_file_path.replace('ADA_UC1_TLO/','UC1_trained_components/')
        
        with open(file_path, 'rb') as f:
            timings_dict = pickle.load(f)
        
        median_train_gap = datetime.timedelta(minutes=timings_dict['median_train_gap'])                                          # For trains that are back-to-back, median time between train 1 departing and train 2 starting loading
        median_arrival_to_loading_notrain = datetime.timedelta(minutes=timings_dict['median_arrival_to_loading_notrain'])        # For trains that arrive with no train in front, median time to bein loading
        median_loading_nodelay = datetime.timedelta(minutes=timings_dict['median_loading_nodelay'])                              # Median train load time where the is no delay
        median_loadcomplete_to_departure = datetime.timedelta(minutes=timings_dict['median_loadcomplete_to_departure'])          # Median time between completing loading and train departing (across all trains)
      
    return  median_train_gap, median_arrival_to_loading_notrain, median_loading_nodelay, median_loadcomplete_to_departure
            


def calc_forecast_timings(df, d, tlo_stage_timing_method='fixed'):
    """
    Inputs: 
        df: Output dataframe with next 5 train schedule details
        d: Datetime of prediction
        tlo_stage_timing_method: Method to determine stage time parameters

    Outputs: 
        Output dataframe with forecast Commence Loading, Complete Loading and Departure times
        calculated for next 5 trains
    """

    # Set model stage timing parameters
    median_train_gap, median_arrival_to_loading_notrain, median_loading_nodelay, median_loadcomplete_to_departure = forecast_parameters(tlo_stage_timing_method)

    idx = pd.IndexSlice

    # Get Delay Start Timestamp
    delay_event_start = df.loc[(d,'Train 1'),'delay_event_start']  
    # Train 1 Commence Load Forecast:
    current_train_arrival = df.loc[(d,'Train 1'),'arrival_actual']
    # Empty Delay Duration 
    no_delay = datetime.timedelta(minutes=0) 

    # If train hasn't arrived, commence loading forecast = scheduled arrival + median_arrival_to_loading_notrain
    if pd.isnull(current_train_arrival):
        df.loc[(d,'Train 1'),'comm_loading_forecast'] =  df.loc[(d,'Train 1'),'arrival_sched'] + median_arrival_to_loading_notrain

    ## CALCULATE TRAIN COMMENCE LOADING ##

    # If train has arrived:
    else:
    # If train has started loading, take actual time
        if not pd.isnull(df.loc[(d,'Train 1'),'comm_loading_actual']):
            df.loc[(d,'Train 1'),'comm_loading_forecast'] = df.loc[(d,'Train 1'),'comm_loading_actual']
        
        # If train hasn't started loading:
        elif df.loc[(d,'Train 1'),'train1_comm_loading_delay_model'] == no_delay: # if there is no delay
            df.loc[(d,'Train 1'),'comm_loading_forecast'] = max(current_train_arrival + median_arrival_to_loading_notrain, d)       
        else: # Arrived but not loading, and there is a delay before loading.
            delay_end = delay_event_start +df.loc[(d,'Train 1'),'train1_comm_loading_delay_model'] # Calculate the forecasting end of the delay by model
            delay_end_q1 = delay_event_start + df.loc[(d,'Train 1'),'train1_delay_duration_q1'] # q1
            delay_end_q3 = delay_event_start + df.loc[(d,'Train 1'),'train1_delay_duration_q3'] # q3            
            df.loc[(d,'Train 1'),'comm_loading_forecast'] = max(delay_end, d)
            df.loc[(d,'Train 1'),'comm_loading_forecast_q1'] = max(delay_end_q1, d) 
            df.loc[(d,'Train 1'),'comm_loading_forecast_q3'] = max(delay_end_q3, d) 

    ## Train 1 Complete Load Forecast:

    # By Default Forecast Complete Loading Range is None, becomes not null when there is a delay before a train load complete.
    df.loc[(d,'Train 1'),'comp_loading_forecast_q1'] = None
    df.loc[(d,'Train 1'),'comp_loading_forecast_q3'] = None

    # If train has completed loading, take the actual time
    if not pd.isnull(df.loc[(d,'Train 1'),'comp_loading_actual']):
        df.loc[(d,'Train 1'),'comp_loading_forecast'] = df.loc[(d,'Train 1'),'comp_loading_actual']
    
    # If train has started loading, take the last available time provided by train loading data, and add the median loading time (no delay) plus delay proportionate to the number of cars remaining
    else:
        cars_remaining = df.loc[(d,'Train 1'),'cars_remaining']
        total_cars = df.loc[(d,'Train 1'),'num_cars']
        if not pd.isnull(df.loc[(d,'Train 1'),'comm_loading_actual']):
            if df.loc[(d,'Train 1'),'train1_loading_delay_model'] == no_delay: # No delay = train just needs to load the remaining cards
                tm = d + (cars_remaining/total_cars)*(median_loading_nodelay) 
                df.loc[(d,'Train 1'),'comp_loading_forecast'] = tm - datetime.timedelta(microseconds=tm.microsecond)  #remove microseconds
            else: # If there is delay then the forecast complete loading time = forecast when delay end(train restart loading) + loading the remaining cars           
                delay_end = delay_event_start + df.loc[(d,'Train 1'),'train1_loading_delay_model'] # Calculate the forecasting end of the delay by model
                delay_end_q1 = delay_event_start + df.loc[(d,'Train 1'),'train1_delay_duration_q1'] # q1
                delay_end_q3 = delay_event_start + df.loc[(d,'Train 1'),'train1_delay_duration_q3'] # q3
                df.loc[(d,'Train 1'),'comp_loading_forecast'] = max(delay_end, d) + (cars_remaining/total_cars)*(median_loading_nodelay)              
                df.loc[(d,'Train 1'),'comp_loading_forecast_q1'] = max(delay_end_q1, d) + (cars_remaining/total_cars)*(median_loading_nodelay)  
                df.loc[(d,'Train 1'),'comp_loading_forecast_q3'] = max(delay_end_q3, d) + (cars_remaining/total_cars)*(median_loading_nodelay)  
  
    # If train hasn't started loading, add median loading time (no delay) to the forecast commence loading time
        else:
            df.loc[(d,'Train 1'),'comp_loading_forecast'] = max(df.loc[(d,'Train 1'),'comm_loading_forecast'] + median_loading_nodelay,d)
            if df.loc[(d,'Train 1'),'train1_comm_loading_delay_model'] != no_delay:
                df.loc[(d,'Train 1'),'comp_loading_forecast_q1'] = max(df.loc[(d,'Train 1'),'comm_loading_forecast_q1'] + median_loading_nodelay,d)
                df.loc[(d,'Train 1'),'comp_loading_forecast_q3'] = max(df.loc[(d,'Train 1'),'comm_loading_forecast_q3'] + median_loading_nodelay,d)

           
    
    ## Train 1 Departure Forecast:
    
    # If train has departed, take the actual time:
    if not pd.isnull(df.loc[(d,'Train 1'),'depart_actual']):
        df.loc[(d,'Train 1'),'depart_forecast'] = df.loc[(d,'Train 1'),'depart_actual']
            
    # If train hasn't departed, add median time from complete loading to departure to the forecast complete loading time plus delay
    elif df.loc[(d,'Train 1'),'train1_departure_delay_model'] == no_delay: # No delay between complete load and departure
        df.loc[(d,'Train 1'),'depart_forecast'] = max(df.loc[(d,'Train 1'),'comp_loading_forecast'] + median_loadcomplete_to_departure,d)
    else: # there is delay between complete load and departure
        delay_end = delay_event_start + df.loc[(d,'Train 1'),'train1_departure_delay_model']
        df.loc[(d,'Train 1'),'depart_forecast'] = max(delay_end,d)


    for train in ['Train 2','Train 3','Train 4','Train 5']:

        prev_train = train[:-1]+str(int(train[-1])-1)
        ### TRAINS 2 to 5
        ## Commence Load Forecast

        # If train hasn't arrived, take max of schedule time or the train 1 forecast departure + gap (to adjust for delays to train1)
        arrival = df.loc[(d,train),'arrival_actual']
        if pd.isnull(arrival):
            df.loc[(d,train),'comm_loading_forecast'] = max(df.loc[(d,train),'comm_loading_sched'], df.loc[(d,prev_train),'depart_forecast'] + median_train_gap,d)

        # If train has arrived:
        else:
        # If train has started loading, take actual time
            if not pd.isnull(df.loc[(d,train),'comm_loading_actual']):
                df.loc[(d,train),'comm_loading_forecast'] = df.loc[(d,train),'comm_loading_actual']

            # If train hasn't started loading, take the maximum of arrival time plus waiting time with no train in front, or the departure time of the previous train plus the median gap 
            else:
                df.loc[(d,train),'comm_loading_forecast'] = max(arrival + median_arrival_to_loading_notrain, df.loc[(d,prev_train),'depart_forecast'] + median_train_gap,d)

        ## Complete Load Forecast

        # Add median loading time (no delay) to the commence loading time     
        df.loc[(d,train),'comp_loading_forecast'] = max(df.loc[(d,train),'comm_loading_forecast'] + median_loading_nodelay,d)

        ## Departure forecast

        # Add median loading time (no delay) to the commence loading time
        df.loc[(d,train),'depart_forecast'] = max(df.loc[(d,train),'comp_loading_forecast'] + median_loadcomplete_to_departure,d)


    return df
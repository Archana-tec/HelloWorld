import pyspark
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import pandas as pd
import os
import load_ADA_data
import argparse
from pyspark.sql import Window
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, DoubleType, StructField, StructType, TimestampType, LongType, StringType, \
    BooleanType

start_time = datetime.datetime.now()

parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--train_schedule")
parser.add_argument("--FPTU")
parser.add_argument("--alarms")
parser.add_argument("--output_dir")
parser.add_argument("--period_start")
parser.add_argument("--period_end")
args = parser.parse_args()

# Create hdfs date range
period_start_utc = datetime.datetime.strptime(args.period_start, '%Y-%m-%d')
period_start_utc_string = str(args.period_start)
# End date is either dynamic or fixed
if args.period_end == 'default':
    period_end_utc_string = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1), '%Y-%m-%d')
    period_end_utc_ext = datetime.datetime.now()
else:
    period_end_utc_string = args.period_end
    period_end_utc_ext = datetime.datetime.strptime(args.period_end, '%Y-%m-%d') + datetime.timedelta(days=1)

# Use extended range to capture all files in hdfs range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc_ext)
dr = (date_range.replace("{", "").replace("}", "").replace("*", "")).split(",")

print(f"[{datetime.datetime.now()}] Period Start: {period_start_utc}")
print(f"[{datetime.datetime.now()}] Period End: {period_end_utc_ext}")
print(f"[{datetime.datetime.now()}] date_range: {date_range}")

output_dir = args.output_dir.replace('.blob.', '.dfs.')
output_dir = output_dir.replace('wasbs', 'abfss')

# spark = SparkSession.builder.getOrCreate()
client_id = "128e82ef-d499-45af-8616-b302a4d2f547"
client_secret = "tOI8Q~KDIPaVQzts8amQScxN5BIbXlIAoKx6fbOp"
tenant_id = "4341df80-fbe6-41bf-89b0-e6e2379c9c23"
spark = SparkSession.builder \
    .appName('app_name') \
    .master('local[*]') \
    .config('spark.sql.execution.arrow.pyspark.enabled', True) \
    .config('spark.sql.session.timeZone', 'UTC') \
    .config('spark.dynamicAllocation.enabled', True) \
    .config('spark.dynamicAllocation.initialExecutors', 3) \
    .config('spark.driver.memory', '32G') \
    .config('spark.ui.showConsoleProgress', True) \
    .config('spark.sql.repl.eagerEval.enabled', True) \
    .config('spark.driver.maxResultSize', '0') \
    .getOrCreate()

spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.auth.type.srtdsdevrtioada02.dfs.core.windows.net", "OAuth"
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth.provider.type.srtdsdevrtioada02.dfs.core.windows.net",
    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.id.srtdsdevrtioada02.dfs.core.windows.net",
    client_id,
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.secret.srtdsdevrtioada02.dfs.core.windows.net",
    client_secret,
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.endpoint.srtdsdevrtioada02.dfs.core.windows.net",
    "https://login.microsoftonline.com/" + tenant_id + "/oauth2/token",
)

linked_service_name = "srtdsdevrtioada02"
spark.conf.set("spark.storage.synapse.linkedServiceName", linked_service_name)
spark.conf.set("fs.azure.account.oauth.provider.type",
               "com.microsoft.azure.synapse.tokenlibrary.LinkedServiceBasedTokenProvider")

# Load PCS Tags
uc1_tags_list = os.path.join(os.path.dirname(__file__), 'UC1_Tags.txt')
tag_list = []
with open(uc1_tags_list) as f:
    tag_list = f.read().splitlines()
f.close()

#### Loading PCS Tags
pcs_tags_dir = args.PCS_tags.replace('.blob.', '.dfs.')
pcs_tags_dir = pcs_tags_dir.replace('wasbs', 'abfss')

# sdf_tags = spark.read.parquet("abfss://azureml-blobstore-01abc001-2e88-4605-bf45-509acf58edca@srtdsdevrtioada02.dfs.core.windows.net/ADA_processed_datasets/PCS_tags")
print(f"[{datetime.datetime.now()}] PCS Tags - Going to read paruqet files ...")
sdf_tags = spark.read.parquet(pcs_tags_dir)
print(f"[{datetime.datetime.now()}] PCS Tags - Finished reading paruqet files ...")
sdf_tags = sdf_tags[sdf_tags.tagid.isin(tag_list)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))]
sdf_tags = sdf_tags.withColumn("value_rio", sdf_tags.value_rio.cast('double'))
sdf_tags.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/PCS_tags")
print(f"[{datetime.datetime.now()}] Tag load complete.")

# #### Loading Alarnms
alarms_dir = args.alarms.replace('.blob.', '.dfs.')
alarms_dir = alarms_dir.replace('wasbs', 'abfss')
print(f"[{datetime.datetime.now()}] Alarms - Going to read paruqet files ...")
sdf_alarms = spark.read.parquet(alarms_dir)
print(f"[{datetime.datetime.now()}] Alarms - Finished reading paruqet files ...")
sdf_alarms = sdf_alarms.withColumn('vt_start', to_timestamp('vt_start'))
sdf_alarms = sdf_alarms[sdf_alarms.vt_start.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))]
sdf_alarms.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/alarms")
print(f'[{datetime.datetime.now()}] Alarms load complete.')

### Loading Train schedule
ts_dir = args.train_schedule.replace('.blob.', '.dfs.')
ts_dir = ts_dir.replace('wasbs', 'abfss')

json_sources = [ts_dir + sub + "*" for sub in dr]
print(f"[{datetime.datetime.now()}] Train Schedule - Going to read paruqet files ...")
sdf_ts = spark.read.parquet(ts_dir)
print(f"[{datetime.datetime.now()}] Train Schedule - Finished reading paruqet files ...")

sdf_ts = sdf_ts[sdf_ts.UPDATED_ON_UTC.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))]
sdf_ts.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/train_schedule")
print(f"[{datetime.datetime.now()}] Train Schedule load complete.")

#### Loading FPTU
fptu_dir = args.FPTU.replace('.blob.', '.dfs.')
fptu_dir = fptu_dir.replace('wasbs', 'abfss')

json_sources = [fptu_dir + sub + "*" for sub in dr]
print(f'[{datetime.datetime.now()}] JSON Sources: {json_sources}')
print(f"[{datetime.datetime.now()}] FPTU - Going to read paruqet files ...")
sdf_fptu = spark.read.parquet(fptu_dir)
print(f"[{datetime.datetime.now()}] FPTU - Finished reading paruqet files ...")

sdf_fptu = sdf_fptu[sdf_fptu.ModifiedAt.between(period_start_utc, period_end_utc_ext + datetime.timedelta(days=1))]
sdf_fptu = sdf_fptu[sdf_fptu.TUM5Code.isin(['ULO', 'ULF', 'OD', 'OS'])]
sdf_fptu = sdf_fptu[sdf_fptu.FixedPlantAssetCode == 'Train Loadout 1']
sdf_fptu = sdf_fptu[~sdf_fptu.Effect.isin(['Wait Train', 'Clearing Train', 'Present Train', 'Placing Train'])]
sdf_fptu.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/FPTU")
print(f"[{datetime.datetime.now()}] FPTU load complete.")

### FPTU - Delay Time Series
print(f"[{datetime.datetime.now()}] FPTU time series transformation starts.")
dt_start_awst = period_start_utc + datetime.timedelta(hours=8)
dt_end_awst = period_end_utc_ext + datetime.timedelta(hours=8)
delta = dt_end_awst - dt_start_awst
delta_mins = delta.total_seconds() / 60
num_periods = delta_mins + 1  # Number of 1 minute periods
datetime_range = pd.date_range(dt_start_awst, periods=num_periods, freq='1T')

sdf_fptu_ts = sdf_fptu.where(f"FixedPlantTimeUsageEventStart between '{dt_start_awst}' and '{dt_end_awst}'")

windowSpec = Window.partitionBy('SourceIdentifier', 'Cause', 'Effect', 'FixedPlantTimeUsageEventStart').orderBy(
    col("FixedPlantTimeUsageEventFinish").desc())
sdf_fptu_ts = sdf_fptu_ts.withColumn("row_number", row_number().over(windowSpec)).where('row_number=1').drop(
    "row_number")

range_df = spark.createDataFrame(pd.DataFrame({'t': datetime_range}))
range_df.createOrReplaceTempView('datetime_range')
sdf_fptu_ts.createOrReplaceTempView('sdf_fptu_ts')

df_fptu_ts = spark.sql("""
    with temp as (
        select 
            t,
            case 
                when count(*)>0 then 1
                else 0
            end as delay
        from datetime_range as d, sdf_fptu_ts as df
        where FixedPlantTimeUsageEventStart <= t
            and FixedPlantTimeUsageEventFinish > t
        group by t
    )
    select temp.t, 1 as delay_in_progress from temp
    UNION
    select d.t, 0 as delay_in_progress from datetime_range as d
    where not exists(select * from temp where temp.t=d.t)
""").orderBy('t')
df_fptu_ts.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/FPTU_delay_ts")
print(f"[{datetime.datetime.now()}] FPTU time series transformation complete.")

# # #### PCS Tags Pivot

print(f"[{datetime.datetime.now()}] Tag pivot starts")

#
# def forward_fill_resample(pdf):
#     # print(pdf)
#     pdf = pdf.sort_values('time_rio', axis=0)
#     df_tags_pivot2 = pdf.set_index('time_rio')
#     df_tags_pivot2 = df_tags_pivot2.fillna(method='ffill')
#     # df_tags_pivot2 = df_tags_pivot2.loc[period_start:period_end_utc_string]
#     df_tags_pivot2 = df_tags_pivot2.resample('T').ffill()
#     df_tags_pivot2 = df_tags_pivot2.dropna(how='all')
#     df_tags_pivot2 = df_tags_pivot2.drop(columns=['timeriodate'])
#     df_tags_pivot2 = df_tags_pivot2.reset_index()
#     return df_tags_pivot2
#
#
# fields = []
# fields.append(StructField('time_rio', TimestampType()))
# for t in tag_list:
#     fields.append(StructField(t.replace('.', '__'), DoubleType()))
# tags_pivot_schema = StructType(fields)
#
# print(f"[{datetime.datetime.now()}] Tag pivot - starting grouping data")
# sdf_tags_pivot = sdf_tags.groupBy('time_rio').pivot('tagid').agg(first('value_rio'))
#
# missing_cols = list(set(tag_list).difference(set(sdf_tags_pivot.columns)))
# print(f"[{datetime.datetime.now()}] Missing Columns: {missing_cols}")
# for m in missing_cols:
#     sdf_tags_pivot = sdf_tags_pivot.withColumn(m, lit(None).cast(DoubleType()))
#
# new_cols = (column.replace('.', '__') for column in sdf_tags_pivot.columns)
# sdf_tags_pivot = sdf_tags_pivot.toDF(*new_cols)
# sdf_tags_pivot = sdf_tags_pivot.withColumn('timeriodate', to_date(col('time_rio'), "yyyy-MM-dd'T'HH:mm:ss"))
# print(f"[{datetime.datetime.now()}] Tag pivot - applyInPandas - foward filling")
# sdf_tags_pivot = sdf_tags_pivot.groupby('timeriodate').applyInPandas(forward_fill_resample, tags_pivot_schema)
# sdf_tags_pivot = sdf_tags_pivot.where(f"time_rio between '{period_start_utc_string}' and '{period_end_utc_string}'")
# new_cols = (column.replace('__', '.') for column in sdf_tags_pivot.columns)
# sdf_tags_pivot = sdf_tags_pivot.toDF(*new_cols)


sdf_tags = sdf_tags.withColumn('t', date_trunc('MINUTE', col('time_rio')))  ## Discuss with DS
sdf_tags.createOrReplaceTempView('sdf_tags')
sdf_tags.cache()

uniq_tag_id = sdf_tags.dropDuplicates(["tagid"]).select("tagid").rdd.flatMap(lambda x: x).collect()

print(f"[{datetime.datetime.now()}] Preparing resampled datetime ...")
time_range_df = pd.DataFrame({'t': pd.date_range(period_start_utc_string, end=period_end_utc_string + ' 23:59:59', freq='1min')})
time_range_df = spark.createDataFrame(time_range_df)
time_range_df.createOrReplaceTempView('time_range_df')
tags_df = pd.DataFrame()
tags_df['tagid'] = uniq_tag_id
tags_df = spark.createDataFrame(tags_df)
tags_df.createOrReplaceTempView('tags_df')
combo_df = spark.sql("""
        select t as time_rio , tagid
        from tags_df, time_range_df
    """)

## Resampling -- Discuss with DS
print(f"[{datetime.datetime.now()}] Resampling ...")
sdf_tags2 = spark.sql(f"""
            select t as time_rio, tagid, value_rio
            from ( 
                select *, row_number() over(partition by t, tagid  order by time_rio ) as g
                from sdf_tags ) as temp
            where g = 1
        """)

sdf_tags2 = sdf_tags2.withColumn("time_rio_existent", col("time_rio"))
df_all_dates = combo_df.join(sdf_tags2, ["time_rio", "tagid"], "leftouter")

## Forward Filling
print(f"[{datetime.datetime.now()}] Foward-filling ...")
window_ff = Window.partitionBy('tagid') \
        .orderBy('time_rio') \
        .rowsBetween(-sys.maxsize, 0)

read_last = F.last(df_all_dates['value_rio'], ignorenulls=True).over(window_ff)
readtime_last = F.last(df_all_dates['time_rio_existent'], ignorenulls=True).over(window_ff)

df_filled = df_all_dates.withColumn('readvalue_ff', read_last) \
        .withColumn('readtime_ff', readtime_last)

df_filled.createOrReplaceTempView('s')

sdf_tags3 = spark.sql("""Select 
                time_rio, tagid, COALESCE(value_rio, readvalue_ff) as value_rio, time_rio as time_rio_existent  from s """)

# df_all_dates = combo_df.join(sdf_tags3, ["time_rio", "tagid"], "leftouter")
sdf_tags3.createOrReplaceTempView('df_all_dates')
sdf_tags3.cache()

## Back filling
print(f"[{datetime.datetime.now()}] Back-filling ...")
bf_value = spark.sql("""
                select d.time_rio, d.tagid, d.value_rio 
                from df_all_dates d, 
                    (select min(time_rio) as time_rio, tagid 
                     from df_all_dates d
                     where  value_rio is not NULL  group by tagid) a 
                where d.tagid = a.tagid and d.time_rio = a.time_rio """)

bf_value.createOrReplaceTempView('bf_value')

sdf_tags4 = spark.sql("""Select
                d.time_rio, d.tagid, 
                COALESCE(d.value_rio, bf_value.value_rio) as value_rio
            from df_all_dates d, bf_value
            where bf_value.tagid = d.tagid 
            UNION 
            SELECT
                d.time_rio, d.tagid, d.value_rio as value_rio
            from df_all_dates d
            where not exists (select * from bf_value where bf_value.tagid = d.tagid )
    """)
sdf_tags4.createOrReplaceTempView('sdf_tags4')

print(f"[{datetime.datetime.now()}] Pivotting ...")
sdf_tags_pivot = sdf_tags4.groupBy('time_rio').pivot('tagid').agg(first('value_rio'))

print(f"[{datetime.datetime.now()}] Tag pivot - writing ..")
sdf_tags_pivot.repartition(10).write.mode('overwrite').parquet(f"{output_dir}/PCS_tags_pivot")

print(f"[{datetime.datetime.now()}] Tag pivot complete.")

end_time = datetime.datetime.now()
print(f"[{datetime.datetime.now()}] DONE in {(end_time - start_time)}...")
import datetime
from ADA_UC1_TLO.uc1_model import uc1_tlo_model_inference
import argparse
import pandas as pd
import pyodbc

from key_vault_reader import KeyVaultReader

parser = argparse.ArgumentParser()
parser.add_argument("--output")
parser.add_argument("--env")
args = parser.parse_args()

print(f'env from args = {args.env}')
print(f'output from args = {args.output}')

env = args.env
if env == 'dev':
    kv_env = 'dev'
    kv_name = 'kv-rt-dsdev-ae-ada01'
else:
    if env == 'prd':
        kv_env = 'prod'
    else:
        kv_env = 'uat'
    kv_name = 'kvaedsprodrtioada'

kv_reader = KeyVaultReader(tenant_id=os.environ.get('adasprdtenantid'),
                           keyvault_name=kv_name)

dt = datetime.datetime.now()
dt = dt - datetime.timedelta(seconds=dt.second, microseconds=dt.microsecond)
print(f'dt = {dt}')

# Run Model Prediction
print(f'uc1_tlo_model_inference')
df = uc1_tlo_model_inference(dt, identify_delay_method='ml', delay_duration_method='GD-only', tlo_stage_timing_method='GD-historical',env=args.env)

# Write result as a csv to blob container
print(f'to_csv')
df.to_csv(args.output+('/ADA_UC1_TLO_results_'+str(dt)[0:10]+'T'+str(dt)[11:16]+'.csv').replace(':','_'), index=True)

### Write to SQL DB
# Reset index to get datetime and train columns
print(f'df_outputs')
df_outputs = df.reset_index()
# Replace NaN with None (Sql friendly)
df_outputs = df_outputs.astype(object).where(pd.notnull(df_outputs), None)
# # Write full output df to ADA Results SQL database (Trains 1 to 5)

hostname = kv_reader.get_secret(f'sqlserver-hostname-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
database = kv_reader.get_secret(f'sqlserver-database-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
username = kv_reader.get_secret(f'sqlserver-username-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
password = kv_reader.get_secret(f'sqlserver-password-{kv_env}')  # kv_env = ['dev',' uat', 'prod']

print(f'database hostname = {hostname}')
print(f'database name = {database}')
print(f'Connecting to {hostname}')

with pyodbc.connect(
                    r'Driver={ODBC Driver 17 for SQL Server};'
                    r'Server=tcp:'+hostname+',1433;'
                    r'Database='+database+';'
                    r'Uid='+username+';'
                    r'Pwd={'+password+'};'
                    r'Encrypt=yes;'
                    r'TrustServerCertificate=yes;'
                    r'Connection Timeout=30;'
               ) as cnxn:
                        cursor = cnxn.cursor()

print(f'Connected!')
print(f'Loading data to {database} database')
for index, row in df_outputs.iterrows():
    cursor.execute("INSERT INTO ADA_UC1_TLO.RESULTS ([Datetime],[train],[train_id],[train_status],\
                    [product],[num_cars],[cars_remaining],[arrival_sched],[arrival_actual],[comm_loading_sched],\
                    [comm_loading_forecast],[comm_loading_actual],[comp_loading_sched],[comp_loading_forecast],\
                    [comp_loading_actual],[depart_sched],[depart_forecast],[depart_actual],[train1_comm_loading_delay_model],\
                    [train1_loading_delay_model],[train1_departure_delay_model],[comp_loading_forecast_q1],[comp_loading_forecast_q3],\
                    [train1_delay_duration_q1],[train1_delay_duration_q3],[delay_event_in_progress],[delay_event_type],\
                    [delay_event_cause],[delay_event_asset],[delay_event_start] ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",\
                    row['datetime'],row.train,row.train_id,row.train_status,row['product'],int(row.num_cars),int(row.cars_remaining),row.arrival_sched,\
                    row.arrival_actual,row.comm_loading_sched,row.comm_loading_forecast,row.comm_loading_actual,row.comp_loading_sched,\
                    row.comp_loading_forecast,row.comp_loading_actual,row.depart_sched,row.depart_forecast,row.depart_actual,\
                    int(row.train1_comm_loading_delay_model),int(row.train1_loading_delay_model),int(row.train1_departure_delay_model),\
                    row.comp_loading_forecast_q1,row.comp_loading_forecast_q3,int(row.train1_delay_duration_q1),int(row.train1_delay_duration_q3),\
                    row.delay_event_in_progress,row.delay_event_type,row.delay_event_cause,row.delay_event_asset,row.delay_event_start )
cnxn.commit()
cursor.close()
print(f'DONE!')

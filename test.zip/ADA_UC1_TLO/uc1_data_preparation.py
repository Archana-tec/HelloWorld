# Import Python Libraries

import pandas as pd
import datetime
import os
import load_ADA_data
import ADA_UC1_TLO.uc1_utils as uc1
import time


def data_load(dt_start, dt_end, purpose='backtest', env='dev'):
    """
    Inputs: 
        dt_start: Start period of prediction period (UTC)
        dt_end: End peridod of prediction period (UTC)

    Outputs: Raw UC1 model input data:
        df_trainsched, df_tags, df_alarm
    """
    delta = dt_end - dt_start
    delta_mins = delta.total_seconds() / 60
    num_periods = delta_mins / 3 + 1  # Number of 3 minute periods

    # Define Tag list - in scope for UC1
    uc1_tags_list = os.path.join(os.path.dirname(__file__), 'UC1_Tags.txt')
    tag_list = []
    with open(uc1_tags_list) as f:
        tag_list = f.read().splitlines()
    f.close()

    ## LOAD RAW DATA ###
    # Load data using Spark method for backtesting
    if purpose == 'backtest':
        # Ingestion of train schedule data (24 hours)
        df_trainsched = load_ADA_data.LoadData("kd-int071-tpps-train-schedule-ada", dt_end, 60 * 24 + num_periods * 3,
                                               env).load_data_spark()
        # Ingestion of tag data (20 mins)
        df_tags = load_ADA_data.LoadData("kd-int054-process-control-data-from-osisoft-pi-ada", dt_end,
                                         20 + num_periods * 3, env, tag_list).load_data_spark()
        # Ingestion of alarm data (120 mins)
        df_alarms = load_ADA_data.LoadData("kd-int080-process-control-alarms-and-events", dt_end, 120 + num_periods * 3,
                                           env).load_data_spark()

    # Load data using non-Spark download method for inferencing (AKS endpoint)
    elif purpose == 'inference':
        # Ingestion of train schedule data (24 hours)
        t_s_tr = time.perf_counter()
        df_trainsched = load_ADA_data.LoadData("kd-int071-tpps-train-schedule-ada", dt_end, 60 * 24 + num_periods * 3,
                                               env).load_data_to_df(data_load_method='mount')
        t_e_tr = time.perf_counter()
        print(f'df_trainsched took {t_e_tr - t_s_tr} seconds')
        # Ingestion of tag data (20 mins)
        t_s_t = time.perf_counter()
        df_tags = load_ADA_data.LoadData("kd-int054-process-control-data-from-osisoft-pi-ada", dt_end,
                                         20 + num_periods * 3, env, tag_list).load_data_to_df(data_load_method='mount')
        t_e_t = time.perf_counter()
        print(f'df_tags took {t_e_t - t_s_t} seconds')
        # Ingestion of alarm data (120 mins). Alarms data is non-essential so return empty dataframe if there is an error loading data
        try:
            t_s_a = time.perf_counter()
            df_alarms = load_ADA_data.LoadData("kd-int080-process-control-alarms-and-events", dt_end,
                                               120 + num_periods * 3, env).load_data_to_df(data_load_method='mount')
            t_e_a = time.perf_counter()
            print(f'df_alarms took {t_e_a - t_s_a} seconds')
        except:
            df_alarms = pd.DataFrame(columns=['eventid', 'tagname', 'unit', 'description', 'area', 'name', 'vt_start', \
                                              'vt_end', 'priority', 'message'])

    return df_trainsched, df_tags, df_alarms


def data_preprocessing(df_trainsched, df_tags, df_alarms):
    """
    Inputs:
        df_trainsched: Raw Train Schedule Dataframe from Data Load
        df_tags: Raw PCS Tags Dataframe from Data Load
        df_alarms: Raw Alarms Dataframe from Data Load

    Outputs: Processed UC1 model input data:
        df_trainsched, df_tags, df_alarms, df_car_weights
    """
    ## Changing date format for train scheduled dataset to the old format

    df_trainsched['UPDATED_ON_UTC'] = pd.to_datetime(df_trainsched['UPDATED_ON_UTC'].str.replace('Z',''))  
    #df_trainsched['UPDATED_ON_UTC'] = pd.to_datetime(df_trainsched['UPDATED_ON_UTC'].str.replace("+",''))  
    # convert the datetime objects back to the desired format  
    df_trainsched['UPDATED_ON_UTC'] = df_trainsched['UPDATED_ON_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['PLANNED_ARRIVAL_TIME_UTC'] = pd.to_datetime(df_trainsched['PLANNED_ARRIVAL_TIME_UTC'].str.replace('Z',''))
    #df_trainsched['PLANNED_ARRIVAL_TIME_UTC'] = pd.to_datetime(df_trainsched['PLANNED_ARRIVAL_TIME_UTC'].str.replace('+',''))
    # convert the datetime objects back to the desired format  
    df_trainsched['PLANNED_ARRIVAL_TIME_UTC'] = df_trainsched['PLANNED_ARRIVAL_TIME_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S') 

    df_trainsched['PLANNED_COMMENCE_LOAD_UTC'] = pd.to_datetime(df_trainsched['PLANNED_COMMENCE_LOAD_UTC'].str.replace('Z', '')) 
    #df_trainsched['PLANNED_COMMENCE_LOAD_UTC'] = pd.to_datetime(df_trainsched['PLANNED_COMMENCE_LOAD_UTC'].str.replace('+', '')) 
    # convert the datetime objects back to the desired format  
    df_trainsched['PLANNED_COMMENCE_LOAD_UTC'] = df_trainsched['PLANNED_COMMENCE_LOAD_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S') 

    df_trainsched['PLANNED_COMPLETE_LOAD_UTC'] = pd.to_datetime(df_trainsched['PLANNED_COMPLETE_LOAD_UTC'].str.replace('Z', ''))  
    #df_trainsched['PLANNED_COMPLETE_LOAD_UTC'] = pd.to_datetime(df_trainsched['PLANNED_COMPLETE_LOAD_UTC'].str.replace('+', '')) 
    # convert the datetime objects back to the desired format  
    df_trainsched['PLANNED_COMPLETE_LOAD_UTC'] = df_trainsched['PLANNED_COMPLETE_LOAD_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S') 

    df_trainsched['PLANNED_DEPARTURE_TIME_UTC'] = pd.to_datetime(df_trainsched['PLANNED_DEPARTURE_TIME_UTC'].str.replace('Z', ''))  
    #df_trainsched['PLANNED_DEPARTURE_TIME_UTC'] = pd.to_datetime(df_trainsched['PLANNED_DEPARTURE_TIME_UTC'].str.replace('+', ''))
    # convert the datetime objects back to the desired format  
    df_trainsched['PLANNED_DEPARTURE_TIME_UTC'] = df_trainsched['PLANNED_DEPARTURE_TIME_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['CREATED_ON_UTC'] = pd.to_datetime(df_trainsched['CREATED_ON_UTC'].str.replace('Z', ''))
    #df_trainsched['CREATED_ON_UTC'] = pd.to_datetime(df_trainsched['CREATED_ON_UTC'].str.replace('+', ''))   
    # convert the datetime objects back to the desired format  
    df_trainsched['CREATED_ON_UTC'] = df_trainsched['CREATED_ON_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['DELETED_ON_UTC'] = pd.to_datetime(df_trainsched['DELETED_ON_UTC'].str.replace('Z', ''))  
    #df_trainsched['DELETED_ON_UTC'] = pd.to_datetime(df_trainsched['DELETED_ON_UTC'].str.replace('+', '')) 
    # convert the datetime objects back to the desired format  
    df_trainsched['DELETED_ON_UTC'] = df_trainsched['DELETED_ON_UTC'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['TD_ACT_ARRIVALTIME'] = pd.to_datetime(df_trainsched['TD_ACT_ARRIVALTIME'].str.replace('Z', ''))  
    #df_trainsched['TD_ACT_ARRIVALTIME'] = pd.to_datetime(df_trainsched['TD_ACT_ARRIVALTIME'].str.replace('+', ''))  
    # convert the datetime objects back to the desired format  
    df_trainsched['TD_ACT_ARRIVALTIME'] = df_trainsched['TD_ACT_ARRIVALTIME'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['TD_ACT_COMMLOAD'] = pd.to_datetime(df_trainsched['TD_ACT_COMMLOAD'].str.replace('Z', ''))  
    #df_trainsched['TD_ACT_COMMLOAD'] = pd.to_datetime(df_trainsched['TD_ACT_COMMLOAD'].str.replace('+', ''))  
    # convert the datetime objects back to the desired format  
    df_trainsched['TD_ACT_COMMLOAD'] = df_trainsched['TD_ACT_COMMLOAD'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['TD_ACT_COMPLOAD'] = pd.to_datetime(df_trainsched['TD_ACT_COMPLOAD'].str.replace('Z', ''))
    #df_trainsched['TD_ACT_COMPLOAD'] = pd.to_datetime(df_trainsched['TD_ACT_COMPLOAD'].str.replace('+', ''))   
    # convert the datetime objects back to the desired format  
    df_trainsched['TD_ACT_COMPLOAD'] = df_trainsched['TD_ACT_COMPLOAD'].dt.strftime('%Y-%m-%dT%H:%M:%S')  

    df_trainsched['TD_ACT_DEPMINE'] = pd.to_datetime(df_trainsched['TD_ACT_DEPMINE'].str.replace('Z', ''))  
    #df_trainsched['TD_ACT_DEPMINE'] = pd.to_datetime(df_trainsched['TD_ACT_DEPMINE'].str.replace('+', ''))  
    # convert the datetime objects back to the desired format  
    df_trainsched['TD_ACT_DEPMINE'] = df_trainsched['TD_ACT_DEPMINE'].dt.strftime('%Y-%m-%dT%H:%M:%S') 

    ## DATA MANIPULATION AND FEATURE ENGINEERING

    # Define timestamp utc cols
    utc_col = ['PLANNED_ARRIVAL_TIME_UTC', 'PLANNED_COMMENCE_LOAD_UTC',
               'PLANNED_COMPLETE_LOAD_UTC', 'PLANNED_DEPARTURE_TIME_UTC',
               'CREATED_ON_UTC', 'UPDATED_ON_UTC', 'DELETED_ON_UTC']
    # Convert utc timestamp into AWST Perth timestamp
    for i in utc_col:
        df_trainsched[i] = uc1.convert_utc_to_local(pd.to_datetime(df_trainsched[i]))
    awst_col = ['TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD', 'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE']
    # Convert cast into datetime format
    for i in awst_col:
        df_trainsched[i] = pd.to_datetime(df_trainsched[i])
    # Rename Columnes from UTC to AWST
    df_trainsched.rename(columns={'PLANNED_ARRIVAL_TIME_UTC': 'PLANNED_ARRIVAL_TIME_AWST',
                                  'PLANNED_COMMENCE_LOAD_UTC': 'PLANNED_COMMENCE_LOAD_AWST',
                                  'PLANNED_COMPLETE_LOAD_UTC': 'PLANNED_COMPLETE_LOAD_AWST',
                                  'PLANNED_DEPARTURE_TIME_UTC': 'PLANNED_DEPARTURE_TIME_AWST',
                                  'CREATED_ON_UTC': 'CREATED_ON_AWST',
                                  'UPDATED_ON_UTC': 'UPDATED_ON_AWST',
                                  'DELETED_ON_UTC': 'DELETED_ON_AWST'
                                  }, inplace=True)
    # Remove Train Schedule Data that have timestamp error
    df_trainsched = df_trainsched[df_trainsched['TRAINSTATUS'] != 'Timestamp Error']
    df_trainsched = df_trainsched[df_trainsched['TRAINSTATUS'] != None] ###DEV
    # Find the first locomotive number
    df_trainsched['LOCOS'].fillna('', inplace=True)
    df_trainsched['First_Loco_ID'] = df_trainsched['LOCOS'].apply(lambda x: pd.to_numeric(x[:4]))

    # Convert Tags numeric values to numeric
    df_tags['value_rio'] = df_tags['value_rio'].apply(pd.to_numeric, errors='ignore')
    # Sort dataset by Tag Name and Timestamp
    df_tags = df_tags.sort_values(['tagid', 'time_rio'])
    # Convert Timezone from UTC into AWST
    df_tags['time_rio'] = uc1.convert_utc_to_local(pd.to_datetime(df_tags['time_rio']))
    # Convert timestamp to naive
    df_tags['time_rio'] = [dt.tz_localize(None) for dt in df_tags['time_rio']]

    # Data imputation for tag that are indicator
    indicator_tags = ['KD1.PPCS.RC0601_RelSeqRun_S', 'KD1.PPCS.RC0601_ReclaimSeqRun_S', 'KD1.PPCS.TL0601DLC01_LNK_S',
                      'KD1.PPCS.TL0601DLC01_TRNPRESENTED_S', 'KD1.PPCS.TL0601DLC01_TRNLOADING_S',
                      'KD1.PPCS.TL0601DLC01_TRNLD_S',
                      'KD1.PPCS.TL0601_TRAINEXITED_S', 'KD1.PPCS.TL0601DLC01_TRNCLEARING_S', 'KD1.PPCS.RC0601_MAN_S',
                      'KD1.PPCS.TL0601_FINES_S', 'KD1.PPCS.TL0601_LUMP_S', 'KD1.PPCS.TL0601_LOCOIN_S',
                      'KD1.PPCS.TL0601_NEWTRAIN']
    df_tags.loc[(df_tags['tagid'].isin(indicator_tags)) & (df_tags['value_rio'].isna()), 'value_rio'] = 0
    # # Forward Filling for other tags
    df_tags.update(df_tags.groupby('tagid')['value_rio'].ffill())
    # # Find previous value of the tag and remove of the current and prev values are the same
    df_tags['prev_value'] = df_tags.groupby('tagid')['value_rio'].shift(1).fillna(-1)
    df_tags = df_tags[df_tags['prev_value'] != df_tags['value_rio']]

    # Find next change time
    df_tags['next_time'] = df_tags.groupby('tagid')['time_rio'].shift(-1)
    df_tags['next_value'] = df_tags.groupby('tagid')['value_rio'].shift(-1)

    # # Put default next_time
    default_ts = pd.to_datetime(datetime.datetime(2099, 12, 31))
    df_tags['next_time'].fillna(default_ts, inplace=True)
    # Rename column name
    df_tags.rename(columns={'time_rio': 'time',
                            'value_rio': 'value'}, inplace=True)

    # Car weight tags are Gross Weights, as that is the relevant measure for over/underloaded ore cars
    selected_car_weights = ['KD1.PPCS.TSC0601TSOT_MNFST_WGNWT_' + str(i) for i in [num for num in range(1, 241)]]
    df_car_weights = df_tags[df_tags['tagid'].isin(selected_car_weights)]
    # Create car no
    df_car_weights['car_no'] = pd.to_numeric(df_car_weights['tagid'].apply(lambda x: x.split('WGNWT_', 1)[1]))

    # Filter for in-scope alarms
    try:
        # Temporary remove acknowledge alarms
        df_alarms = df_alarms[df_alarms['name'] != 'Acknowledge']
    except:
        df_alarms = pd.DataFrame(columns=['eventid', 'tagname', 'unit', 'description',
                                          'area', 'name', 'vt_start', 'vt_end',
                                          'priority', 'message', 'asset'])
    # Data Prep of alarm data

    df_alarms.vt_end = df_alarms.vt_end.astype(str).apply(
        lambda x: x.replace('9999-12-31T01:00:00', '2059-12-31 00:00:00'))
    df_alarms.vt_end = df_alarms.vt_end.values.astype("datetime64[s]")
    df_alarms['vt_start'] = pd.to_datetime(df_alarms['vt_start'])
    df_alarms['vt_end'] = pd.to_datetime(df_alarms['vt_end'])
    df_alarms['message'].fillna('', inplace=True)
    df_alarms['description'].fillna('', inplace=True)
    # Remove Alarms that are not in the TLO Area
    excl_unit = ['Screening', 'Secondary Crushing',
                 'Primary Crushing', 'Service', 'Operator Log',
                 'Sampling', 'Laboratory Safety System',
                 'Production Preperation Cell 1', 'Vial Conveyor System',
                 'Pit Preparation Cell 1', 'Archive System',
                 'Laboratory Ancillary System']
    df_alarms = df_alarms[(~df_alarms['unit'].isin(excl_unit))]  # in the TLO area
    df_alarms['asset'] = ''
    # Extract Asset Codes from tagname
    df_alarms.loc[df_alarms['tagname'].str.contains('CV0622'), 'asset'] = 'CV0622'
    df_alarms.loc[df_alarms['tagname'].str.contains('RC0601'), 'asset'] = 'RC0601'
    df_alarms.loc[df_alarms['tagname'].str.contains('BN0601'), 'asset'] = 'BN0601'
    df_alarms.loc[df_alarms['tagname'].str.contains('RC0601CV21'), 'asset'] = 'CV21'
    df_alarms.loc[df_alarms['tagname'].str.contains('SK0501'), 'asset'] = 'SK0501'
    df_alarms.loc[df_alarms['tagname'].str.contains('SK0502'), 'asset'] = 'SK0502'

    return df_trainsched, df_tags, df_alarms, df_car_weights


def next_5trains_output_df(dt, df_trainsched, df_tags):
    """
    Inputs:
        dt: Datetime of prediction
        df_trainsched: Pre-processed Train Schedule input data
        df_tags: Pre-processed PCS Tags input data

    Outputs:
        Output dataframe with train schedule and other details filed
        for the next 5 trains
    """
    # Filter for 1 day of data from timestamp dt
    df_tsdt = df_trainsched[(df_trainsched['UPDATED_ON_AWST'] <= dt) & (
                df_trainsched['UPDATED_ON_AWST'] > dt - datetime.timedelta(hours=25))]

    # Get the last train schedule update per train
    df_tsdt = df_tsdt.sort_values(by="UPDATED_ON_AWST").drop_duplicates(subset=["SCHEDULE_TRAIN_ID"],
                                                                        keep="last").sort_values(
        by="PLANNED_ARRIVAL_TIME_AWST")

    ### Data Cleaning on Train Schedule Data ###
    # Find the max train arrival timestamp for the last train that departed/loaded/commence loading during this period
    max_arrival = df_tsdt[pd.notnull(df_tsdt['TD_ACT_DEPMINE'])]['TD_ACT_ARRIVALTIME'].max()

    # Remove trains which have departed more than 10 minutes ago
    departed_trains = df_tsdt[df_tsdt.TD_ACT_DEPMINE < dt - datetime.timedelta(minutes=10)]['TRAIN_ID'].unique()
    df_tsdt = df_tsdt[~df_tsdt.TRAIN_ID.isin(departed_trains)]

    # Remove trains which arrived at mine before the max train arrival timestamp for the last departed train.
    # Assumptions: any trains that arrived before the last departed train are already loaded. Train first arrives will be loaded first as well.
    if pd.notnull(max_arrival):  # in case there is no departed train in the day
        df_tsdt = df_tsdt[df_tsdt.TD_ACT_ARRIVALTIME.fillna(datetime.datetime(2099, 12, 31)) >= max_arrival]
    else:
        pass

    # Clean Train: Try to remove updates for past loaded train
    df_tsdt = df_tsdt[df_tsdt.TD_ACT_COMPLOAD.fillna(datetime.datetime(2099, 12, 31)) >= dt - datetime.timedelta(
        days=2)]  # remove trains that completed loaded more than 2 days ago

    # Get first locomotive id from tag
    tag_loco_id = uc1.find_tag_lag_value(df_tags, 'KD1.PPCS.TL0601DLC01_LNKDTRNID_S', dt, 0)

    if (tag_loco_id != 0) & (len(df_tsdt[df_tsdt.First_Loco_ID == tag_loco_id]) > 0):

        # Get the current locoid that is connected to DLC tags
        TRAIN_ID_cr = df_tsdt[df_tsdt.First_Loco_ID == tag_loco_id].TRAIN_ID.values[0]
        # Get the next 5 trains (from the current connected train)
        df_tsdt = df_tsdt[df_tsdt.TRAIN_ID >= TRAIN_ID_cr][0:5]
    else:  # If no match take the next 5 trains from the train schedule
        # Keep only next 5 trains
        df_tsdt = df_tsdt[0:5]

    # Set Index
    df_tsdt.set_index('TRAIN_ID', inplace=True)

    # Fill train schedule details for next 5 trains at time dt
    trains = ['Train 1', 'Train 2', 'Train 3', 'Train 4', 'Train 5']
    idx = pd.MultiIndex.from_product([[dt], trains], names=['datetime', 'train'])

    import_cols = ['PLANNED_ARRIVAL_TIME_AWST', 'UPDATED_ON_AWST',
                   'PLANNED_COMMENCE_LOAD_AWST', 'PLANNED_COMPLETE_LOAD_AWST',
                   'PLANNED_DEPARTURE_TIME_AWST', 'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                   'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE', 'NUMBER_OF_CARS',
                   'NUMBER_OF_CARS_COMPLETED', 'PRODUCT_NAME', 'TRAINSTATUS', 'First_Loco_ID']

    cols = ['train_id'] + import_cols
    df = pd.DataFrame(None, idx, cols)

    ### Account for when there are not 5 next trains returned on the train schedule extract
    for train in trains:
        i = trains.index(train)
        try:
            train_id = df_tsdt.index[i]
            df.loc[(dt, train), 'train_id'] = train_id
            df.loc[(dt, train), import_cols] = df_tsdt.loc[train_id, import_cols]
            df.loc[(dt, train), 'cars_remaining'] = df.loc[(dt, train), 'NUMBER_OF_CARS']
        except IndexError:
            pass

    # Get number of cars loaded from pcs tag data
    loading_ind = uc1.find_tag_lag_value(df_tags, 'KD1.PPCS.TL0601DLC01_TRNLOADING_S', dt, 0)
    loaded_ind = uc1.find_tag_lag_value(df_tags, 'KD1.PPCS.TL0601DLC01_TRNLD_S', dt, 0)
    num_of_car_loaded = uc1.find_tag_lag_value(df_tags, 'KD1.PPCS.TL0601_WGNLD_C', dt, 0)
    cars_loaded = (loading_ind * num_of_car_loaded)

    # Update Train 1 cars remaining based on tag data
    if loading_ind == 1:  # if train is loading
        train_id_loading = df[df['TRAINSTATUS']=='Loading']['train_id'].tolist() ###DEV
        print('train_id_loading is: ', train_id_loading) ###DEV
        print('loading train index is: ', df[df['TRAINSTATUS']=='Loading'].index) ###DEV
        try:
            train_loading = str(df[df['TRAINSTATUS']=='Loading'].index.tolist()[0][1]) ###DEV
        except IndexError as err:                                                       ###DEV
            print('Handling IndexError in train loading dataframe index')               ###DEV
        

        if len(train_id_loading)==1: ###DEV
            train_loading_id = train_loading ###DEV
            df.loc[(dt, train_loading_id), 'cars_remaining'] = df.loc[(dt, train_loading_id), 'NUMBER_OF_CARS'] - cars_loaded ###DEV

        elif len(train_id_loading)>1: ###DEV
            print('Data issue: more than 1 train loading at the same time!') ###DEV
            train_loading_id = train_loading ###DEV
            df.loc[(dt, train_loading_id), 'cars_remaining'] = df.loc[(dt, train_loading_id), 'NUMBER_OF_CARS'] - cars_loaded ###DEV
        
        else: ###DEV
            print('No Train is loading') ###DEV
        # df.loc[(dt, 'Train 1'), 'cars_remaining'] = df.loc[(dt, 'Train 1'), 'NUMBER_OF_CARS'] - cars_loaded
    elif (loaded_ind == 1) | (df.loc[(dt, 'Train 1'), 'TRAINSTATUS'] == 'Loaded') | (
            df.loc[(dt, 'Train 1'), 'TRAINSTATUS'] == 'Departed'):  # If train is loaded
        df.loc[(dt, 'Train 1'), 'cars_remaining'] = 0
    else:  # if train has not start loading
        pass

    # Rename columns

    df.rename(columns={'TD_ACT_ARRIVALTIME': 'arrival_actual',
                       'TD_ACT_COMMLOAD': 'comm_loading_actual',
                       'TD_ACT_COMPLOAD': 'comp_loading_actual',
                       'TD_ACT_DEPMINE': 'depart_actual',
                       'PLANNED_ARRIVAL_TIME_AWST': 'arrival_sched',
                       'PLANNED_COMMENCE_LOAD_AWST': 'comm_loading_sched',
                       'PLANNED_COMPLETE_LOAD_AWST': 'comp_loading_sched',
                       'PLANNED_DEPARTURE_TIME_AWST': 'depart_sched',
                       'NUMBER_OF_CARS': 'num_cars',
                       'NUMBER_OF_CARS_COMPLETED': 'cars_completed',
                       'PRODUCT_NAME': 'product',
                       'TRAINSTATUS': 'train_status',
                       'UPDATED_ON_AWST': 'carloading_extracttime'
                       }, inplace=True)

    return df

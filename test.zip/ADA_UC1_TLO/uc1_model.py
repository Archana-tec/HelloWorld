import datetime
import pandas as pd
from azureml.core import Dataset, Datastore
import numpy as np
import ADA_UC1_TLO.uc1_utils as uc1
import ADA_UC1_TLO.uc1_data_preparation as uc1_data_preparation
import ADA_UC1_TLO.uc1_delay as uc1_delay
import ADA_UC1_TLO.uc1_tlo_forecast as uc1_tlo_forecast
import gc

def uc1_tlo_model_inference(dt, identify_delay_method='ml', delay_duration_method='GD-only', tlo_stage_timing_method='GD-historical', env='uat'):
    # LOAD INPUT DATA
    df_trainsched, df_tags, df_alarms = uc1_data_preparation.data_load(dt, dt, purpose='inference',env=env)

    # PREPROCESS INPUT DATA #
    df_trainsched, df_tags, df_alarms, df_car_weights = uc1_data_preparation.data_preprocessing(df_trainsched, df_tags, df_alarms)

    # RETRIEVE PREDICTION FROM PREVIOUS TIME PERIOD #
    # Convert timestamp to local time (AWST)
    dt_awst = dt + datetime.timedelta(hours=8) 

    ws = uc1.get_workspace(env)    
    tlo_forecast_model_output = 'tlo-forecast-model-output'
    last_predict_ts = None 
    output_col = ['train_id','train_status', 'product', 'num_cars', 'cars_remaining',
                'arrival_sched', 'arrival_actual', 'comm_loading_sched','comm_loading_forecast',
                'comm_loading_actual', 'comp_loading_sched', 'comp_loading_forecast','comp_loading_actual',
                'depart_sched','depart_forecast', 'depart_actual', 'train1_comm_loading_delay_model',
                'train1_loading_delay_model', 'train1_departure_delay_model','comp_loading_forecast_q1',
                'comp_loading_forecast_q3','train1_delay_duration_q1','train1_delay_duration_q3', 
                'delay_event_in_progress','delay_event_type','delay_event_cause','delay_event_asset','delay_event_start']
    
    try:  
        output_ds = Dataset.get_by_name(ws, name=tlo_forecast_model_output)
        df_output = output_ds.to_pandas_dataframe()
        df_output = df_output[df_output['train']=='Train 1']
        last_predict_ts = pd.to_datetime(df_output['datetime'][0])

        if last_predict_ts == dt_awst - datetime.timedelta(minutes = 3): # must be the prediction from the last 3 minute period
            df_output = df_output
            df_output['delay_event_start'] = pd.to_datetime(df_output['delay_event_start'])
        else:
            df_output = pd.DataFrame(columns=output_col) # if the prediction is not from the last 3 minute period then don't take it 
        df_output = df_output.replace('ERROR',np.NaN)

    except :
    # If the register output dataset is not available, create an empty df
        df_output = pd.DataFrame(columns=output_col)


    # PRODUCE MODEL OUTPUTS #
    # Fill in Train Schedule data for the next 5 trains at timestamp ts
    df = uc1_data_preparation.next_5trains_output_df(dt_awst, df_trainsched, df_tags)
    
    # Set delay duration method
    df_delaydur = uc1_delay.delay_duration(delay_duration_method, env)

    # Identify Delay events and forecast delay timings for the current ts
    df = uc1_delay.identify_delay(dt_awst, df, df_tags, df_alarms, df_car_weights, df_output, df_delaydur, identify_delay_method)

    # Calculate TLO forecast timings for each stage
    df = uc1_tlo_forecast.calc_forecast_timings(df, dt_awst, tlo_stage_timing_method) 

    # Format Data Type for final output
    df['train1_comm_loading_delay_model'] = df['train1_comm_loading_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)
    df['train1_loading_delay_model'] = df['train1_loading_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)
    df['train1_departure_delay_model'] = df['train1_departure_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)   
    df['train1_delay_duration_q1'] = df['train1_delay_duration_q1'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)   
    df['train1_delay_duration_q3'] = df['train1_delay_duration_q3'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)       
    df['comm_loading_forecast'] =  df['comm_loading_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
    df['comp_loading_forecast'] =  df['comp_loading_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
    df['depart_forecast'] =  df['depart_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
    df['comp_loading_forecast_q1'] =  df['comp_loading_forecast_q1'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)
    df['comp_loading_forecast_q3'] =  df['comp_loading_forecast_q3'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)

    # Re-order and keep only required columns
    df = df[output_col]

    # Register Output Dataset in AzureML    
    if env == 'dev':
        datastore = Datastore.get(ws, f'ada_results_storage_dev')
    else:
        datastore = Datastore.get(ws, f'ada_results_storage_prod')
    output_ds = Dataset.Tabular.register_pandas_dataframe(dataframe=df.reset_index(), target=datastore, name=tlo_forecast_model_output)  
    
    # Clean up memory by deleting interim dataframe and garabage collect
    del df_tags
    del df_alarms
    del df_car_weights
    del df_output
    del df_delaydur

    gc.collect() 
    return df


def uc1_tlo_model_backtest(dt_start, dt_end, identify_delay_method='rule-based', delay_duration_method='similar-mines', tlo_stage_timing_method='fixed', env="dev"):
    # LOAD INPUT DATA
    df_trainsched,df_tags,df_alarms = uc1_data_preparation.data_load(dt_start, dt_end, purpose='backtest',env=env)
    
    # PREPROCESS INPUT DATA #
    df_trainsched, df_tags, df_alarms, df_car_weights = uc1_data_preparation.data_preprocessing(df_trainsched,df_tags,df_alarms)

    # SET DATETIME RANGE FOR OUTPUT #
    delta = dt_end - dt_start
    delta_mins = delta.total_seconds()/60
    num_periods = delta_mins/3 + 1  # Number of 3 minute periods
    dt_start_awst = dt_start + datetime.timedelta(hours=8)   # Convert UTC timestamp dt to AWST
    datetime_range = pd.date_range(dt_start_awst, periods=num_periods, freq='3T')    # 3 minute intervals across date range
    
    output_col = ['train_id','train_status', 'product', 'num_cars', 'cars_remaining',
                'arrival_sched', 'arrival_actual', 'comm_loading_sched','comm_loading_forecast',
                'comm_loading_actual', 'comp_loading_sched', 'comp_loading_forecast','comp_loading_actual',
                'depart_sched','depart_forecast', 'depart_actual', 'train1_comm_loading_delay_model',
                'train1_loading_delay_model', 'train1_departure_delay_model','comp_loading_forecast_q1',
                'comp_loading_forecast_q3','train1_delay_duration_q1','train1_delay_duration_q3', 
                'delay_event_in_progress','delay_event_type','delay_event_cause','delay_event_asset','delay_event_start']

    # Get Workspace
    ws = uc1.get_workspace(env)      

    # LOOP THROUGH DATETIME RANGE TO PRODUCE OUTPUT # 
    df_combined = pd.DataFrame()
    tlo_forecast_model_output = 'tlo-forecast-model-output'
    last_predict_ts = None
    for ts in datetime_range:
        # Read the existing output registered table or create the output table empty
        if len(datetime_range)>1: # Used for back testing only 
            # For first timestamp in range, create empty dataframe
            if ts == datetime_range[0]:
                df_output = pd.DataFrame(columns=output_col)
                reg_ds = 0
            # For all other timestamps, retrieve the final dataframe from the previous timestamp
            else:
                df_output = df
                reg_ds = 0
        else: # production real time prediction (one timestamp at a time and the register dataset contains the previous 3 min output only)
            try:  
            # Retrieve the register output dataset
                output_ds = Dataset.get_by_name(ws, name=tlo_forecast_model_output)
                df_output = output_ds.to_pandas_dataframe()
                df_output = df_output[df_output['train']=='Train 1']
                last_predict_ts = pd.to_datetime(df_output['datetime'].values[0])

                if last_predict_ts == ts - datetime.timedelta(minutes = 3): # must be the prediction from the last 3 minute period
                    df_output = df_output
                    df_output['delay_event_start'] = pd.to_datetime(df_output['delay_event_start'])
                else:
                    df_output = pd.DataFrame(columns=output_col) # if the prediction is not from the last 3 minute then don't take it
                df_output = df_output.replace('ERROR',np.NaN)
                
            except :
            # If the register output dataset is not available, create an empty df
                df_output = pd.DataFrame(columns=output_col)
            reg_ds = 1 
                
        # Fill in Train Schedule data for the next 5 trains at timestamp ts
        df = uc1_data_preparation.next_5trains_output_df(ts, df_trainsched, df_tags)
        
        # Set delay duration method
        df_delaydur = uc1_delay.delay_duration(delay_duration_method, env)

        # Identify Delay events and forecast delay timings for the current ts
        df = uc1_delay.identify_delay(ts, df, df_tags, df_alarms, df_car_weights, df_output, df_delaydur, identify_delay_method)

        # Calculate TLO forecast timings for each stage
        df = uc1_tlo_forecast.calc_forecast_timings(df, ts, tlo_stage_timing_method) 

        # Format Data Type for final output
        df['train1_comm_loading_delay_model'] = df['train1_comm_loading_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)
        df['train1_loading_delay_model'] = df['train1_loading_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)
        df['train1_departure_delay_model'] = df['train1_departure_delay_model'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)   
        df['train1_delay_duration_q1'] = df['train1_delay_duration_q1'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)   
        df['train1_delay_duration_q3'] = df['train1_delay_duration_q3'].apply(lambda x:x.total_seconds()/60).round(1).fillna(0)       
        df['comm_loading_forecast'] =  df['comm_loading_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
        df['comp_loading_forecast'] =  df['comp_loading_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
        df['depart_forecast'] =  df['depart_forecast'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S"))
        df['comp_loading_forecast_q1'] =  df['comp_loading_forecast_q1'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)
        df['comp_loading_forecast_q3'] =  df['comp_loading_forecast_q3'].apply(lambda x:x.strftime("%Y-%m-%d %H:%M:%S") if pd.notnull(x) else x)
        
        # Re-order and keep only required columns
        df = df[output_col]

        df_combined = df_combined.append(df)

    # Register the output of the model appropriately
    if reg_ds == 1: # if the output dataset need to be registered

        # Register Output Dataset in AzureML    
        if env == 'dev':
            blob_datastore_name = 'ada_results_storage_dev'
        else:
            blob_datastore_name = 'ada_results_storage_prod'
        datastore = Datastore.get(ws, blob_datastore_name)
        output_ds = Dataset.Tabular.register_pandas_dataframe(dataframe = df_combined.reset_index(),target = datastore,name = tlo_forecast_model_output)  

    else: # back testing only -- no need to register the output
        pass 

    return df_combined
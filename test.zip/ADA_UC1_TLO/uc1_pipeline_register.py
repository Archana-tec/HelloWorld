# Import libraries
import argparse
import datetime
from azureml.core import Model, Run

# Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('--input_folder')
parser.add_argument('--training_start')
parser.add_argument('--training_end')
args = parser.parse_args()
model_folder = args.input_folder 

# Get the experiment run context
run = Run.get_context()

# Get run info
try: run_id = run._run_id 
except: run_id = ''
try: run_name = run._run_name
except: run_name = ''
try: run_details_url = run._run_details_url
except: run_details_url = ''

if args.training_end =='default':
    training_end_string =  datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days = 7), '%Y-%m-%d')
else: 
    training_end_string = args.training_end

# Model registry description
description = f"Training dates: {args.training_start} to {training_end_string}, Run Name: {run_name} Run ID: {run_id}, Run Details: {run_details_url}"

# Register model
Model.register(workspace = run.experiment.workspace,
               model_path = model_folder,
               model_name = 'ADA_UC1_TLO_Model',
               description = description
               )

run.complete()
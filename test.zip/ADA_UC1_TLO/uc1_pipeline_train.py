import uuid
import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Run
import datetime
import pandas as pd
import numpy as np
import shutil
import pickle
import argparse
import load_ADA_data
from pyspark.sql.types import StructType,StructField, StringType, IntegerType,  LongType,TimestampType

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

parser = argparse.ArgumentParser()
parser.add_argument("--input_dataset_dir")
parser.add_argument("--output_folder")
parser.add_argument("--training_start")
parser.add_argument("--training_end")
args = parser.parse_args()
input_dataset_dir = args.input_dataset_dir
output_folder = args.output_folder

run = Run.get_context()

# Create Output Directory
os.makedirs(output_folder, exist_ok=True)
os.makedirs(output_folder+'/UC1_trained_components', exist_ok=True)



"""
###
TRAINED COMPONENT 1
DELAY DURATION BASED ON GUDAI-DARRI DATA
###
"""

print(f"[{datetime.datetime.now()}] Begin training Gudai Darri-based Delay Duration....")

# Start Spark Session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")
# Load FPTU data
fptu_sdf = spark.read.parquet(input_dataset_dir+'/FPTU**')
fptu = fptu_sdf.toPandas()

# Data Prep
fptu.Effect = fptu.Effect.str.replace('Fault - ','Trip - ')
fptu['duration'] = fptu.FixedPlantTimeUsageEventFinish - fptu.FixedPlantTimeUsageEventStart
fptu['duration_mins'] = fptu['duration'].apply(lambda x:x.total_seconds()/60).round(1)

# Remove before 6th June due to highly inconsistent data
fptu = fptu[fptu.FixedPlantTimeUsageEventStart > datetime.datetime(2022,6,6)]

def q1(x):
    return x.quantile(0.25)

def q3(x) :
    return x.quantile(0.75)

f = ['count','median', q1, q3]

# Create Lookup Table
effect_only_group = fptu.groupby(by='Effect')['duration_mins'].agg(f).reset_index()
effect_cause_group = fptu.groupby(by=['Effect','Cause'])['duration_mins'].agg(f).reset_index()
effect_cause_asset_group = fptu.groupby(by=['Effect','Cause','CauseFixedPlantAssetCode'])['duration_mins'].agg(f).reset_index()
asset_only_group = fptu.groupby(by=['CauseFixedPlantAssetCode'])['duration_mins'].agg(f).reset_index()
fully_unknown = pd.DataFrame({'Effect':['Unknown'],'count':[fptu['duration_mins'].count()],'median':[fptu['duration_mins'].median()],'q1':[q1(fptu['duration_mins'])],'q3':[q3(fptu['duration_mins'])]})

gd_delay = pd.concat([effect_cause_asset_group, effect_cause_group, effect_only_group, asset_only_group, fully_unknown]).reset_index(drop=True)

gd_delay.rename(columns={'count':'event_count', 'median':'median_duration','Effect':'effect','Cause':'cause','q1':'q1_duration','q3':'q3_duration'}, inplace=True)
gd_delay.sort_values(by='event_count', ascending=False, inplace=True)
gd_delay.insert(loc=0, column='delay_event', value='')
gd_delay.loc[~pd.isnull(gd_delay.cause),'delay_event'] = gd_delay['effect'] +str(r' / ')+ gd_delay['cause']
gd_delay.loc[pd.isnull(gd_delay.cause),'delay_event'] = gd_delay['effect']


# Export to Output Folder
gd_delay.to_csv(output_folder+'/UC1_trained_components/gd_delay_duration_lookup.csv', index=False)

print(f"[{datetime.datetime.now()}] Training complete: Gudai Darri-based Delay Duration")



"""
###
TRAINED COMPONENT 2
ML-BASED DELAY IDENTIFICATION
###
"""

print(f"[{datetime.datetime.now()}] Begin training ML-based Delay Identification model...")

# Import ML libraries and UC1 packages

from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import make_scorer, confusion_matrix, precision_recall_fscore_support, f1_score
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sktime.forecasting.model_selection import temporal_train_test_split
import matplotlib.pyplot as plt
import joblib
from pandasql import sqldf

import ADA_UC1_TLO.uc1_utils as uc1
import ADA_UC1_TLO.uc1_data_preparation as uc1_data_preparation

## INGEST AND MANIPULATE TRAINING DATA ##

# Training set datetime range
## Set Training End
if args.training_end == 'default':
    dt_now = datetime.datetime.now()
    training_end_utc = (dt_now - datetime.timedelta(minutes=dt_now.minute, seconds=dt_now.second,
                                                    microseconds=dt_now.microsecond)) - datetime.timedelta(days=7)
else:
    training_end_utc = datetime.datetime.strptime(args.training_end, '%Y-%m-%d') + datetime.timedelta(days=1)

if args.training_start == 'default':
    training_start_utc = training_end_utc - datetime.timedelta(days=90)  # By Default, we use recent 90 days of data to train the ml model.
else:
    training_start_utc = datetime.datetime.strptime(args.training_start, '%Y-%m-%d')

training_start_awst = training_start_utc + datetime.timedelta(hours=8)
training_end_awst = training_end_utc + datetime.timedelta(hours=8)

print(f"[{datetime.datetime.now()}] ML model training period start: {str(training_start_awst)}")
print(f"[{datetime.datetime.now()}] ML model training period end: {str(training_end_awst)}")

delta = training_end_awst - training_start_awst
delta_mins = delta.total_seconds() / 60
num_periods = delta_mins + 1  # Number of 1 minute periods
datetime_range = pd.date_range(training_start_awst, periods=num_periods,
                               freq='1T')  # 1 minute intervals across date range

# TRAIN SCHEDULE #
print(f"[{datetime.datetime.now()}] Loading Train Schedule parquet ...")
trainsched_sdf = spark.read.parquet(input_dataset_dir + '/train_schedule**')
print(f"[{datetime.datetime.now()}] Train scheduler - to Pandas ...")
df_trainsched = trainsched_sdf.toPandas()
print(f"[{datetime.datetime.now()}] df_trainsched shape = {df_trainsched.shape}")

# Load PCS Tags Raw Data
print(f"[{datetime.datetime.now()}] Loading Tags parquet ...")
tags_sdf = spark.read.parquet(input_dataset_dir + '/PCS_tags')
print(f"[{datetime.datetime.now()}] Tags - to Pandas ...")
df_tags = tags_sdf.toPandas()
print(f"[{datetime.datetime.now()}] df_tags shape = {df_tags.shape}")

# DELAY DATA (TIME SERIES) - TARGET VARIABLE
# Load from previous pipeline step (1 = Delay event in progress)
print(f"[{datetime.datetime.now()}] Loading delay parquet ...")
df_delay = pd.read_parquet(input_dataset_dir + '/FPTU_delay_ts')
print(f"[{datetime.datetime.now()}] df_delay shape = {df_delay.shape}")

# Preprocess df_trainsched and df_tags
print(f"[{datetime.datetime.now()}] data_preprocessing started ...")
df_trainsched, df_tags, df_alarms, df_car_weights = uc1_data_preparation.data_preprocessing(df_trainsched, df_tags,
                                                                                            pd.DataFrame())
print(f"[{datetime.datetime.now()}] data_preprocessing done ...")
print(f"[{datetime.datetime.now()}] df_trainsched shape = {df_trainsched.shape}")
print(f"[{datetime.datetime.now()}] df_tags shape = {df_tags.shape}")
print(f"[{datetime.datetime.now()}] df_alarms shape = {df_alarms.shape}")
print(f"[{datetime.datetime.now()}] df_car_weights shape = {df_car_weights.shape}")

print(f"[{datetime.datetime.now()}] STEP 1 ...")
# Get the current Train per each timestamp (1 min)
df_trainsched.sort_values(['SCHEDULE_TRAIN_ID', 'UPDATED_ON_AWST'], inplace=True)
df_trainsched['Record_End'] = df_trainsched.groupby('SCHEDULE_TRAIN_ID')['UPDATED_ON_AWST'].shift(-1)
df_trainsched['Record_End'].fillna(datetime.datetime(2059, 12, 31), inplace=True)
df_trainsched['TD_ACT_DEPMINE'].fillna(datetime.datetime(2099, 1, 1), inplace=True)
# Get Loco ID from Tag Data Per each Minute
loco_tag = df_tags[df_tags.tagid == 'KD1.PPCS.TL0601DLC01_LNKDTRNID_S'][['time', 'value']].set_index('time').resample('T').ffill()
df_interval = pd.DataFrame(datetime_range, columns=['datetime'])
df_interval = df_interval.merge(loco_tag, left_on='datetime', right_index=True, how='inner')
df_interval.rename(columns={'value': 'loco_from_tag'}, inplace=True)
print(f"[{datetime.datetime.now()}] df_interval shape = {df_interval.shape}")

print(f"[{datetime.datetime.now()}] STEP 2 - START ...")
sdf_interval=spark.createDataFrame(df_interval)


trainsched_schema = StructType( [
                StructField("SCHEDULE_TRAIN_ID", LongType(), True),
                StructField("TRAIN_ID", StringType(), True),
                StructField("LOCOS", StringType(), True),
                StructField("NUMBER_OF_CARS", LongType(), True),
                StructField("NUMBER_OF_CARS_COMPLETED", StringType() , True), # This is string, but we will cast to Long later
                StructField("PRODUCT_NAME", StringType() , True),
                StructField("PLANNED_ARRIVAL_TIME_AWST", TimestampType() , True),
                StructField("PLANNED_COMMENCE_LOAD_AWST", TimestampType() , True),
                StructField("PLANNED_COMPLETE_LOAD_AWST", TimestampType() , True),
                StructField("PLANNED_DEPARTURE_TIME_AWST", TimestampType() , True),
                StructField("TD_ACT_ARRIVALTIME", TimestampType() , True),
                StructField("TD_ACT_COMMLOAD", TimestampType() , True),
                StructField("TD_ACT_COMPLOAD", TimestampType() , True),
                StructField("TD_ACT_DEPMINE", TimestampType() , True),
                StructField("TRAINSTATUS", StringType() , True),
                StructField("CREATED_ON_AWST", TimestampType() , True),
                StructField("UPDATED_ON_AWST", TimestampType() , True),
                StructField("DELETED_ON_AWST", StringType() , True), # This is string, but we will cast to timestamp later
                StructField("file_timestamp", StringType() , True),
                StructField("First_Loco_ID", StringType() , True),
                StructField("Record_End", TimestampType() , True),
])
df_trainsched['NUMBER_OF_CARS_COMPLETED'] = df_trainsched['NUMBER_OF_CARS_COMPLETED'].replace(np.NaN, -99999).astype('int')
df_trainsched['First_Loco_ID'] = df_trainsched['First_Loco_ID'].fillna(-99999).astype('int')
df_trainsched['DELETED_ON_AWST'] = df_trainsched['DELETED_ON_AWST'].fillna('1970-01-01 00:00:00')
df_trainsched['DELETED_ON_AWST'] = df_trainsched['DELETED_ON_AWST'].astype(str)

sdf_trainsched=spark.createDataFrame(df_trainsched, schema=trainsched_schema)
sdf_trainsched = sdf_trainsched.withColumn("DELETED_ON_AWST",  when(col("DELETED_ON_AWST")=='1970-01-01 00:00:00',None).otherwise(to_timestamp("DELETED_ON_AWST")))
sdf_trainsched = sdf_trainsched.withColumn("NUMBER_OF_CARS_COMPLETED",  when(col("NUMBER_OF_CARS_COMPLETED")=='-99999',None).otherwise(col("NUMBER_OF_CARS_COMPLETED").cast(LongType())))
sdf_trainsched = sdf_trainsched.withColumn("First_Loco_ID",  when(col("First_Loco_ID")=='-99999',None).otherwise(col("First_Loco_ID").cast(LongType())))

sdf_interval.createOrReplaceTempView('df_interval')
sdf_trainsched.createOrReplaceTempView('df_trainsched')

x = sdf_interval.agg({"datetime": "max"}).collect()[0]
max_interval_datetime = x['max(datetime)']
x = sdf_interval.agg({"datetime": "min"}).collect()[0]
min_interval_datetime = x['min(datetime)']

ranges = load_ADA_data.hdfs_range(min_interval_datetime, max_interval_datetime).replace("{","").replace("}*","").split(",")

mode='overwrite'
id = str(uuid.uuid4())
print(f"[{datetime.datetime.now()}] STEP 2 - UUID {id} ...")
for r in ranges:
    sdf_interval_temp = sdf_interval.where(f"datetime like '{r}-%'")
    sdf_interval_temp.createOrReplaceTempView('df_interval')
    print(f"[{datetime.datetime.now()}] STEP 2 - {r} START ...")
    # Write your query in SQL syntax
    cond_join = '''
        select 
            df_left.datetime,
            df_left.loco_from_tag,
            df_right.*,
            case when df_right.First_Loco_ID = df_left.loco_from_tag then 1 else 2 end as loco_rank,
            row_number() over (partition by df_left.datetime order by PLANNED_ARRIVAL_TIME_AWST) as rank
        from df_interval as df_left
        join df_trainsched as df_right
        on
            df_left.datetime >= df_right.UPDATED_ON_AWST
        and df_left.datetime < df_right.Record_End
        and df_right.TD_ACT_DEPMINE>df_left.datetime
    '''
    # Now, get your queries results as dataframe using the sqldf object that you created
    spark.sql(cond_join).repartition(1).write.mode(mode).parquet(f'/tmp/{id}/')
    if mode =='overwrite':
        mode = 'append'
    print(f"[{datetime.datetime.now()}] STEP 2 - {r} END ...")
df = pd.read_parquet(f'/tmp/{id}/')
print(f"[{datetime.datetime.now()}] STEP 2 - df shape = {df.shape}")
print(f"[{datetime.datetime.now()}] STEP 2 - END ...")

print(f"[{datetime.datetime.now()}] STEP 3 ...")
df.datetime = pd.to_datetime(df.datetime)
# Get the first train at each datetime
df = df.sort_values(['datetime', 'loco_rank', 'rank']).drop_duplicates(subset=['datetime'], keep='first')

df.rename(columns={'TD_ACT_ARRIVALTIME': 'arrival_actual',
                   'TD_ACT_COMMLOAD': 'comm_loading_actual',
                   'TD_ACT_COMPLOAD': 'comp_loading_actual',
                   'TD_ACT_DEPMINE': 'depart_actual',
                   'PLANNED_ARRIVAL_TIME_AWST': 'arrival_sched',
                   'PLANNED_COMMENCE_LOAD_AWST': 'comm_loading_sched',
                   'PLANNED_COMPLETE_LOAD_AWST': 'comp_loading_sched',
                   'PLANNED_DEPARTURE_TIME_AWST': 'depart_sched',
                   'NUMBER_OF_CARS': 'num_cars',
                   'NUMBER_OF_CARS_COMPLETED': 'cars_completed',
                   'PRODUCT_NAME': 'product',
                   'TRAINSTATUS': 'train_status',
                   'UPDATED_ON_AWST': 'carloading_extracttime'
                   }, inplace=True)
df['Timestamp'] = df.datetime
df.set_index('datetime', drop=True, inplace=True)
df.arrival_actual = pd.to_datetime(df.arrival_actual)

print(f"[{datetime.datetime.now()}] Train Schedule processing complete")

# Select tags that are used for the model
df_tags_selected = df_tags[df_tags['tagid'].isin(
    ['KD1.PPCS.BN0601WT01_PV', 'KD1.PPCS.CH0601CH01_LWR_S', 'KD1.PPCS.TL0601_SIT_PV', 'KD1.PPCS.RC0601CV21_CLCDCHRT',
     'KD1.PPCS.TL0601_LUMPS_S',
     'KD1.PPCS.CV0622WT01_ACTDAT_BELTSPD', 'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST', 'KD1.PPCS.RC0601_RelSeqRun_S',
     'KD1.PPCS.RC0601_ReclaimSeqRun_S', 'KD1.PPCS.TL0601DLC01_TRNLD_S', 'KD1.PPCS.TL0601DLC01_TRNLOADING_S',
     'KD1.PPCS.TL0601DLC01_LNK_S',
     'KD1.PPCS.TL0601DLC01_TRNCLEARING_S', 'KD1.PPCS.TL0601_WGNLD_C', 'KD1.PPCS.TL0601DLC01_LNKDTRNID_S',
     'KD1.PPCS.TL0601_LOCOIN_S',
     'KD1.PPCS.TL0601DLC01_TRNPRESENTED_S', 'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',
     'KD1.PPCS.CV0622WT01_ACTDAT_TONRT',
     'KD1.PPCS.CV0622WT02_ACTDAT_TONRT'
     ])]

print(f"[{datetime.datetime.now()}] STEP 4 ...")
cond_join = '''
    select 
        df_left.datetime,
        df_right.tagid,
        df_right.value,
        df_right.time
    from df as df_left
    join df_tags_selected as df_right
    on
        df_left.[datetime] >= df_right.[time]
    and df_left.[datetime] < df_right.[next_time]
'''

# Now, get your queries results as dataframe using the sqldf object that you created
df_tags_selected = sqldf(cond_join, locals())
print(f"[{datetime.datetime.now()}] STEP 5 ...")

df_tags_selected.datetime = pd.to_datetime(df_tags_selected.datetime)
# Unpivot the table to one tag per one column
df_tags_selected = df_tags_selected.pivot(index='datetime', columns='tagid')[['value', 'time']]

print(f"[{datetime.datetime.now()}] STEP 5 - df_tags_selected shape = {df_tags_selected.shape}")

# Join pivoted tags with df
df_combined = df.merge(df_tags_selected, left_index=True, right_index=True)
print(f"[{datetime.datetime.now()}] STEP 5 - df_combined shape = {df_combined.shape}")

df_combined = df_combined[[
    'num_cars',
    'cars_completed',
    'arrival_actual',
    'train_status',
    'First_Loco_ID',
    'Timestamp',
    ('value', 'KD1.PPCS.TL0601DLC01_LNKDTRNID_S'),
    ('value', 'KD1.PPCS.TL0601DLC01_LNK_S'),
    ('value', 'KD1.PPCS.TL0601DLC01_TRNCLEARING_S'),
    ('value', 'KD1.PPCS.TL0601DLC01_TRNLD_S'),
    ('value', 'KD1.PPCS.TL0601DLC01_TRNLOADING_S'),
    ('value', 'KD1.PPCS.TL0601DLC01_TRNPRESENTED_S'),
    ('value', 'KD1.PPCS.TL0601_LOCOIN_S'),
    ('value', 'KD1.PPCS.TL0601_WGNLD_C'),
    ('value', 'KD1.PPCS.BN0601WT01_PV'),
    ('value', 'KD1.PPCS.CH0601CH01_LWR_S'),
    ('value', 'KD1.PPCS.TL0601_SIT_PV'),
    ('value', 'KD1.PPCS.RC0601CV21_CLCDCHRT'),
    ('value', 'KD1.PPCS.TL0601_LUMPS_S'),
    ('value', 'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST'),
    ('value', 'KD1.PPCS.CV0622WT01_ACTDAT_TONRT'),
    ('value', 'KD1.PPCS.CV0622WT02_ACTDAT_TONRT'),
    ('value', 'KD1.PPCS.CV0622WT01_ACTDAT_BELTSPD'),
    ('value', 'KD1.PPCS.RC0601_RelSeqRun_S'),
    ('value', 'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes'),
    ('value', 'KD1.PPCS.RC0601_ReclaimSeqRun_S'),
    ('time', 'KD1.PPCS.TL0601DLC01_LNKDTRNID_S'),
    ('time', 'KD1.PPCS.TL0601DLC01_TRNLD_S'),
    ('time', 'KD1.PPCS.TL0601DLC01_TRNLOADING_S'),
]]
# Rename columns with better names
df_combined.columns = ['num_cars', 'cars_completed', 'arrival_actual', 'train_status', 'First_Loco_ID', 'timestamp',
                       'TL0601DLC01_LNKDTRNID_S_value', 'TL0601DLC01_LNK_S_value',
                       'TL0601DLC01_TRNCLEARING_S_value', 'TL0601DLC01_TRNLD_S_value', 'TL0601DLC01_TRNLOADING_S_value',
                       'TL0601DLC01_TRNPRESENTED_S_value', 'TL0601_LOCOIN_S_value',
                       'car_loaded', 'BinLevel_0', 'Chute_Lowered_0', 'Train_Speed_0', 'RC0601_dischargerate_0',
                       'Train_Lump', 'CV0622_Belt_Tonnage_0', 'CV0622_Belt_Tph_1', 'CV0622_Belt_Tph_2',
                       'CV0622_Belt_Speed1_0', 'RC0601_Relocation_0', 'RC0601CV21WT01_0', 'RC0601_Reclaiming_0',
                       'TL0601DLC01_Depart_time', 'TL0601DLC01_TRNLD_S_time',
                       'TL0601DLC01_TRNLOADING_S_time']

print(f"[{datetime.datetime.now()}] STEP 6 ...")
# Find backdated loaded complete timings
df_combined['TL0601DLC01_TRNLD_S_time'] = pd.to_datetime(df_combined.TL0601DLC01_TRNLD_S_time).fillna(
    datetime.datetime(1900, 1, 1))
df_combined['TL0601DLC01_TRNLD_S_time'] = [uc1.round_to_next_min(ts) for ts in df_combined['TL0601DLC01_TRNLD_S_time']]
df_combined['time_prev_2hours'] = df_combined['timestamp'] - datetime.timedelta(hours=2)
df_combined['loaded_prev_2hours'] = df_combined['TL0601DLC01_TRNLD_S_time'].apply(
    lambda x: x - datetime.timedelta(hours=2))
df_combined['loaded_prev_1min'] = df_combined['TL0601DLC01_TRNLD_S_time'].apply(
    lambda x: x - datetime.timedelta(minutes=1))
df_combined['loaded_prev_2hours'] = df_combined['TL0601DLC01_TRNLD_S_time'].apply(
    lambda x: x - datetime.timedelta(hours=2))
df_combined['loaded_prev_4hours'] = df_combined['TL0601DLC01_TRNLD_S_time'].apply(
    lambda x: x - datetime.timedelta(hours=4))
# Find load commence and completed datetimes at those backdated timings
ts_tags = df_combined[['TL0601DLC01_TRNLD_S_time', 'TL0601DLC01_TRNLOADING_S_time', 'timestamp']]
print(f"[{datetime.datetime.now()}] STEP 7 ...")

cond_join = '''
    select 
        df_left.datetime,
        df1.TL0601DLC01_TRNLOADING_S_time as tag_load_commence_clearing_ts,
        df2.TL0601DLC01_TRNLOADING_S_time as tag_load_commence_loaded_ts,
        df3.TL0601DLC01_TRNLD_S_time as tag_load_complete_depart_ts,
        df4.TL0601DLC01_TRNLOADING_S_time as tag_load_commence_depart_ts
    from df_combined as df_left
    inner join ts_tags as df1
    on
        df_left.[time_prev_2hours] = df1.[timestamp]   
    inner join ts_tags as df2
    on
        df_left.[loaded_prev_2hours] = df2.[timestamp]
    inner join ts_tags as df3
    on
        df_left.[loaded_prev_1min] = df3.[timestamp]
    inner join ts_tags as df4
    on 
        df_left.loaded_prev_4hours = df4.[timestamp]
'''
# Now, get your queries results as dataframe using the sqldf object that you created
df_second_join = sqldf(cond_join, locals())
print(f"[{datetime.datetime.now()}] STEP 8 ...")
df_second_join.datetime = pd.to_datetime(df_second_join.datetime)
# Combine backdated features with combined datafram
df_combined = df_combined.merge(df_second_join, left_on='timestamp', right_on='datetime')
df_combined = df_combined.merge(df_delay, left_on='timestamp', right_index=True)

# Align datetime format for timestamp fields
datetime_cols = ['arrival_actual', 'TL0601DLC01_Depart_time', 'TL0601DLC01_TRNLD_S_time',
                 'TL0601DLC01_TRNLOADING_S_time', 'time_prev_2hours',
                 'loaded_prev_2hours', 'loaded_prev_1min', 'loaded_prev_4hours', 'datetime',
                 'tag_load_commence_clearing_ts',
                 'tag_load_commence_loaded_ts', 'tag_load_complete_depart_ts', 'tag_load_commence_depart_ts']

for cols in datetime_cols:
    df_combined[cols] = pd.to_datetime(df_combined[cols])

print(f"[{datetime.datetime.now()}] STEP 9 ...")
# Find out if the train is unloaded at each timestamp
unloaded_train = df_combined.apply(
    lambda x: uc1.calc_unloaded_train(x.TL0601DLC01_TRNLOADING_S_value, x.TL0601DLC01_Depart_time,
                                      x.TL0601DLC01_TRNLOADING_S_time), axis=1)

print(f"[{datetime.datetime.now()}] STEP 9 - unlaoded_train = {unloaded_train.size}")
print(f"[{datetime.datetime.now()}] STEP 9 - df_combined shape = {df_combined.shape}")
df_combined['unloaded_train'] = unloaded_train
# Get train_status per each timestamp
train_status_output = df_combined.apply(
    lambda x: uc1.train_status_logic(x.timestamp, x.train_status, x.num_cars, x.arrival_actual,
                                     x.TL0601DLC01_LNK_S_value, x.TL0601DLC01_TRNLOADING_S_value,
                                     x.TL0601DLC01_TRNLD_S_value, x.TL0601DLC01_TRNCLEARING_S_value, x.car_loaded,
                                     x.First_Loco_ID, x.TL0601_LOCOIN_S_value, x.TL0601DLC01_LNKDTRNID_S_value,
                                     x.TL0601DLC01_TRNLD_S_time, x.TL0601DLC01_TRNLOADING_S_time,
                                     x.TL0601DLC01_Depart_time, x.tag_load_commence_clearing_ts,
                                     x.tag_load_commence_loaded_ts, x.tag_load_complete_depart_ts,
                                     x.tag_load_commence_depart_ts, x.unloaded_train,
                                     x.TL0601DLC01_TRNPRESENTED_S_value), axis=1)

# Get values of each output
train_status = []
ts_total_cars = []
actual_arrival = []
actual_load_commence_ts = []
actual_load_complete_ts = []
actual_departure_ts = []

for i in train_status_output:
    train_status.append(i[0])
    ts_total_cars.append(i[1])
    actual_arrival.append(i[2])
    actual_load_commence_ts.append(i[3])
    actual_load_complete_ts.append(i[4])
    actual_departure_ts.append(i[4])

# ### Additional Feature Engineering ###
df_combined['CV0622_Belt_Tonnage_2'] = df_combined['CV0622_Belt_Tonnage_0'] - df_combined[
    'CV0622_Belt_Tonnage_0'].shift(2)
df_combined['BinLevel_1'] = df_combined['BinLevel_0'].shift(1)
df_combined['Chute_Lowered_1'] = df_combined['Chute_Lowered_0'].shift(1)
df_combined['Train_Speed_1'] = df_combined['Train_Speed_0'].shift(1)
df_combined['car_loaded_1'] = df_combined['car_loaded'] - df_combined['car_loaded'].shift(1)
df_combined['CV0622_Belt_Speed1_1'] = df_combined['CV0622_Belt_Speed1_0'].shift(1)
df_combined['CV0622_Belt_Tonnage_1'] = df_combined['CV0622_Belt_Tonnage_0'] - df_combined[
    'CV0622_Belt_Tonnage_0'].shift(1)
df_combined['RC0601_Reclaiming_1'] = df_combined['RC0601_Reclaiming_0'].shift(1)
df_combined['RC0601_dischargerate_1'] = df_combined['RC0601_dischargerate_0'].shift(1)
df_combined['RC0601_dischargerate_2'] = df_combined['RC0601_dischargerate_0'].shift(2)
df_combined['RC0601CV21WT01_1'] = df_combined['RC0601CV21WT01_0'] - df_combined['RC0601CV21WT01_0'].shift(1)
df_combined['RC0601CV21WT01_2'] = df_combined['RC0601CV21WT01_0'] - df_combined['RC0601CV21WT01_0'].shift(2)

df_combined['train_status'] = train_status
df_combined['actual_load_commence_ts'] = pd.to_datetime(actual_load_commence_ts)
df_combined['actual_load_complete_ts'] = pd.to_datetime(actual_load_complete_ts)
df_combined['ts_total_cars'] = pd.to_numeric(ts_total_cars)
df_combined['actual_arrival'] = pd.to_datetime(actual_arrival)

df_combined.loc[df_combined['train_status'].isin(['Arrived', 'Pre-Loading']), 'since_arrival'] = df_combined[
                                                                                                     'datetime'] - \
                                                                                                 df_combined[
                                                                                                     'actual_arrival']
df_combined.loc[df_combined['train_status'].isin(['Loaded', 'Clearing']), 'since_completion'] = df_combined[
                                                                                                    'datetime'] - \
                                                                                                df_combined[
                                                                                                    'actual_load_complete_ts']
df_combined.loc[df_combined['train_status'].isin(['Arrived', 'Expected']), 'car_remaining'] = df_combined[
    'ts_total_cars']
df_combined.loc[df_combined['train_status'] == 'Loading', 'car_remaining'] = df_combined['ts_total_cars'] - df_combined[
    'car_loaded']
df_combined.loc[df_combined['train_status'].isin(['Loaded', 'Departed', 'Ready for Departure']), 'car_remaining'] = 0
df_combined['since_arrival'] = df_combined['since_arrival'].apply(lambda x: x.total_seconds() / 60).fillna(0)
df_combined['since_completion'] = df_combined['since_completion'].apply(lambda x: x.total_seconds() / 60).fillna(0)
df_combined['car_remaining'].fillna(0, inplace=True)

# # Drop Unwanted Variables
df_combined.drop(columns=['CV0622_Belt_Tonnage_0', 'TL0601DLC01_LNKDTRNID_S_value', 'TL0601DLC01_LNK_S_value',
                          'TL0601DLC01_TRNCLEARING_S_value', 'TL0601DLC01_TRNLD_S_value',
                          'TL0601DLC01_TRNLOADING_S_value', 'car_loaded', 'TL0601DLC01_TRNPRESENTED_S_value',
                          'TL0601_LOCOIN_S_value', 'TL0601DLC01_Depart_time',
                          'TL0601DLC01_TRNLD_S_time', 'TL0601DLC01_TRNLOADING_S_time', 'time_prev_2hours',
                          'loaded_prev_2hours', 'loaded_prev_1min', 'loaded_prev_4hours', 'datetime',
                          'tag_load_commence_clearing_ts', 'tag_load_commence_loaded_ts', 'tag_load_complete_depart_ts',
                          'First_Loco_ID', 'tag_load_commence_depart_ts',
                          'actual_load_commence_ts', 'actual_load_complete_ts', 'ts_total_cars', 'actual_arrival',
                          'unloaded_train', 'num_cars', 'cars_completed', 'arrival_actual',
                          'Chute_Lowered_0', 'RC0601_Relocation_0'], inplace=True)
# Rename columns
df_combined.rename(
    columns={'timestamp': 'Datetime', 'train_status': 'Train_Status', 'delay_in_progress': 'Delay_In_Progress'},
    inplace=True)
# # Drop timings when the train hasn't arrive or departed
df_combined = df_combined[~df_combined['Train_Status'].isin(['Expected', 'Departed', 'Timestamp Error'])]
# # Encode Train Status
ts_dict = {'Arrived': 1, 'Pre-Loading': 1, 'Loading': 2, 'Loaded': 3, 'Clearing': 3, 'Ready for Departure': 4}
reversedDict = {val: key for (key, val) in ts_dict.items()}
df_combined['Train_Status'] = df_combined['Train_Status'].map(ts_dict)

# # Remove nulls caused by shift
df_combined = df_combined.dropna(how='any')

# # Remove Period where the tag data are missing, or during mine shutdown
lack_data_start = datetime.datetime(2022, 9, 7, 0, 0)
lack_data_end = datetime.datetime(2022, 9, 12, 8, 0)

df_combined = df_combined[~df_combined.Datetime.between(lack_data_start, lack_data_end)]

print(f"[{datetime.datetime.now()}] Feature Engineering complete.")
print(f"[{datetime.datetime.now()}] STEP 10 ...")
## MODEL TRAINING ##

# Drop unwanted features
col = ['Datetime', 'Delay_In_Progress']
X = df_combined.loc[:, ~df_combined.columns.isin(col)]
y = df_combined['Delay_In_Progress'].astype('int')


# # Random Split dataset into train and test
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y)

# Temporal Split dataset into train and test
y_train, y_test, X_train, X_test = temporal_train_test_split(y=y, X=X, test_size = 0.2)


# GRID SEARCH
# Define scoring metrics
F1_score = make_scorer(f1_score)

# Instantiate a Decision Tree classifier: tree
tree = DecisionTreeClassifier(random_state=123, class_weight='balanced')
# Parameters
tree_param = [{'criterion': ['entropy', 'gini'],
               'max_depth': [None, 1, 3, 5],
               'max_leaf_nodes': [None, 2, 4],
               'max_features': [4, 6, 9, 12, 15],
               'min_samples_leaf': [2, 4, 6],
               'min_samples_split': [2, 4, 6],
               'ccp_alpha': [0, 1, 2]}]

print(f"[{datetime.datetime.now()}] Begin Model Training")

# Conduct Grid Search
clf_GS= GridSearchCV(tree, tree_param, cv=5, scoring=F1_score, error_score="raise",n_jobs=1)
clf_GS.fit(X_train, y_train)

print(f"[{datetime.datetime.now()}] Model Training complete ")
print(f"[{datetime.datetime.now()}] Best Model Parameter: {clf_GS.best_estimator_.get_params()}")
print(f"[{datetime.datetime.now()}] Best Model Fscore is {format(clf_GS.best_score_)}")

# Calculate Accuracy
y_pred = clf_GS.best_estimator_.predict(X_test)
cf = confusion_matrix(y_test, y_pred)
# tn, fp, fn, tp = confusion_matrix(y_test, y_pred).ravel() ###DEV comment out - redundant code
# df_cf = pd.DataFrame(cf, columns=['Predict 0', 'Predict 1'], index=['Actual 0', 'Actual 1']) ###DEV comment out - redundant code
precision, recall, fscore, support = precision_recall_fscore_support(y_test, y_pred, average='binary')

# Precision tp/(tp+fp)
print(f"[{datetime.datetime.now()}] precision: {str(precision)}")
# Recall tp/(tp+fn)
print(f"[{datetime.datetime.now()}] recall: {str(recall)}")
# Balanced between precision and recall
print(f"[{datetime.datetime.now()}] FScore: {str(fscore)}")

# Log Accuracy Result
run.log('FScore', float(fscore))
run.log('Precision', float(precision))
run.log('Recall', float(recall))


# Log the Confusion Matrix to the Azure ML run
cm_display = ConfusionMatrixDisplay(confusion_matrix = cf, display_labels = ['No Delay', 'Delay'])
cm_display.plot()
plt.show()
run.log_image('ConfusionMatrix',plot=plt, description='Confusion Matrix')


# Save the trained model
joblib.dump(value=clf_GS.best_estimator_,
            filename=output_folder + '/UC1_trained_components/ML-model-uc1-delayidentification.pkl')

print(f"[{datetime.datetime.now()}] Training complete: ML-based Delay Identification model ")


"""
###
TRAINED COMPONENT 3
GUDAI DARRI ONLY BASED TLO STAGE DURATION
###
"""

print('Begin training Gudai Darri only based TLO stage duration...')

trainsched_sdf = spark.read.parquet(input_dataset_dir+'/train_schedule**')
df_timings = trainsched_sdf.toPandas()

df_fptu_ts = pd.read_parquet(input_dataset_dir+'/FPTU_delay_ts')

datetime_cols = ['PLANNED_ARRIVAL_TIME_UTC', 'PLANNED_COMMENCE_LOAD_UTC',
                    'PLANNED_COMPLETE_LOAD_UTC', 'PLANNED_DEPARTURE_TIME_UTC',
                    'CREATED_ON_UTC', 'UPDATED_ON_UTC', 'DELETED_ON_UTC','TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                    'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE','UPDATED_ON_UTC']

for col in datetime_cols:
    df_timings[col] = pd.to_datetime(df_timings[col])

df_timings = df_timings.sort_values(by='UPDATED_ON_UTC')
df_timings = df_timings.drop_duplicates(subset='TRAIN_ID',keep='last')

latest_arrival = df_timings.TD_ACT_ARRIVALTIME.max()
last4w_start = latest_arrival - datetime.timedelta(days=28)
df_timings = df_timings[df_timings.TD_ACT_ARRIVALTIME >= last4w_start]
df_timings = df_timings[df_timings.TD_ACT_DEPMINE.notnull()]
df_timings = df_timings.sort_values(by='TD_ACT_ARRIVALTIME')
df_timings = df_timings[df_timings.TRAINSTATUS != 'Timestamp Error']

df_timings.loc[:,'dep_time'] = df_timings.loc[:,'TD_ACT_DEPMINE'] - df_timings.loc[:,'TD_ACT_COMPLOAD']
df_timings['dep_time_mins'] = df_timings['dep_time'].apply(lambda x:x.total_seconds()/60).round(1)
median_loadcomplete_to_departure = df_timings.dep_time_mins.median() # Median time between completing loading and train departing (across all trains)

# Calculate loading time for each train
df_timings.loc[:,'load_time'] = df_timings.loc[:,'TD_ACT_COMPLOAD'] - df_timings.loc[:,'TD_ACT_COMMLOAD']
df_timings['load_time_mins'] = df_timings['load_time'].apply(lambda x:x.total_seconds()/60).round(1)
# Calculate minutes delay in the loading phase for each train
trains = df_timings.TRAIN_ID.unique()
for train in trains:
    loading_delay_slice = df_fptu_ts.loc[df_timings.loc[df_timings.TRAIN_ID==train,'TD_ACT_COMMLOAD'].values[0]:df_timings.loc[df_timings.TRAIN_ID==train,'TD_ACT_COMPLOAD'].values[0]]
    loading_delay_mins = loading_delay_slice['delay_in_progress'].sum()
    df_timings.loc[df_timings.TRAIN_ID==train,'loading_delay_mins'] = loading_delay_mins
# Calulate median of loading times with delay duration removed
median_loading_nodelay = (df_timings.load_time_mins - df_timings.loading_delay_mins).median()

df_timings['prev_train_departure'] = df_timings['TD_ACT_DEPMINE'].shift(1)
df_timings.loc[df_timings.prev_train_departure > df_timings.TD_ACT_ARRIVALTIME, 'train_in_front'] = 'Y'
df_timings.loc[df_timings.prev_train_departure <= df_timings.TD_ACT_ARRIVALTIME, 'train_in_front'] = 'N'
df_timings.loc[:,'arr_time'] = df_timings.loc[:,'TD_ACT_COMMLOAD'] - df_timings.loc[:,'TD_ACT_ARRIVALTIME']
df_timings['arr_time_mins'] = df_timings['arr_time'].apply(lambda x:x.total_seconds()/60).round(1)
df_timings.loc[:,'train_gap_time'] = df_timings.loc[:,'TD_ACT_COMMLOAD'] - df_timings.loc[:,'prev_train_departure']
df_timings['train_gap_time_mins'] = df_timings['train_gap_time'].apply(lambda x:x.total_seconds()/60).round(1)

median_train_gap = df_timings[df_timings.train_in_front =='Y'].train_gap_time_mins.median()    # For trains that are back-to-back, median time between train 1 departing and train 2 starting loading
median_arrival_to_loading_notrain = df_timings[df_timings.train_in_front =='N'].arr_time_mins.median()   # For trains that arrive with no train in front, median time to bein loading

print('Median train gap: '+str(median_train_gap)+' mins')
print('Median arrival to load start (no train ahead): '+str(median_arrival_to_loading_notrain)+' mins')
print('Median load time (no delay): '+str(median_loading_nodelay)+' mins')
print('Median load complete to departure: '+str(median_loadcomplete_to_departure)+' mins')


# Export outputs to trained components folder

tlo_timings_dict = {'median_train_gap':median_train_gap, 
                    'median_arrival_to_loading_notrain':median_arrival_to_loading_notrain,
                    'median_loading_nodelay':median_loading_nodelay,
                    'median_loadcomplete_to_departure':median_loadcomplete_to_departure}

with open(output_folder+'/UC1_trained_components/tlo_stage_timings.pkl','wb') as f:
    pickle.dump(tlo_timings_dict, f)


print('Training complete: Gudai Darri only based TLO stage duration')


"""
###
FIXED MODEL FILES FROM REPO

Copy UC1 model files from Repo to the model outputs folder.
###
"""

shutil.copytree('ADA_UC1_TLO',output_folder+'/ADA_UC1_TLO', dirs_exist_ok=True)
shutil.copytree('config',output_folder+'/config', dirs_exist_ok=True)
shutil.copy('load_ADA_data.py',output_folder)

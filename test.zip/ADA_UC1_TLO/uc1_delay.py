from azureml.core import Dataset
import ADA_UC1_TLO.uc1_utils as uc1
import datetime
import numpy as np
import pandas as pd
import joblib
import os 

def identify_delay_rule(df_tags, train_status, current_dt,method='rule-based',total_cars=None,actual_arrival=None):
    """
    Inputs: 
        df_tags: Prep-processed PCS Tags dataframe
        train_status: Train status at datetime of prediction
        current_dt: Datetime of prediction 
        method: rule-based vs ml

    Outputs: 
        delay_event_in_progress: 
    """  
    delay_event_in_progress = 0 
    if train_status in ['Departed','Expected', 'Timestamp Error']:  # Train with those status cannot have delay
        delay_event_in_progress = 0 

    else: # Train at mine

        if method == 'rule-based': # Just looking at train speed and car loaded 

            train_speed_tag_name = 'KD1.PPCS.TL0601_SIT_PV'
            car_loaded_tag_name = 'KD1.PPCS.TL0601_WGNLD_C'
            train_speed_1min = round(uc1.find_tag_lag_value(df_tags,train_speed_tag_name,current_dt,1))
            train_speed_curr = round(uc1.find_tag_lag_value(df_tags,train_speed_tag_name,current_dt,0))
            cars_loaded_3min = uc1.find_tag_lag_value(df_tags,car_loaded_tag_name,current_dt,3) 
            cars_loaded_curr = uc1.find_tag_lag_value(df_tags,car_loaded_tag_name,current_dt,0) 
            train_speed_threshold = 0.4            
            if train_status in ['Loading']:
                if (train_speed_1min < train_speed_threshold) & (train_speed_curr < train_speed_threshold):
                    delay_event_in_progress = 1
                elif cars_loaded_curr - cars_loaded_3min <3 : # loading less than 1 car per minute
                    delay_event_in_progress = 1
                else: 
                    delay_event_in_progress = 0
                    
        elif method == 'ml':

            since_arrival=0
            since_completion=0

            # Time since arrival,loading,complete loading
            if train_status in ['Arrived','Pre-Loading']:
                since_arrival = (current_dt-actual_arrival).total_seconds()/60
            elif train_status in ['Loaded']:
                act_compload = pd.to_datetime(uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601DLC01_TRNLD_S',current_dt,0,current_dt,'timestamp') )
                since_completion = (current_dt-act_compload).total_seconds()/60  

            # Car Loaded and Car Remaining
            car_loaded_0 = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,0)
            if train_status == 'Loading':
                car_remaining = total_cars - car_loaded_0
            elif train_status in ['Loaded','Clearing','Departed','Ready for Departure']:
                car_remaining = 0
            else: 
                car_remaining = total_cars

            col_dict ={
                    'Train_Status':[train_status], 
                    'BinLevel_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.BN0601WT01_PV',current_dt,0)], 
                    'Train_Speed_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_SIT_PV',current_dt,0)],
                    'RC0601_dischargerate_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21_CLCDCHRT',current_dt,0)], 
                    'Train_Lump':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_LUMPS_S',current_dt,0)], 
                    'CV0622_Belt_Tph_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_TONRT',current_dt,0)],
                    'CV0622_Belt_Tph_2':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT02_ACTDAT_TONRT',current_dt,0)],
                    'CV0622_Belt_Speed1_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_BELTSPD',current_dt,0)],
                    'RC0601CV21WT01_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',current_dt,0)],
                    'RC0601_Reclaiming_0':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601_ReclaimSeqRun_S',current_dt,0)],
                    'CV0622_Belt_Tonnage_2':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST',current_dt,0) - uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST',current_dt,2)],                    
                    'BinLevel_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.BN0601WT01_PV',current_dt,1)],
                    'Chute_Lowered_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CH0601CH01_LWR_S',current_dt,1)], 
                    'Train_Speed_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_SIT_PV',current_dt,1)],
                    'car_loaded_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,0) - uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,1)], 
                    'CV0622_Belt_Speed1_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_BELTSPD',current_dt,1)],
                    'CV0622_Belt_Tonnage_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST',current_dt,0) - uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST',current_dt,1)],
                    'RC0601_Reclaiming_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601_ReclaimSeqRun_S',current_dt,1)],      
                    'RC0601_dischargerate_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21_CLCDCHRT',current_dt,1)],
                    'RC0601_dischargerate_2':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21_CLCDCHRT',current_dt,2)], 
                    'RC0601CV21WT01_1':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',current_dt,0)-uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',current_dt,1)],       
                    'RC0601CV21WT01_2':[uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',current_dt,0)-uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21WT01_AccumulatedTonnes',current_dt,2)],                                      
                    'since_arrival':[since_arrival],
                    'since_completion':[since_completion], 
                    'car_remaining':[car_remaining]
                    }
            df_input = pd.DataFrame(col_dict)

            # Encode Train Status
            ts_dict = {'Arrived':1,'Pre-Loading':1,'Loading':2,'Loaded':3,'Clearing':3,'Ready for Departure':4}
            df_input['Train_Status'] = df_input['Train_Status'].map(ts_dict)

            # Load trained ml model
            current_file_path = os.path.join(os.path.dirname(__file__), 'ML-model-uc1-delayidentification.pkl')
            model_path = current_file_path.replace('ADA_UC1_TLO/','UC1_trained_components/')
            ml_model = joblib.load(model_path)

            # Make Prediction 
            pred = ml_model.predict(df_input)
            delay_event_in_progress = pred[0]

    return delay_event_in_progress


def delay_duration(method='similar-mines', env='dev'):
    """
    Inputs: Method to calculate Delay Duration"
        similar-mines: Delay duration is based off historical data from similar mine sites
    
    Outputs: Delay duration lookup table
    """

    ws = uc1.get_workspace(env)
    if method == 'similar-mines':
        df_delaydur = Dataset.get_by_name(ws, name='DelayDurationTable-SimilarMines').to_pandas_dataframe()

    elif method == 'GD-only':
        current_file_path = os.path.join(os.path.dirname(__file__), 'gd_delay_duration_lookup.csv')
        file_path = current_file_path.replace('ADA_UC1_TLO/','UC1_trained_components/')

        df_delaydur = pd.read_csv(file_path)
    
    return df_delaydur
        



class DelayClassifier:
    def __init__(self, df,df_tags, df_alarm, df_car_weights, df_prev, current_dt,identify_delay_method = 'rule-based'): 
        self.current_dt = current_dt
        self.df_tags = df_tags
        self.df_prev = df_prev
        self.df_car_weights = df_car_weights
        self.alarms_last5min = df_alarm
        self.df = df

        # Define variables needed for identification functions
        ## Train Related Tags
        self.cars_loaded_prev_3min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,3) 
        self.cars_loaded_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_WGNLD_C',current_dt,0) 
        self.train_speed_curr = round(uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TL0601_SIT_PV',current_dt,0),1) # there is another weight tag     
        self.last_car_netWeight_1min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TSC0601_WGNNETWGT',current_dt,1)
        self.last_car_netWeight_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.TSC0601_WGNNETWGT',current_dt,0)   

        ## Reclaimer Related Tags
        self.stockpile_prev_10min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601Spl_Act_SP_Name_S',current_dt,10)                   
        self.stockpile_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601Spl_Act_SP_Name_S',current_dt,0)   
        self.bench_prev_10min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601Spl_Act_RC_BenNum_S',current_dt,10)   
        self.bench_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601Spl_Act_RC_BenNum_S',current_dt,0)  
        self.relocating_ind = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601_RelSeqRun_S',current_dt,0) 
        self.reclaiming_ind = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601_ReclaimSeqRun_S',current_dt,0)
        self.cv21_beltspeed_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.RC0601CV21_SPDVAL',current_dt,0)
        # Stacker Related Tags
        self.stacker1_stockpile_prev_1min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.SK0501Spl_Act_SP_Name_S',current_dt,1) 
        self.stacker1_stockpile_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.SK0501Spl_Act_SP_Name_S',current_dt,0)  
        self.stacker2_stockpile_prev_1min = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.SK0502Spl_Act_SP_Name_S',current_dt,1)  
        self.stacker2_stockpile_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.SK0502Spl_Act_SP_Name_S',current_dt,0)
        # Bin Related Tags 
        self.bin_weight_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.BN0601WT01_PV',current_dt,0) 
        # Conveyor CV0622 Related Tags
        self.cv0622_beltspeed1_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT01_ACTDAT_BELTSPD',current_dt,0) 
        self.cv0622_beltspeed2_curr = uc1.find_tag_lag_value(df_tags,'KD1.PPCS.CV0622WT02_ACTDAT_BELTSPD',current_dt,0) 


        # Get Indicator for Delay Event in Progress
        self.train_status,self.total_cars,self.actual_arrival,self.actual_load_commence_ts,self.actual_load_complete_ts, self.actual_departure_ts = uc1.determine_train_status(df_tags,df,current_dt)  
        self.delay_event_in_progress = identify_delay_rule(df_tags,self.train_status,current_dt,identify_delay_method,self.total_cars,self.actual_arrival)
 
        # Get Delay Information from previous forecast
        try:
            self.delay_event_type_prev_min = self.df_prev['delay_event_type'][0]
            self.delay_event_cause_prev_min = self.df_prev['delay_event_cause'][0]
            self.delay_event_asset_prev_min = self.df_prev['delay_event_asset'][0]
            self.delay_event_start_prev_min = self.df_prev['delay_event_start'][0]
            self.comm_loading_actual_prev_min = self.df_prev['comm_loading_actual'][0]
            self.comp_loading_actual_prev_min = self.df_prev['comp_loading_actual'][0]
            self.train_id_prev_min = self.df_prev['train_id'][0]
            self.train_status_prev_min = self.df_prev['train_status'][0]

        except: 
            self.delay_event_type_prev_min =''
            self.delay_event_cause_prev_min = ''
            self.delay_event_asset_prev_min = ''
            self.delay_event_start_prev_min = None
            self.comp_loading_actual_prev_min = None
            self.comm_loading_actual_prev_min = None
            self.train_id_prev_min = ''
            self.train_status_prev_min = ''

         # Identify when train stop completely    
        if (self.train_speed_curr <= 0.1) | (self.cars_loaded_prev_3min == self.cars_loaded_curr): 
            self.train_stops = 1       
        else:
            self.train_stops = 0

    def reclaiming_movements(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
        reclaimer_movement = ''
                        
        if self.train_status in ['Loading','Pre-Loading']:

            # 1) Identify if the Reclaimer is moving
            if self.relocating_ind == 1:
                delay_event_type = 'Operational - Machine Relocation'
                
                if (self.stockpile_curr != self.stockpile_prev_10min) & (self.cars_loaded_curr != 0):# if stockpile is different
                    delay_event_cause = 'Empty Stockpile'
                    reclaimer_movement = str(self.stockpile_prev_10min) + '-' + str(self.stockpile_curr)
                
                elif (self.stockpile_curr != self.stockpile_prev_10min) & (self.cars_loaded_curr == 0):
                    delay_event_cause = 'Machine, Setting Up'
                    reclaimer_movement = str(self.stockpile_prev_10min) + '-' + str(self.stockpile_curr)
                
                elif (self.stacker1_stockpile_curr != self.stacker1_stockpile_prev_1min) or (self.stacker2_stockpile_curr != self.stacker2_stockpile_prev_1min): 
                    #if stacker is moving
                    delay_event_cause = 'Full Stockpile'
                
                elif self.delay_event_cause_prev_min != 'Unknown':
                    delay_event_cause = self.delay_event_cause_prev_min
                else:
                    delay_event_cause = 'Unknown'
                              
            # 2) Identify bench change
            elif (self.bench_curr != self.bench_prev_10min) & (self.train_status == 'Loading'):
                delay_event_type = 'Operational - Machine Relocation'
                delay_event_cause = 'Operational, Bench Change' 
                
            # 3) Relocation finished but reclaiming hasn't restarted yet
            elif (self.delay_event_type_prev_min == 'Operational - Machine Relocation') & (self.reclaiming_ind == 0):
                delay_event_type = 'Operational - Machine Relocation'
                delay_event_cause = self.delay_event_cause_prev_min
           
          
        # Asset is always BRC501 for reclaimer moves  
        if delay_event_type == 'Operational - Machine Relocation':
            delay_event_asset = 'RC0601' 
        
        
        return delay_event_type, delay_event_cause, delay_event_asset, reclaimer_movement
    
    
    def trackscale_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
        
        # Identify Trackscale is not showing reading during TLO
        if self.train_status == 'Loading':
            
            # the number of cars loaded is increasing but he last car weight at track scale is aways 0
            if (self.delay_event_in_progress == 1) & (self.cars_loaded_curr > 0) & (self.last_car_netWeight_1min == 0) & (self.last_car_netWeight_curr == 0):
                delay_event_type = 'Trip - Track Scales'
                delay_event_cause = 'Reading, None'
                  
        return delay_event_type, delay_event_cause, delay_event_asset


    def dlc_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
            
        # DLC Alarms 
        link_loss_alarms = ['TL0601DLC01_LnkFlt_A','BPL503_TacLss_A','BPL503_GrdTneLss_A','B41_BPL503.GndTneLss_A',
        'TL0601DLC01_RadLnkLss_A']
        e_alarms = ['TL0601_Master_Shutdown_A','TL0601DLC01_FrcSby_A','TL0601DLC01_IndBrkFlt_A','TL0601DLC01_EBrkAppFlt_A']
        comm_fault = ['BPL503_TrnCtrl_A','SR0603UPS01XC01_Com_A','TL0601PLC03_PriCom_A','CV0622WT01_Com_A','SR0602PN01XC01_Com_A','CP0601XY01_Com_A','CP0602XY01_Com_A','LC060103FXC01_ComOK_A']
        joystick_alarms = ['TL0601DLC01_JS_Pos_A','TL0601DLC01_JS_AttReq_A','TL0601DLC01_JS_IndBrk_A','TL0601DLC01_JS_Pwr_A']
        speed_trips = ['TL0601DLC01_ManOvrSpd_A','TL0601DLC01_AutOvrSpd_A','TL0601_SIT_Hi_A'] 
        
        DLC_alarm_tags = link_loss_alarms+e_alarms+joystick_alarms
        
        alarms_last5min_DLC = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(DLC_alarm_tags)),case=False)]
        alarms_last5min_plcfault = self.alarms_last5min[(self.alarms_last5min['tagname'].str.contains(('|'.join(['PLC','SLC'])),case=False)) & (self.alarms_last5min['description'].str.contains('Fault'))] 
        alarms_last5min_commfault = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(comm_fault)),case=False)]  
        alarms_last5min_overspeed = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(speed_trips)),case=False)]
        
        if self.delay_event_in_progress == 1:

            if self.train_status in ['Loading','Pre-Loading']:
                if (len(alarms_last5min_plcfault) != 0) | (len(alarms_last5min_commfault) != 0):
                    # There are Train Control System PLC Fault 
                    delay_event_type = 'Trip - Control System'     
                
                elif len(alarms_last5min_DLC) != 0 :
                    # There are DLC alarms within the previous 5 mins
                    delay_event_type = 'Rail - DLC Fault'

                elif len(alarms_last5min_overspeed) != 0:
                    # There are Train overspeed or underspeed alarms within the previous 5 mins
                    delay_event_type = 'Rail - Train Surging'
        else:
            pass
            
        return delay_event_type, delay_event_cause, delay_event_asset
    
    
    def electrical_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
    
        electrical_alarm_keywords = ['Multilin','Relay']
    
        alarms_last5m_electrical = self.alarms_last5min[(self.alarms_last5min['message'].str.contains(('|'.join(electrical_alarm_keywords)),case=False)) & (self.alarms_last5min['tagname'].str.contains('_A'))& (self.alarms_last5min['message'].str.contains('Trip'))]
 
        
        if self.train_status in ['Loading','Pre-Loading','Arrived','Loaded']:
         
            if (len(alarms_last5m_electrical) != 0) & (self.delay_event_in_progress == 1):
                # There are Electrical alarms within the previous 5 mins
                delay_event_type = 'Trip - Electrical'
                delay_event_asset = alarms_last5m_electrical['asset'].values[0]
                
    
        return delay_event_type, delay_event_cause, delay_event_asset
    
    
    def overunderloaded_cars_delay(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
        
        UL_cars_at_digoff = 0
        OVL_cars_at_digoff = 0

        # Identify Reverse Train Alarm     
        alarms_last5m_reverse = self.alarms_last5min[self.alarms_last5min['tagname']=='TL0601_SIT_Rev_A']
              
        # Get train number of car loaded now minus 11 cars (dig off point is approx 11 cars from weightometer)
        car_at_digoff_point = self.cars_loaded_curr - 11  

        df_cw =self.df_car_weights[(self.df_car_weights['time'] <= self.current_dt) & (self.df_car_weights['next_time'] > self.current_dt)]
        if any( x > 145 for x in df_cw[(df_cw['car_no'].between(car_at_digoff_point-1,car_at_digoff_point+1))]['value'].values):
            OVL_cars_at_digoff = 1
        elif  any( x <70 for x in  df_cw[(df_cw['car_no'].between(car_at_digoff_point-1,car_at_digoff_point+1))]['value'].values):  # Train underloaded at the dig off point   
            UL_cars_at_digoff = 1
        elif  any( 0 < x <70 for x in  df_cw[(df_cw['car_no'].between(self.cars_loaded_curr, self.cars_loaded_curr+1))]['value'].values) &(len(alarms_last5m_reverse)>0): # Reverse the train to reload the current car
            UL_cars_at_digoff = 1        
        else: 
            OVL_cars_at_digoff = 0
            UL_cars_at_digoff = 0            

        
        if self.train_status == 'Loading':
    
            if (self.train_stops == 1) & (self.bin_weight_curr > 300): # Train must stop and the bin level must be high
                if OVL_cars_at_digoff == 1 :
                    delay_event_type = 'Overloaded Ore Car'
                elif UL_cars_at_digoff == 1:
                    delay_event_type = 'Underloaded Ore Car'
        
        return delay_event_type,delay_event_cause, delay_event_asset

    def anti_collision_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' # cause not required (median duration of delay is similar)
        delay_event_asset = '' # asset not required
    
        ACS_alarm_keywords = ['ACS','Collision']
    
        alarms_last5m_acs = self.alarms_last5min[self.alarms_last5min['message'].str.contains(('|'.join(ACS_alarm_keywords)),case=False)]
 
        
        if self.train_status in ['Loading','Pre-Loading','Arrived']: 
         
            if (len(alarms_last5m_acs) != 0) & (self.delay_event_in_progress == 1):
                # There are Anti Collision alarms within the previous 5 mins
                delay_event_type = 'Trip - Anti Collision'
                
        return delay_event_type, delay_event_cause, delay_event_asset

    def wait_for_product_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' # cause not required
        delay_event_asset = '' # asset not required (always the Bin)
        
        alarms_last5m_binlvl = self.alarms_last5min[(self.alarms_last5min['description'].str.contains('Level',case=False))&(self.alarms_last5min['tagname'].str.contains('BN0601'))]
        
        if self.train_status in ['Loading','Pre-Loading','Arrived']: 
            
            if len(alarms_last5m_binlvl) > 0:
                delay_event_type = 'Trip - Level Sensor'
                if len(alarms_last5m_binlvl[(alarms_last5m_binlvl['description'].str.contains('High',case=False))])>0:
                    delay_event_cause = 'Level, High-High'
                elif len(alarms_last5m_binlvl[(alarms_last5m_binlvl['description'].str.contains('Low',case=False))])>0:
                    delay_event_cause = 'Level, Low-Low' 
                else:
                    delay_event_cause = ''

            elif (self.bin_weight_curr < 200) & (self.delay_event_in_progress == 1) & (self.total_cars != self.cars_loaded_curr ): # The Train hasn't finish loading all of the cars
                # The bin level must be low (threhold < 200)
                delay_event_type = 'Wait For Product'
            else:
                pass
                
        return delay_event_type, delay_event_cause, delay_event_asset 

    def operational_process_startup_shutdown(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' # cause not required 
        delay_event_asset = '' # asset not required
    
        alarms_last5m = self.alarms_last5min[self.alarms_last5min['tagname']=='NOT_TL0601_SysStt_S_IL']
        car_remaining = self.total_cars - self.cars_loaded_curr 

        if (len(alarms_last5m) != 0):
           
            delay_event_type = 'Operational - Process Startup, Shutdown'
        elif (self.bin_weight_curr <= 1000) & (car_remaining <= 15): # Loading the last few cars
            delay_event_type = 'Operational - Process Startup, Shutdown'  
        elif (self.train_status == 'Loading')  & (self.cars_loaded_curr <= 10): # Train Start Loading the first 10 cars
            delay_event_type = 'Operational - Process Startup, Shutdown'                          
        return delay_event_type, delay_event_cause, delay_event_asset        

    def belt_trips(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 
        # In scope belts
        belts = ['CV0622','RC0601CV21']
        
        belts_alarms = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(belts)),case=False)]
        belts_alarms['description'].fillna('',inplace=True)
        # Belt Drift Alarms 
        BD = belts_alarms[(belts_alarms['description'].str.contains('Belt Drift'))]
        BD['Trip_Type'] = 'Trip - Belt Drift'
        # Belt Overspeed/Underspeed
        OUS = belts_alarms[(belts_alarms['description'].str.contains('Overspeed'))|(belts_alarms['description'].str.contains('Underspeed'))|(belts_alarms['tagname'].isin(['CV0622WT02_TonRtHiHi_A','CV0622WT02_TonRtHi_A']))]
        OUS['Trip_Type'] = 'Trip - Overspeed or Underspeed'
        #Pull Wire Alarms
        PW = belts_alarms[belts_alarms['description'].str.contains('Pull Wire')]
        PW['Trip_Type'] = 'Trip - Pull Wire'
        # Fault - Motor
        FM = belts_alarms[(belts_alarms['description'].str.contains('Relay'))&(belts_alarms['description'].str.contains('Motor'))]
        FM['Trip_Type'] = 'Fault - Motor'        
        # Belt Weightometer Fault
        WF = belts_alarms[(belts_alarms['description'].str.contains('Weightometer'))&(belts_alarms['description'].str.contains('Fault'))]
        WF['Trip_Type'] = 'Trip - Belt Weightometer'  
        # Belt Overtension or Undertension 
        BT = belts_alarms[(belts_alarms['description'].str.contains('Tension'))]
        BT['Trip_Type'] = 'Trip - Undertension or Overtension'  
        belt_trips_alarms = pd.concat([BD,OUS,PW,FM,WF,BT])
        df_count = belt_trips_alarms.groupby(['asset','Trip_Type'])['eventid'].count().reset_index()
        df_count.sort_values('eventid',ascending=False,inplace=True)

        # Check if the belt drift alarms tags are 1
        if (uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT11_HIHI_A',self.current_dt,0) == 1)|(uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT11_HI_A',self.current_dt,0) == 1)|(uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT30_HIHI_A',self.current_dt,0) == 1):
            belt_drift = 1
        # Check if there are any belt drift alarms in the past 10 minutes
        elif (self.current_dt <= uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT11_HIHI_A',self.current_dt,0,self.current_dt,'timestamp') + datetime.timedelta(minutes = 10))|(self.current_dt <= uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT11_HI_A',self.current_dt,0,self.current_dt,'timestamp') + datetime.timedelta(minutes = 10))|(self.current_dt <= uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.CV0622BDT30_HIHI_A',self.current_dt,0,self.current_dt,'timestamp') + datetime.timedelta(minutes = 10)):
            belt_drift = 1
        else: 
            belt_drift = 0

        # Check if the belt speed is zero: Otherwise it might be false alarm
        if (belt_drift == 1) & (self.cv0622_beltspeed1_curr  < 1) & (self.cv0622_beltspeed2_curr < 1):
            delay_event_type = 'Trip - Belt Drift'
            delay_event_asset = 'CV0622'
        elif (self.cv0622_beltspeed1_curr <1 ) & (self.cv0622_beltspeed2_curr <1) & (len(df_count[df_count['asset'] =='CV0622'])>0):
            delay_event_type = df_count.loc[(df_count['asset'] =='CV0622'),'Trip_Type'].iloc[0]
            delay_event_asset = 'CV0622'
            
        elif (self.cv21_beltspeed_curr <1) & (len(df_count[df_count['asset'] =='CV21'])>0):
            delay_event_type = df_count.loc[(df_count['asset'] =='CV21'),'Trip_Type'].iloc[0]
            delay_event_asset = 'CV21'              

        return delay_event_type, delay_event_cause, delay_event_asset     

    def manual_operation(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Get the value for Reclaimer Manual Mode Indicator
        manual_ops_rc = uc1.find_tag_lag_value(self.df_tags,'KD1.PPCS.RC0601_MAN_S',self.current_dt,0)
        if manual_ops_rc > 0:
            delay_event_type = 'Operational - Manual Operation'
            delay_event_cause = 'Operational, Manual Reclaiming' 
            delay_event_asset = 'RC0601' 
            
        return delay_event_type, delay_event_cause, delay_event_asset    

    def trip_hydraulic_system(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Find relevant alarms
        alarms_armhigh = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains('RC0601BW01NT01_Hi')] # RC0601BW01NT01_HiHi_A Bucketwheel Torque Arm Load Cell High High Alarm
        alarms_bwfail = self.alarms_last5min[self.alarms_last5min['tagname']=='RC0601BW01_Run_A'] # RC0601BW01_Run_A Bucketwheel Failed to Run	
        alarms_bwoilhigh = self.alarms_last5min[self.alarms_last5min['tagname']=='RC0601BW01DA01GB01LS02_A'] # Bucketwheel Gearbox Oil Level High
        if len(alarms_armhigh) > 0:
            delay_event_type = 'Trip - Hydraulic System'
            delay_event_cause = 'Pressure, High' 
            delay_event_asset = 'RC0601' 
        elif len(alarms_bwfail)>0 & len(alarms_bwoilhigh)>0 :
            delay_event_type = 'Trip - Hydraulic System'
            delay_event_cause = 'Level, Low' # Need to review
            delay_event_asset = 'BW01'             
      
        return delay_event_type, delay_event_cause, delay_event_asset    


    def trip_lubrication_system(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 
        lubrication_alarms = ['RC0601BW01DA01GB01LS01_A','RC0601BW01DA01GB01LS02_A','RC0601BW01DA01GB01PT02_Hi_A','RC0601BW01DA01GB01PT01_Lo_A','RC0601BW01DA01GB01PT01_LoLo_A']
        # Find relevant alarms
        alarms_preshigh = self.alarms_last5min[self.alarms_last5min['tagname'].isin(['RC0601BW01DA01GB01PT02_Hi_A','RC0601BW01DA01GB01PT01_Hi_A'])] # Bucketwheel Gearbox Oil Differential Pressure High	
        alarms_preslow = self.alarms_last5min[self.alarms_last5min['tagname'].isin(['RC0601BW01DA01GB01PT01_Lo_A','RC0601BW01DA01GB01PT01_LoLo_A'])] # Bucketwheel Gearbox Oil Pressure Low	
        alarms_bwoillow = self.alarms_last5min[self.alarms_last5min['tagname'].isin(['RC0601BW01DA01GB01LS01_A','RC0601BW01DA01GB01LS02_A'])] # Bucketwheel Gearbox Oil Level Low

        if len(alarms_bwoillow) > 0:
            delay_event_type = 'Trip - Lubrication System (Oil)'
            delay_event_cause = 'Level, Low' 
        elif len(alarms_preshigh)>0:
            delay_event_type = 'Trip - Lubrication System (Oil)'
            delay_event_cause = 'Pressure (Differential), High' 
        elif len(alarms_preslow)>0:
            delay_event_type = 'Trip - Lubrication System (Oil)'
            delay_event_cause =  'Pressure, Low' 
                                  
        return delay_event_type, delay_event_cause, delay_event_asset  

    def trip_position_encoder(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Find relevant alarms
        alarms = ['RC0601SLW01ZS03_Cal_LenFlt_A','RC0601LS05_HiHi_A','RC0601IR04_SIL_A'] # Slew Encoder 3 Calibration Proximity Switch Striker Length Fault
        alarms_positionfault = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(alarms)),case=False)]
        if len(alarms_positionfault) > 0:
            delay_event_type = 'Trip - Position or Encoder'

        return delay_event_type, delay_event_cause, delay_event_asset  

    def operational_blockage(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Find relevant alarms
	
        alarms_blockchute_cv21 = self.alarms_last5min[self.alarms_last5min['tagname']=='RC0601CV21BCS01_HiHi_A'] # Boom Conveyor Blocked Chute Head End Tilt Switch Alarm
        if len(alarms_blockchute_cv21) > 0:
            delay_event_type = 'Operational - Blockage'
            delay_event_cause = 'Operational, Surging' 
            delay_event_asset = 'CV21'

                
        return delay_event_type, delay_event_cause, delay_event_asset

    def trip_motor(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Find relevant alarms
        rc0601_motor_alarms_mp = ['RC0601SLW01DA0xMT01IT01_Imb_HiHi_A','RC0601SLW01DA0xMT01IT01_Imb_Hi_A','RC0601BW01PR10Alm_A'] #
        rc0601_motor_alarms_oc = ['RC0601BW01PR10Alm_A']
     
        alarms_last5min_rc0601_mp = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(rc0601_motor_alarms_mp)),case=False)]
        alarms_last5min_rc0601_oc = self.alarms_last5min[self.alarms_last5min['tagname'].str.contains(('|'.join(rc0601_motor_alarms_oc)),case=False)]

        if len(alarms_last5min_rc0601_mp) > 0:
            delay_event_type = 'Trip - Motor'
            delay_event_cause = 'Motor Protection, Under Voltage' 
            delay_event_asset = 'RC0601' 
        elif len(alarms_last5min_rc0601_oc) > 0:
            delay_event_type = 'Trip - Motor'
            delay_event_cause = 'Over Current' 
            delay_event_asset = 'RC0601' 
        return delay_event_type, delay_event_cause, delay_event_asset

    def trip_pecell(self):
        # Initialise ouputs
        delay_event_type = ''
        delay_event_cause = '' 
        delay_event_asset = '' 

        # Find relevant alarms
        alarms_last5min_pecell = self.alarms_last5min[(self.alarms_last5min['message'].str.contains('Fault')) & (self.alarms_last5min['message'].str.contains('PE Cell'))]

        if len(alarms_last5min_pecell) > 0:
            delay_event_type = 'Trip - PE Cell'

        return delay_event_type, delay_event_cause, delay_event_asset

             
    def delay_identification_model(self):
        """ 
        Inputs:
        df_tags : pivoted tag dataframe
        df_alarms: alarms dataframe
        current_dt: the current timestamp format YYYY-MM-DD HH:MM:SS
        
        Outputs:
        delay_event_in_progress, delay_event_type, delay_event_cause, delay_event_asset, delay_event_start, reclaimer_movement
        
        """
        # Initialise output values
        delay_event_type = ''
        delay_event_cause = ''
        delay_event_asset = ''
        delay_event_start = None
        reclaimer_movement = ''
        
        # IDENTIFY PRESENCE OF DELAY EVENT
        
        # IDENTIFY DELAY EVENT TYPE
    
        # Pull identifiers from workbook
        
        if self.delay_event_in_progress == 1:
            delay_event_type, delay_event_cause, delay_event_asset = self.operational_process_startup_shutdown()

            if delay_event_type == '':
                delay_event_type, delay_event_cause, delay_event_asset, reclaimer_movement = self.reclaiming_movements() 

                if delay_event_type == '':
                    delay_event_type, delay_event_cause, delay_event_asset = self.overunderloaded_cars_delay()

                    if delay_event_type == '':
                        delay_event_type, delay_event_cause, delay_event_asset = self.dlc_trips()

                        if delay_event_type == '':
                            delay_event_type, delay_event_cause, delay_event_asset = self.belt_trips()            

                            if delay_event_type == '':
                                delay_event_type, delay_event_cause, delay_event_asset = self.trackscale_trips()
                                
                                if delay_event_type == '':
                                    delay_event_type, delay_event_cause, delay_event_asset = self.anti_collision_trips()
                                    
                                    if delay_event_type == '':
                                        delay_event_type, delay_event_cause, delay_event_asset = self.electrical_trips()
                                        
                                        if delay_event_type == '':
                                            delay_event_type, delay_event_cause, delay_event_asset = self.manual_operation()

                                            if delay_event_type == '':
                                                delay_event_type, delay_event_cause, delay_event_asset = self.operational_blockage()

                                                if delay_event_type == '':
                                                    delay_event_type, delay_event_cause, delay_event_asset = self.trip_pecell()

                                                    if delay_event_type == '':
                                                        delay_event_type, delay_event_cause, delay_event_asset = self.trip_position_encoder()

                                                        if delay_event_type == '':
                                                            delay_event_type, delay_event_cause, delay_event_asset = self.trip_lubrication_system()

                                                            if delay_event_type == '':
                                                                delay_event_type, delay_event_cause, delay_event_asset = self.trip_hydraulic_system()

                                                                if delay_event_type == '':
                                                                    delay_event_type, delay_event_cause, delay_event_asset = self.trip_motor()                                                    

                                                                    if delay_event_type == '':
                                                                        delay_event_type, delay_event_cause, delay_event_asset = self.wait_for_product_trips()
                                                            

                            
        #If nothing new identified and delay is still in progress, continue previous minute classification
        if (self.delay_event_in_progress == 1) & (delay_event_type == ''):
            delay_event_type = self.delay_event_type_prev_min
            delay_event_cause = self.delay_event_cause_prev_min
            delay_event_asset = self.delay_event_asset_prev_min
        
             
        ## IDENTIFY EVENT START TIME         
        if self.delay_event_in_progress == 1:
            if (pd.isnull(self.delay_event_start_prev_min) ): 
                delay_event_start = self.current_dt
            elif (self.delay_event_type_prev_min != ''):
                delay_event_start = self.delay_event_start_prev_min
                delay_event_type = self.delay_event_type_prev_min
                delay_event_cause = self.delay_event_cause_prev_min
            else:
                delay_event_start = self.delay_event_start_prev_min
        else:
            delay_event_start = None
            
        # Correct Commence & Complete loading Actual using previous prediction
        if (self.df['train_id'][0] == self.train_id_prev_min) & (self.train_status_prev_min !='Arrived') & (pd.notnull(self.comm_loading_actual_prev_min)): # Commence & Complete loading actual is none when train only arrives
            self.actual_load_commence_ts = self.comm_loading_actual_prev_min
            if (self.train_status in ['Loaded','Ready for Departure','Departed']):
                if (pd.notnull(self.comp_loading_actual_prev_min)):
                    self.actual_load_complete_ts = self.comp_loading_actual_prev_min
                elif pd.to_datetime(self.actual_load_complete_ts ) <= pd.to_datetime(self.actual_load_commence_ts ): # if the actual complete is before actual commence, take the current ts. if could be there is lay in updating the loaded tag in PCS
                    self.actual_load_complete_ts = self.current_dt
                else: 
                    pass                 
        else: 
            self.actual_load_commence_ts = self.actual_load_commence_ts
            self.actual_load_complete_ts = self.actual_load_complete_ts 

        return self.delay_event_in_progress, delay_event_type, delay_event_cause, delay_event_asset, delay_event_start, reclaimer_movement, self.train_status ,self.actual_load_commence_ts,self.actual_load_complete_ts,self.actual_departure_ts



def identify_delay(ts, df, df_tags, df_alarms, df_car_weights, df_output, df_delaydur,identify_delay_method = 'rule-based'):
    """
    Inputs: 
           ts: timestamp of prediction
           df: train detail dataframe
           df_tags: processed tag dataframe
           df_alarms: processed alarm dataframe
           df_car_weights: car weights dataframe
           df_output: output of previous 3 min prediction
           df_delaydur: pre-calculated delay duration dataframe
           identify_delay_method: Method to identify delay (rule-based vs ml)
    Outputs: 
            df: train detail with delay event,cause and asset dataframe
    """      
    
    # Get Alarm dataset for started between now and 1 hour ago and ended no more than 5 minutes ago. 
    df_alarms_5 = df_alarms[(df_alarms['vt_start'] >= ts - datetime.timedelta(hours = 1)) & (df_alarms['vt_start'] <= ts) & (df_alarms['vt_end'] > ts - datetime.timedelta(minutes = 10))]
    # Remove duplicate alarms (keep only the latest of that alarm within the time interval)
    df_alarms_5 = df_alarms_5.sort_values('vt_start',ascending=True).drop_duplicates(subset=["tagname"], keep="last")    
    # Identify Delay, Type Cause and Train Status at td
    delay_event_in_progress, delay_event_type, delay_event_cause, delay_event_asset, delay_event_start, reclaimer_movement, train_status,actual_load_commence_ts,actual_load_complete_ts,actual_departure_ts  = DelayClassifier(df,df_tags, df_alarms_5, df_car_weights, df_output, ts,identify_delay_method).delay_identification_model()

    # Update Train Status for the first train based on revised calculation
    df.loc[(ts,'Train 1'),'train_status'] = train_status
    
    # Update Train Actual Commence Loading and Complete Loading Timestamp based on Tag Data when the train schedule hasn't been updated yet
    if (train_status in ['Loading','Clearing']) & (pd.isnull(df.loc[(ts,'Train 1'),'comm_loading_actual'])):
        df.loc[(ts,'Train 1'),'comm_loading_actual'] = pd.to_datetime(actual_load_commence_ts)
    elif train_status in ['Loaded','Ready for Departure','Departed']:
        if  pd.isnull(df.loc[(ts,'Train 1'),'comp_loading_actual']):
            df.loc[(ts,'Train 1'),'comp_loading_actual'] = pd.to_datetime(actual_load_complete_ts)
        if pd.isnull(df.loc[(ts,'Train 1'),'comm_loading_actual']):
            df.loc[(ts,'Train 1'),'comm_loading_actual'] = pd.to_datetime(actual_load_commence_ts)
        if (train_status == 'Departed') & (pd.isnull(df.loc[(ts,'Train 1'),'depart_actual'])):
            df.loc[(ts,'Train 1'),'depart_actual'] = pd.to_datetime(actual_departure_ts)
    else:
        pass

            
    # Update car_remaining again for Train status 'Clearing' & "Ready for Departure":
    if (train_status in ['Ready for Departure','Clearing','Departed','Loaded']):
        df.loc[(ts,'Train 1'),'cars_remaining'] = 0 # all cars would be loaded
        
    # Find delay_event based on delay_event_type + delay_event_cause
    if delay_event_type != '': 
        if delay_event_cause != '':
            delay_event = delay_event_type + ' / ' + delay_event_cause
        else:
            delay_event = delay_event_type 
    elif delay_event_in_progress == 1: 
        delay_event = 'Unknown'
    else:
        delay_event = ''

    # Create delay_event_in_progress field
    if delay_event_in_progress == 1:
        df.loc[(ts,'Train 1'),'delay_event_in_progress'] = 'Y'
        df.loc[(ts,'Train 1'),'delay_event_type'] = delay_event_type
        df.loc[(ts,'Train 1'),'delay_event_cause'] = delay_event_cause
        df.loc[(ts,'Train 1'),'delay_event_asset'] = delay_event_asset
        df.loc[(ts,'Train 1'),'delay_event_start'] = delay_event_start 
    else:
        df.loc[(ts,'Train 1'),'delay_event_in_progress'] = 'N'
        df.loc[(ts,'Train 1'),'delay_event_type'] = ''
        df.loc[(ts,'Train 1'),'delay_event_cause'] = ''
        df.loc[(ts,'Train 1'),'delay_event_asset'] = ''
        df.loc[(ts,'Train 1'),'delay_event_start'] = np.NaN
        
    if delay_event_in_progress == 0:
        df.loc[(ts,'Train 1'),'train1_comm_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_departure_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_delay_duration_q1'] = datetime.timedelta(minutes=0) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q3'] =datetime.timedelta(minutes=0)
    elif (train_status == 'Loading') & (delay_event_in_progress == 1):    
        
        match_dur= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'median_duration'].values[0]
        match_dur_q1= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q1_duration'].values[0]
        match_dur_q3= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q3_duration'].values[0]
        df.loc[(ts,'Train 1'),'train1_comm_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_loading_delay_model'] = datetime.timedelta(minutes=match_dur)
        df.loc[(ts,'Train 1'),'train1_departure_delay_model'] = datetime.timedelta(minutes=0)   
        df.loc[(ts,'Train 1'),'train1_delay_duration_q1'] = datetime.timedelta(minutes=match_dur_q1) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q3'] = datetime.timedelta(minutes=match_dur_q3) 

    elif (train_status in ['Arrived','Pre-Loading']) & (delay_event_in_progress == 1):    
        
        match_dur= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'median_duration'].values[0]
        match_dur_q1= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q1_duration'].values[0]
        match_dur_q3= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q3_duration'].values[0]        
        df.loc[(ts,'Train 1'),'train1_comm_loading_delay_model'] = datetime.timedelta(minutes=match_dur)
        df.loc[(ts,'Train 1'),'train1_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_departure_delay_model'] = datetime.timedelta(minutes=0) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q1'] = datetime.timedelta(minutes=match_dur_q1) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q3'] = datetime.timedelta(minutes=match_dur_q3) 

    elif (train_status == 'Loaded') & (delay_event_in_progress == 1):    
        
        match_dur= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'median_duration'].values[0]
        match_dur_q1= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q1_duration'].values[0]
        match_dur_q3= df_delaydur.loc[(df_delaydur['delay_event'] == delay_event),'q3_duration'].values[0]        
        df.loc[(ts,'Train 1'),'train1_comm_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_departure_delay_model'] = datetime.timedelta(minutes=match_dur)
        df.loc[(ts,'Train 1'),'train1_delay_duration_q1'] = datetime.timedelta(minutes=match_dur_q1) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q3'] = datetime.timedelta(minutes=match_dur_q3) 
        
    else:   
        df.loc[(ts,'Train 1'),'train1_comm_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_loading_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_departure_delay_model'] = datetime.timedelta(minutes=0)
        df.loc[(ts,'Train 1'),'train1_delay_duration_q1'] = datetime.timedelta(minutes=0) 
        df.loc[(ts,'Train 1'),'train1_delay_duration_q3'] =datetime.timedelta(minutes=0)
    return df
'''
The following code is intended to deploy, run, and schedule UC2's training pipelines.
The outcome of which is a new registered model version for UC2 per belt.
'''

import os
import datetime
from azureml.core import Workspace, Experiment, Environment, Dataset
from azureml.core.compute import AmlCompute
from azureml.core.datastore import Datastore
from azureml.core.runconfig import RunConfiguration, DockerConfiguration
from azureml.pipeline.core import Pipeline, PipelineData, Schedule, ScheduleRecurrence, PublishedPipeline, PipelineParameter
from azureml.pipeline.steps import PythonScriptStep
from azureml.data import OutputFileDatasetConfig
from azureml.core import Dataset, Datastore
from azureml.data import HDFSOutputDatasetConfig
from azureml.core.authentication import ServicePrincipalAuthentication
import datetime
import logging
from os import environ
import argparse


# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the src folder
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is {}".format(cwd.split("\\")[-1])


# ---------- Parsed Variables ---------- #
parser = argparse.ArgumentParser(description="Argparser")
parser.add_argument('-b', "--belt-name", help = "<Required> Name of the belt for which this pipeline is being created", required = True)
args = parser.parse_args()

# ---------- Environment Variables ---------- #
env = os.environ["ENV"]

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# Authenticating into the ml workspace
svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)

# Authenticating into the ml workspace
ws = Workspace.get(
    name=workspace_name,
    subscription_id=subscription_id,
    resource_group=resource_group,
    auth = svc_pr
)

# ---------- Compute Variables ---------- #
compute_name = os.environ["COMPUTENAME"]

# ---------- Docker Environment Variables ---------- #
environment_name = os.environ["ENVIRONMENTNAME"]

# ---------- Pipeline Variables ---------- #
training_period_start = PipelineParameter(name="period_start", default_value='2022-07-01')
training_period_end = PipelineParameter(name="period_end", default_value='default') # Default previous date
belt_name = args.belt_name
pipeline_name = "uc2_training_pipeline_" + belt_name
pipeline_schedule_name = "uc2_training_pipeline_" + belt_name + "_schedule"


# Output variables being used
logging.info("---------- Environment Variables ----------")
logging.info("Environment: {}".format(env))

logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Compute Variables ----------")
logging.info("Compute Name: {}".format(compute_name))

logging.info("---------- Docker Environment Variables ----------")
logging.info("Environment Name: {}".format(environment_name))

logging.info("---------- Pipeline Variables ----------")
logging.info("Training Period Start Date: {}".format(training_period_start))
logging.info("Training Period End Date: {}".format(training_period_end))
logging.info("Belt Name: {}".format(belt_name))
logging.info("Pipeline Name: {}".format(pipeline_name))
logging.info("Pipeline Schedule Name: {}".format(pipeline_schedule_name))

# # Authenticating into the ml workspace
# ws = Workspace.get(
#     name = workspace_name,
#     subscription_id = subscription_id,
#     resource_group = resource_group
# )

# ---------- Disable Old Experiment and Schedule ---------- #
def disable_pipeline_and_schedule(ws, scheduler_name, pipeline_name):
    logging.info(f"Disableing Pipeline and Schedule")
    logging.info(f"- Scheduler name = {scheduler_name}")
    logging.info(f"- Pipeline name = {pipeline_name}")
    # Find and disable scoring schedules
    pipeline_schedules = Schedule.list(
        workspace=ws
    )

    # Find and disable azure ml pipelines
    published_pipelines = PublishedPipeline.list(
        workspace=ws
    )

    schedules = [
        schedule for schedule in pipeline_schedules
        if schedule.name in list([scheduler_name])
    ]
    logging.info(f"{len(schedules)} number of schedules found")

    # Disable old schedule
    for schedule in schedules:
        schedule.disable()
        logging.info("{} succcessfully disabled".format(schedule._name))
    logging.info("Successfully disabled all pipeline schedules")

    pipelines = [
        pipeline for pipeline in published_pipelines
        if pipeline._name in list([pipeline_name])
    ]
    logging.info("{} number of pipelines found".format(len(pipelines)))

    # Disable old pipelines
    for pipeline in pipelines:
        PublishedPipeline.get(
            workspace = ws,
            id = pipeline.id
        ).disable()
        logging.info("{} succcessfully disabled".format(pipeline._name))
    logging.info("Successfully disabled all pipelines")

# ---------- Create New Pipeline Experiment ---------- #
# Grab the workspace and landing prod/dev/uat datastore
print("environment coming as", env)
if env=='dev':
    datastore_nam = 'ada_landed_data_storage_dev'
    def_datastore_name = 'ada_results_storage_dev'
    path = 'new-test/'
else:
    datastore_nam='ada_landed_data_storage_prod'
    def_datastore_name = 'ada_results_storage_prod'
    path = ''

ada_prod = Datastore.get(
    workspace = ws,
    datastore_name = datastore_nam
)
logging.info("Retrieved landing datastore with name: {}".format(ada_prod.name))

results_store = Datastore.get(
    workspace = ws,
    datastore_name = def_datastore_name
)
logging.info("Retrieved workspace datastore with name: {}".format(results_store.name))

def_blob_store = Datastore.get(
    workspace = ws,
    datastore_name = "workspaceblobstore"
)
logging.info("Retrieved workspace datastore with name: {}".format(def_blob_store.name))

# if env == "dev":
#     compute_name= "crtdevrashaml1"
# else:
#     computer_name = "crtrtioaeuae"

# Grab the compute cluster that the pipeline will run on
ml_compute_instance = AmlCompute(
    workspace = ws,
    name = compute_name
)

# Setting up compute environment
my_env = Environment.get(
    workspace = ws,
    name = environment_name
)
run_config = RunConfiguration()
docker_config = DockerConfiguration(use_docker = True)
run_config.docker = docker_config
run_config.environment = my_env
logging.info("Set up compute with name = {} and environment with name = {}".format(compute_name, environment_name))

# Retrieve datasets from the "ada_landed_data_storage_prod" / "ada_landed_data_storage_dev" datastore and mount it to the pipeline

# new
# run_config.spark.configuration["spark.driver.memory"] = "48g" 
# run_config.spark.configuration["spark.driver.cores"] = 5 
# run_config.spark.configuration["spark.executor.memory"] = "48g" 
# run_config.spark.configuration["spark.executor.cores"] = 5 
# run_config.spark.configuration["spark.executor.instances"] = 4
# run_config.spark.configuration['spark.dynamicAllocation.enabled'] =True
# run_config.spark.configuration['spark.dynamicAllocation.initialExecutors'] = 4
# run_config.spark.configuration['spark.dynamicAllocation.maxExecutors'] = 5



PCS_tags_dataset = Dataset.File.from_files(
    path = (results_store, 'ADA_processed_datasets/PCS_tags/**'),
    validate=False
)
PCS_tags_input = PCS_tags_dataset.as_named_input('PCS_Tags').as_mount()
logging.info("Retrieved dataset with name = PCS_Tags and placed as mount on the compute instance of the pipeline")

# FPTU_dataset = Dataset.File.from_files(path=(ada_prod,'kd-int058-ordw-fixed-plant-time-usage-ada/**'), validate=False)
FPTU_dataset = Dataset.File.from_files(path=(results_store,'ADA_processed_datasets/fptu/**'), validate=False)
FPTU_input = FPTU_dataset.as_named_input('Fixed_Plant_Time_Usage').as_mount()
logging.info("Retrieved dataset with name = Fixed_Plant_Time_Usage and placed as mount on the compute instance of the pipeline")
Weather_dataset = Dataset.File.from_files(path=(ada_prod,f'kd-int056-weatherzone-forecasts-ada/**'), validate=False)
#Weather_dataset = Dataset.File.from_files(path=(ada_prod,f'{path}kd-int056-weatherzone-forecasts-ada/**'), validate=False)
Weather_input = Weather_dataset.as_named_input('Weather_Forecast_Data').as_mount()

# Defining Interim Datastores
raw_data_interim = PipelineData(
    'UC2_Raw_Data', 
    datastore = def_blob_store
)

data_prep_interim = PipelineData(
    'UC2_Data_Prep', 
    datastore = def_blob_store
)

model_folder = PipelineData(
    'UC2_Model', 
    datastore = def_blob_store
)


# ---------- Training Parameters ---------- #
hparam_tuning = True
cross_validation = False
train_start = None
train_end = None
test_start = None 
test_end = None

train_arguments = [
    "--data_prep_interim", data_prep_interim,
    "--model_folder", model_folder,
    "--period_start", training_period_start,
    "--period_end", training_period_end,
    "--belt", belt_name
    ]

if train_start is not None: train_arguments = train_arguments + ["--train_start", train_start]
if train_end is not None: train_arguments = train_arguments + ["--train_end", train_end]
if test_start is not None: train_arguments = train_arguments + ["--test_start", test_start]
if test_end is not None: train_arguments = train_arguments + ["--test_end", test_end]
if hparam_tuning: train_arguments = train_arguments + ["--hparam_tuning"]
if cross_validation: train_arguments = train_arguments + ["--cross_validation"]

# Define Raw Data Cache Location 
#raw_data_cache = OutputFileDatasetConfig(destination=(def_blob_store, 'MD/UC2_Dataset_Cache/'+belt_name))
# raw_data_cache = HDFSOutputDatasetConfig(destination=(def_blob_store, 'MD/UC2_Dataset_Cache/'+belt_name))
# raw_data = Dataset.File.from_files(path=(def_blob_store,'MD/UC2_Dataset_Cache/'+belt_name+'/**'), validate=False)
# raw_data_input = raw_data.as_named_input('Raw_Data_Input').as_download()
# logging.info("Set output folder as {} in the workspace datastore".format('MD/UC2_Dataset_Cache/'+belt_name))

# Defining the steps required for the Azure ML Pipeline
source_directory = "..\\..\\..\\..\\"

# Step 1 and 2: Data Load and Processing
data_load_step = PythonScriptStep(
    script_name="ADA_UC2_CDP/uc2_pipeline_dataprocessing.py",
    source_directory=source_directory, 
    inputs=[PCS_tags_input, FPTU_input, Weather_input],
    outputs=[data_prep_interim, raw_data_interim],
    arguments = [
        "--PCS_tags", PCS_tags_input,
        "--FPTU", FPTU_input,
        "--Weather", Weather_input,
        "--belt", belt_name,
        "--data_prep_interim", data_prep_interim,
        "--raw_data_interim", raw_data_interim,
        "--period_start", training_period_start,
        "--period_end", training_period_end],
    compute_target=ml_compute_instance,
    runconfig=run_config,
    allow_reuse=False)


# Step 3: Model Training 
train_step = PythonScriptStep(
    script_name="ADA_UC2_CDP/uc2_pipeline_train.py",
    source_directory=source_directory, 
    inputs=[data_prep_interim, raw_data_interim],
    outputs=[model_folder],
    arguments = train_arguments,
    compute_target=ml_compute_instance,
    runconfig=run_config,
    allow_reuse=False) 

# Step 4: Register Model
register_step = PythonScriptStep(
    script_name="ADA_UC2_CDP/uc2_pipeline_registermodel.py", 
    arguments = [
        "--input_folder", model_folder,
        "--belt", belt_name,
        "--period_start", training_period_start,
        "--period_end", training_period_end],
    inputs=[model_folder],
    compute_target=ml_compute_instance, 
    source_directory=source_directory,
    runconfig=run_config,
    allow_reuse=False)

logging.info("Registered python script steps for Azure ML pipeline")

# Set up and run as experiment
pipeline = Pipeline(
    workspace = ws, 
    steps = [
        data_load_step,
        train_step, 
        register_step
    ]
)
'''
pipeline_run = Experiment(
    workspace = ws,
    name = pipeline_name
).submit(
    pipeline
)
logging.info("Submitting experiment with name: {}".format(pipeline_name))
#
# pipeline_run.wait_for_completion(
#     show_output = False
# )
logging.info("Succesfully completed pipeline experiment")
'''
# ---------- Disable Old Experiment and Schedule ---------- #
# Find and disable schedules
# pipeline_schedules = Schedule.list(
#     workspace = ws
# )
# schedules = [
#     schedule for schedule in pipeline_schedules
#     if schedule._name in list(pipeline_schedule_name)
# ]
# logging.info("{} number of schedules found".format(len(schedules)))

# # Disable old schedule
# for schedule in schedules:
#     schedules.disable()
#     logging.info("{} succcessfully disabled".format(schedule._name))
# logging.info("Successfully disabled all pipeline schedules")

# # Find and disable azure ml pipelines
# published_pipelines = PublishedPipeline.list(
#     workspace = ws
# )
# pipelines = [
#     pipeline for pipeline in published_pipelines
#     if pipeline._name in list(pipeline_schedule_name)
# ]
# logging.info("{} number of pipelines found".format(len(pipelines)))

# # Disable old pipelines
# for pipeline in pipelines:
#     PublishedPipeline.get(
#         workspace = ws,
#         id = pipeline.id
#     ).disable()
#     logging.info("{} succcessfully disabled".format(pipeline._name))
# logging.info("Successfully disabled all pipelines")

# ---------- Publish New Pipeline and Create Schedule ---------- #
# Publish pipeline
published_pipeline = pipeline.publish(
     name = pipeline_name,
     description = "Weekly pipeline for RioTinto ADA Use Case 2 Training Pipeline",
     version="1.0"
)

logging.info("Successfully published {pipeline_name} pipeline to Azure ML workspace")

pipeline_id = published_pipeline.id
experiment_name = pipeline_name

# Set up a recurring schedule
recurrence = ScheduleRecurrence(
    frequency = "Week", 
    interval = 1,
    week_days = ["Wednesday"],
    time_of_day = "23:00"
)

recurring_schedule = Schedule.create(
    workspace = ws,
    name = pipeline_schedule_name, 
    description="Use Case 2 Training Pipeline Schedule",
    pipeline_id = pipeline_id, 
    experiment_name = experiment_name, 
    recurrence = recurrence
)
logging.info("Successfully created schedule for the published pipeline")
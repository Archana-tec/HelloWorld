'''
The following code downloads the latest UC2 belt model within an environment.
The downloaded model is then used in a build artifact so that it is available for registration in another AML workspace.
Enables cross account model promotion.
'''

import os
from azureml.core import Workspace, Model
import json
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the src folder
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is {}".format(cwd.split("\\")[-1])

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

# ---------- Model Variables ---------- #
model_prefix = os.environ["MODELPREFIX"]
model_folder = os.environ["MODELFOLDER"]

# Output variable being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Model Variables ----------")
logging.info("Model Prefix: {}".format(model_prefix))
logging.info("Model Folder: {}".format(model_folder))

# Authenticating into the current ml workspace
ws = Workspace.get(
    name = workspace_name,
    subscription_id = subscription_id,
    resource_group = resource_group
)
logging.info("Authenticated into the current ML workspace with name: {}".format(workspace_name))

# Read in the list of belts that are in scope
with open("./ADA_ADO/mlops/uc2/infra/config/belts.json") as fp:
    belts = json.load(fp)

# Loop through each belt and download the respective model artifact
for belt in belts:
    logging.info("Downloading model for belt: {}".format(belt["belt_name"]))

    # Create model name using the model_prefix and belt
    model_name = model_prefix + belt["belt_name"] + "_Model"
    logging.info("Model being downloaded: {}".format(model_name))

    try:
        # Retrieve latest model    
        model = Model(
            workspace = ws,
            name = model_name
        )
        logging.info("Retrieved model with name: {}".format(model_name))
    except:
        logging.info("Could not find model with name: {}".format(model_name))
        continue

    # Download model to local
    model.download(
        target_dir = "new_model/" + belt["belt_name"],
        exist_ok = True
    )
    logging.info("Downloaded model with name: {}".format(model_name))

    # Create metadata artifact and save it in the model
    metadata = {
        "model_name": model.name,
        "description": model.description,
        "version": model.version
    }
    logging.info("Model Metadata: {}".format(metadata))

    # Navigate into the model artifact
    try:
        os.chdir("new_model/" + belt["belt_name"] + "/" + model_folder)
    except:
        logging.info("new_model/{}/{} could not be found".format(belt["belt_name"], model_folder))
        raise ValueError("Model artifact was not downloaded locally in the expected folder")

    with open("metadata.json", "w") as fp:
        json.dump(metadata, fp)
        logging.info("Written model metadata to model artifact")

    # Navigate back to the previous folder
    os.chdir("../../../")
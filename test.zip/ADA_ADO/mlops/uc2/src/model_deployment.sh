# The following bash script deploys an aks endpoint with a model deployment to an Azure ML Workspace
# Usage of this bash script: sh model_deployment.sh -w <workspace_name> -r <resource_group> -b <belt_name> -a <aks_endpoint_name> -e <env> -m <model_prefix> -v <model_version> -c <compute-version>

while getopts w:r:b:a:e:m:v:c:k: flag
do
    case "${flag}" in
        w) workspace_name=${OPTARG};;
        r) resource_group=${OPTARG};;
        b) belt_name=${OPTARG};;
        a) aks_endpoint_name=${OPTARG};;
        e) env=${OPTARG};;
        m) model_prefix=${OPTARG};;
        v) model_version=${OPTARG};;
        c) compute_version=${OPTARG};;
        k) keyvault_name=${OPTARG};;
    esac
done

deployment_name=ada-uc2-cdp-${belt_name}-${env}
deployment_name=${deployment_name,,}

echo "---------- Variables ----------";
echo "Workspace Name: ${workspace_name}";
echo "Resource Group: ${resource_group}";
echo "Belt Name: ${belt_name}"
echo "AKS Endpoint Name: ${aks_endpoint_name}"
echo "AKS Deployment Name: ${deployment_name}"
echo "Env: ${env}"
echo "Model Name: ${model_prefix}"
echo "Model Version: ${model_version}"
echo "Compute Version: ${compute_version}"
echo "Key Vault Name: ${keyvault_name}"

# Try create endpoint
# If it already exists then no need to deploy endpoint and rather deploy model

echo "Searching deployment ${deployment_name}"
OUTPUT=`az ml online-deployment list --endpoint-name ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} --query "length([?name=='${deployment_name}'])"`

cp ../infra/models/${env}/model.yml ../infra/models/${env}/model-${belt_name}-${env}.yml
echo -e "\nenvironment_variables:\n    belt: \"${belt_name}\"\n    env: \"${env}\"\n">>../infra/models/${env}/model-${belt_name}-${env}.yml

if [[ "${OUTPUT}" -eq 1 ]]; then
    echo "+ Found deployment ${deployment_name}"
    echo "Updating Model Deployment ${deployment_name}"
    az ml online-deployment update --name ${deployment_name} --endpoint ${aks_endpoint_name} --resource-group ${resource_group} \
                                   --workspace ${workspace_name} --file ../infra/models/${env}/model-${belt_name}-${env}.yml \
                                   --set model=azureml:${model_prefix}${belt_name}_Model:${model_version} \
                                   --set environment=azureml:uc2-ada-environment:${compute_version} \
                                   --debug  &
    BACK_PID=$!
    wait ${BACK_PID}
    BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
    wait ${BACK_PID2}
    echo "Updating Model Deployment ${deployment_name} DONE"
else
    echo "+ Deployment ${deployment_name} not found"
    echo "Creating Model Deployment ${deployment_name}"

    az ml online-deployment create --name ${deployment_name} --endpoint ${aks_endpoint_name} --resource-group ${resource_group} \
                                   --workspace ${workspace_name} --file ../infra/models/${env}/model.yml \
                                   --set model=azureml:${model_prefix}${belt_name}_Model:${model_version} \
                                   --set environment=azureml:uc2-ada-environment:${compute_version} \
                                   --all-traffic --debug &
    BACK_PID=$!
    wait ${BACK_PID}
    BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
    wait ${BACK_PID2}
    echo "Creating Model Deployment ${deployment_name} DONE"
fi


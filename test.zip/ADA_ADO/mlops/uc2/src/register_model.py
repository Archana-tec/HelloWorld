'''
The following code registers a model from the build artifact.
Works in conjunction with download_model.py for cross workspace model promotion.
'''

import os
import sys
from azureml.core import Workspace, Model
import argparse
import json
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to this folder
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is {}".format(cwd.split("\\")[-1])

# ---------- Parsed Variables ---------- #
parser = argparse.ArgumentParser(description="Argparser")
parser.add_argument('-b', "--belt-name", help = "<Required> Name of the belt for which this pipeline is being created", required = True)
args = parser.parse_args()

# ---------- Environment Variables ---------- #
env = os.environ["ENV"]

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

# ---------- Model Variables ---------- #
belt_name = args.belt_name
model_prefix = os.environ["MODELPREFIX"]
model_folder = os.environ["MODELFOLDER"]
model_name = model_prefix + belt_name + "_Model"

# Output variable being used
logging.info("---------- Environment Variables ----------")
logging.info("Environment: {}".format(env))

logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Model Variables ----------")
logging.info("Belt Name: {}".format(belt_name))
logging.info("Model Prefix: {}".format(model_prefix))
logging.info("Model Folder: {}".format(model_folder))
logging.info("Model Name: {}".format(model_name))

# Authenticating into the current ml workspace
ws = Workspace.get(
    name = workspace_name,
    subscription_id = subscription_id,
    resource_group = resource_group
)
logging.info("Authenticated into the current ML workspace with name: {}".format(workspace_name))

# Retrieve latest in environment model
current_model = Model(
    workspace = ws,
    name = model_name
)

# source directory of the model
new_model_source_directory = "../../../../new_model/" 
current_model_source_directory = "../../../../current_model/"

print("belt name:",belt_name)

# Read new model's metadata
with open(new_model_source_directory + belt_name + "/" + model_folder + "/metadata.json") as fp:
    new_model_metadata = json.load(fp)
    logging.info("Stored new model metadata as variable")
print("new_model_metadata:",new_model_metadata)
# Locally download the current model's artifacts to retrieve the metadata
# If not retrieved, this is the first time the model is being deployed
try:
    current_model.download(
        target_dir = current_model_source_directory,
        exist_ok = True
    )
    logging.info("Downloaded model with name: {}".format(model_name))

    # Grab current model's metadata - in production this is expected to always exist but adding in logic to handle if this is not the case
    try:
        # Read current model's metadata
        with open(current_model_source_directory + belt_name + "/" + model_folder + "/metadata.json") as fp:
            current_model_metadata = json.load(fp)
            logging.info("Stored current model metadata as variable: {}".format(current_model_metadata))
    except:
        # Temporary dictionary
        current_model_metadata = {
            "model_name": "NA",
            "description": "NA",
            "version": "NA"
        }
        logging.info("Stored current model metadata as temp variable: {}".format(current_model_metadata))

    # Compare the two model's metadata to determine whether or not the model being deployed already exists as the latest model
    # Only have to look at version to ensure duplication
    if new_model_metadata["version"] == current_model_metadata["version"]:
        logging.info("Model has already been deployed to this environment and is hence not required to be registered again")
        sys.exit()

except:
    logging.info("First time model is being deployed")

# Register model in environment
Model.register(
    workspace = ws,
    model_path = new_model_source_directory + belt_name + "/" + model_folder,
    model_name = model_name,
    description = new_model_metadata["description"]
)
current_model = Model(
    workspace = ws,
    name = model_name
)
logging.info("Model {} version {} registered as version {} in {}".format(model_name, new_model_metadata["version"], current_model.version, env))
name_model_version='modelversion_'+belt_name
print(f'##vso[task.setvariable variable={name_model_version};]{current_model.version}')


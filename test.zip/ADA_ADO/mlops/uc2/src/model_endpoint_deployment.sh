# The following bash script deploys an aks endpoint with a model deployment to an Azure ML Workspace
# Usage of this bash script: sh model_deployment.sh -w <workspace_name> -r <resource_group> -b <belt_name> -a <aks_endpoint_name> -e <env> -m <model_prefix> -v <model_version> -c <compute-version>

while getopts w:r:b:a:e:m:v:c:k: flag
do
    case "${flag}" in
        w) workspace_name=${OPTARG};;
        r) resource_group=${OPTARG};;
        b) belt_name=${OPTARG};;
        a) aks_endpoint_name=${OPTARG};;
        e) env=${OPTARG};;
        m) model_prefix=${OPTARG};;
        v) model_version=${OPTARG};;
        c) compute_version=${OPTARG};;
        k) keyvault_name=${OPTARG};;
    esac
done

deployment_name=ada-uc2-cdp-${belt_name}-${env}
deployment_name=${deployment_name,,}

echo "---------- Variables ----------";
echo "Workspace Name: ${workspace_name}";
echo "Resource Group: ${resource_group}";
echo "Belt Name: ${belt_name}"
echo "AKS Endpoint Name: ${aks_endpoint_name}"
echo "AKS Deployment Name: ${deployment_name}"
echo "Env: ${env}"
echo "Model Name: ${model_prefix}"
echo "Model Version: ${model_version}"
echo "Compute Version: ${compute_version}"
echo "Key Vault Name: ${keyvault_name}"

# Try create endpoint
# If it already exists then no need to deploy endpoint and rather deploy model

echo "Searching Endpoint ${aks_endpoint_name}"
OUTPUT=`az ml online-endpoint list --resource-group ${resource_group} --workspace ${workspace_name} --query "length([?name=='${aks_endpoint_name}'])"`

if [[ "${OUTPUT}" -eq 1 ]]; then
    echo "+ Found endpoint ${aks_endpoint_name}"
else
    echo "+ Endpoint ${aks_endpoint_name} not found"
    echo "Creating Endpoint ${aks_endpoint_name}"
    az ml online-endpoint create --name ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} \
                                 --file ../infra/endpoints/${env}/${belt_name}_endpoint.yml --debug &

    BACK_PID=$!
    wait ${BACK_PID}
    BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
    wait ${BACK_PID2}
    echo "Creating Endpoint ${aks_endpoint_name} DONE"
fi

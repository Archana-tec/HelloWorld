# The following bash script deploys an aks endpoint with a model deployment to an Azure ML Workspace
# Usage of this bash script: sh model_deployment.sh -w <workspace_name> -r <resource_group> -b <belt_name> -a <aks_endpoint_name> -e <env> -m <model_prefix> -v <model_version> -c <compute-version>
while getopts w:r:b:a:e:m:v:c:k: flag
do
    case "${flag}" in
        w) workspace_name=${OPTARG};;
        r) resource_group=${OPTARG};;
        b) belt_name=${OPTARG};;
        a) aks_endpoint_name=${OPTARG};;
        e) env=${OPTARG};;
        m) model_prefix=${OPTARG};;
        v) model_version=${OPTARG};;
        c) compute_version=${OPTARG};;
        k) keyvault_name=${OPTARG};;
    esac
done

deployment_name=ada-uc2-cdp-${belt_name}-${env}
deployment_name=${deployment_name,,}
lc_belt_name=`echo "${belt_name}" | tr '[:upper:]' '[:lower:]'`

echo "---------- Variables ----------";
echo "Workspace Name: ${workspace_name}";
echo "Resource Group: ${resource_group}";
echo "Belt Name: ${belt_name}"
echo "AKS Endpoint Name: ${aks_endpoint_name}"
echo "AKS Deployment Name: ${deployment_name}"
echo "Env: ${env}"
echo "Model Name: ${model_prefix}"
echo "Model Version: ${model_version}"
echo "Compute Version: ${compute_version}"
echo "Key Vault Name: ${keyvault_name}"

echo "Searching Endpoint ${aks_endpoint_name}"
OUTPUT=`az ml online-endpoint list --resource-group ${resource_group} --workspace ${workspace_name} --query "length([?name=='${aks_endpoint_name}'])"`

if [[ "${OUTPUT}" -eq 1 ]]; then
    echo "+ Found endpoint ${aks_endpoint_name}"

    echo "Assign Key Vault Secrets User role to ${aks_endpoint_name}"
    # Get the object ID of the newly created endpoint
    assignee_object_id=`az ml online-endpoint show --resource-group ${resource_group} --workspace ${workspace_name} --name ${aks_endpoint_name} --query "identity.principal_id" -o tsv`

    echo "assignee_object_id: ${assignee_object_id}"

    # Get the scope path of the keyvault
    kv_scope=`az keyvault show --resource-group ${resource_group} --name ${keyvault_name}  --query "id" -o tsv`
    echo "scope: ${kv_scope}"

    role_definition=`MSYS_NO_PATHCONV=1 az.bat role definition list --scope ${kv_scope} --query "[?roleName=='Key Vault Secrets User'].id" -o tsv`
    echo "role_definition: ${role_definition}"

    role_assigned=`MSYS_NO_PATHCONV=1 az.bat role assignment list --role ${role_definition} --scope ${kv_scope} --query "length([?principalId=='${assignee_object_id}'])"`
    if [[ "${role_assigned}" -eq 0 ]]; then
      # # Assign Key Vault Secrets User role to the newly created endpoint
      MSYS_NO_PATHCONV=1 az.bat role assignment create --role ${role_definition} --scope ${kv_scope} --assignee-object-id ${assignee_object_id} --assignee-principal-type ServicePrincipal

      BACK_PID=$!
      wait ${BACK_PID}
      BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
      wait ${BACK_PID2}
    else
      echo "Assign Key Vault Secrets User role to ${aks_endpoint_name} EXISTS"
    fi
    echo "Assign Key Vault Secrets User role to ${aks_endpoint_name} DONE"
fi

echo "Searching deployment ${deployment_name}"
OUTPUT=`az ml online-deployment list --endpoint-name ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} --query "length([?name=='${deployment_name}'])"`

 if [[ "${OUTPUT}" -eq 1 ]]; then
     echo "+ Found deployment ${deployment_name}"
     echo "Updating Model Deployment ${deployment_name}"

     echo "Registering API URI ${deployment_name}"
     SCORING_URI=`az ml online-endpoint show --resource-group ${resource_group} --workspace ${workspace_name} --name ${aks_endpoint_name} --query "scoring_uri" -o tsv`
     echo "Scoring URI = ${SCORING_URI}"

     az keyvault secret set --vault-name ${keyvault_name} -n uc2-inference-endpoint-url-${lc_belt_name}-${env}  --value ${SCORING_URI}

     BACK_PID=$!
     wait ${BACK_PID}
     BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
     wait ${BACK_PID2}

     echo "Registering API URI ${deployment_name} DONE"


     echo "Registering API Key ${deployment_name}"
     API_KEY=`az ml online-endpoint get-credentials --resource-group ${resource_group} --workspace ${workspace_name} --name ${aks_endpoint_name} --query "primaryKey" -o tsv`
     echo "API Key fetched!"
     echo "Scoring URI = ${SCORING_URI}">/dev/null
     echo "Scoring URI = ****"

     az keyvault secret set --vault-name ${keyvault_name} -n uc2-inference-endpoint-apikey-${lc_belt_name}-${env}  --value ${API_KEY}

     BACK_PID=$!
     wait ${BACK_PID}
     BACK_PID2=`ps ax|grep "python3 -Im azure.cli"|cut -f1| awk '{print $1}'|head -n 1`
     wait ${BACK_PID2}

     echo "Registering API Key ${deployment_name} DONE"

 fi


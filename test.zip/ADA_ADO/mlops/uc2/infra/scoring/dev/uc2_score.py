import os
import sys
import logging
import json
import datetime
import pandas as pd
import numpy as np
import pyodbc
from azure.storage.blob import BlobServiceClient
import configparser
import traceback

from key_vault_reader import KeyVaultReader


def init():
    """
    This function is called when the container is initialized/started, typically after create/update of the deployment.
    You can write the logic here to perform init operations like caching the model in memory
    """
    # Specify model path for importing UC2 model
    global model_path
    model_path = os.path.join(os.getenv("AZUREML_MODEL_DIR"), 'UC2_Model')
    sys.path.append(model_path)

    logging.info("Init complete")


def run(raw_data):
    """
    This function is called for every invocation of the endpoint to perform the actual scoring/prediction.
    In the example we extract the data from the json input and call the scikit-learn model's predict()
    method and return the result back
    """
    # Import UC2 model inference function
    sys.path.append(model_path)
    from ADA_UC2_CDP.uc2_inference_model import uc2_cdp_model

    # Retrieve input data (timestamp to make prediction at)
    print("Request received")
    print(f"raw_data = {raw_data}")
    data = json.loads(raw_data)["data"]
    data = np.array(data)
    dt = datetime.datetime(data[0, 0], data[0, 1], data[0, 2], data[0, 3], data[0, 4])

    belt = os.environ['belt']
    print(f'Belt = {belt}')
    # Get Config locations and paths
    cfg_path = model_path + '/config/config-gd.ini'
    config_obj = configparser.ConfigParser()
    config_obj.read(cfg_path)

    # Environment - Workspace in which which the script is being executed in
    env = os.environ['env']
    if env == 'dev':
        kv_env = 'dev'
        kv_name = 'kv-rt-dsdev-ae-ada01'
    else:
        if env == 'prod':
            kv_env = 'prod'
        else:
            kv_env = 'uat'
        kv_name = 'kvaedsprodrtioada'

    print(f'env = {env}')
    print(f'Key Vault Name = {kv_name}')
    kv_reader = KeyVaultReader(keyvault_name=kv_name)

    # Get credentials information to connect to blob result container
    # Account_uri = config_obj['credentials_'+env]['Account_uri']
    Account_uri = kv_reader.get_secret(f'config-sa-account-uri-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    container_name = 'ada-results-storage-' + kv_env

    # Generate model output
    try:
        df = uc2_cdp_model(dt, belt, classifier='rf')

        print('Prediction - ' + df['belt'][0] + ' - ' + str(df['datetime_of_prediction'][0]) + ' : ' + df['prediction'][
            0])
        result = df.loc[0, :].to_json()
        print(f"Result = {result}")
    except Exception as e:
        print('Failed when generating model output: ' + str(e))
        error_type = str(type(e)).split("'")[1]
        print(f'Error type: {error_type}')
        tb = traceback.format_exc().replace(r'"', r'\"')
        print(f'Traceback:')
        print(f'{tb}:')
        return '{"status": "failed", "error_message": "' + str(e) + '", "error_type": "' + error_type + '"}'

    # Write model output to ADA Results SQL database
    hostname = kv_reader.get_secret(f'sqlserver-hostname-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    database = kv_reader.get_secret(f'sqlserver-database-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    username = kv_reader.get_secret(f'sqlserver-username-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    password = kv_reader.get_secret(f'sqlserver-password-{kv_env}')  # kv_env = ['dev',' uat', 'prod']

    try:
        with pyodbc.connect(
                r'Driver={ODBC Driver 17 for SQL Server};'
                r'Server=tcp:' + hostname + ',1433;'
                                            r'Database=' + database + ';'
                                                                      r'Uid=' + username + ';'
                                                                                           r'Pwd={' + password + '};'
                                                                                                                 r'Encrypt=yes;'
                                                                                                                 r'TrustServerCertificate=yes;'
                                                                                                                 r'Connection Timeout=30;'
        ) as cnxn:
            cursor = cnxn.cursor()
        for index, row in df.iterrows():
            cursor.execute("INSERT INTO ADA_UC2_CDP.RESULTS ([Datetime of prediction],Belt,Prediction,[Probability Normal],\
                            [Probability BeltDrift],[Probability Operational Blockage],[Downtime duration median],\
                            [Downtime duration Q1],[Downtime duration Q3],[Downtime duration IQR]) values(?,?,?,?,?,?,?,?,?,?)", \
                           row.datetime_of_prediction, row.belt, row.prediction, row.probability_normal,
                           row.probability_belt_drift, \
                           row.probability_operational_blockage, row.downtime_duration_median_mins,
                           row.downtime_duration_q1_mins, \
                           row.downtime_duration_q3_mins, row.downtime_duration_iqr_mins)
        cnxn.commit()
        cursor.close()
    except Exception as e:
        print('Failed when generating model output: ' + str(e))
        error_type = str(type(e)).split("'")[1]
        print(f'Error type: {error_type}')
        tb = traceback.format_exc().replace(r'"', r'\"')
        print(f'Traceback:')
        print(f'{tb}:')
        return '{"status": "failed", "error_message": "' + str(e) + '", "error_type": "' + error_type + '"}'

    try:
        # Write to Blob Result Container as CSV
        output = df.to_csv(encoding="utf-8", index=False)  # Save csv locally
        # Call Blob Client
        blob_service = BlobServiceClient.from_connection_string(Account_uri)
        # Upload CSV to blob container
        blob_client = blob_service.get_blob_client(container=container_name, blob=(
                    'ADA_UC2_CDP/' + belt + '/' + belt + '_CDP_prediction_results_' + str(dt)[0:10] + 'T' + str(dt)[
                                                                                                            11:16] + '.csv').replace(
            ':', '_'))
        blob_client.upload_blob(output, overwrite=True)

        logging.info('Uploaded CSV file to Blob: ' + (
                    'ADA_UC2_CDP/' + belt + '/' + belt + '_CDP_prediction_results_' + str(dt)[0:10] + 'T' + str(dt)[
                                                                                                            11:16] + '.csv').replace(
            ':', '_'))
    except Exception as e:
        print('Failed when generating model output: ' + str(e))
        error_type = str(type(e)).split("'")[1]
        print(f'Error type: {error_type}')
        tb = traceback.format_exc().replace(r'"', r'\"')
        print(f'Traceback:')
        print(f'{tb}:')
        return '{"status": "failed", "error_message": "' + str(e) + '", "error_type": "' + error_type + '"}'

    return result   
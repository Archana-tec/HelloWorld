from azure.identity import ManagedIdentityCredential, DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

class KeyVaultReader:
    def __init__(self, keyvault_name, tenant_id=None):
        if tenant_id==None:
            credential = DefaultAzureCredential()
        else:
            credential = ManagedIdentityCredential(tenant_id=tenant_id)
        self.client = SecretClient(f"https://{keyvault_name}.vault.azure.net", credential)

    def get_secret(self, secret_name):
        secret = self.client.get_secret(secret_name)
        return secret.value
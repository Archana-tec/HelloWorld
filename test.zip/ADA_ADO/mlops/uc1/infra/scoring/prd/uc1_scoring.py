import os
import sys
import logging
import json
import datetime
import pandas as pd
import numpy as np
import pyodbc
from azure.storage.blob import BlobServiceClient
import configparser

from key_vault_reader import KeyVaultReader

def init():
    """
    This function is called when the container is initialized/started, typically after create/update of the deployment.
    You can write the logic here to perform init operations like caching the model in memory
    """
    # Specify model path for importing UC2 model
    global model_path
    model_path = os.path.join(os.getenv("AZUREML_MODEL_DIR"),'UC1_Model')
    sys.path.append(model_path)
    
    logging.info("Init complete")

def run(raw_data):
    """
    This function is called for every invocation of the endpoint to perform the actual scoring/prediction.
    In the example we extract the data from the json input and call the scikit-learn model's predict()
    method and return the result back
    """
    # Import UC2 model inference function    
    sys.path.append(model_path)
    from ADA_UC1_TLO.uc1_model import uc1_tlo_model_inference

    # Get Config locations and paths
    cfg_path = model_path+'/config/config-gd.ini'
    config_obj = configparser.ConfigParser()
    config_obj.read(cfg_path)
        
    # Environment - Workspace in which which the script is being executed in
    env = 'prd' 
    if env == 'dev':
        kv_env = 'dev'
        kv_name = 'kv-rt-dsdev-ae-ada01'
    else:
        if env=='prd':
            kv_env = 'prod'
        else:
            kv_env = 'uat'
        kv_name = 'kvaedsprodrtioada'

    kv_reader = KeyVaultReader(tenant_id=os.environ["SPTENANTID"],
                               keyvault_name=kv_name)

    # Get credentials information to connect to blob result container
    # Account_uri = config_obj['credentials_'+env]['Account_uri']
    Account_uri = kv_reader.get_secret(f'config-sa-account-uri-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    container_name = 'ada-results-storage-'+env

    # Retrieve input data (timestamp to make prediction at)
    logging.info("Request received")
    data = json.loads(raw_data)["data"]
    data = np.array(data)
    dt = datetime.datetime(data[0,0],data[0,1],data[0,2],data[0,3],data[0,4])
    
    # Generate model output
    df = uc1_tlo_model_inference(dt, identify_delay_method='ml', delay_duration_method='GD-only', tlo_stage_timing_method='GD-historical',env='uat')
    
    # Print result for Train 1
    result_train1 = df.iloc[0,:].to_json()
    print(result_train1)
    # Reset index to get datetime and train columns 
    df_outputs = df.reset_index()
    # Replace NaN with None (Sql friendly)
    df_outputs = df_outputs.astype(object).where(pd.notnull(df_outputs), None)

    # # Write full output df to ADA Results SQL database (Trains 1 to 5)
    hostname = kv_reader.get_secret(f'sqlserver-hostname-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    database = kv_reader.get_secret(f'sqlserver-database-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    username = kv_reader.get_secret(f'sqlserver-username-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    password = kv_reader.get_secret(f'sqlserver-password-{kv_env}')  # kv_env = ['dev',' uat', 'prod']
    with pyodbc.connect(
                        r'Driver={ODBC Driver 17 for SQL Server};'
                        r'Server=tcp:'+hostname+',1433;'
                        r'Database='+database+';'
                        r'Uid='+username+';'
                        r'Pwd={'+password+'};'
                        r'Encrypt=yes;'
                        r'TrustServerCertificate=yes;'
                        r'Connection Timeout=30;'
                        ) as cnxn:
                            cursor = cnxn.cursor()
    for index, row in df_outputs.iterrows(): 
        cursor.execute("INSERT INTO ADA_UC1_TLO.RESULTS ([Datetime],[train],[train_id],[train_status],\
                       [product],[num_cars],[cars_remaining],[arrival_sched],[arrival_actual],[comm_loading_sched],\
                       [comm_loading_forecast],[comm_loading_actual],[comp_loading_sched],[comp_loading_forecast],\
                       [comp_loading_actual],[depart_sched],[depart_forecast],[depart_actual],[train1_comm_loading_delay_model],\
                       [train1_loading_delay_model],[train1_departure_delay_model],[comp_loading_forecast_q1],[comp_loading_forecast_q3],\
                       [train1_delay_duration_q1],[train1_delay_duration_q3],[delay_event_in_progress],[delay_event_type],\
                       [delay_event_cause],[delay_event_asset],[delay_event_start] ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",\
                        row['datetime'],row.train,row.train_id,row.train_status,row['product'],int(row.num_cars),int(row.cars_remaining),row.arrival_sched,\
                        row.arrival_actual,row.comm_loading_sched,row.comm_loading_forecast,row.comm_loading_actual,row.comp_loading_sched,\
                        row.comp_loading_forecast,row.comp_loading_actual,row.depart_sched,row.depart_forecast,row.depart_actual,\
                        int(row.train1_comm_loading_delay_model),int(row.train1_loading_delay_model),int(row.train1_departure_delay_model),\
                        row.comp_loading_forecast_q1,row.comp_loading_forecast_q3,int(row.train1_delay_duration_q1),int(row.train1_delay_duration_q3),\
                        row.delay_event_in_progress,row.delay_event_type,row.delay_event_cause,row.delay_event_asset,row.delay_event_start )
    cnxn.commit()
    cursor.close()

    # Write to Blob Result Container as CSV
    output = df_outputs.to_csv(encoding="utf-8",index=False) # Save csv locally
    # Call Blob Client
    blob_service = BlobServiceClient.from_connection_string(Account_uri)
    # Get Container Client
    container_client = blob_service.get_container_client(container_name)
    # Upload CSV to blob container
    blob_client = blob_service.get_blob_client(container=container_name, blob=('ADA_UC1_TLO/ADA_UC1_TLO_results_'+str(dt)[0:10]+'T'+str(dt)[11:16]+'.csv').replace(':','_'))
    blob_client.upload_blob(output,overwrite=True)

    logging.info('Uploaded CSV file to Blob: '+ ('ADA_UC1_TLO_results_'+str(dt)[0:10]+'T'+str(dt)[11:16]+'.csv').replace(':','_'))

    return result_train1   
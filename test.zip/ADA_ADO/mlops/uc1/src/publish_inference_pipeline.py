'''
The following code is intended to deploy, run, and schedule UC1's training pipeline.
The outcome of which is a new registered model version for UC1.
'''

import os
import datetime
from azureml.core import Workspace, Experiment, Environment, Dataset, Model
from azureml.core.compute import AmlCompute
from azureml.core.datastore import Datastore
from azureml.core.runconfig import RunConfiguration, DockerConfiguration
from azureml.pipeline.core import Pipeline, PipelineData, Schedule, ScheduleRecurrence, PublishedPipeline
from azureml.pipeline.steps import PythonScriptStep
from azureml.data import OutputFileDatasetConfig
import logging
import uuid
import shutil
from distutils.dir_util import copy_tree
from glob import glob

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the uc1 folder
'''
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
assert cwd.split("\\")[-1] == "src", "Current working directory is {}".format(cwd.split("\\")[-1])
'''

# ---------- Environment Variables ---------- #
env = os.environ["ENV"]

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# ---------- Compute Variables ---------- #
compute_name = os.environ["COMPUTENAME"]

# ---------- Docker Environment Variables ---------- #
environment_name = os.environ["ENVIRONMENTNAME"]

# ---------- Model Variables ---------- #
model_name = os.environ["MODELNAME"]
model_version = os.environ["MODELVERSION"]   # model version can be different from DEV, UAT, and PROD

# ---------- Pipeline Variables ---------- #
pipeline_name = "uc1_inference_pipeline"
pipeline_schedule_name = "uc1_inference_pipeline_schedule"

# Output variables being used
logging.info("---------- Environment Variables ----------")
logging.info("Environment: {}".format(env))

logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Compute Variables ----------")
logging.info("Compute Name: {}".format(compute_name))

logging.info("---------- Docker Environment Variables ----------")
logging.info("Environment Name: {}".format(environment_name))

logging.info("---------- Pipeline Variables ----------")
logging.info("Model Name: {}".format(model_name))
logging.info("Model Version: {}".format(model_version))

# Authenticating into the ml workspace

from azureml.core.authentication import ServicePrincipalAuthentication
svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)

ws = Workspace.get(
    name=workspace_name,
    subscription_id=subscription_id,
    resource_group=resource_group,
    auth = svc_pr
)

# ---------- Disable Old Experiment and Schedule ---------- #
def disable_pipeline_and_schedule(ws, scheduler_name, pipeline_name):
    logging.info(f"Disableing Pipeline and Schedule")
    logging.info(f"- Scheduler name = {scheduler_name}")
    logging.info(f"- Pipeline name = {pipeline_name}")
    # Find and disable scoring schedules
    pipeline_schedules = Schedule.list(
        workspace=ws
    )

    # Find and disable azure ml pipelines
    published_pipelines = PublishedPipeline.list(
        workspace=ws
    )

    schedules = [
        schedule for schedule in pipeline_schedules
        if schedule.name in list([scheduler_name])
    ]
    logging.info(f"{len(schedules)} number of schedules found")

    # Disable old schedule
    for schedule in schedules:
        schedule.disable()
        logging.info("{} succcessfully disabled".format(schedule._name))
    logging.info("Successfully disabled all pipeline schedules")

    pipelines = [
        pipeline for pipeline in published_pipelines
        if pipeline._name in list([pipeline_name])
    ]
    logging.info("{} number of pipelines found".format(len(pipelines)))

    # Disable old pipelines
    for pipeline in pipelines:
        PublishedPipeline.get(
            workspace = ws,
            id = pipeline.id
        ).disable()
        logging.info("{} succcessfully disabled".format(pipeline._name))
    logging.info("Successfully disabled all pipelines")

def copy_and_overwrite(from_path, to_path):
    if os.path.exists(to_path):
        shutil.rmtree(to_path)
    return shutil.copytree(from_path, to_path)

# ---------- Create New Pipeline Experiment ---------- #
# Grab the workspace and landing prod datastore
if env=='dev':
    datastore_name1='ada_results_storage_dev'
elif env=='uat':
    datastore_name1 = 'ada_results_storage_uat'
else:
    datastore_name1='ada_results_storage_prod'

ada_results_datastore = Datastore.get(
    workspace = ws,
    datastore_name = datastore_name1
)
logging.info("Retrieved workspace datastore with name: {}".format(ada_results_datastore.name))

# Grab the compute cluster that the pipeline will run on
aml_compute_cluster = AmlCompute(
    workspace = ws,
    name = compute_name
)

# Setting up compute environment
my_env = Environment.get(
    workspace = ws,
    name = environment_name
)
run_config = RunConfiguration()
docker_config = DockerConfiguration(use_docker = True)
run_config.docker = docker_config
run_config.environment = my_env
logging.info("Set up compute with name = {} and environment with name = {}".format(compute_name, environment_name))

# Download model from AML
uuid_str = str(uuid.uuid4())
source_directory = Model(ws, name=model_name, version=model_version).download(target_dir=f'/tmp/{uuid_str}')
logging.info(f'Download model {model_name}:{model_version} from AML to {source_directory}')

copied_files = copy_and_overwrite(f'./ADA_UC1_TLO/', source_directory + '/ADA_UC1_TLO/')
logging.info(f'Copy Python files to the deployment folder')
logging.info(f'Copied files = {copied_files}')

copied_files = copy_and_overwrite(f'./config/', source_directory + '/config/')
logging.info(f'Copy config to the deployment folder')
logging.info(f'Copied files = {copied_files}')

shutil.copyfile(f'./load_ADA_data.py', source_directory + '/load_ADA_data.py')
shutil.copyfile(f'./key_vault_reader.py', source_directory + '/key_vault_reader.py')
logging.info(f'Copy additional python files to the deployment folder')

if env == 'prod':
    inference_env = 'prd'
else:
    inference_env = env


output_folder = OutputFileDatasetConfig(destination=(ada_results_datastore, 'ADA_UC1_TLO'))

inference_step = PythonScriptStep(script_name="ADA_UC1_TLO/uc1_inference_pipeline.py",
                                source_directory=source_directory,
                                outputs=[output_folder],
                                arguments = ["--output", output_folder, "--env", inference_env],  # dev, uat, and prd -- yes accenture use prd not prod
                                compute_target=aml_compute_cluster,
                                runconfig=run_config,
                                allow_reuse=False)


# ---------- Disable Old Experiment and Schedule ---------- #
disable_pipeline_and_schedule(ws, pipeline_schedule_name, pipeline_name)

# Create pipeline object
pipeline = Pipeline(
    workspace=ws,
    steps=[inference_step]
)

published_pipeline = pipeline.publish(
        name=pipeline_name,
        description="UC1 Training Pipeline",
        version="1.0"
    )
logging.info(f"Successfully published {pipeline_name} pipeline to Azure ML workspace")


# ---------- Publish New Pipeline and Create Schedule ---------- #
# Set up a recurring schedule
'''
if env=='dev':
    recurrence = ScheduleRecurrence(
        frequency="Day",
        minutes=[0],
        hours=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23],
        interval=1
    )
else:
    recurrence = ScheduleRecurrence(
        frequency = "Minute",
        interval = 3
    )
'''
if env=='dev':
    recurrence = ScheduleRecurrence(
        frequency = "Minute",
        interval = 3
    )
else:
    recurrence = ScheduleRecurrence(
        frequency = "Minute",
        interval = 3
    )

pipeline_id = published_pipeline.id
experiment_name = pipeline_name

recurring_schedule = Schedule.create(
        workspace=ws,
        name=pipeline_schedule_name,
        description="UC1 Inference Pipeline Schedule",
        pipeline_id=pipeline_id,
        experiment_name=experiment_name,
        recurrence=recurrence
)
logging.info("Successfully created schedule for the published pipeline")



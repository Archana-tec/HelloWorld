# The following bash script deploys an aks endpoint with a model deployment to an Azure ML Workspace
# Usage of this bash script: sh model_deployment.sh -w <workspace_name> -r <resource_group> -a <aks_endpoint_name> -e <env> -m <model_name> -v <model_version> -c <compute_version>

while getopts w:r:a:e:m:v:c: flag
do
    case "${flag}" in
        w) workspace_name=${OPTARG};;
        r) resource_group=${OPTARG};;
        a) aks_endpoint_name=${OPTARG};;
        e) env=${OPTARG};;
        m) model_name=${OPTARG};;
        v) model_version=${OPTARG};;
        c) compute_version=${OPTARG};;
    esac
done

echo "---------- Variables ----------";
echo "Workspace Name: ${workspace_name}";
echo "Resource Group: ${resource_group}";
echo "AKS Endpoing Name: ${aks_endpoint_name}"
echo "Env: ${env}"
echo "Model Name: ${model_name}"
echo "Model Version: ${model_version}"
echo "Compute Version: ${compute_version}"

# Try create endpoint
# If it already exists then no need to deploy endpoint and rather deploy model
{ # Try
    echo "Creating Endpoint"
    az ml online-endpoint create --name ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} --file ../infra/endpoints/${env}/endpoint.yml --debug

    echo "Creating Model Deployment"
    az ml online-deployment create --name ada-uc1-tlo-${env} --endpoint ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} --file ../infra/models/${env}/model.yml --set model=azureml:${model_name}:${model_version} --set environment=azureml:uc1-ada-environment:${compute_version} --all-traffic --debug
} || { # If error
    echo "Endpoint already exists"
    echo "Deleting Existing Model Deployment"
    az ml online-deployment delete --name ada-uc1-tlo-${env} --endpoint ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name}  --debug

    echo "Creating Model Deployment"
    az ml online-deployment create --name ada-uc1-tlo-${env} --endpoint ${aks_endpoint_name} --resource-group ${resource_group} --workspace ${workspace_name} --file ../infra/models/${env}/model.yml --set model=azureml:${model_name}:${model_version} --set environment=azureml:uc1-ada-environment:${compute_version} --all-traffic --debug
}
'''
The following code downloads the latest UC1 model within an environment.
The downloaded model is then used in a build artifact so that it is available for registration in another AML workspace.
Enables cross account model promotion.
'''

import os
from azureml.core import Workspace, Model
import json
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

# ---------- Model Variables ---------- #
model_name = os.environ["MODELNAME"]
model_folder = os.environ["MODELFOLDER"]

# Output variable being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Model Variables ----------")
logging.info("Model Name: {}".format(model_name))
logging.info("Model Folder: {}".format(model_folder))

# Authenticating into the current ml workspace
ws = Workspace.get(
    name = workspace_name,
    subscription_id = subscription_id,
    resource_group = resource_group
)
logging.info("Authenticated into the current ML workspace with name: {}".format(workspace_name))

# Retrieve latest model
model = Model(
    workspace = ws,
    name = model_name
)

# Download model to local
model.download(
    target_dir = "new_model",
    exist_ok = True
)
logging.info("Downloaded model with name: {}".format(model_name))

# Create metadata artifact and save it in the model
metadata = {
    "model_name": model.name,
    "description": model.description,
    "version": model.version
}
logging.info("Model Metadata: {}".format(metadata))

# Navigate into the model artifact
try:
    print("enter to chng the model directory")
    os.chdir("new_model/" + model_folder)
    logging.info("Model directory: {}".format(os.getcwd()))
except:
    logging.info("Exception")
    logging.info("new_model/{} could not be found".format(model_folder))
    raise ValueError("Model artifact was not downloaded locally in the expected folder")

with open("metadata.json", "w") as fp:
    json.dump(metadata, fp)
    logging.info("Written model metadata to model artifact")
'''
The following code creates the datastore and dataset references within the Azure ML workspace.
These references enable the referencing of data stored in ADLS within the workspace.
'''

import os
from azureml.core import Workspace, Datastore, Dataset
import json
import logging
from azureml.core.authentication import InteractiveLoginAuthentication, ServicePrincipalAuthentication, AzureCliAuthentication

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]
tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# Authenticating into the ml workspace

from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core import Workspace
from azureml.core.authentication import AzureCliAuthentication, InteractiveLoginAuthentication

# workspace authentication
try:
    # use cli authentication for automated process    
    auth = AzureCliAuthentication()
    auth.get_authentication_header()
except Exception as e:
    print(f"[ERROR] Failed to authenticate using AzureCliAuthentication {e.args}, trying InteractiveLoginAuthentication") 
    auth = InteractiveLoginAuthentication(tenant_id=os.environ["SPTENANTID"])
'''
cli_auth = AzureCliAuthentication()
print(cli_auth)


from azureml.core.authentication import InteractiveLoginAuthentication
ia = InteractiveLoginAuthentication(tenant_id=tenant_id,force=True)

svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)
'''


try:
    # set workspace    
    ws = Workspace.get(name=workspace_name,subscription_id=subscription_id,resource_group=resource_group,auth=auth)
except:
    # if doesn't exist then create one, could take 1-2 min
    print(f"[INFO] {workspace_name} does not exist, creating it...")
    ws = Workspace.create(name=workspace_name,subscription_id=subscription_id,resource_group=resource_group,create_resource_group=True,location=location,auth=auth)
    print('[INFO] Successfully retrieved workspace:',ws.name,ws.resource_group,ws.location,ws.subscription_id, sep="\n")

'''
ws = Workspace.get(
    name = workspace_name,
    resource_group = resource_group,
    subscription_id = subscription_id,
    auth = svc_pr)

logging.info("Authenticated into workspace via Interactive Login Authentication method")

# Listing authentication
try:
    print(vars(ws._auth_object))
except Exception as e:
    print(e)
try:
    print(vars(ws._auth))
except Exception as e:
    print(e)

# List datastores
try:
    print(ws.datastores)
except Exception as e:
    print(e)

# List models
try:
    print(ws.models)
except Exception as e:
    print(e)

# List experiments
try:
    print(ws.experiments)
except Exception as e:
    print(e)

# List workspace details
try:
    print(vars(ws))
except Exception as e:
    print(e)

# Get the default datastore (asserting ws connection is right)
blob_store = ws.get_default_datastore()

# Check connection was successful
try:
    print("Blob store:", vars(blob_store))
except:
    print("vars did not work")

try:
    print("Blob store directory:", dir(blob_store))
except:
    print("dir didn't work")



'''

# ---------- Environment Variables ---------- #
env = os.environ["ENV"]

# Output global variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Environment Variables ----------")
logging.info("Env: {}".format(env))

# Pring current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the infrastructure folder
cwd = os.getcwd()
print(cwd)
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is incorrect - can not find config files"

# Authenticating into the ml workspace
#ws = Workspace.from_config()
#ws = Workspace.get(
#    name=workspace_name,
#    subscription_id=subscription_id,
#    resource_group=resource_group
#)
print("workspace name:",ws)

# Create datastores form config file
#with open("..\\config\\datastores_config.json") as fp:
with open("./ADA_ADO/infrastructure/config/datastores_config.json") as fp:
    # Read in data from config file
    data = json.load(fp)

    # For each datastore defined in the config file
    for datastore in data:
        # Log the dictionary to the console
        logging.info("Datastore Detail:\n{}".format(datastore))

        # Store datastore_name as it's own variable from the datastore dictionary
        datastore_name = datastore["datastore_name"]
        datastore_acnt_name = datastore["account_name"]
        datastore_cnt_name = datastore["container_name"]
        datastore_type=datastore["datastore_type"]
        

        # If the datastore is not intended for the environment being deployed to then skip
        if env not in datastore["env"]:
            logging.info("Datastore {} is not intended for {}".format(datastore_name, env))
            continue

        # Verify that the datastore does not exist already
        print("Datastore name", datastore_name)
        print("referring account name:",datastore_acnt_name)
        
        try:
            print("workspace name:",ws)
            datastore = Datastore.get(
                workspace = ws, 
                datastore_name = datastore_name
            
            )
            print("datastore:",datastore)
            print(datastore.account_name)
            logging.info("Datastore with name {} already exists.".format(datastore_name))
            '''
            if datastore.account_name == datastore_acnt_name:
                logging.info("Datastore with name {} already exists.".format(datastore))
                logging.info("Datastore with name {} already exists.".format(datastore_name))
            else:
                if datastore_type == "Azure Blob Container":
                    print(datastore_name,account_name,container_name)
                    datastore = Datastore.register_azure_blob_container(
                    workspace = ws,
                    datastore_name = datastore_name,
                    overwrite=True,
                    account_name = datastore_acnt_name, # Storage account name
                    container_name = datastore_cnt_name # Name of Azure blob container
                    )
                    logging.info("Registered Azure Blob Storage Datastore with name: {}".format(datastore_name))
                    logging.info("Registered Azure Blob Storage Datastore: {}".format(datastore))
                elif datastore_type == "Azure File Share":

                    datastore = Datastore.register_azure_blob_container(
                    workspace = ws,
                    datastore_name = datastore_name,
                    overwrite=True,
                    account_name = datastore_acnt_name, # Storage account name
                    file_share_name = datastore_cnt_name # Name of Azure File Share
                    )
                    logging.info("Registered Azure File Share Datastore with name: {}".format(datastore_name))
            '''
        except:
        
            # Check the type of datastore required and register in the azure ml workspace
            if datastore_type == "Azure Data Lake Storage Gen2":
                datastore = Datastore.register_azure_data_lake_gen2(
                    workspace = ws,
                    datastore_name = datastore_name,
                    overwrite=True,
                    subscription_id=subscription_id, 
                    resource_group=resource_group,
                    tenant_id=tenant_id, 
                    client_id=principal_id, 
                    client_secret=client_secret,
                    grant_workspace_access= True,
                    account_name = datastore_acnt_name, # Storage account name
                    filesystem =datastore_cnt_name # Name of Azure blob container
                )
                logging.info("Registered Azure Blob Storage Datastore with name: {}".format(datastore_name))
                logging.info("Registered Azure Blob Storage Datastore: {}".format(datastore))
            elif datastore_type == "Azure File Share":
                # datastore = register_azure_file_share_datastore(
                #     workspace = ws,
                #     datastore_name = datastore_name,
                #     overwrite=True,
                #     account_name = datastore_acnt_name, # Storage account name
                #     file_share_name = datastore_cnt_name # Name of Azure File Share
                datastore = Datastore.register_azure_file_share(
                    workspace = ws,
                    datastore_name = datastore_name,
                    overwrite=True,
                    # subscription_id=subscription_id, 
                    # resource_group=resource_group,
                    # tenant_id=tenant_id, 
                    # client_id=principal_id, 
                    # client_secret=client_secret,
                    # grant_workspace_access= True,
                    account_name = datastore_acnt_name, # Storage account name
                    file_share_name = datastore_cnt_name, # Name of Azure File Share
                    create_if_not_exists = True
                )
                logging.info("Registered Azure File Share Datastore with name: {}".format(datastore_name))

# Create from datasets from config file
# with open("./ADA_ADO/infrastructure/config/file_datasets_config.json") as fp:
# #with open("..\\config\\file_datasets_config.json") as fp:
#     # Read in data from config file
#     data = json.load(fp)

#     # For each dataset defined in the config file
#     for file_dataset in data:
#         # Log the dictionary to the console
#         logging.info("Dataset Detail:\n{}".format(file_dataset))

#         # Store dataset_name as it's own variable from the dataset dictionary
#         dataset_name = file_dataset["dataset_name"]
#         datastore_name = file_dataset["datastore_name"]
#         print(env)
#         # If the datastore is not intended for the environment being deployed to then skip
#         if env not in file_dataset["env"]:
#             logging.info(" File dataset {} and Datastore {} is not intended for {}".format(dataset_name,datastore_name, env))
#             continue

#         # Verify that the dataset does not exist already
        
#         try:
#             print("in try block for getting dataset from WS:", ws)
#             print("dataset name:",dataset_name)
#             dataset = Dataset.get_by_name(
#                 workspace = ws, 
#                 name = dataset_name
#             )
#             logging.info("Dataset with name {} already exists.".format(dataset_name))
#         # If it does not, create and register the dataset
#         except:
#             print("in except block for registering dataset in WS:",ws)
#             datastore = Datastore.get(
#                 workspace = ws, 
#                 datastore_name = datastore_name
#             )
#             dataset = Dataset.File.from_files(
#                 path = (datastore, file_dataset["dataset_path"]),
#                 validate = False
#             )
#             dataset.register(
#                 workspace = ws,
#                 name = dataset_name,
#                 create_new_version=True
#             )
#             logging.info("Registered file dataset with name: {}".format(dataset_name))

# Create from datasets from config file
with open("./ADA_ADO/infrastructure/config/tabular_datasets_config.json") as fp:
#with open("..\\config\\tabular_datasets_config.json") as fp:
    # Read in data from config file
    data = json.load(fp)

    # For each dataset defined in the config file
    for table_dataset in data:
        # Log the dictionary to the console
        logging.info("Dataset Detail:\n{}".format(table_dataset))

        # Store dataset_name as it's own variable from the dataset dictionary
        dataset_name = table_dataset["dataset_name"]
        datastore_name = table_dataset["datastore_name"]

        # If the datastore is not intended for the environment being deployed to then skip
        if env not in table_dataset["env"]:
            logging.info(" Table dataset {} and Datastore {} is not intended for {}".format(dataset_name,datastore_name, env))
            continue

        # Verify that the dataset does not exist already
        
        try:
            dataset = Dataset.get_by_name(
                workspace = ws, 
                name = dataset_name
            )
            logging.info("Dataset with name {} already exists.".format(dataset_name))
        # If it does not, create and register the dataset
        except:
        
            datastore = Datastore.get(
                workspace = ws, 
                datastore_name = datastore_name
            )
            dataset = Dataset.Tabular.from_delimited_files(
                path = (datastore, table_dataset["dataset_path"]),
                validate = False
            )
            dataset.register(
                workspace = ws,
                name = dataset_name
            )
            logging.info("Registered tabular dataset with name: {}".format(dataset_name))


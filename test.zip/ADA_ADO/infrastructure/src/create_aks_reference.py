'''
The following code creates a reference to the AKS compute cluster within the Azure ML workspace.
The AKS compute cluster is used downstream for inferencing.
'''

import azureml.core
import os
from azureml.core import Workspace
from azureml.core.compute import ComputeTarget, ComputeInstance, AmlCompute, AksCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.exceptions import UserErrorException
from azureml.core.environment import Environment
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

# ---------- Compute Variables ---------- #
#vnet_resourcegroup_name = os.environ["vnetResourceGroupName"]
#vnet_name = os.environ["vnetName"]
#subnet_name = os.environ["subnetName"]
#service_cidr = os.environ["serviceCIDR"]
#dns_service_ip = os.environ["DNSServiceIP"]
#docker_bridge_cidr = os.environ["dockerBridgeCIDR"]
aks_target_name = os.environ["AKSTARGETNAME"]
aks_source_name = os.environ["AKSSOURCENAME"]

# Output variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Compute Variables ----------")
#logging.info("Vnet Resource Group Name: {}".format(vnet_resourcegroup_name))
#logging.info("Vnet Name: {}".format(vnet_name))
#logging.info("Subnet Name: {}".format(subnet_name))
#logging.info("Service CIDR: {}".format(service_cidr))
#logging.info("DNS Service IP: {}".format(dns_service_ip))
#logging.info("Docker Bridge CIDR: {}".format(docker_bridge_cidr))
logging.info("AKS Target Name: {}".format(aks_target_name))
logging.info("AKS Source Name: {}".format(aks_source_name))

# Authenticating into the ml workspace
ws = Workspace.get(
    name = workspace_name,
    subscription_id = subscription_id,
    resource_group = resource_group
)

# If Aks reference does not already exists, then attach the external aks cluster as reference
# Otherwise grab existing
try:
    aks_target = AksCompute(
        workspace = ws,
        name = target_name
    )
    logging.info("Aks compute reference found with name: {}".format(target_name))
except ComputeTargetException:
    # Create AKS compute target and await the completion
    attach_configuration = AksCompute.attach_configuration(
        resource_group = resource_group,
        cluster_name = aks_source_name
    )
    compute_target = ComputeTarget.attach(
        workspace = ws, 
        name = aks_target_name, 
        attach_configuration = attach_configuration
    )
    compute_target.wait_for_completion(show_output=True)

    logging.info("Attached AKS compute target with name: {}".format(aks_target_name))
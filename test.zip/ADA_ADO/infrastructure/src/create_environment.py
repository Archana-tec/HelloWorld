'''
The following code creates an environment in the Azure ML workspace.
Manages the required application dependencies required for training, testing, and inferencing.
'''

import azureml.core
import os
from azureml.core import Workspace
from azureml.core.compute import ComputeTarget, ComputeInstance, AmlCompute, AksCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.exceptions import UserErrorException
from azureml.core.environment import Environment
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]
tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]


# ---------- Docker Environment Variables ---------- #
environment_name = os.environ["ENVIRONMENTNAME"]
docker_file_path = os.environ["DOCKERFILEPATH"]
requirements_file_path = os.environ["REQUIREMENTSFILEPATH"]

# Output variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Docker Environment Variables ----------")
logging.info("Environment Name: {}".format(environment_name))
logging.info("Docker File Path: {}".format(docker_file_path))
logging.info("Requirements.yml File Path: {}".format(requirements_file_path))

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the infrastructure folder
# cwd = os.getcwd()
# logging.info("-------- CWD: {} ------- ".format(cwd))
# os.chdir(r"C:\agent\_work\4\s")

cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is incorrect - will not find docker_file_path or requirements filepath"


f = open(f'./ADA_ADO/{docker_file_path}', 'r')
file_contents = f.read()
logging.info (file_contents)
f.close()

# Authenticating into the ml workspace

from azureml.core.authentication import ServicePrincipalAuthentication

svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)

ws = Workspace.get(
    name=workspace_name,
    subscription_id=subscription_id,
    resource_group=resource_group,
    auth = svc_pr
)

# Use the absolute docker_file_path and requirements filepath 
abs_docker_file_path = "./ADA_ADO/" + docker_file_path
print("abs_docker_file_path"+abs_docker_file_path)
print("requirements_file_path"+requirements_file_path)
abs_requirements_file_path = "./ADA_ADO/" + requirements_file_path
print("abs_requirements_file_path"+abs_requirements_file_path)


# Create Azure ML Environment with base settings from the dockerfile provided
# Furthermore, provide python dependencies through a conda_specification yaml file
env = Environment.from_dockerfile(
    name = environment_name,
    dockerfile = abs_docker_file_path,
    # conda_specification = abs_requirements_file_path
)

# Use the latest inferencing stack
env.inferencing_stack_version='latest'

env.register(
    ws
)
logging.info("Created new environment with name: {}".format(environment_name))
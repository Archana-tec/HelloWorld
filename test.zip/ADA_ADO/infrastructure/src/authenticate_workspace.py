'''
The following code is intended to authenticate into the ml workspace and test if components of the ml workspace are retrievable.
Asserts the proper configuration of the service principal.
'''

import os
import logging
from azureml.core import Workspace

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Global Variables ----------#
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]
tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# Output variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

# Authenticating into the ml workspace
from azureml.core.authentication import ServicePrincipalAuthentication

svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret)

ws = Workspace.get(
    name = workspace_name,
    resource_group = resource_group,
    subscription_id = subscription_id,
    auth = svc_pr
)
logging.info("Authenticated into workspace via Interactive Login Authentication method")

# Listing authentication
try:
    print(vars(ws._auth_object))
except Exception as e:
    print(e)
try:
    print(vars(ws._auth))
except Exception as e:
    print(e)

# List datastores
try:
    print(ws.datastores)
except Exception as e:
    print(e)

# List models
try:
    print(ws.models)
except Exception as e:
    print(e)

# List experiments
try:
    print(ws.experiments)
except Exception as e:
    print(e)

# List workspace details
try:
    print(vars(ws))
except Exception as e:
    print(e)

# Get the default datastore (asserting ws connection is right)
blob_store = ws.get_default_datastore()

# Check connection was successful
try:
    print("Blob store:", vars(blob_store))
except:
    print("vars did not work")

try:
    print("Blob store directory:", dir(blob_store))
except:
    print("dir didn't work")
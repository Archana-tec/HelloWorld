'''
The following code deploys, runs, and schedules the AML pipeline to load data in to the workspace.
The loaded data is used downstream in training pipelines.
'''

import os
from azureml.core import Workspace, Environment, Experiment
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.datastore import Datastore
from azureml.core.compute import AmlCompute
from azureml.exceptions import ComputeTargetException
from azureml.core.runconfig import RunConfiguration, DockerConfiguration
from azureml.pipeline.core import Pipeline, PublishedPipeline, Schedule, ScheduleRecurrence, PublishedPipeline
from azureml.pipeline.steps import PythonScriptStep
from azureml.pipeline.core.schedule import Schedule
from azureml.data import OutputFileDatasetConfig
from azureml.core import Dataset, Datastore
from azureml.data import HDFSOutputDatasetConfig
import datetime
import logging
from os import environ

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the infrastructure folder
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is incorrect"

# ---------- Workspace Variables ---------- #
env = os.environ["ENV"]
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# Authenticating into the ml workspace


svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)

# ---------- Compute Variables ---------- #
compute_name = os.environ["COMPUTENAME"]

# ---------- Docker Environment Variables ---------- #
environment_name = os.environ["ENVIRONMENTNAME"]

# ---------- Pipeline Variables ---------- #
pipeline_name = "ada_ado_data_load"
pipeline_schedule_name = "ada_ado_data_load_schedule"

# Output variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Compute Variables ----------")
logging.info("Compute Name: {}".format(compute_name))

logging.info("---------- Docker Environment Variables ----------")
logging.info("Environment Name: {}".format(environment_name))

logging.info("---------- Pipeline Variables ----------")
logging.info("Pipeline Name: {}".format(pipeline_name))
logging.info("Pipeline Schedule Name: {}".format(pipeline_schedule_name))

# Authenticating into the ml workspace
ws = Workspace.get(
    name=workspace_name,
    subscription_id=subscription_id,
    resource_group=resource_group,
    auth = svc_pr
)

# ---------- Disable Old Experiment and Schedule ---------- #
def disable_pipeline_and_schedule(ws, scheduler_name, pipeline_name):
    logging.info(f"Disableing Pipeline and Schedule")
    logging.info(f"- Scheduler name = {scheduler_name}")
    logging.info(f"- Pipeline name = {pipeline_name}")
    # Find and disable scoring schedules
    pipeline_schedules = Schedule.list(
        workspace=ws
    )

    # Find and disable azure ml pipelines
    published_pipelines = PublishedPipeline.list(
        workspace=ws
    )

    schedules = [
        schedule for schedule in pipeline_schedules
        if schedule.name in list([scheduler_name])
    ]
    logging.info(f"{len(schedules)} number of schedules found")

    # Disable old schedule
    for schedule in schedules:
        schedule.disable()
        logging.info("{} succcessfully disabled".format(schedule._name))
    logging.info("Successfully disabled all pipeline schedules")

    pipelines = [
        pipeline for pipeline in published_pipelines
        if pipeline._name in list([pipeline_name])
    ]
    logging.info("{} number of pipelines found".format(len(pipelines)))

    # Disable old pipelines
    for pipeline in pipelines:
        PublishedPipeline.get(
            workspace = ws,
            id = pipeline.id
        ).disable()
        logging.info("{} succcessfully disabled".format(pipeline._name))
    logging.info("Successfully disabled all pipelines")

# ---------- Create New Pipeline Experiment ---------- #
# Grab the workspace and landing prod/dev/uat datastore
print("environment coming as", env)
if env=='dev':
    datastore_nam = 'ada_landed_data_storage_dev'
    def_datastore_name = 'ada_results_storage_dev'
    environment = 'DEV'
else:
    datastore_nam='ada_landed_data_storage_prod'
    def_datastore_name = 'ada_results_storage_prod'
    environment = 'PROD'

ada_prod = Datastore.get(
    workspace = ws,
    datastore_name = datastore_nam
)
logging.info("Retrieved landing datastore with name: {}".format(ada_prod.name))

def_blob_store = Datastore.get(
    workspace = ws,
    datastore_name = def_datastore_name
)
logging.info("Retrieved workspace datastore with name: {}".format(def_blob_store.name))

if env == "dev":
    compute_name= "crtdevrashaml1"
    path = 'new-test/'
else:
    computer_name = "crtrtioaeuae"
    path = ''

# Grab the compute cluster that the pipeline will run on
ml_compute_instance = AmlCompute(
    workspace = ws,
    name = compute_name
)

#Need Change
environment_name="ado-ada-environment"
#environment_name="spark-env"

# Setting up compute environment
my_env = Environment.get(
    workspace = ws,
    name = environment_name
)
run_config = RunConfiguration()
docker_config = DockerConfiguration(use_docker = True)
run_config.docker = docker_config
run_config.environment = my_env
logging.info("Set up compute with name = {} and environment with name = {}".format(compute_name, environment_name))

# Retrieve datasets from the "ada_landed_data_storage_prod" / "ada_landed_data_storage_dev" datastore and mount it to the pipeline

# new
run_config.spark.configuration["spark.driver.memory"] = "48g" 
run_config.spark.configuration["spark.driver.cores"] = 5 
run_config.spark.configuration["spark.executor.memory"] = "48g" 
run_config.spark.configuration["spark.executor.cores"] = 5 
run_config.spark.configuration["spark.executor.instances"] = 4
run_config.spark.configuration['spark.dynamicAllocation.enabled'] =True
run_config.spark.configuration['spark.dynamicAllocation.initialExecutors'] = 4
run_config.spark.configuration['spark.dynamicAllocation.maxExecutors'] = 5

'''
PCS_tags_dataset = Dataset.get_by_name(
    workspace = ws,
    name = "kd-int054-process-control-data-from-osisoft-pi-ada"
)
PCS_tags_input = PCS_tags_dataset.as_named_input('PCS_Tags').as_mount()
'''

PCS_tags_dataset = Dataset.File.from_files(path=(ada_prod,f'{path}kd-int054-process-control-data-from-osisoft-pi-ada/**'), validate=False)
PCS_tags_input = PCS_tags_dataset.as_named_input('PCS_Tags').as_hdfs()
#PCS_tags_input = PCS_tags_dataset.as_named_input('PCS_Tags').as_mount()

logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("PCS_Tags"))

'''
train_schedule_dataset = Dataset.get_by_name(
    workspace = ws,
    name = "kd-int071-tpps-train-schedule-ada"
)
train_schedule_input = train_schedule_dataset.as_named_input('Train_Schedule').as_mount()
logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("Train_Schedule"))

FPTU_dataset = Dataset.get_by_name(
    workspace = ws,
    name = "kd-int058-ordw-fixed-plant-time-usage-ada"
)
FPTU_input = FPTU_dataset.as_named_input('Fixed_Plant_Time_Usage').as_mount()
logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("Fixed_Plant_Time_Usage"))

alarms_dataset = Dataset.get_by_name(
    workspace = ws,
    name = 'kd-int080-process-control-alarms-and-events'
)
alarms_input = alarms_dataset.as_named_input('Alarms').as_mount()
'''

alarms_dataset = Dataset.File.from_files(path=(ada_prod,f'{path}kd-int080-process-control-alarms-and-events/**'), validate=False)
alarms_input = alarms_dataset.as_named_input('Alarms').as_hdfs()
#alarms_input = alarms_dataset.as_named_input('Alarms').as_mount()

logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("Alarms"))

train_schedule_dataset = Dataset.File.from_files(path=(ada_prod,f'{path}kd-int071-tpps-train-schedule-ada/**'), validate=False)
train_schedule_input = train_schedule_dataset.as_named_input('Train_Schedule').as_hdfs()

logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("Train_Schedule"))

fptu_dataset = Dataset.File.from_files(path=(ada_prod,f'{path}kd-int058-ordw-fixed-plant-time-usage-ada/**'), validate=False)
fptu_input = fptu_dataset.as_named_input('fptu').as_hdfs()

logging.info("Retrieved dataset with name = {} and placed as mount on the compute instance of the pipeline".format("FPTU"))


# Set output folder in the workspace datastore
# output_folder = OutputFileDatasetConfig(
#     destination = (def_blob_store, "ADA_processed_datasets")
# )
# logging.info("Set output folder as {} in the workspace datastore".format("ADA_processed_datasets"))


if environ.get("output_container") is not None:
    output_container = environ.get("output_container")
else:
    output_container = "ADA_processed_datasets"

# output_container = "ADA_processed_datasets_ADO"

output_folder_tags = HDFSOutputDatasetConfig(destination=(def_blob_store, output_container))
output_folder_alarms = HDFSOutputDatasetConfig(destination=(def_blob_store, output_container))
output_folder_train_schedule = HDFSOutputDatasetConfig(destination=(def_blob_store, output_container))
output_folder_fptu = HDFSOutputDatasetConfig(destination=(def_blob_store, output_container))
logging.info("Set output folder as {} in the workspace datastore".format(output_container))


deployment_type =["tags", "alarms", "train_schedule", "fptu"]
for i in deployment_type:
    data_load_step = []
    script_name = 'daily_'+i+'_data_load_pipeline.py'
    
    if i == "tags":
        output_folder= output_folder_tags
        input = PCS_tags_input
        recurrence = ScheduleRecurrence(frequency="Day", interval=1, hours=[21],
                                        minutes=[0])  # Runs every day at 9pm UTC or 5AM Perth Time
    elif i == "alarms":
        output_folder= output_folder_alarms
        input = alarms_input
        recurrence = ScheduleRecurrence(frequency="Day", interval=1, hours=[21],
                                        minutes=[0])  # Runs every day at 9pm UTC or 5AM Perth Time
    elif i == "train_schedule":
        output_folder = output_folder_train_schedule
        input = train_schedule_input
        recurrence = ScheduleRecurrence(frequency="Day", interval=1, hours=[21],
                                        minutes=[0])  # Runs every day at 9pm UTC or 5AM Perth Time
    else:
        output_folder = output_folder_fptu
        input = fptu_input
        recurrence = ScheduleRecurrence(frequency="Day", interval=1, hours=[21],
                                        minutes=[0]) # Runs every day at 9pm UTC or 5AM Perth Time

    arguments = [
            "--"+i, input,
            "--output_dir", output_folder,
            "--environment", environment
    ]

    experiment_name = "Daily_Data_Load_Experiment_"+i
    pipeline_name = "Daily_Data_Load_Pipeline_"+i+"_Synapse"
    scheduler_name = "Daily Data Load Scheduler -"+i+" (Synapse)"
    description = 'Daily load of' +i+ 'data pipeline (Synapse)'
    scheduler_description = 'Scheduler for Daily load of'+i+' data pipeline (Synapse)'

    steps = PythonScriptStep(script_name=script_name,
                                source_directory="./", 
                                inputs=[input],
                                outputs=[output_folder],
                                arguments = arguments,
                                compute_target=ml_compute_instance,
                                runconfig=run_config,
                                allow_reuse=False)
    data_load_step.append(steps)

    # Disable schedule and pipeline
    disable_pipeline_and_schedule(ws,
                            scheduler_name = scheduler_name,
                            pipeline_name=pipeline_name
                )

    pipeline = Pipeline(
        workspace=ws,
        steps=[data_load_step]
    )

    published_pipeline = pipeline.publish(
        name=pipeline_name,
        description="Daily data loagin pipeline for RioTinto ADA Daily Data Load",
        version="1.0"
    )
    logging.info(f"Successfully published {pipeline_name} pipeline to Azure ML workspace")

    pipeline_id = published_pipeline.id
    experiment_name = pipeline_name


    recurring_schedule = Schedule.create(
        workspace=ws,
        name=scheduler_name,
        description="Daily Data Load Schedule",
        pipeline_id=pipeline_id,
        experiment_name=experiment_name,
        recurrence=recurrence
    )
    logging.info("Successfully created schedule for the published pipeline")

'''

# Full date range for data prep step
period_start = "2022-08-11"
period_end = "2022-08-12"

data_load_step = PythonScriptStep(
    script_name = "daily_data_load_pipeline.py",
    source_directory = "./",
    inputs = [PCS_tags_input, alarms_input],
    #alarms_input, train_schedule_input, 
        #FPTU_input],
    outputs = [output_folder],
    arguments = ["--PCS_tags", PCS_tags_input,
        #"--train_schedule", train_schedule_input,
        #"--FPTU", FPTU_input,
        "--alarms", alarms_input,
        "--output_dir", output_folder],
       # "--period_start", period_start,
       # "--period_end", period_end],
    compute_target = ml_compute_instance,
    runconfig = run_config,
    allow_reuse=False
)
'''

# Create pipeline object


# Set up and run as experiment
# pipeline_run = Experiment(
#                     workspace = ws,
#                     name = pipeline_name
#                 ).submit(pipeline)
# logging.info("Submitting experiment with name: {}".format(pipeline_name))

# pipeline_run.wait_for_completion(
#     show_output=False
# )
# logging.info("Successfully completed pipeline experiment")

# ---------- Publish New Pipeline and Create Schedule ---------- #
# Publish pipeline
# published_pipeline = pipeline_run.publish_pipeline(
#      name = pipeline_name,
#      description="Daily pipeline for RioTinto ADA Daily Data Load",
#      version=1.0
# )


'''
The following code creates a compute cluster within the Azure ML Workspace.
The compute cluster will be used downstream to run ML training pipelines.
'''

import azureml.core
import os
from azureml.core import Workspace
from azureml.core.compute import ComputeTarget, ComputeInstance, AmlCompute, AksCompute
from azureml.core.compute_target import ComputeTargetException
from azureml.exceptions import UserErrorException
from azureml.core.environment import Environment
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')

# ---------- Workspace Variables ---------- #
workspace_name = os.environ["WORKSPACENAME"]
resource_group = os.environ["RESOURCEGROUP"]
subscription_id = os.environ["SUBSCRIPTION"]

tenant_id = os.environ["SPTENANTID"]
principal_id = os.environ["SPPRINCIPALID"]
client_secret = os.environ["SPCLIENTSECRET"]

# Authenticating into the ml workspace

from azureml.core.authentication import ServicePrincipalAuthentication
svc_pr = ServicePrincipalAuthentication(
       tenant_id=tenant_id,
       service_principal_id=principal_id,
       service_principal_password=client_secret,
       _enable_caching=True)
print(svc_pr)

# ---------- Compute Variables ---------- #
compute_name = os.environ["COMPUTENAME"]
vm_size = os.environ["VMSIZE"]
min_nodes = int(os.environ["MINNODES"])
max_nodes = int(os.environ["MAXNODES"])
idle_seconds_before_scaledown = int(os.environ["IDLESECONDSBEFORESCALEDOWN"])
vnet_resourcegroup_name = os.environ["VNETRESOURCEGROUPNAME"]
vnet_name = os.environ["VNETNAME"]
subnet_name = os.environ["SUBNETNAME"]

# Output variables being used
logging.info("---------- Workspace Variables ----------")
logging.info("Workspace Name: {}".format(workspace_name))
logging.info("Resource Group: {}".format(resource_group))
logging.info("Subscription Id: {}".format(subscription_id))

logging.info("---------- Compute Variables ----------")
logging.info("Compute Name: {}".format(compute_name))
logging.info("Vm Size: {}".format(vm_size))
logging.info("Min Nodes: {}".format(min_nodes))
logging.info("Max Nodes: {}".format(max_nodes))
logging.info("Idle Seconds Before Scaledown: {}".format(idle_seconds_before_scaledown))
logging.info("Vnet Resource Group Name: {}".format(vnet_resourcegroup_name))
logging.info("Vnet Name: {}".format(vnet_name))
logging.info("Subnet Name: {}".format(subnet_name))

# Print current working directory to ensure that pipeline is using this folder as its working directory
# Assert that cwd is pointing to the infrastructure folder
cwd = os.getcwd()
logging.info("-------- CWD: {} ------- ".format(cwd))
#assert cwd.split("\\")[-1] == "src", "Current working directory is incorrect"

# Authenticating into the ml workspace
ws = Workspace.get(
    name=workspace_name,
    subscription_id=subscription_id,
    resource_group=resource_group,
    auth = svc_pr
)

# Verify whether or not cluster exists
try:
    cluster = AmlCompute(
        ws,
        compute_name
    )
    logging.info("Found existing compute cluster with name: {}".format(compute_name))

    # If the vm_size is different, delete the compute cluster and re-create 
    if (cluster.vm_size != vm_size or cluster.vnet_resourcegroup_name != vnet_resourcegroup_name or 
            cluster.vnet_name != vnet_name or cluster.subnet_name != subnet_name):
        cluster.delete()
        cluster.wait_for_completion(is_delete_operation = True)
        raise ComputeTargetException("Deleted compute cluster")

    # Update the existing compute cluster with the details provided
    cluster.update(
        min_nodes = min_nodes,
        max_nodes = max_nodes,
        idle_seconds_before_scaledown = idle_seconds_before_scaledown
    )
    logging.info("Cluster with name {} has nodes updated to min of {} to max of {}".format(compute_name, min_nodes, max_nodes))
except ComputeTargetException:
    compute_config = AmlCompute.provisioning_configuration(
        vm_size = vm_size,
        min_nodes = min_nodes,
        max_nodes = max_nodes,
        idle_seconds_before_scaledown = idle_seconds_before_scaledown,
        vnet_resourcegroup_name = vnet_resourcegroup_name,
        vnet_name = vnet_name,
        subnet_name = subnet_name
    )
    cluster = ComputeTarget.create(
        ws,
        compute_name,
        compute_config
    )
    cluster.wait_for_completion(show_output = True)
    logging.info("Registered new compute cluster with name: {}".format(compute_name))
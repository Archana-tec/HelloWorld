# Azure DevOps

## Purpose
The following folder contains all code and config required to run and execute Azure DevOps build/release pipelines.
In this documentation, we will outline each folder's purpose and contents with the hope that anyone can navigate through the contents using this README.
This paired with the Wiki that details how the ADO pipelines use these files will give a holistic view of how Azure DevOps can serve the end to end lifecycle for these 3 use cases.

## Folders
The following folders are relevant in this section:
- build_artifacts: Contains yaml build pipeline definitions which package up artifacts from the repo and within AML.
- compute_config: Contains config related to compute resources - specifically docker images and requirements (organised by use case) to be created within AML.
- infrastructure: Contains config and source code to spin up datastores, datasets, and compute.
- mlops: Contains config and source code to take each use case from dev to production.


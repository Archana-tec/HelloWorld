
import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Dataset
import argparse

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--alarms")
parser.add_argument("--output_dir")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder \
                .appName('app_name') \
                .master('local[*]') \
                .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                .config('spark.sql.session.timeZone', 'UTC') \
                .config('spark.driver.memory','32G') \
                .config('spark.ui.showConsoleProgress', True) \
                .config('spark.sql.repl.eagerEval.enabled', True) \
                .config('spark.driver.maxResultSize','0')\
                .getOrCreate()


### TAGS LOAD ###
print(args.output_dir+'/PCS_tags')
try:
    current_tags_file = spark.read.parquet(args.output_dir+'/PCS_tags')
    current_tags_max_date = current_tags_file.select(max('time_rio')).first()[0]
    period_start_utc = current_tags_max_date - datetime.timedelta(days=1)
except:
    period_start_utc = datetime.datetime(2022,7,1) # default to start of July if no file is found

period_end_utc = datetime.datetime.now()
# period_end_utc = period_start_utc + relativedelta(months = 1) - relativedelta(days = 1)
print('Start Date: '+ period_start_utc.strftime("%Y-%m-%d"))
print('End Date: '+period_end_utc.strftime("%Y-%m-%d"))

# Create hdfs date range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
print('Tags range: '+date_range)

# Load PCS Tags and append to previous iterations

hdfs_path = "/KD-INT054_"+date_range
sdf_tags = spark.read.option("multiline", "true").json(args.PCS_tags+hdfs_path).withColumn("filename", input_file_name())
sdf_tags = load_ADA_data.NormaliseJsonSpark(sdf_tags).normalise_tags_spark()

sdf_tags2 = spark.read.parquet(args.output_dir+'/PCS_tags')

sdf_tags2.createOrReplaceTempView("old_df")
sdf_tags.createOrReplaceTempView("new_df")

# print(f'Count of existing data in PCS_tags: {sdf_tags2.count()}')
# print(f'Count of the output of normalise_tags_spark: {sdf_tags.count()}')

# the below query is to identify the new data.
# the output of normalize_tags_spark contains data which is already exist in the output folder
new_data = spark.sql("""
            select n.*
            from  new_df n
            where not exists (
                select * from old_df o 
                where o.tagid = n.tagid
                  and o.time_rio = n.time_rio
                  and o.value_rio = n.value_rio
            )
""")

# print(f'Count of the new unique data: {new_data.count()}')

new_data.write.mode('append').parquet(args.output_dir+'/PCS_tags')

print('Tags load complete.')


### ALARMS LOAD ###
try:
    current_alarms_file = spark.read.parquet(args.output_dir+'/alarms/**')
    current_alarms_max_date = datetime.datetime.strptime(current_alarms_file.select(max('vt_start')).first()[0],'%Y-%m-%dT%H:%M:%S')
    period_start_utc = current_alarms_max_date - datetime.timedelta(days=1)
except:
    period_start_utc = datetime.datetime(2022,7,1) # default to start of July if no file is found

print('Start Date: '+ period_start_utc.strftime("%Y-%m-%d"))
print('End Date: '+period_end_utc.strftime("%Y-%m-%d"))
# period_end_utc = datetime.datetime.now()  # Commented as we use the above period_end_utc so that alarm and tag data is aligned

# Create hdfs date range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
print('Alarms range: '+date_range)

hdfs_path = "/PCDB-"+date_range
sdf_alarms = spark.read.option("multiline", "true").json(args.alarms+hdfs_path).withColumn("filename", input_file_name())
sdf_alarms = load_ADA_data.NormaliseJsonSpark(sdf_alarms).normalise_alarms_spark()

sdf_alarms2 = spark.read.parquet(args.output_dir+'/alarms')

sdf_alarms2.createOrReplaceTempView("old_alarm_df")
sdf_alarms.createOrReplaceTempView("new_alarm_df")

# print(f'Count of existing data in alarms folder: {sdf_alarms2.count()}')
# print(f'Count of the output of normalise_alarms_spark: {sdf_alarms.count()}')

new_alarm_data = spark.sql("""
            select n.*
            from  new_alarm_df n
            where not exists (
                select * from old_alarm_df o 
                where o.eventid = n.eventid
                  and o.tagname = n.tagname
                  and o.unit = n.unit
                  and o.description = n.description
                  and o.area = n.area
                  and o.name = n.name
                  and o.vt_start = n.vt_start
                  and o.vt_end = n.vt_end
                  and o.priority = n.priority
                  and o.message = n.message
            )
""")

# print(f'Count of the new unique alarm data: {new_alarm_data.count()}')

new_alarm_data.write.mode('append').parquet(args.output_dir+'/alarms')

print('Alarms load complete.')

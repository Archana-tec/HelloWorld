import numpy as np
import pandas as pd
import math
import os
import datetime

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--dataprep_input")
parser.add_argument("--manual_inputs")
parser.add_argument("--belt_tonnage_input")
parser.add_argument("--belt_time_input")
parser.add_argument("--AF_tonnage_input")
parser.add_argument("--AF_time_input")
parser.add_argument("--forecast_date")
parser.add_argument("--output_dir")
args = parser.parse_args()

if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


# Load outputs from data prep step
df_pds = pd.read_csv(args.dataprep_input+'/df_pds.csv')
df_shutdown = pd.read_csv(args.dataprep_input+'/df_shutdown.csv')
date_range_df_centre = pd.read_csv(args.dataprep_input+'/date_range_df_centre.csv')
UC3_belts = ['CV0101', 'CV0102', 'CV0211', 'CV0312', 'CV0313', 'CV0316', 'CV0514', 'CV0517', 'CV0622', 'CV21 (RC0601)', 'CV15 (SK0501)', 'CV18 (SK0502)', 'BF0401', 'BF0402']
UC3_AFs = ['AF0101', 'AF0201', 'AF0202']

# Load outputs from model steps
## Belt wear outputs

concat_pd_list_tons_final = pd.read_csv(args.belt_tonnage_input+'/belt_tonnage_model_'+forecast_date+'.csv')
concat_pd_list_tons_final.days_to_replace_ton = pd.to_timedelta(concat_pd_list_tons_final.days_to_replace_ton)

concat_pd_list_days_final = pd.read_csv(args.belt_time_input+'/belt_days_model_'+forecast_date+'.csv')

fwd_mine_plan = pd.read_csv(args.belt_tonnage_input+'/planned_tons_chk_'+forecast_date+'.csv')

chk_plan = fwd_mine_plan.empty
print('mine plan empty: ',str(chk_plan))

if chk_plan:
    final_output = concat_pd_list_days_final
    final_output['days_to_replace_time'] = pd.to_timedelta(concat_pd_list_days_final['days_to_replace_time'].apply(math.ceil), 'D')
else:
    final_output = concat_pd_list_tons_final

## Importing belt wise critical thickness
belt_tech_specs = pd.read_csv(args.manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_critical_thickness = belt_tech_specs[belt_tech_specs.Feature.str.contains('Critical Thickness')]
belt_critical_thickness['wearSurface'] = belt_critical_thickness.Feature.apply(lambda x: x.split(' ')[0])
belt_critical_thickness = belt_critical_thickness.rename(columns = {'Asset_ID':'areaName', 'Value':'Critial Thickness'})
belt_critical_thickness.reset_index(drop=True, inplace=True)
belt_critical_thickness['areaName'] = belt_critical_thickness['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
belt_critical_thickness['Key'] = belt_critical_thickness['areaName']+'_'+belt_critical_thickness['wearSurface']
belt_critical_thickness = belt_critical_thickness.rename(columns = {'Critial Thickness':'critical_thickness_mm'})
belt_critical_thickness = belt_critical_thickness[['Key', 'critical_thickness_mm']]

## Importing and manipulating shurdown data
clbshut_df = pd.read_csv(args.dataprep_input+'/df_shutdown.csv')
clbshut_df['modified_datetime'] = pd.to_datetime(clbshut_df['modified_datetime'])
clbshut_df['planned_start_date'] = pd.to_datetime(clbshut_df['planned_start_date']) 
clbshut_df['planned_duration_hours'] = clbshut_df['planned_duration_hours'].astype('float')                                      
clbshut_df.head()

# Applying filters on shutdown data
clbshut_df = clbshut_df[(clbshut_df['shut_type_name'] == 'Scheduled') &
                        (clbshut_df['planned_duration_hours'] >= 24) &
                        (~clbshut_df['equipment_description'].str.contains('GDIT', na=False))]

# Removing duplicates keeping last modified date
clbshut_wodup = pd.DataFrame()

shut_ids = list(clbshut_df['shut_id'].unique())
# shut_ids = [46450]
for i in shut_ids:
    temp_df = clbshut_df[clbshut_df['shut_id'] == i]
    max_mod_date = temp_df['modified_datetime'].max()
    temp_df = temp_df[temp_df['modified_datetime'] == max_mod_date]
    clbshut_wodup = pd.concat([clbshut_wodup, temp_df], ignore_index=True)
    clbshut_wodup['equipment_description'] = clbshut_wodup['equipment_description'].str.replace("\r\n","")

### Replicate shutdown data based on mapping
shutdown_mapping_dict = {
                        'BF0401' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],  
                        'BF0402' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],  
                        'CV0101' : ['PRIMARY CRUSHING CS0101      '],
                        'CV0102' : ['PRIMARY CRUSHING CS0101      '],
                        'CV0211' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],  
                        'CV0312' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV0313' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV0316' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV0514' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV0517' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV0622' : ['GUDAI-DARRI TLO (Formerly Koodaideri)'],
                        'CV21 (RC0601)' : ['GUDAI-DARRI TLO (Formerly Koodaideri)'],
                        'CV15 (SK0501)' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'CV18 (SK0502)' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'AF0101' : ['PRIMARY CRUSHING CS0101      '],
                        'AF0201' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)'],
                        'AF0202' : ['GUDAI-DARRI PLANT (Formerly Koodaideri)']
                        }   
clbshut_final = pd.DataFrame()
for i in list(shutdown_mapping_dict.keys()):

    rel_circuit = shutdown_mapping_dict.get(i)
    temp_df = clbshut_wodup[clbshut_wodup['equipment_description'].isin(rel_circuit)]
    temp_df['areaName'] = i
    clbshut_final = pd.concat([clbshut_final, temp_df[['areaName', 'planned_start_date']]], 
                               ignore_index = True)

clbshut_final = clbshut_final.drop_duplicates()
clbshut_final = clbshut_final.sort_values(['areaName', 'planned_start_date']).reset_index(drop=True)

final_output = final_output.merge(belt_critical_thickness, on='Key', how='left')
final_output['asset_id'] = final_output['Key'].apply(lambda x: x.split('_')[0])
final_output['floc_id'] = final_output['asset_id'].apply(lambda x: '3029'+x)
final_output['subcomponentname'] = final_output['Key'].apply(lambda x: x.split('_')[1])
final_output['asset_type'] = final_output['asset_id'].apply(lambda x: 'Apron Feeder' if x in UC3_AFs else 'Belt')
# final_output_dt_rslt = date_range_df_centre.groupby('areaName', as_index=False).apply(lambda x: x.iloc[-1][['date_range', 'result_min_7']]).rename(columns = {'date_range':'latest_thickness_date', 'result_min_7':'latest_thickness_mm'})

final_output_dt_rslt = df_pds[(df_pds['areaName'].isin(UC3_belts)) & (df_pds['wearSurface'] == 'Top')].groupby(['areaName', 'wearSurface', 'test_date', 'lastSavedDateTime', 'testId'], as_index=False).agg({'result' : 'min'})
final_output_dt_rslt = final_output_dt_rslt.groupby(['areaName', 'wearSurface'],as_index=False).apply(lambda x:x.loc[x[x['test_date']==x['test_date'].max()]['result'].idxmin()])
final_output_dt_rslt.rename(columns = {'test_date' : 'latest_thickness_date', 'result' : 'latest_thickness_mm'}, inplace=True)

final_output = final_output.merge(final_output_dt_rslt[['areaName', 'wearSurface', 'latest_thickness_date', 'latest_thickness_mm']], left_on=['asset_id', 'subcomponentname'], right_on=['areaName', 'wearSurface'], how='left')
final_output['latest_thickness_date'] = pd.to_datetime(final_output['latest_thickness_date'], format = '%Y-%m-%d')

final_output['days_to_replace_ton'] = pd.to_timedelta(final_output['days_to_replace_ton'])
final_output['forecast_critical_thickness_date'] = final_output.apply(lambda x: x['latest_thickness_date'] + x['days_to_replace_time'] if chk_plan else x['latest_thickness_date'] + x['days_to_replace_ton'], axis=1)

try:
    final_output['days_to_replace_ton_scn1'] = pd.to_timedelta(final_output['days_to_replace_ton_scn1'])
    final_output['days_to_replace_ton_scn2'] = pd.to_timedelta(final_output['days_to_replace_ton_scn2'])
    final_output['scenario1_forecast_critical_thickness_date'] = final_output['latest_thickness_date'] + final_output['days_to_replace_ton_scn1']
    final_output['scenario2_forecast_critical_thickness_date'] = final_output['latest_thickness_date'] + final_output['days_to_replace_ton_scn2']
except:
    pass
    print('Forward Mine Plan not available !')

forecast_replacement_date_df = pd.DataFrame()

final_output = final_output[final_output['subcomponentname']=='Top']

for i in final_output['asset_id'].unique():
    temp_clb_dates = list(clbshut_final[clbshut_final['areaName'] == i]['planned_start_date'])
    
    fctd = pd.to_datetime(list(final_output[final_output['asset_id'] == i]['forecast_critical_thickness_date'])[0], format = '%Y-%m-%d')
    diff_list = [a-fctd for a in temp_clb_dates]
    closest_date = temp_clb_dates[diff_list.index(sorted(diff_list, reverse=True)[0])]
    
    fctd_scn1 = pd.to_datetime(list(final_output[final_output['asset_id'] == i]['scenario1_forecast_critical_thickness_date'])[0], format = '%Y-%m-%d')
    diff_list_scn1 = [a-fctd_scn1 for a in temp_clb_dates]
    closest_date_scn1 = temp_clb_dates[diff_list_scn1.index(sorted(diff_list_scn1, reverse=True)[0])]
    
    fctd_scn2 = pd.to_datetime(list(final_output[final_output['asset_id'] == i]['scenario2_forecast_critical_thickness_date'])[0], format = '%Y-%m-%d')
    diff_list_scn2 = [a-fctd_scn2 for a in temp_clb_dates]
    closest_date_scn2 = temp_clb_dates[diff_list_scn2.index(sorted(diff_list_scn2, reverse=True)[0])]
    
    
    temp_res_df =pd.DataFrame()
    temp_res_df['asset_id'] = [i]
    temp_res_df['forecast_replacement_date'] = [closest_date]
    temp_res_df['forecast_replacement_date_scn1'] = [closest_date_scn1]
    temp_res_df['forecast_replacement_date_scn2'] = [closest_date_scn2]

    forecast_replacement_date_df =pd.concat([forecast_replacement_date_df, temp_res_df], ignore_index=True)

final_output = pd.merge(final_output,
                        forecast_replacement_date_df,
                        on = ['asset_id'],
                        how='left')
final_output['forecast_date'] = pd.Timestamp(datetime.datetime.today().date())
final_output['RUL_days'] = final_output['forecast_critical_thickness_date'] - final_output['forecast_date']
final_output['RUL_days_buffer'] = final_output['forecast_critical_thickness_date'] - final_output['forecast_replacement_date']
final_output['forecast_replacement_date'] = np.where(final_output['RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['forecast_replacement_date'])
final_output['RUL_days_buffer'] = np.where(final_output['RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['RUL_days_buffer'])

try:
    final_output['scenario1_RUL_days'] = final_output['scenario1_forecast_critical_thickness_date'] - final_output['forecast_date']
    final_output['scenario1_RUL_days_buffer'] = final_output['scenario1_forecast_critical_thickness_date'] - final_output['forecast_replacement_date_scn1']
    final_output['scenario1_forecast_replacement_date'] = np.where(final_output['scenario1_RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['forecast_replacement_date_scn1'])
    final_output['scenario1_RUL_days_buffer'] = np.where(final_output['scenario1_RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['scenario1_RUL_days_buffer'])

    final_output['scenario2_RUL_days'] = final_output['scenario2_forecast_critical_thickness_date'] - final_output['forecast_date']
    final_output['scenario2_RUL_days_buffer'] = final_output['scenario2_forecast_critical_thickness_date'] - final_output['forecast_replacement_date_scn2']
    final_output['scenario2_forecast_replacement_date'] = np.where(final_output['scenario2_RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['forecast_replacement_date_scn2'])
    final_output['scenario2_RUL_days_buffer'] = np.where(final_output['scenario2_RUL_days_buffer'].dt.days > 90, pd.NaT, final_output['scenario2_RUL_days_buffer'])

except:
    pass

final_output = final_output.rename(columns = {
                                              'mm_per_month':'wear_rate_mm_per_month', 
                                              'mm_per_Mton':'wear_rate_mm_per_MT', 
                                              'tons_to_replace(MT)':'RUL_MT'
                                              })

cols = [
        'forecast_date','asset_id','floc_id','subcomponentname','asset_type',
        'critical_thickness_mm','latest_thickness_mm','latest_thickness_date', 'wear_rate_mm_per_MT','wear_rate_mm_per_month','RUL_MT',
        'forecast_critical_thickness_date', 'RUL_days', 'forecast_replacement_date', 'RUL_days_buffer',
        'scenario1_forecast_critical_thickness_date', 'scenario1_forecast_replacement_date', 'scenario1_RUL_days', 'scenario1_RUL_days_buffer', 
        'scenario2_forecast_critical_thickness_date', 'scenario2_forecast_replacement_date', 'scenario2_RUL_days', 'scenario2_RUL_days_buffer'
        ]

cols_final = [x for x in cols if x in final_output.columns]
final_output = final_output[cols_final]
final_output['forecast_replacement_date'] = pd.to_datetime(final_output['forecast_replacement_date'], format='%Y-%m-%d')

# Export to output folder

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

final_output.to_csv(output_folder+'/ADA_UC3_WRF_results_belt_'+forecast_date+'.csv', index = False)

# Standard Packages
import numpy as np
import logging
import pandas as pd
import datetime
from pandas.tseries import offsets
from datetime import timedelta
import re
from azureml.core.datastore import Datastore
from azureml.core import Workspace,Dataset
from azureml.data.datapath import DataPath
from azureml.core import Run
import copy
import matplotlib.dates as mdates
import ast
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
import os

# Our Custom Libraries
import load_ADA_data


# Parse Arguments
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--PDS")
parser.add_argument("--shutdowns")
parser.add_argument("--UC3_manual_inputs")
parser.add_argument("--output_dir")
args = parser.parse_args()

# Date range for data import - take largest available range of data
dt_start = datetime.datetime(2022,1,1)
dt_now = datetime.datetime.now()
date_range = load_ADA_data.hdfs_range(dt_start, dt_now)

# Start Spark Session
os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
spark = SparkSession.builder \
                .appName('app_name') \
                .master('local[*]') \
                .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                .config('spark.sql.session.timeZone', 'UTC') \
                .config('spark.driver.memory','32G') \
                .config('spark.ui.showConsoleProgress', True) \
                .config('spark.sql.repl.eagerEval.enabled', True) \
                .config('spark.driver.maxResultSize','0')\
                .getOrCreate()


# Set up logging configuration---
logging.basicConfig(level=logging.INFO, format='%(asctime)s :: [%(levelname)s] :: %(message)s')
logging.info("pcs tags info :- {}".format(args.PCS_tags))
test = spark.read.parquet(args.PCS_tags)
logging.info("Loading Df :- {}".format(test.show(2)))
# ----

## PDS DATA LOAD AND PREPARATION ##

print('---> Begin PDS data preparation...')

hdfs_path = "/Pds-ada-"+date_range
sdf_pds = spark.read.option("multiline", "true").json(args.PDS+hdfs_path).withColumn("filename", input_file_name())
sdf_pds = load_ADA_data.NormaliseJsonSpark(sdf_pds).normalise_pds_spark()

df_pds = sdf_pds.toPandas()
# Notebook version
# df_pds = load_ADA_data.LoadData('kd-int075-pds-ada', dt_now, date_diff_mins).load_data_spark()

# Asset Scope for UC3
UC3_belts = ['CV0101', 'CV0102', 'CV0211', 'CV0312', 'CV0313', 'CV0316', 'CV0514', 'CV0517', 'CV0622', 'CV21 (RC0601)', 'CV15 (SK0501)', 'CV18 (SK0502)', 'BF0401', 'BF0402']
UC3_AFs = ['AF0101', 'AF0201', 'AF0202']

# Filter for only relevant assets
df_pds = df_pds[df_pds.areaName.isin(UC3_belts+UC3_AFs)].reset_index(drop=True)

# Strip time out of testDate
df_pds['test_date'] = pd.to_datetime(df_pds['testDate'].dt.date, format = "%Y-%m-%d")
# Cut along width

df_pds.head()

#### Filtering out 0 and NA tickness values
df_pds = df_pds.dropna(subset = ['result'], how = 'any')
df_pds = df_pds[df_pds['result']>0]

df_full = copy.deepcopy(df_pds)
try:
    df_full = df_full.loc[lambda x: ~x.areaName.isin(UC3_AFs)]
except:
    pass
# del df_pds
df_full['part_of_asset'] = df_full.groupby(['areaName', 'wearSurface', 'equipmentId', 'test_date'])[['x']].transform(lambda x: pd.cut(x, 3, right=True, labels=['Left', 'Centre', 'Right']))

df_first = df_full.query('part_of_asset == "Left"').sort_values(['areaName', 'wearSurface', 'test_date']).reset_index(drop=True)
df_second = df_full.query('part_of_asset == "Centre"').sort_values(['areaName', 'wearSurface', 'test_date']).reset_index(drop=True)
df_third = df_full.query('part_of_asset == "Right"').sort_values(['areaName', 'wearSurface', 'test_date']).reset_index(drop=True)

df_pds_eid = copy.deepcopy(df_pds)

# Group by minimum thickness accross the width at each test

def manipulate_thickness_v2(df_pds):

    ### Modified Code - part1

    grouped = df_pds.groupby(['areaName','wearSurface', 'equipmentId', 'test_date'], as_index=False)['result'].min()
    grouped = grouped.assign(test_date = lambda x: pd.to_datetime(x['test_date'], format = "%Y-%m-%d"))
    grouped = grouped.sort_values(['areaName', 'wearSurface', 'equipmentId', 'test_date'])
    # grouped[grouped['wearSurface']=='Top'].reset_index(drop=True).groupby(['areaName', 'wearSurface'])['test_date'].nunique().sort_values()
    grouped['date_span'] = grouped.groupby(['areaName', 'wearSurface', 'equipmentId'])['test_date'].diff()
    grouped['result_span'] = grouped.groupby(['areaName', 'wearSurface', 'equipmentId'])['result'].diff().abs()
    grouped['plf'] = (grouped.groupby(['areaName','wearSurface', 'equipmentId']).cumcount())
    grouped['result_delta'] = grouped.result_span.div(grouped.date_span.dt.days+1)
    group_df = grouped.groupby(['areaName', 'wearSurface', 'equipmentId'])

    ### Modified Code - part2

    date_range_df = pd.DataFrame([])
    for key, group in group_df:
        local_group_df = pd.DataFrame([])
        local_group_df['date_range'] = pd.date_range(start=group.iloc[0]['test_date'], end=group.iloc[-1]['test_date'], freq='D')
        local_group_df[['areaName', 'wearSurface', 'equipmentId']] = key[0], key[1], key[2]
        dt_rng = local_group_df.pop('date_range')
        local_group_df.insert(0, 'date_range', dt_rng)
        # local_group_df['group_wise_index'] = local_group_df.groupby(['areaName', 'wearSurface'])['date_range'].cumcount()
        date_range_df = pd.concat((date_range_df, local_group_df), ignore_index=True)

    ### Modified Code - part3

    date_range_df_copy = copy.deepcopy(date_range_df)
    date_range_df = pd.merge(date_range_df_copy, grouped, how = 'left', left_on = ['areaName', 'wearSurface', 'equipmentId', 'date_range'], right_on= ['areaName', 'wearSurface', 'equipmentId', 'test_date'], indicator=True).drop(columns = ['test_date'])
    date_range_df['plf'] = date_range_df['plf'].ffill()
    date_range_df['group_wise_index'] = date_range_df.groupby((date_range_df['result'].notnull()).cumsum()).cumcount()
    date_range_df['result_delta'] = date_range_df.groupby(['areaName', 'wearSurface', 'equipmentId'])['result_delta'].bfill()
    date_range_df['result_delta'] = date_range_df['result_delta'].fillna(0)
    date_range_df['result_copy'] = date_range_df['result'].copy()
    date_range_df['result_copy'] = date_range_df['result_copy'].ffill()
    date_range_df['to_subtract'] = date_range_df['group_wise_index'] * date_range_df['result_delta']
    date_range_df['result'] = date_range_df['result_copy'] - date_range_df['to_subtract']
    date_range_df['plfw'] = date_range_df.groupby(['areaName', 'wearSurface', 'equipmentId'])['plf'].transform('max')
    date_range_df['plfw'] = date_range_df['plfw'].astype('int')
    date_range_df.drop(columns = ['date_span', 'result_span', 'result_delta', 'result_copy', 'group_wise_index', 'to_subtract', 'plf'], inplace=True)
    d1_agg = copy.deepcopy(date_range_df).sort_values(['areaName', 'wearSurface', 'equipmentId', 'date_range']).set_index('date_range')
    d1_agg['result_change'] = d1_agg.groupby(['areaName', 'wearSurface', 'equipmentId'])[['result']].apply(lambda x: x.diff().fillna(0).abs())
    d1_agg['result_change_sum'] = d1_agg.groupby(['areaName', 'wearSurface', 'equipmentId'])['result_change'].transform('sum')
    d1_agg['month'] = d1_agg.index.month
    d1_agg_days = d1_agg.reset_index().groupby(['areaName', 'wearSurface', 'equipmentId']).apply(lambda x: x.groupby(x.date_range.dt.month).size()).reset_index().rename(columns={'date_range':'month', 0:'days_in_month'})#.droplevel(-1)
    d1_agg = d1_agg.reset_index()
    d1_agg['days_in_month'] = pd.merge(d1_agg, d1_agg_days, on = ['areaName', 'wearSurface', 'equipmentId', 'month'], how = 'left')[['days_in_month']]
    d1_agg['historical_degradation_rate'] = d1_agg.result_change_sum.div(d1_agg.days_in_month)
    d1_agg = d1_agg.drop(columns = ['result_change', 'result_change_sum', 'month', 'days_in_month'])
    d1_agg = d1_agg.set_index('date_range')

    return d1_agg

date_range_df_first = manipulate_thickness_v2(df_first)            
date_range_df_second = manipulate_thickness_v2(df_second)              # Converting the three PDS data into daily leve;
date_range_df_third = manipulate_thickness_v2(df_third)

print('---> PDS data preparation complete.')


## TAG DATA LOAD AND PREPARATION ##

print('---> Begin PCS Tags data preparation...')

# Load tag lists
uc3_tag_list_speed = {}

# Pipeline version
uc3_tags =  os.path.join(os.path.dirname(__file__), 'UC3_Tags.txt')
# Notebook version
#uc3_tags = './UC3_Tags.txt'

with open(uc3_tags) as f:
    tag_dict = f.read()#.splitlines()
f.close()
# uc3_tag_dict = json.loads(tag_dict)
uc3_tag_dict = ast.literal_eval(tag_dict)
uc3_tag_list_speed = uc3_tag_dict['speed']
uc3_tag_list_ton = uc3_tag_dict['ton']
print('---> Tag lists loaded.')

# Load historical Belt Speed tag data from the manual input files (data from before INT054 integration deployment required)
print('---> Load historical Belt Speed data from manual input files.')

tag_speed = pd.read_csv(args.UC3_manual_inputs+'/GD_Historical_Belt_Speed_ms.csv')
tag_speed.columns = [_.replace('-', '_') for _ in tag_speed.columns]
tag_speed_melt = tag_speed.melt(id_vars='Date_Time', value_vars=[_ for _ in tag_speed.columns if 'Date_Time' not in _], value_name='speed', var_name='areaName')
tag_speed_melt['Date_Time'] = pd.to_datetime(tag_speed_melt['Date_Time'])
month_start = tag_speed_melt.dropna().sort_values(['areaName','Date_Time'], ascending=True).groupby('areaName').apply(lambda x: pd.to_datetime(x.Date_Time.iloc[0], format='%Y-%m-%d').month_name())
tag_speed_melt = tag_speed_melt.sort_values(['areaName','Date_Time'], ascending=True)
tag_speed_melt['speed'] = tag_speed_melt['speed'].fillna(0)
tag_speed_melt.reset_index(drop=True, inplace=True)
tag_speed_melt['Date'] = tag_speed_melt.Date_Time.dt.date
tag_speed_melt.head()
print('---> Historical Belt Speed data load complete.')

# Load live tag data from the daily data load pipeline outputs (through integration INT054)
print('---> Load live Belt Speed data.')

# Period start = last datetime of the manual input file

period_start = (tag_speed_melt.Date_Time.max()+pd.DateOffset(minutes=1)).to_pydatetime()
sdf_tags = spark.read.parquet(args.PCS_tags)
sdf_tags = sdf_tags[sdf_tags.tagid.isin(uc3_tag_list_speed)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start, dt_now)]
df_tags_speed = sdf_tags.toPandas()
print(df_tags_speed.tail())
print('Num rows live data: '+str(len(df_tags_speed)))
df_tags_speed = df_tags_speed.rename(columns = {'tagid':'areaName', 'time_rio':'Date_Time', 'value_rio':'speed'})
df_tags_speed = df_tags_speed.drop(columns = 'file_timestamp')
df_tags_speed = df_tags_speed[['Date_Time', 'areaName', 'speed']]
df_tags_speed['Date_Time'] = pd.to_datetime(df_tags_speed['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
df_tags_speed['Date'] = df_tags_speed.Date_Time.dt.date

print('---> Live Belt Speed data load complete.')

# Appending historical data to live data (Belt Speed)
tag_speed_melt = pd.concat((tag_speed_melt, df_tags_speed), ignore_index=True)
tag_speed_melt['Date'] = pd.to_datetime(tag_speed_melt['Date'], format = '%Y-%m-%d')
tag_speed_melt['speed'] = pd.to_numeric(tag_speed_melt['speed'])
tag_speed_melt = tag_speed_melt.sort_values(['areaName','Date_Time'], ascending=True)
tag_speed_melt['speed'] = tag_speed_melt['speed'].fillna(0)

print('---> Begin Downtime feature calculation')
# Calculating start/ stop based on belt speed for each tag
def starts_stops(g):
    g = g.sort_values(by='Date_Time').reset_index(drop=True)
    g['lag_speed'] = g['speed'].shift(1)
    g['future_speed'] = g['speed'].shift(-1)
    g['Status']=np.nan
    g['Status1']=np.nan
    g.loc[(g['speed']==0) & (g['lag_speed']!=0),'Status']='On'
    g.loc[(g['speed']==0) & (g['future_speed']!=0),'Status1']='Off'
    g_on = g[g['Status']=='On'].drop(columns='Status1').rename(columns={'Date_Time':'Time_1'}).reset_index(drop=True)
    # g_on = g[g['Status']=='On'].rename(columns={'Date_Time':'Start_Time', 'Status1':'Status1_Org'}).reset_index(drop=True)
    g_off = g[g['Status1']=='Off'][['Date_Time', 'Status1']].rename(columns={'Date_Time':'Time_2'}).reset_index(drop=True)
    # print(g_on.columns)
    # print(g_off.columns)
    g_concat = pd.concat((g_on, g_off), axis=1)
    # print(g_concat.columns)
    try:
        g_concat['Diff']=(g_concat['Time_2']-g_concat['Time_1']).astype('timedelta64[h]').abs()
        g_concat['Time_max'] = pd.to_datetime(g_concat[['Time_1', 'Time_2']].max(axis=1))
        g_concat['Time_min'] = pd.to_datetime(g_concat[['Time_1', 'Time_2']].min(axis=1))
    except:
        print("**************", list(g_concat.areaName), "**************")
        print(g_concat.columns)
        print(g_concat)
    g_concat=g_concat[g_concat['Diff']>0]
    g_concat = g_concat.reset_index(drop=True)
    time_max = g_concat.pop('Time_max')
    time_min = g_concat.pop('Time_min')
    dates = g_concat.pop('Date')
    g_concat.insert(0, 'Date', dates)
    g_concat.insert(2, 'Time_min', time_min)
    g_concat.insert(3, 'Time_max', time_max)
    g_copy = g.set_index('Date_Time')
    # g_concat['downtime_freq'] = g_concat.apply(lambda x: len(g_copy.truncate(before=pd.Timestamp(x.Time_min), after=pd.Timestamp(x.Time_max))), axis=1)
    return g_concat[['Date', 'areaName', 'Time_min', 'Time_max', 'Diff']]


tag_speed_melt_downtime = tag_speed_melt.groupby('areaName', as_index=False).apply(starts_stops).droplevel(-1)
tag_speed_melt_downtime.index.names=['group']
tag_speed_melt_downtime.reset_index(inplace=True)
tag_speed_melt_downtime['asset'] = tag_speed_melt_downtime.areaName.apply(lambda x: re.findall(r'(\.[A-Z]+[0-9]+)', x)[0].split('.')[1])
asset = tag_speed_melt_downtime.pop('asset')
tag_speed_melt_downtime.insert(3, 'Asset', asset)
tag_speed_melt_downtime['Asset'] = tag_speed_melt_downtime['Asset'].replace({'RC0601':'CV21 (RC0601)', 'SK0501':'CV15 (SK0501)', 'SK0502':'CV18 (SK0502)'})


tag_speed_melt_downtime[tag_speed_melt_downtime.Date!=(tag_speed_melt_downtime.Time_min.dt.date)]

tag_speed_melt_downtime_copy = copy.deepcopy(tag_speed_melt_downtime)
tag_speed_melt_downtime_copy['Date'] = pd.to_datetime(tag_speed_melt_downtime_copy['Date'])
tag_speed_melt_downtime_copy['Downtime_1_hr'] = 1 # creating a flag for downtime_1hr in belt speed tag data
tag_speed_melt_downtime_copy['Date'].min()


date_range_df_first = date_range_df_first.reset_index().merge(tag_speed_melt_downtime_copy[['Date', 'Asset', 'Downtime_1_hr']], left_on=['date_range', 'areaName'], right_on=['Date', 'Asset'], how='left').drop(columns='Date')
date_range_df_second = date_range_df_second.reset_index().merge(tag_speed_melt_downtime_copy[['Date', 'Asset', 'Downtime_1_hr']], left_on=['date_range', 'areaName'], right_on=['Date', 'Asset'], how='left').drop(columns='Date')
date_range_df_third = date_range_df_third.reset_index().merge(tag_speed_melt_downtime_copy[['Date', 'Asset', 'Downtime_1_hr']], left_on=['date_range', 'areaName'], right_on=['Date', 'Asset'], how='left').drop(columns='Date')

date_range_df_first['Downtime_1_hr'] = date_range_df_first['Downtime_1_hr'].fillna(0)
date_range_df_second['Downtime_1_hr'] = date_range_df_second['Downtime_1_hr'].fillna(0)
date_range_df_third['Downtime_1_hr'] = date_range_df_third['Downtime_1_hr'].fillna(0)
date_range_df_third.head()

print('---> Downtime feature calculation complete.')

# Average result difference feature calculation (based on equipment id)
df_pds_equipId = df_pds_eid.loc[df_pds_eid['result'].notnull()].reset_index(drop=True).groupby(['areaName', 'wearSurface', 'test_date', 'testDate', 'averageResultDifference'], as_index=False).agg({'equipmentId':'unique'})
df_pds_equipId['equipmentId_pull'] = df_pds_equipId['equipmentId'].apply(lambda x: x[-1])
df_pds_equipId['equipmentId_diff'] = df_pds_equipId.groupby(['areaName', 'wearSurface']).agg({'equipmentId_pull':'diff'})
df_pds_equipId['equipmentId_diff'] = df_pds_equipId['equipmentId_diff'].fillna(1).mask(lambda x: x!=0,1)


df_pds_equipId_group = df_pds_equipId.groupby(['areaName', 'wearSurface', 'test_date'], as_index=False).agg({'equipmentId_diff':'sum'})
df_pds_equipId_group['equipmentId_diff'] = df_pds_equipId_group['equipmentId_diff'].mask(lambda x: x!= 1, np.nan)
df_pds_equipId_group['equipmentId_diff'] = df_pds_equipId_group['equipmentId_diff'].mask(lambda x: x==1, 0)
df_pds_equipId_group = df_pds_equipId_group.rename(columns = {'equipmentId_diff': 'averageResultDifference'})
date_range_df_first = date_range_df_first.reset_index().merge(df_pds_equipId_group[['test_date', 'areaName', 'wearSurface', 'averageResultDifference']], left_on=['date_range', 'areaName', 'wearSurface'], right_on=['test_date', 'areaName', 'wearSurface'], how='left').drop(columns='test_date')
date_range_df_second = date_range_df_second.reset_index().merge(df_pds_equipId_group[['test_date', 'areaName', 'wearSurface', 'averageResultDifference']], left_on=['date_range', 'areaName', 'wearSurface'], right_on=['test_date', 'areaName', 'wearSurface'], how='left').drop(columns='test_date')
date_range_df_third = date_range_df_third.reset_index().merge(df_pds_equipId_group[['test_date', 'areaName', 'wearSurface', 'averageResultDifference']], left_on=['date_range', 'areaName', 'wearSurface'], right_on=['test_date', 'areaName', 'wearSurface'], how='left').drop(columns='test_date')


# Load historical Tonnage tag data from the manual input files (data from before INT054 integration deployment required)
print('---> Load historical Tonnage data from manual input files.')

tag_ton = pd.read_csv(args.UC3_manual_inputs+'/GD_Historical_Tonnage.csv')
tag_ton.columns = [_.replace('-', '_') for _ in tag_ton.columns]
tag_ton_val_cols = [_ for _ in tag_ton.columns if 'Date_Time' not in _]
tag_ton['Date_Time'] = pd.to_datetime(tag_ton['Date_Time'])
tag_ton = tag_ton.sort_values(by='Date_Time')
period_start_ton = tag_ton['Date_Time'].max()



# Load liveTonnage tag data from the daily data load pipeline outputs (through integration INT054)
print('---> Loading live Tonnage data.')

# Period start = last datetime of the manual input file
period_start = (tag_ton.Date_Time.max()+pd.DateOffset(minutes=1)).to_pydatetime()
sdf_tags = spark.read.parquet(args.PCS_tags)
sdf_tags = sdf_tags[sdf_tags.tagid.isin(uc3_tag_list_ton)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start, dt_now)]
df_tags_ton = sdf_tags.toPandas()
print(df_tags_ton.tail())
print('Num rows live data: '+str(len(df_tags_ton)))

df_tags_ton = df_tags_ton.rename(columns = {'tagid':'areaName', 'time_rio':'Date_Time', 'value_rio':'ton'})
df_tags_ton = df_tags_ton.drop(columns = 'file_timestamp')
df_tags_ton = df_tags_ton[['areaName', 'ton', 'Date_Time']]
df_tags_ton['Date_Time'] = pd.to_datetime(df_tags_ton['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
# df_tags_ton['Date'] = df_tags_ton['Date_Time'].dt.date
# df_tags_ton['Asset'] = df_tags_ton['areaName'].apply(lambda x: re.findall(r'(\.[A-Z]+[0-9]+)', x)[0].split('.')[1])
# df_tags_ton.drop(columns={'Date_Time'}, inplace=True)
df_tags_ton['ton'] = pd.to_numeric(df_tags_ton['ton'])
df_tags_ton_pivot = df_tags_ton.pivot_table(index='Date_Time', columns='areaName', values='ton', aggfunc='max')#.reset_index()
df_tags_ton_pivot = df_tags_ton_pivot.resample('D').max()
df_tags_ton_pivot = df_tags_ton_pivot.reset_index()
df_tags_ton_pivot = df_tags_ton_pivot.iloc[1:].reset_index(drop=True)
df_tags_ton_pivot['Date_Time'] = pd.to_datetime(df_tags_ton_pivot['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
df_tags_ton_pivot.head()
print('---> Loaded live Tonnage data')
print(df_tags_ton_pivot.tail())

tag_ton = pd.concat((tag_ton, df_tags_ton_pivot), ignore_index=True)
tag_ton = tag_ton.sort_values('Date_Time')

# Tonnage data cleaning
print('---> Processing the tonnage data')
for col in tag_ton_val_cols:
    tag_ton[col] = tag_ton[col].ffill().fillna(0)
    tag_ton[col] = np.where(tag_ton[col] < 0, 0, tag_ton[col])
    tag_ton[col] = tag_ton[col].mask(tag_ton[col].diff() < 0, np.nan).ffill()

tag_ton_melt = tag_ton.melt(id_vars='Date_Time', value_vars=tag_ton_val_cols, value_name='ton', var_name='areaName')
tag_ton_melt['Date_Time'] = pd.to_datetime(tag_ton_melt['Date_Time'])
month_start_ton = tag_ton_melt.dropna().sort_values(['areaName','Date_Time'], ascending=True).groupby('areaName').apply(lambda x: pd.to_datetime(x.Date_Time.iloc[0], format='%Y-%m-%d').month_name())
tag_ton_melt = tag_ton_melt.sort_values(['areaName','Date_Time'], ascending=True)
tag_ton_melt['ton'] = tag_ton_melt['ton'].fillna(0)
tag_ton_melt.reset_index(drop=True, inplace = True)
tag_ton_melt['Date'] = tag_ton_melt.Date_Time.dt.date
tag_ton_melt['Asset'] = tag_ton_melt['areaName'].apply(lambda x: re.findall(r'(\.[A-Z]+[0-9]+)', x)[0].split('.')[1])
period_start_ton = tag_ton_melt['Date_Time'].max()
tag_ton_melt.drop(columns={'Date_Time'}, inplace=True)
tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'], format='%Y-%m-%d')
tag_ton_melt.head()


tag_ton_mapping_dict = {
                        'BF0401' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'BF0402' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'CV0101' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'CV0102' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'CV0211' : ['KD1.PPCS.CV0211WT03_TOTNRST'],
                        'CV0312' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'CV0313' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'CV0316' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'CV0514' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'CV0517' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'CV0622' : ['KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST'],
                        'RC0601-CV21' : ['KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST'],
                        'SK0501-CV15' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'SK0502-CV18' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'AF0101' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'AF0201' : ['KD1.PPCS.CV0211WT01_TOTNRST'],
                        'AF0202' : ['KD1.PPCS.CV0211WT01_TOTNRST', 'KD1.PPCS.CV0211WT03_TOTNRST']
                        }


df_tonnage = pd.DataFrame()

for i in list(tag_ton_mapping_dict.keys()):

    rel_belt = tag_ton_mapping_dict.get(i)
    print('rel_belt: {}'.format(tag_ton_mapping_dict.get(i)))
    temp_df = tag_ton_melt[tag_ton_melt['areaName'].isin(rel_belt)].reset_index()
    print('=======> tag_ton_melt areaName: {}'.format(tag_ton_melt.areaName.unique()))
    temp_df['Belt'] = i
    print(temp_df.head())
    if i == 'AF0202':
        temp_df_pivo = temp_df.pivot(index=['Date', 'Belt'], columns=['areaName'], values='ton')
        temp_df_pivo_cols = list(temp_df_pivo.select_dtypes('float').columns)
        print('===> temp_df_pivo_cols: ', temp_df_pivo_cols)
        print('===> temp_df_pivo_cols_all: ', temp_df_pivo.columns)
        print(temp_df_pivo.head())
        temp_df_pivo['ton'] = temp_df_pivo.apply(lambda x: x[temp_df_pivo_cols[1]] - x[temp_df_pivo_cols[0]], axis=1)
        
        temp_df_pivo['ton'] = temp_df_pivo['ton'].ffill().fillna(0)
        temp_df_pivo['ton'] = np.where(temp_df_pivo['ton'] < 0, 0, temp_df_pivo['ton'])
        temp_df_pivo['ton'] = temp_df_pivo['ton'].mask(temp_df_pivo['ton'].diff() < 0, np.nan).ffill()

        temp_df = temp_df_pivo.reset_index()[['Date', 'Belt', 'ton']]
    df_tonnage = pd.concat([df_tonnage, temp_df], axis = 0)
    print(i, tag_ton_mapping_dict.get(i))
df_tonnage['ton'] = np.where(df_tonnage['Belt'].isin(['BF0401', 'BF0402']), df_tonnage['ton']/2, df_tonnage['ton'])
tag_ton_melt_copy = copy.deepcopy(tag_ton_melt)
tag_ton_melt = copy.deepcopy(df_tonnage)
tag_ton_melt['Belt'] = tag_ton_melt['Belt'].replace({'RC0601-CV21':'CV21 (RC0601)', 'SK0501-CV15':'CV15 (SK0501)', 'SK0502-CV18':'CV18 (SK0502)'})
tag_ton_melt = tag_ton_melt.groupby(['Belt', 'Date'], as_index = False).agg({'ton' : 'max'})
# tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'], format='%Y-%m-%d')    


tag_ton_melt['ton_diff'] = tag_ton_melt.groupby('Belt').agg({'ton':'diff'}).values

tag_ton_melt['ton_diff'] = np.where(tag_ton_melt['ton_diff'] >1000000, 0, tag_ton_melt['ton_diff'])
# tag_ton_melt['ton_diff'] = np.where(tag_ton_melt['ton_diff'] <0, tag_ton_melt['ton'], tag_ton_melt['ton_diff'])
tag_ton_melt['ton_diff'] = np.where(tag_ton_melt['ton_diff'] <0, 0, tag_ton_melt['ton_diff'])
tag_ton_melt['ton'] = tag_ton_melt.groupby('Belt')['ton_diff'].cumsum()

# print(tag_ton_melt[tag_ton_melt['Belt'] == 'CV0312'][['Date', 'ton']].tail(50))

tag_ton_melt.loc[:, 'Date'] = pd.to_datetime(tag_ton_melt['Date'], format='%Y-%m-%d')
# tag_ton_melt.to_csv('tag_ton_melt_v2.csv', index=False)
tag_ton_melt.tail()
print('---> Tonnage data processed')

date_range_df_first = date_range_df_first.merge(tag_ton_melt[['Belt', 'Date', 'ton']], left_on=['areaName', 'date_range'], right_on=['Belt', 'Date'], how='left').drop(columns = ['Belt', 'Date'])
date_range_df_second = date_range_df_second.merge(tag_ton_melt[['Belt', 'Date', 'ton']], left_on=['areaName', 'date_range'], right_on=['Belt', 'Date'], how='left').drop(columns = ['Belt', 'Date'])
date_range_df_third = date_range_df_third.merge(tag_ton_melt[['Belt', 'Date', 'ton']], left_on=['areaName', 'date_range'], right_on=['Belt', 'Date'], how='left').drop(columns = ['Belt', 'Date'])


date_range_df_first['ton'] = date_range_df_first['ton'].fillna(0)
date_range_df_second['ton'] = date_range_df_second['ton'].fillna(0)
date_range_df_third['ton'] = date_range_df_third['ton'].fillna(0)



# Load Belt Technical Specifications

print('---> Loading Belt Length data')
belt_tech_specs = pd.read_csv(args.UC3_manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_length_specs = belt_tech_specs.loc[lambda x: x.Feature == 'Belt Length'].reset_index(drop=True)
belt_length_specs = belt_length_specs.pivot(index='Asset_ID', columns='Feature', values='Value').reset_index()
belt_length_specs = belt_length_specs.rename(columns = {'Asset_ID':'areaName'})
belt_length_specs['areaName'] = belt_length_specs['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
print('---> Loaded Belt Length data')

date_range_df_first = date_range_df_first.drop(columns='index').merge(belt_length_specs, on=['areaName'], how='left')
date_range_df_second = date_range_df_second.drop(columns='index').merge(belt_length_specs, on=['areaName'], how='left')
date_range_df_third = date_range_df_third.drop(columns='index').merge(belt_length_specs, on=['areaName'], how='left')

# Function to calculate cumsum feature (tonnage)
print('---> Calculating cumulative feature (tonnage)')
def diff_ton_cal(df_model):
    cols = list(df_model.columns)
    df_model['key'] = df_model['areaName'] + "_" + df_model['wearSurface']
    df_model = df_model.sort_values(['areaName', 'wearSurface', 'date_range'])

    res = df_model.groupby(['key']).agg({'ton' : 'diff'})
    res.columns = ['ton_diff']
    df_model = pd.concat([df_model, res], axis = 1)
    # df_model['ton_diff'] = df_model['ton_diff'].dt.total_seconds()/60

    df_model['cumsum_ton_key'] = np.where(df_model['averageResultDifference'] ==0, df_model['key'] + "_" + df_model['date_range'].astype(str), np.NaN)
    df_model['cumsum_ton_key'] = (df_model['cumsum_ton_key']).ffill(axis=0)
    df_model['ton_diff_tweaked'] = np.where(df_model['averageResultDifference'] ==0, 0, df_model['ton_diff'])

    res = df_model.groupby(['cumsum_ton_key']).agg({'ton_diff_tweaked' : 'cumsum'})
    res.columns = ['Cumsum']
    df_model = pd.concat([df_model, res], axis = 1)
    cols = cols + ['Cumsum']
    return df_model[cols]


date_range_df_first = diff_ton_cal(date_range_df_first)
date_range_df_second = diff_ton_cal(date_range_df_second)
date_range_df_third = diff_ton_cal(date_range_df_third)
print('---> Calculated cumulative feature (tonnage)')

# Function to calculate diff_days feature (days)
print('---> Calculating cumulative feature (days)')
def diff_days_cal(df_model):
    cols = list(df_model.columns)
    df_model['key'] = df_model['areaName'] + "_" + df_model['wearSurface']
    df_model = df_model.sort_values(['areaName', 'wearSurface', 'date_range'])

    res = df_model.groupby(['key']).agg({'date_range' : 'diff'})
    res.columns = ['Run_Time']
    df_model = pd.concat([df_model, res], axis = 1)
    df_model['Run_Time'] = df_model['Run_Time'].dt.total_seconds()/60

    df_model['cumsum_time_key'] = np.where(df_model['averageResultDifference'] ==0, df_model['key'] + "_" + df_model['date_range'].astype(str), np.NaN)
    df_model['cumsum_time_key'] = (df_model['cumsum_time_key']).ffill(axis=0)
    df_model['Run_Time_tweaked'] = np.where(df_model['averageResultDifference'] ==0, 0, df_model['Run_Time'])

    res = df_model.groupby(['cumsum_time_key']).agg({'Run_Time_tweaked' : 'cumsum'})
    res.columns = ['Cumsum_Time']
    df_model = pd.concat([df_model, res], axis = 1)
    df_model['diff_days'] = df_model['Cumsum_Time']/(60*24)
    cols = cols + ['diff_days']
    return df_model[cols]

date_range_df_first = diff_days_cal(date_range_df_first)
date_range_df_second = diff_days_cal(date_range_df_second)
date_range_df_third = diff_days_cal(date_range_df_third)
print('---> Calculated cumulative feature (days)')



# Average degradation rate calculation based on Cumsum
print('---> Calculating degradation rate using Cumsum (tonnage)')
def avg_degradation_rate_ton(complete_cycle,param,col):
    # complete_cycle = Daily Data
    # param = num_date
    """

    Parameters
    ----------
    complete_cycle : TYPE
        DESCRIPTION.
    col : TYPE
        DESCRIPTION.

    Returns
    -------
    avg_dgradation : TYPE
        DESCRIPTION.

    """
    # key = ['areaName', 'wearSurface']
    complete_cycle['key'] = complete_cycle['areaName'] + "_" + complete_cycle['wearSurface']
    avg_dgradation = pd.DataFrame()
    for k in complete_cycle['key'].unique():

        tst=complete_cycle[complete_cycle['key']==k]

        x = tst[param] - tst[param].min()
        try:
            trend = np.polyfit(x,tst[col],1)
            s=trend[0]
            tst['deg_rate_ton']=s
            avg_dgradation = avg_dgradation.append(tst)
        except:
            continue
        
    return avg_dgradation


date_range_df_left = avg_degradation_rate_ton(date_range_df_first,'Cumsum','result')
date_range_df_centre = avg_degradation_rate_ton(date_range_df_second,'Cumsum','result')
date_range_df_right = avg_degradation_rate_ton(date_range_df_third,'Cumsum','result')

date_range_df_left['deg_rate_ton'] = date_range_df_left.groupby(['areaName', 'wearSurface'])['deg_rate_ton'].transform('mean')
date_range_df_centre['deg_rate_ton'] = date_range_df_centre.groupby(['areaName', 'wearSurface'])['deg_rate_ton'].transform('mean')
date_range_df_right['deg_rate_ton'] = date_range_df_right.groupby(['areaName', 'wearSurface'])['deg_rate_ton'].transform('mean')
print('---> Calculated degradation rate using cumsum (tonnage')

# Average degradation rate calculation using diff days (time)
print('---> Calculating degradation rate using diff_days (time)')
def avg_degradation_rate_time(complete_cycle,param,col):
# complete_cycle = Daily Data
# param = num_date
    """

    Parameters
    ----------
    complete_cycle : TYPE
        DESCRIPTION.
    col : TYPE
        DESCRIPTION.

    Returns
    -------
    avg_dgradation : TYPE
        DESCRIPTION.

    """
    # key = ['areaName', 'wearSurface']
    complete_cycle['key'] = complete_cycle['areaName'] + "_" + complete_cycle['wearSurface']
    avg_dgradation = pd.DataFrame()
    for k in complete_cycle['key'].unique():

        tst=complete_cycle[complete_cycle['key']==k]

        x = tst[param] - tst[param].min()
        try:
            trend = np.polyfit(x,tst[col],1)
            s=trend[0]
            tst['deg_rate_time']=s
            avg_dgradation = avg_dgradation.append(tst)
        except:
            continue
        
    return avg_dgradation

date_range_df_left['num_date'] = mdates.date2num(date_range_df_left.date_range)
date_range_df_centre['num_date'] = mdates.date2num(date_range_df_centre.date_range)
date_range_df_right['num_date'] = mdates.date2num(date_range_df_right.date_range)

date_range_df_left = avg_degradation_rate_time(date_range_df_left,'num_date','result')
date_range_df_centre = avg_degradation_rate_time(date_range_df_centre,'num_date','result')
date_range_df_right = avg_degradation_rate_time(date_range_df_right,'num_date','result')

date_range_df_left['deg_rate_time'] = date_range_df_left.groupby(['areaName', 'wearSurface'])['deg_rate_time'].transform('mean')
date_range_df_centre['deg_rate_time'] = date_range_df_centre.groupby(['areaName', 'wearSurface'])['deg_rate_time'].transform('mean')
date_range_df_right['deg_rate_time'] = date_range_df_right.groupby(['areaName', 'wearSurface'])['deg_rate_time'].transform('mean')
print('---> Calculated degradation rate using diff_days (time)')



# Creating total degradation feature
date_range_df_left = date_range_df_left.rename(columns = {'deg_rate_ton': 'deg_rate_7_ton'})
date_range_df_left['thrXdeg_rate'] = date_range_df_left['Cumsum'] * date_range_df_left['deg_rate_7_ton']
date_range_df_centre = date_range_df_centre.rename(columns = {'deg_rate_ton': 'deg_rate_7_ton'})
date_range_df_centre['thrXdeg_rate'] = date_range_df_centre['Cumsum'] * date_range_df_centre['deg_rate_7_ton']
date_range_df_right = date_range_df_right.rename(columns = {'deg_rate_ton': 'deg_rate_7_ton'})
date_range_df_right['thrXdeg_rate'] = date_range_df_right['Cumsum'] * date_range_df_right['deg_rate_7_ton']
print('---> Calculated total degradation using deg_rate_7_ton (tonnage)')

date_range_df_left = date_range_df_left.rename(columns = {'deg_rate_time': 'deg_rate_7_time'})
date_range_df_left['dayXdeg_rate'] = date_range_df_left['diff_days'] * date_range_df_left['deg_rate_7_time']
date_range_df_centre = date_range_df_centre.rename(columns = {'deg_rate_time': 'deg_rate_7_time'})
date_range_df_centre['dayXdeg_rate'] = date_range_df_centre['diff_days'] * date_range_df_centre['deg_rate_7_time']
date_range_df_right = date_range_df_right.rename(columns = {'deg_rate_time': 'deg_rate_7_time'})
date_range_df_right['dayXdeg_rate'] = date_range_df_right['diff_days'] * date_range_df_right['deg_rate_7_time']
print('---> Calculated total degradation using deg_rate_7_time (time)')



# Calculating daily throughput
date_range_df_left = pd.concat((date_range_df_left, date_range_df_left.groupby(['areaName', 'wearSurface']).agg({'ton':'diff'}).rename(columns={'ton':'daily_throughput'})), axis=1)
date_range_df_left['daily_throughput'] = date_range_df_left['daily_throughput'].fillna(0)
date_range_df_centre = pd.concat((date_range_df_centre, date_range_df_centre.groupby(['areaName', 'wearSurface']).agg({'ton':'diff'}).rename(columns={'ton':'daily_throughput'})), axis=1)
date_range_df_centre['daily_throughput'] = date_range_df_centre['daily_throughput'].fillna(0)
date_range_df_right = pd.concat((date_range_df_right, date_range_df_right.groupby(['areaName', 'wearSurface']).agg({'ton':'diff'}).rename(columns={'ton':'daily_throughput'})), axis=1)
date_range_df_right['daily_throughput'] = date_range_df_right['daily_throughput'].fillna(0)
print('Daily Throughput feature calculated')


date_range_df_left = date_range_df_left.rename(columns={'Belt Length':'Belt_Length'})
date_range_df_centre = date_range_df_centre.rename(columns={'Belt Length':'Belt_Length'})
date_range_df_right = date_range_df_right.rename(columns={'Belt Length':'Belt_Length'})


date_range_df_right_copy = copy.deepcopy(date_range_df_right)
date_range_df_centre_copy = copy.deepcopy(date_range_df_centre)
date_range_df_left_copy = copy.deepcopy(date_range_df_left)


date_range_df_right['Key'] = date_range_df_right['areaName'] + '_' + date_range_df_right['wearSurface']
date_range_df_centre['Key'] = date_range_df_centre['areaName'] + '_' + date_range_df_centre['wearSurface']
date_range_df_left['Key'] = date_range_df_left['areaName'] + '_' + date_range_df_left['wearSurface']
date_range_df_right = date_range_df_right.rename(columns = {'result':'result_min_7'})
date_range_df_centre = date_range_df_centre.rename(columns = {'result':'result_min_7'})
date_range_df_left = date_range_df_left.rename(columns = {'result':'result_min_7'})


# Filtering pds dates to match tag data
last_dates_list = [pd.Timestamp(df_pds.test_date.max()), pd.Timestamp(tag_ton_melt.Date.max()), pd.Timestamp(tag_speed_melt.Date.max())]
last_dates_list.sort()
date_to_filter = last_dates_list[0]
date_range_df_right = date_range_df_right.loc[lambda x: x.date_range <= date_to_filter, :]
date_range_df_centre = date_range_df_centre.loc[lambda x: x.date_range <= date_to_filter, :]
date_range_df_left = date_range_df_left.loc[lambda x: x.date_range <= date_to_filter, :]


date_range_df_right_model = date_range_df_right[['Key', 'areaName', 'wearSurface', 'Belt_Length', 'daily_throughput', 'Cumsum', 'deg_rate_7_ton', 'thrXdeg_rate', 'diff_days', 'deg_rate_7_time', 'dayXdeg_rate', 'Downtime_1_hr', 'num_date', 'result_min_7']].reset_index(drop=True)
date_range_df_centre_model = date_range_df_centre[['Key', 'areaName', 'wearSurface', 'Belt_Length', 'daily_throughput', 'Cumsum', 'deg_rate_7_ton', 'thrXdeg_rate', 'diff_days', 'deg_rate_7_time', 'dayXdeg_rate', 'Downtime_1_hr', 'num_date', 'result_min_7']].reset_index(drop=True)
date_range_df_left_model = date_range_df_left[['Key', 'areaName', 'wearSurface', 'Belt_Length', 'daily_throughput', 'Cumsum', 'deg_rate_7_ton', 'thrXdeg_rate', 'diff_days', 'deg_rate_7_time', 'dayXdeg_rate', 'Downtime_1_hr', 'num_date', 'result_min_7']].reset_index(drop=True)

# Belt critical thickness
print('Loading Belt wise critical thickness')
belt_critical_specs = belt_tech_specs[belt_tech_specs.Feature.str.contains('Critical Thickness')]
belt_critical_specs['wearSurface'] = belt_critical_specs.Feature.apply(lambda x: x.split(' ')[0])
belt_critical_specs['wearSurface'] = belt_critical_specs['wearSurface'].replace({'Pan': 'Top of Pan', 'Chain': 'Chain Length'})
belt_critical_specs = belt_critical_specs.rename(columns = {'Asset_ID':'areaName', 'Value':'Critial Thickness'})
belt_critical_specs.reset_index(drop=True, inplace=True)
belt_critical_specs['areaName'] = belt_critical_specs['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
belt_critical_specs['Critial Thickness'] = belt_critical_specs['Critial Thickness'].astype('float')
print('Loaded Belt-wise critical thickness.')


date_range_df_right_model = date_range_df_right_model.merge(belt_critical_specs[['areaName', 'wearSurface', 'Critial Thickness']], on=['areaName', 'wearSurface'], how='left').drop(columns=['areaName', 'wearSurface'])
date_range_df_centre_model = date_range_df_centre_model.merge(belt_critical_specs[['areaName', 'wearSurface', 'Critial Thickness']], on=['areaName', 'wearSurface'], how='left').drop(columns=['areaName', 'wearSurface'])
date_range_df_left_model = date_range_df_left_model.merge(belt_critical_specs[['areaName', 'wearSurface', 'Critial Thickness']], on=['areaName', 'wearSurface'], how='left').drop(columns=['areaName', 'wearSurface'])
date_range_df_right_model['part_of_asset'] = 'right'
date_range_df_centre_model['part_of_asset'] = 'centre'
date_range_df_left_model['part_of_asset'] = 'left'


print('###### DATA PREPARATION FOR APRON FEEDER STARTED ######')

# Filter for only relevant assets
print('filtering only Apron Feeder Data from PDS')
df_pds_apron_qtrly = df_pds[df_pds.areaName.isin(UC3_AFs)].reset_index(drop=True)
df_pds_apron_qtrly.areaName.unique()


try:
    
    # Strip time out of testDate
    # df_pds_apron_qtrly['averageResultDifference'] = df_pds_apron_qtrly['averageResultDifference'].fillna(0)
    df_pds_apron_qtrly = df_pds_apron_qtrly.groupby(['areaName','wearSurface','equipmentDescription','equipmentId', 'test_date'], as_index=False).agg({'result':'min'})
    df_pds_apron_qtrly = df_pds_apron_qtrly.rename(columns = {'result':'result_min'})
    df_pds_apron_qtrly['test_date'] = pd.to_datetime(df_pds_apron_qtrly['test_date'].dt.date, format = "%Y-%m-%d")
    print(df_pds_apron_qtrly.head())

    df_pds_apron_qtrly = df_pds_apron_qtrly.merge(tag_ton_melt[['Belt', 'Date', 'ton']], left_on=['areaName', 'test_date'], right_on=['Belt', 'Date'], how='left').drop(columns = ['Belt', 'Date'])
    df_pds_apron_qtrly['ton'] = df_pds_apron_qtrly['ton'].fillna(0)

    def pds_processing(df_pds_apron_qtrly):
    
        """
        Processing PDS data 
        
        """
        
        df_pds_apron_qtrly['Side'] = np.where(df_pds_apron_qtrly['equipmentDescription'].str.contains('RHS'), 'RHS',
                            np.where(df_pds_apron_qtrly['equipmentDescription'].str.contains('LHS'), 'LHS', 'Pan'))

        df_pds_apron_qtrly['equipmentId']=df_pds_apron_qtrly['equipmentId'].astype(str)
        df_pds_apron_qtrly['Key'] = df_pds_apron_qtrly.apply(lambda x: '_'.join([x.areaName, x.wearSurface, x.equipmentId, x.Side]), axis=1)
        df_pds_apron_qtrly=df_pds_apron_qtrly.sort_values(['Key', 'test_date'])
        df_pds_apron_qtrly['Tonn_acc']=df_pds_apron_qtrly.groupby(['areaName','wearSurface','Side','equipmentId'])['ton'].transform('diff')
        df_pds_apron_qtrly['Tonnage']=df_pds_apron_qtrly.groupby(['areaName','wearSurface','Side','equipmentId'])['Tonn_acc'].transform('cumsum')
        df_pds_apron_qtrly['num_date'] = mdates.date2num(df_pds_apron_qtrly.test_date)
        df_pds_apron_qtrly['min']=df_pds_apron_qtrly.groupby(['Key'])['num_date'].transform('min')
        df_pds_apron_qtrly['diff_days']=df_pds_apron_qtrly['num_date']-df_pds_apron_qtrly['min']
        df_pds_apron_qtrly.loc[df_pds_apron_qtrly['Tonnage'].isna(),'Tonnage']=0
        df_pds_apron_qtrly['con_diff']=df_pds_apron_qtrly.groupby(['Key'])['num_date'].transform('diff')
        df_pds_apron_qtrly['thick']=df_pds_apron_qtrly.groupby(['Key'])['result_min'].transform('diff')
        df_pds_apron_qtrly.loc[df_pds_apron_qtrly['con_diff'].isnull(),'con_diff']=0
        df_pds_apron_qtrly.loc[df_pds_apron_qtrly['Tonn_acc'].isnull(),'Tonn_acc']=0
        df_pds_apron_qtrly.loc[df_pds_apron_qtrly['thick'].isnull(),'thick']=0   
        df_pds_apron_qtrly = pd.merge(df_pds_apron_qtrly,
                                      belt_critical_specs[['areaName', 'wearSurface', 'Critial Thickness']],
                                      on = ['areaName', 'wearSurface'],
                                      how = 'left') 

        return df_pds_apron_qtrly

    df_pds_apron_qtrly = pds_processing(df_pds_apron_qtrly)

    print(df_pds_apron_qtrly.columns)

    def chain_df(df_pds_apron_qtrly):
    
        '''
        Extract chain data for tonnage model
        '''
        data_chain=df_pds_apron_qtrly[df_pds_apron_qtrly['wearSurface']=='Chain Length']
        ### Outliers
        ### Removing -ve chain length
        data_chain['Max_thick']=data_chain.groupby(['Key'])['result_min'].transform('max')
        data_chain['Min_thick']=data_chain.groupby(['Key'])['result_min'].transform('min')
        data_chain['Delta_thick_variation']=data_chain['Max_thick']-data_chain['Min_thick']
        data_chain['delta_thickness_per_tonn']=data_chain['thick']/data_chain['Tonn_acc']
        data_chain.loc[data_chain['delta_thickness_per_tonn'].isna(),'delta_thickness_per_tonn']=0
        data_chain['delta_thickness_per_mtonn']=data_chain['thick']*10**6/data_chain['Tonn_acc']
        data_chain.loc[data_chain['delta_thickness_per_mtonn'].isna(),'delta_thickness_per_mtonn']=0
        data_chain['delta_thickness_per_day']=data_chain['thick']/data_chain['con_diff']
        data_chain['delta_thickness_per_month']=data_chain['delta_thickness_per_day']*30
        data_chain.loc[data_chain['delta_thickness_per_day'].isna(),'delta_thickness_per_day']=0
        return data_chain
    try:
        pds_chain_df = chain_df(df_pds_apron_qtrly)
    except:
        pass


    def toppan_df(df_pds_apron_qtrly):
    
        '''
        Top of Pan extraction from PDS
        '''
        dtop=df_pds_apron_qtrly[df_pds_apron_qtrly['wearSurface']=='Top of Pan']
        dtop['delta_thickness_per_day']=dtop['thick']/dtop['con_diff']
        dtop.loc[dtop['delta_thickness_per_day'].isna(),'delta_thickness_per_day']=0
        dtop['delta_thickness_per_month']=dtop['delta_thickness_per_day']*30
        dtop['delta_thickness_per_tonn']=dtop['thick']/dtop['Tonn_acc']
        dtop.loc[dtop['delta_thickness_per_tonn'].isna(),'delta_thickness_per_tonn']=0
        dtop['delta_thickness_per_mtonn']=dtop['thick']*10**6/dtop['Tonn_acc']
        dtop.loc[dtop['delta_thickness_per_mtonn'].isna(),'delta_thickness_per_mtonn']=0
        l1=[]
        for key in dtop['Key'].unique():
            dtemp=dtop[dtop['Key']==key]
            if len(dtemp)>=1:
                l1.append(key)
        dtop1=dtop.copy()
        dtop1['Max_thick']=dtop1.groupby(['Key'])['result_min'].transform('max')
        dtop1['Min_thick']=dtop1.groupby(['Key'])['result_min'].transform('min')
        dtop1['Delta_thick_variation']=dtop1['Max_thick']-dtop1['Min_thick']
        dtop1=dtop1[dtop1['Key'].isin(l1)]
        return dtop1

    pds_toppan_df = toppan_df(df_pds_apron_qtrly)

except:
    print('Warning  !  If you see this message, please check back on Apron Feeder Data !!!')
    df_pds_apron_qtrly = df_pds_apron_qtrly.groupby(['areaName','averageResultDifference','wearSurface','equipmentDescription','equipmentId', 'test_date'], as_index=False).agg({'result':'min'}).rename(columns={'result':'result_min'})
    df_pds_apron_qtrly['Key'] = df_pds_apron_qtrly.apply(lambda x: '_'.join([x.areaName, x.wearSurface, x.equipmentId, x.Side]), axis=1)
    ky = df_pds_apron_qtrly.pop('Key')
    df_pds_apron_qtrly.insert(0, 'Key', ky)
    df_pds_apron_qtrly = pd.merge(df_pds_apron_qtrly,
                                      belt_critical_specs[['areaName', 'wearSurface', 'Critial Thickness']],
                                      on = ['areaName', 'wearSurface'],
                                      how = 'left')
    pds_chain_df = df_pds_apron_qtrly[df_pds_apron_qtrly['wearSurface']=='Chain Length']
    pds_toppan_df = df_pds_apron_qtrly[df_pds_apron_qtrly['wearSurface']=='Top of Pan']

print('#### DATA PREPARATION FOR APRON FEEDER COMPLETE ####')  


# Load Shutdown Schedule data
print('---> Loading Shutdown data')
hdfs_path = "/*"+date_range
sdf_shutdown = spark.read.option("multiline", "true").json(args.shutdowns+hdfs_path).withColumn("filename", input_file_name())
sdf_shutdown = load_ADA_data.NormaliseJsonSpark(sdf_shutdown).normalise_shutdown_spark()

df_shutdown = sdf_shutdown.toPandas()
df_shutdown = df_shutdown.sort_values('planned_start_date')
df_shutdown['planned_start_date'] = pd.to_datetime(df_shutdown['planned_start_date'])

print('---> Shutdown data complete.')


## Output Processed Data for next Pipeline step

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

tag_ton_melt.to_csv(output_folder+'/tag_ton_melt.csv', index=False)
date_range_df_right_model.to_csv(output_folder+'/date_range_df_right_model.csv', index=False)
date_range_df_centre_model.to_csv(output_folder+'/date_range_df_centre_model.csv', index=False)
date_range_df_centre.to_csv(output_folder+'/date_range_df_centre.csv', index=False)
date_range_df_left_model.to_csv(output_folder+'/date_range_df_left_model.csv', index=False)
date_range_df_left.to_csv(output_folder+'/date_range_df_left.csv', index=False) 
try:
    pds_chain_df.to_csv(output_folder+'/pds_chain_df.csv', index=False)
except:
    pass
pds_toppan_df.to_csv(output_folder+'/pds_toppan_df.csv', index=False)

df_shutdown.to_csv(output_folder+'/df_shutdown.csv', index=False)

df_pds.to_csv(output_folder+'/df_pds.csv', index=False)

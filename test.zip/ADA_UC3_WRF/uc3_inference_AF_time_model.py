import pandas as pd
import numpy as np
import os
import datetime
from datetime import timedelta
import math

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--input_data")
parser.add_argument("--manual_inputs")
parser.add_argument("--forecast_date")
parser.add_argument("--output_dir")
args = parser.parse_args()

if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


# Import outputs of data prep step
try:
    pds_chain_df = pd.read_csv(args.input_data+'/pds_chain_df.csv')
except:
    pass
pds_toppan_df = pd.read_csv(args.input_data+'/pds_toppan_df.csv')

# Import PoC Degradation rates based on Cape Lambert B assets
df_poc_deg_rates = pd.read_csv(args.manual_inputs+'/CLB_Model_Files/CLB_AF_deg_rates.csv')

# Chain Length
try:
    try:
        def days_prediction_chain(pds_chain_df):
        
            '''
            Model for chain Length
            '''
            
            df_time_ch1=pd.DataFrame()
            for Key in pds_chain_df['Key'].unique():
                data_temp=pds_chain_df[pds_chain_df['Key']==Key]
                if len(data_temp)>=2:
                    df_time_ch=pd.DataFrame()
                    X = (data_temp.num_date - data_temp.num_date.min()).values.reshape(-1,1)
                    y=data_temp.result_min
                    trend=LinearRegression().fit(X,y)
                    delta_var=data_temp['Delta_thick_variation'].max()
                    data_act=data_temp[data_temp['delta_thickness_per_day']!=0]
                    mn=data_act['delta_thickness_per_day'].mean()
                    s=trend.coef_
                    i=trend.intercept_
                    final_thk = data_temp['Critial Thickness'].unique()[0]
                    critial_day=(final_thk-i)/s
                    print(critial_day,mn)
                    if s==0:
                        day_rem=9999
                    else:
                        day_rem=critial_day-data_temp['diff_days'].max()
                    
                    df_time_ch['Key']=[Key]
                    df_time_ch[['areaName', 'wearSurface', 'equipmentID', 'Side']] = df_time_ch['Key'].str.split('_', expand=True)
                    df_time_ch['mm_per_month']=[np.round(s,4)*30]
                    if s < 0:
                        df_time_ch['days_to_replace_time'] = 9999
                    else:
                        df_time_ch['days_to_replace_time']=day_rem
                    df_time_ch['test_date'] = data_temp['test_date'].max()
                    df_time_ch1=df_time_ch1.append(df_time_ch)
            df_time_ch1=df_time_ch1.sort_values(by='Key')
            return df_time_ch1

        chain_df_days_output = days_prediction_chain(pds_chain_df)

    except Exception as error:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        line_number = exception_traceback.tb_lineno
        print("Exception type: ", exception_type)
        print("Exception in try blockLine number: ", line_number)

        chain_df_days_output = pds_chain_df.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                        'result_min' : 'last'})
        
        chain_df_days_output[['areaName', 'wearSurface', 'equipmentID', 'Side']] = chain_df_days_output['Key'].str.split('_', expand=True)         
        
        chain_df_days_output['mm_per_month'] = df_poc_deg_rates[df_poc_deg_rates['wearSurface'] == 'Chain Length']['deg_rate_time'].mean()                                                                                      
        chain_df_days_output['days_to_replace_time'] = (chain_df_days_output['Critial Thickness'] - chain_df_days_output['result_min'])*30/chain_df_days_output['mm_per_month']

        chain_df_days_output = chain_df_days_output.loc[chain_df_days_output.groupby('areaName')['days_to_replace_time'].idxmin()]

        chain_df_days_output['Key'] = chain_df_days_output['areaName'] + '_' + chain_df_days_output['wearSurface']

        print('Days Prediction Chain Length -- PoC deg rates have been used !!!')
except:
    pass

# Top of Pan
try:
    def days_prediction_toppan(pds_toppan_df):
    
        '''
        Top of Pan plot
        '''
        df_time_top1=pd.DataFrame()
        for Key in pds_toppan_df['Key'].unique():
            data_temp=pds_toppan_df[pds_toppan_df['Key']==Key]
            
            if len(data_temp)>=2:
                df_time_top=pd.DataFrame()
                data_act=data_temp[data_temp['delta_thickness_per_day']!=0]
                mn=data_act['delta_thickness_per_day'].mean()
                data_act1=data_temp[data_temp['delta_thickness_per_day']!=0]
                mn_tn=data_act1['delta_thickness_per_mtonn'].mean()
                x = data_temp.num_date - data_temp.num_date.min()
                
                trend = np.polyfit(x,data_temp.result_min,1)
                delta_var=data_temp['Delta_thick_variation'].max()
                s=trend[0]
                i=trend[1]
                
                mape_sum=0
                for day, thk in zip(x, data_temp.result_min):
                    prediction = s*day+i
                #     mape_sum += abs((thk - prediction)/delta_var)
                # mape = mape_sum / len(data_temp) 
            
                final_thk = data_temp['Critial Thickness'].unique()[0]
                critial_day=(final_thk-i)/s
                day_rem=critial_day-data_temp['diff_days'].max()
                # print(Key, mape*100,round(mn,4)*30,round(mn_tn,4),round(day_rem,4))   
                
                df_time_top['Key']=[Key]
                df_time_top[['areaName', 'wearSurface', 'equipmentID', 'Side']] = df_time_top['Key'].str.split('_', expand=True)         
                # df_time_top['Mape']=[mape*100]
                df_time_top['mm_per_month']=[np.round(mn*30,4)]
                if mn >= 0:
                    df_time_top['days_to_replace_time'] = [9999]
                else:
                    df_time_top['days_to_replace_time']=[day_rem]
                df_time_top['test_date'] = data_temp['test_date'].max()
                # df_time_top['Accuracy']=[100-(mape*100)]
                df_time_top1=df_time_top1.append(df_time_top)
                
         
        df_time_top1=df_time_top1.sort_values(by='Key')
        return df_time_top1

    toppan_df_days_output = days_prediction_toppan(pds_toppan_df)
    print(' --> Generated through polyfit <---')

except Exception as error:
    exception_type, exception_object, exception_traceback = sys.exc_info()
    line_number = exception_traceback.tb_lineno
    print("Exception type: ", exception_type)
    print("Exception in try blockLine number: ", line_number)   

    toppan_df_days_output = pds_toppan_df.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                      'result_min' : 'last', 'test_date':'max'})
    toppan_df_days_output[['areaName', 'wearSurface', 'equipmentID', 'Side']] = toppan_df_days_output['Key'].str.split('_', expand=True)         
    
    toppan_df_days_output['mm_per_month'] = df_poc_deg_rates[df_poc_deg_rates['wearSurface'] == 'Top of Pan']['deg_rate_time'].mean()                                                                                      
    toppan_df_days_output['days_to_replace_time'] = (toppan_df_days_output['result_min'] - toppan_df_days_output['Critial Thickness'])*30/toppan_df_days_output['mm_per_month']
    print('Days Prediction Top of Pan -- PoC deg rates have been used !!!')


# Output model results

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

if toppan_df_days_output.empty:
    final_output_af = chain_df_days_output
elif chain_df_days_output.empty:
    final_output_af = toppan_df_days_output
else:                
    final_output_af = pd.concat([chain_df_days_output, toppan_df_days_output], ignore_index=True)
print(final_output_af)
final_output_af['days_to_replace_time'] = pd.to_timedelta(final_output_af['days_to_replace_time'].apply(math.ceil), 'D')
final_output_af['test_date'] = pd.to_datetime(final_output_af['test_date'])
final_output_af['date_to_critical_thickness'] = final_output_af['test_date'] + final_output_af['days_to_replace_time']

final_output_af.to_csv(output_folder+'/final_af_days_output_'+forecast_date+'.csv', index=False)
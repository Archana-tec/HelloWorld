import pandas as pd
import math
import os
import datetime

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--forecast_date")
parser.add_argument("--belt_input")
parser.add_argument("--AF_input")
parser.add_argument("--output_dir")
args = parser.parse_args()
    
if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


# Load outputs from model steps
final_output_belt = pd.read_csv(args.belt_input+'/ADA_UC3_WRF_results_belt_'+forecast_date+'.csv')
final_output_AF = pd.read_csv(args.AF_input+'/ADA_UC3_WRF_results_AF_'+forecast_date+'.csv')

# Combine outputs from model steps
uc3_output = pd.concat([final_output_belt, final_output_AF], ignore_index = True)
uc3_output = uc3_output.loc[lambda x: x.subcomponentname != 'Bottom'].reset_index(drop=True)
uc3_output['forecast_replacement_date'] = pd.to_datetime(uc3_output['forecast_replacement_date'], format='%Y-%m-%d')
uc3_output['scenario1_forecast_replacement_date'] = pd.to_datetime(uc3_output['scenario1_forecast_replacement_date'], format='%Y-%m-%d')
uc3_output['scenario2_forecast_replacement_date'] = pd.to_datetime(uc3_output['scenario2_forecast_replacement_date'], format='%Y-%m-%d')
uc3_output['RUL_days_buffer'] = uc3_output['RUL_days_buffer'].apply(lambda x: pd.Timedelta(x))
uc3_output['scenario1_RUL_days_buffer'] = uc3_output['scenario1_RUL_days_buffer'].apply(lambda x: pd.Timedelta(x))
uc3_output['scenario2_RUL_days_buffer'] = uc3_output['scenario2_RUL_days_buffer'].apply(lambda x: pd.Timedelta(x))

uc3_output['forecast_date'] = pd.to_datetime(uc3_output['forecast_date'], format='%Y-%m-%d')
uc3_output['latest_thickness_date'] = pd.to_datetime(uc3_output['latest_thickness_date'], format='%Y-%m-%d')
uc3_output['forecast_critical_thickness_date'] = pd.to_datetime(uc3_output['forecast_critical_thickness_date'], format='%Y-%m-%d')
uc3_output['scenario1_forecast_critical_thickness_date'] = pd.to_datetime(uc3_output['scenario1_forecast_critical_thickness_date'], format='%Y-%m-%d')
uc3_output['scenario2_forecast_critical_thickness_date'] = pd.to_datetime(uc3_output['scenario2_forecast_critical_thickness_date'], format='%Y-%m-%d')

try:
    uc3_output = uc3_output.drop(columns='critical_thickness_mm.1')
except:
    pass
print(uc3_output.shape)



uc3_output['forecast_date'] = uc3_output['forecast_date'].dt.date
uc3_output['latest_thickness_date'] = uc3_output['latest_thickness_date'].dt.date
uc3_output['forecast_critical_thickness_date'] = uc3_output['forecast_critical_thickness_date'].dt.date
uc3_output['forecast_replacement_date'] = uc3_output['forecast_replacement_date'].dt.date
uc3_output['scenario1_forecast_critical_thickness_date'] = uc3_output['scenario1_forecast_critical_thickness_date'].dt.date
uc3_output['scenario1_forecast_replacement_date'] = uc3_output['scenario1_forecast_replacement_date'].dt.date
uc3_output['scenario2_forecast_critical_thickness_date'] = uc3_output['scenario2_forecast_critical_thickness_date'].dt.date
uc3_output['scenario2_forecast_replacement_date'] = uc3_output['scenario2_forecast_replacement_date'].dt.date
uc3_output['floc_id']=uc3_output['floc_id'].replace({'3029CV15 (SK0501)':'3029SK0501CV15', '3029CV18 (SK0502)':'3029SK0502CV18', '3029CV21 (RC0601)':'3029RC0601CV21'})




# Export to output folder

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)
print(output_folder)
uc3_output.to_csv(output_folder+'/ADA_UC3_WRF_results_'+forecast_date+'.csv', index = False)
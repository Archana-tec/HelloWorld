# Import libraries
import argparse
from azureml.core import Model, Run

# Parse arguments
parser = argparse.ArgumentParser()
parser.add_argument('--input_folder')

args = parser.parse_args()
model_folder = args.input_folder 

# Get the experiment run context
run = Run.get_context()

Model.register(workspace = run.experiment.workspace,
               model_path = model_folder,
               model_name = 'UC3_WRF',
               description = 'Wear Rate Forecast Model'
               )

run.complete()
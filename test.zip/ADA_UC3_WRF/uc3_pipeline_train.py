import os
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Run
import datetime
import pandas as pd
import numpy as np
import math
import shutil
import pickle
import joblib
import argparse
from sklearn.linear_model import LinearRegression

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

parser = argparse.ArgumentParser()
parser.add_argument("--input_dataset_dir")
parser.add_argument("--output_folder")
args = parser.parse_args()


#### Create Output folder
output_folder = args.output_folder
os.makedirs(output_folder, exist_ok=True)

#### Import model inputs
belt_wear_fast = pd.read_csv(args.input_dataset_dir+'/belt_wear_fast.csv')
belt_wear_slow = pd.read_csv(args.input_dataset_dir+'/belt_wear_slow.csv')

complete_cycle_fast = pd.read_csv(args.input_dataset_dir+'/complete_cycle_fast.csv')
complete_cycle_slow = pd.read_csv(args.input_dataset_dir+'/complete_cycle_slow.csv')



#### Function for Time Based Model
def days_prediction(train,test,section,belt_category):
    """
    

    Parameters
    ----------
    train : TYPE
        DESCRIPTION.
    test : TYPE
        DESCRIPTION.
    section : TYPE
        DESCRIPTION.

    Returns
    -------
    advisory : TYPE
        DESCRIPTION.

    """
    
    reg = LinearRegression()
    train['dayXdeg_rate_time']=train['diff_days']*train['deg_rate_time'+'_'+section]
    train = train.dropna()
    X_train=train[['diff_days','Belt_Length','daily_throughput','deg_rate_time'+'_'+section,'dayXdeg_rate_time','Downtime_1_hr']]
    
    # y_train=train['Corrected_Thickness'+'_'+section]
    y_train=train['result_min'+'_'+section]
    y_train=np.array(y_train).reshape(-1, 1)
    
    reg.fit(X_train, y_train)
    
    c = reg.intercept_[0]
    m1 = reg.coef_[0][0]
    m2 = reg.coef_[0][1]
    m3 = reg.coef_[0][2]
    m4 = reg.coef_[0][3]
    m5 = reg.coef_[0][4]
    m6 = reg.coef_[0][5]
    
    coef_df = pd.DataFrame({'c' : [c], 'm1' : [m1], 'm2' :  [m2], 'm3' : [m3], 'm4' : [m4], 'm5' : [m5], 'm6' : [m6]})
    print(coef_df)        
    
    model_name = 'days_model_' + belt_category + '_' + section + '.pkl'
    print(model_name)
    # model_path = 'Models/Time_Based/'
    joblib.dump(reg, filename=output_folder + '/' + model_name)
    print(model_name, 'saved as pickle')
    advisory = pd.DataFrame()

    for k in test['Key'].unique():
        
        tst = test[test['Key']==k]
        deg_rate = tst['deg_rate_time'+'_'+section].unique()[0]
        
        if math.isnan(deg_rate):
            deg_rate=train['deg_rate_time'+'_'+section].mean()
            tst['deg_rate_time'+'_'+section]=deg_rate
            
        tst['dayXdeg_rate_time']=tst['diff_days']*tst['deg_rate_time'+'_'+section]
        y_belt =tst['Critial Thickness'].unique()[0]
        

        end_thickness = tst.iloc[-1]['result_min'+'_'+section]
        out=(y_belt-end_thickness)/(m1+(m5*deg_rate))
        slope = m1+(m5*deg_rate)
        
        if (len(tst)>=4) & (belt_category=='slow'):
        
            # Polyfit for cycle k
            x = tst.num_date - tst.num_date.min()
            trend = np.polyfit(x,tst['result_min'+'_'+section],1)
            y=tst['result_min'+'_'+section]
            s=trend[0]
            i=trend[1]
        
            #Polyfit for last 5 points
     
            if len(tst[tst.shape[0]-5:]) > 1:
                
                trend_rt = np.polyfit(x[tst.shape[0]-5:],tst[tst.shape[0]-5:]['result_min'+'_'+section],1)
                x=x[tst.shape[0]-5:]
                y=tst[tst.shape[0]-5:]['result_min'+'_'+section]
            else:
                trend_rt = np.polyfit(x,tst['result_min'+'_'+section],1)
            s_rt=trend_rt[0]
            i_rt=trend_rt[1]
            
            out1 = (y_belt-end_thickness)/s
            out1 = np.where(out1<0,99999,out1)
            out2 = (y_belt-end_thickness)/s_rt
            out2 = np.where(out2<0,99999,out2)
            out = np.where(out1<out2,out1,out2)
            slope = np.where(out1<out2,s,s_rt)

        
        d = {'Key':[k],'Days to Replace'+'_'+section:out,'mm_per_day'+'_'+section:slope}
        df = pd.DataFrame(data=d)
        advisory=advisory.append(df)
    return advisory



#### Training Fast Wear Belts
test=pd.DataFrame()
d1=belt_wear_fast.groupby('areaName')
for arnm in belt_wear_fast['areaName'].unique():
    print(arnm)
    dtemp=d1.get_group(arnm)
    tr=pd.DataFrame()
    tt=pd.DataFrame()
    last_key = dtemp.iloc[-1]['key']
    if ((dtemp.iloc[-1]['averageResultDifference']!=0) | (len(dtemp[dtemp['key']==last_key])==1)):
        key=dtemp.iloc[-1]['key']
        tr=dtemp[dtemp['key']!=key]
        tt=dtemp[dtemp['key']==key]
    else:
        tr=dtemp 
    test=test.append(tt,ignore_index=True)

train = complete_cycle_fast
train = train.drop_duplicates()

days_advisory_fast = test[['Key']].drop_duplicates()

thickness_cols = [col for col in belt_wear_fast.columns if 'result_min_' in col]

for col in thickness_cols:
    belt_section = col.split('_')[-1]
    advisory_section = days_prediction(train,test,section=belt_section,belt_category='fast')
    days_advisory_fast = pd.merge(days_advisory_fast,advisory_section,on=['Key'],how='left')

print(days_advisory_fast)    



#### Training Slow Wear Belts
test=pd.DataFrame()
d1=belt_wear_slow.groupby('areaName')
for arnm in belt_wear_slow['areaName'].unique():
    print(arnm)
    dtemp=d1.get_group(arnm)
    tr=pd.DataFrame()
    tt=pd.DataFrame()
    last_key = dtemp.iloc[-1]['key']
    if ((dtemp.iloc[-1]['averageResultDifference']!=0) | (len(dtemp[dtemp['key']==last_key])==1)):
        key=dtemp.iloc[-1]['key']
        tr=dtemp[dtemp['key']!=key]
        tt=dtemp[dtemp['key']==key]
    else:
        tr=dtemp 
    test=test.append(tt,ignore_index=True)

train = complete_cycle_slow
train = train.drop_duplicates()

days_advisory_slow = test[['Key']].drop_duplicates()

for col in thickness_cols:
    belt_section = col.split('_')[-1]
    advisory_section = days_prediction(train,test,section=belt_section,belt_category='slow')
    days_advisory_slow = pd.merge(days_advisory_slow,advisory_section,on=['Key'],how='left')

print(days_advisory_fast)  




#### Function for Tonnage Based Model
def tons_prediction(train,test,section,belt_category):
    """
    

    Parameters
    ----------
    train : TYPE
        DESCRIPTION.
    test : TYPE
        DESCRIPTION.
    section : TYPE
        DESCRIPTION.

    Returns
    -------
    advisory : TYPE
        DESCRIPTION.

    """
    
    reg = LinearRegression()
    train['thrXdeg_rate_ton']=train['Cumsum']*train['deg_rate_ton'+'_'+section]
    train = train.dropna()
    X_train=train[['Cumsum','Belt_Length','daily_throughput','deg_rate_ton'+'_'+section,'thrXdeg_rate_ton','Downtime_1_hr']]
    
    y_train=train['result_min'+'_'+section]
    y_train=np.array(y_train).reshape(-1, 1)
    
    reg.fit(X_train, y_train)
    
    c = reg.intercept_[0]
    m1 = reg.coef_[0][0]
    m2 = reg.coef_[0][1]
    m3 = reg.coef_[0][2]
    m4 = reg.coef_[0][3]
    m5 = reg.coef_[0][4]
    m6 = reg.coef_[0][5]
    
    coef_df = pd.DataFrame({'c' : [c], 'm1' : [m1], 'm2' :  [m2], 'm3' : [m3], 'm4' : [m4], 'm5' : [m5], 'm6' : [m6]})
    print(coef_df)
    
    model_name = 'tons_model_' + belt_category + '_' + section + '.pkl'
    print(model_name)
    # model_path = 'Models/Time_Based/'
    joblib.dump(reg, filename=output_folder + '/' + model_name)
    print(model_name, 'saved as pickle')
    advisory = pd.DataFrame()

    advisory = pd.DataFrame()

    for k in test['Key'].unique():
        
        tst = test[test['Key']==k]
        
        deg_rate = tst['deg_rate_ton'+'_'+section].unique()[0]
        
        if math.isnan(deg_rate):
            deg_rate=train['deg_rate_ton'+'_'+section].mean()
            tst['deg_rate_ton'+'_'+section]=deg_rate
        tst['thrXdeg_rate_ton']=tst['Cumsum']*tst['deg_rate_ton'+'_'+section]
        y_belt =tst['Critial Thickness'].unique()[0]


        

        end_thickness = tst.iloc[-1]['result_min'+'_'+section]
        out=(y_belt-end_thickness)/(m1+(m5*deg_rate))
        slope = m1+(m5*deg_rate)
        
        if (len(tst)>=4) & (belt_category=='slow'):
        
            # Polyfit for cycle k
            x = tst.Cumsum - tst.Cumsum.min()
            trend = np.polyfit(x,tst['result_min'+'_'+section],1)
            y=tst['result_min'+'_'+section]
            s=trend[0]
            i=trend[1]
        
            #Polyfit for last 5 points
     
            if len(tst[tst.shape[0]-5:]) > 1:
                
                trend_rt = np.polyfit(x[tst.shape[0]-5:],tst[tst.shape[0]-5:]['result_min'+'_'+section],1)
                x=x[tst.shape[0]-5:]
                y=tst[tst.shape[0]-5:]['result_min'+'_'+section]
            else:
                trend_rt = np.polyfit(x,tst['result_min'+'_'+section],1)
            s_rt=trend_rt[0]
            i_rt=trend_rt[1]
            
            out1 = (y_belt-end_thickness)/s
            
            out1 = (y_belt-end_thickness)/s
            out1 = np.where(out1<0,9999*10**6,out1)
            out2 = (y_belt-end_thickness)/s_rt
            out2 = np.where(out2<0,9999*10**6,out2)
            out = np.where(out1<out2,out1,out2)
            slope = np.where(out1<out2,s,s_rt)

        
        d = {'Key':[k],'Tons to Replace'+'_'+section:out,'mm_per_ton'+'_'+section:slope}
        df = pd.DataFrame(data=d)
        advisory=advisory.append(df)
    return advisory



#### Tons training - Fast Wear Belts
test=pd.DataFrame()
d1=belt_wear_fast.groupby('areaName')
for arnm in belt_wear_fast['areaName'].unique():
    print(arnm)
    dtemp=d1.get_group(arnm)
    tr=pd.DataFrame()
    tt=pd.DataFrame()
    last_key = dtemp.iloc[-1]['key']
    if ((dtemp.iloc[-1]['averageResultDifference']!=0) | (len(dtemp[dtemp['key']==last_key])==1)):
        key=dtemp.iloc[-1]['key']
        tr=dtemp[dtemp['key']!=key]
        tt=dtemp[dtemp['key']==key]
    else:
        tr=dtemp 
    test=test.append(tt,ignore_index=True)

train = complete_cycle_fast
train = train.drop_duplicates()
# Last Point Performance
tons_advisory_fast = test[['Key']].drop_duplicates()

for col in thickness_cols:
    belt_section = col.split('_')[-1]
    advisory_section = tons_prediction(train,test,section=belt_section,belt_category='fast')
    tons_advisory_fast = pd.merge(tons_advisory_fast,advisory_section,on=['Key'],how='left')




#### Tons prediction - Slow Wear Blet
test=pd.DataFrame()
d1=belt_wear_slow.groupby('areaName')
for arnm in belt_wear_slow['areaName'].unique():
    print(arnm)
    dtemp=d1.get_group(arnm)
    tr=pd.DataFrame()
    tt=pd.DataFrame()
    last_key = dtemp.iloc[-1]['key']
    if ((dtemp.iloc[-1]['averageResultDifference']!=0) | (len(dtemp[dtemp['key']==last_key])==1)):
        key=dtemp.iloc[-1]['key']
        tr=dtemp[dtemp['key']!=key]
        tt=dtemp[dtemp['key']==key]
    else:
        tr=dtemp 
    test=test.append(tt,ignore_index=True)

train = complete_cycle_slow
train = train.drop_duplicates()
# Last Point Performance
tons_advisory_slow = test[['Key']].drop_duplicates()

for col in thickness_cols:
    belt_section = col.split('_')[-1]
    advisory_section = tons_prediction(train,test,section=belt_section,belt_category='fast')
    tons_advisory_slow = pd.merge(tons_advisory_slow,advisory_section,on=['Key'],how='left')

# Standard Packages
import numpy as np
import pandas as pd
import copy
import joblib
import os
import math
from glob import glob
import openpyxl
import xlrd
import datetime
from datetime import timedelta
from pandas.tseries.offsets import MonthEnd

# Parse Arguments
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--input_data")
parser.add_argument("--manual_inputs")
parser.add_argument("--forecast_date")
parser.add_argument("--output_dir")
args = parser.parse_args()

if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


input_folder = args.input_data

tag_ton_melt = pd.read_csv(input_folder+'/tag_ton_melt.csv')
date_range_df_right_model = pd.read_csv(input_folder+'/date_range_df_right_model.csv')
date_range_df_centre_model = pd.read_csv(input_folder+'/date_range_df_centre_model.csv')
date_range_df_left_model = pd.read_csv(input_folder+'/date_range_df_left_model.csv')
date_range_df_left = pd.read_csv(input_folder+'/date_range_df_left.csv')

args_forecast_date = pd.Timestamp(forecast_date).date()

print("---> Prediction Section Tonnage")
def tons_prediction(test,section = '7',belt_category = 'fast'):
    """
    

    Parameters
    ----------
    test : TYPE
        DESCRIPTION.
    section : TYPE
        DESCRIPTION.

    Returns
    -------
    advisory : TYPE
        DESCRIPTION.

    """
    poa = test['part_of_asset'].unique()[0]

    pkl_key = str(poa) + '_' + str(belt_category)

    def get_pkl(pkl_key = pkl_key):
        return{
            'left_fast':'tons_model_fast_1.pkl',
            'left_slow':'tons_model_slow_1.pkl',
            'centre_fast':'tons_model_fast_2.pkl',
            'centre_slow':'tons_model_slow_2.pkl',
            'right_fast':'tons_model_fast_3.pkl',
            'right_slow':'tons_model_slow_3.pkl'
        }.get(pkl_key, lambda: None)

    pkl_path = get_pkl()
    test = test.drop(columns = 'part_of_asset')
    reg = joblib.load(args.manual_inputs+'/B4_Model_Files/'+pkl_path)
    c = reg.intercept_[0]
    m1 = reg.coef_[0][0]
    m2 = reg.coef_[0][1]
    m3 = reg.coef_[0][2]
    m4 = reg.coef_[0][3]
    m5 = reg.coef_[0][4]
    m6 = reg.coef_[0][5]
    
    coef_df = pd.DataFrame({'c' : [c], 'm1' : [m1], 'm2' :  [m2], 'm3' : [m3], 'm4' : [m4], 'm5' : [m5], 'm6' : [m6]})
    print(coef_df)
    
    advisory = pd.DataFrame()

    for k in test['Key'].unique():
        
        tst = test[test['Key']==k]
        
        deg_rate = tst['deg_rate'+'_'+section + '_ton'].unique()[0]
        y_belt =float(tst['Critial Thickness'].unique()[0])

        end_thickness = tst.iloc[-1]['result_min'+'_'+section]
        out=(y_belt-end_thickness)/(m1+(m5*deg_rate))
        if out<0:
            out = 0
        slope = m1+(m5*deg_rate)
        
        if (len(tst)>=4) & (belt_category=='slow'):
        
            # Polyfit for cycle k
            x = tst.Cumsum - tst.Cumsum.min()
            trend = np.polyfit(x,tst['result_min'+'_'+section],1)
            y=tst['result_min'+'_'+section]
            s=trend[0]
            i=trend[1]
        
            #Polyfit for last 30 points
            n = 30
            if len(tst[tst.shape[0]-n:]) > 1:
                
                trend_rt = np.polyfit(x[tst.shape[0]-n:],tst[tst.shape[0]-n:]['result_min'+'_'+section],1)
                x=x[tst.shape[0]-n:]
                y=tst[tst.shape[0]-n:]['result_min'+'_'+section]
            else:
                trend_rt = np.polyfit(x,tst['result_min'+'_'+section],1)
            s_rt=trend_rt[0]
            i_rt=trend_rt[1]
            
            out1 = (y_belt-end_thickness)/s
            
            out1 = (y_belt-end_thickness)/s
            out1 = np.where(out1<0,9999*10**6,out1)
            out2 = (y_belt-end_thickness)/s_rt
            out2 = np.where(out2<0,9999*10**6,out2)
            out = np.where(out1<out2,out1,out2)
            if out<0:
                out = 0
            slope = np.where(out1<out2,s,s_rt)

        
        d = {'Key':[k],'Tons to Replace'+'_'+section:out,'mm_per_ton'+'_'+section:slope}
        df = pd.DataFrame(data=d)
        advisory=advisory.append(df)
        
    return advisory



rt_pred_fast_ton = tons_prediction(date_range_df_right_model)



rt_pred_slow_ton = tons_prediction(date_range_df_right_model, belt_category='slow')



ct_pred_fast_ton = tons_prediction(date_range_df_centre_model)



ct_pred_slow_ton = tons_prediction(date_range_df_centre_model, belt_category='slow')



lt_pred_fast_ton = tons_prediction(date_range_df_left_model)



lt_pred_slow_ton = tons_prediction(date_range_df_left_model, belt_category='slow')


tag_ton_melt_planned = copy.deepcopy(tag_ton_melt)
tag_ton_melt_planned = tag_ton_melt_planned.sort_values(['Belt', 'Date'])
tag_ton_melt_planned['ton_diff'] = tag_ton_melt_planned.groupby('Belt')['ton'].diff()
tag_ton_melt_planned['ton_diff'] = tag_ton_melt_planned['ton_diff'].fillna(tag_ton_melt_planned['ton'])
tag_ton_melt_planned['ton'] = tag_ton_melt_planned['ton_diff']
tag_ton_melt_planned.drop(columns='ton_diff', inplace=True)


tag_ton_melt_planned.groupby('Belt')['Date'].min().max()#.to_dict()

### Calculating ratio from Tonnage data
tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'], format = '%Y-%m-%d')
print(tag_ton_melt.columns)

ratio_dict = {}
for i in tag_ton_melt['Belt'].unique():

    temp_df = tag_ton_melt[tag_ton_melt['Belt'] ==i]

    temp_max_date = temp_df['Date'].max()
    temp_max_ton = list(temp_df[temp_df['Date'] == temp_max_date]['ton'])[0]
    
    temp_cutoff_date = temp_max_date - timedelta(days = 29)
    temp_cutoff_ton = list(temp_df[temp_df['Date'] == temp_cutoff_date]['ton'])[0]
    
    tonn_30_days = temp_max_ton - temp_cutoff_ton
    ratio_dict[i] = tonn_30_days

ratio_dict = {k:v/ratio_dict.get('CV0622') for k,v in ratio_dict.items()}

### Preparing planned data
def planned_data_belt():
    
    ## Importing, cleaning and converting to daily level - Forward Mine Plan 2022, 2023 
    fmp_files = []
    for root, dirs, files in os.walk(args.manual_inputs+'/Forward_Mine_Plan'):
        for name in files:
            fmp_files.append(os.path.join(root, name))

    year_list = []
    planned_data = pd.DataFrame()
    for i in fmp_files:
        dates = pd.read_excel(i, engine='openpyxl', skiprows=5, nrows=1)        ## Row conatins dates
        dates = dates.iloc[:, 5:17]
        dates = dates.loc[0, :].values.tolist()
        dates = pd.to_datetime(dates, format='%Y-%m-%d').to_list()

        values = pd.read_excel(i, engine='openpyxl', skiprows=84, nrows=1)       ## Row conatins values
        values = values.iloc[:, 5:17]
        values = values.loc[0, :].values.tolist()
        values = [a.replace(',', '') if "," in str(a) else a for a in values]
        
        temp_df = pd.DataFrame()
        temp_df['Date'] = dates
        # temp_df['Date'] = pd.to_datetime(temp_df['Date'], format = '%b-%y')
        temp_df['ton'] = values
        temp_df['ton'] = temp_df['ton'].astype(float)

        temp_df['end_date'] = pd.to_datetime(temp_df['Date'], format="%Y%m") + MonthEnd(0)
        temp_df['ton'] = temp_df['ton'].astype(float) * 1000
        temp_df['daily_ton'] = temp_df['ton']/temp_df['end_date'].dt.day

        
        temp_year = list(temp_df['Date'].dt.year.unique())[0]
        # base_data = temp_df

        all_dates_df = pd.DataFrame(pd.date_range(start=str(temp_year)+'-01-01', end=str(temp_year)+'-12-31'), columns = ['Date'])

        temp_df = pd.merge(all_dates_df,
                            temp_df[['Date', 'daily_ton']],
                            on = ['Date'],
                            how = 'left')

        temp_df['daily_ton'] = temp_df['daily_ton'].ffill()                     
        planned_data = pd.concat([planned_data, temp_df], ignore_index=True)    

    planned_data = planned_data.sort_values(['Date']).reset_index(drop=True) 
    
    max_cur_yr = planned_data['Date'].dt.year.max()
    final_yr = planned_data['Date'].dt.year.max()+4

    base_data = planned_data[planned_data['Date'].dt.year == max_cur_yr]
    base_data['grp_col'] = base_data.groupby(base_data['Date'].dt.month)['Date'].transform('min')
    base_data = base_data.reset_index(drop=True)
    base_data = base_data.groupby([base_data['grp_col']], as_index=False).agg({'daily_ton' : 'sum'})
    base_data.rename(columns = {'grp_col' : 'Date', 'daily_ton' : 'ton'}, inplace=True)

    for i in list(range(max_cur_yr+1, final_yr+1)):

        temp_fwd_plan = pd.DataFrame(pd.date_range(start=str(i) + '-01-01', end=str(i) + '-12-31'), columns = ['Date'])
        temp_fwd_plan = pd.merge(temp_fwd_plan,
                                base_data[['Date', 'ton']],
                                left_on = [temp_fwd_plan['Date'].dt.month, temp_fwd_plan['Date'].dt.day],
                                right_on = [base_data['Date'].dt.month, base_data['Date'].dt.day],
                                how = 'left')
                                    
        temp_fwd_plan = temp_fwd_plan[['Date_x', 'ton']]
        temp_fwd_plan.rename(columns = {'Date_x' : 'Date'}, inplace=True)
        temp_fwd_plan['end_date'] = pd.to_datetime(temp_fwd_plan['Date'], format="%Y%m") + MonthEnd(0)
        temp_fwd_plan['ton'] = temp_fwd_plan['ton'].ffill()
        temp_fwd_plan['daily_ton'] = temp_fwd_plan['ton']/temp_fwd_plan['end_date'].dt.day
        temp_fwd_plan = temp_fwd_plan[['Date', 'daily_ton']]
        planned_data = pd.concat([planned_data, temp_fwd_plan], ignore_index=True)

    planned_data.rename(columns = {'Date' : 'Date',
                                    'daily_ton' : 'Tonnage'}, inplace=True)

    planned_data_final = pd.DataFrame()
    for i in ratio_dict.keys():

        temp_df = copy.deepcopy(planned_data)
        temp_df['Belt'] = i
        rel_ratio = ratio_dict.get(i)
        temp_df['Tonnage'] = temp_df['Tonnage']*rel_ratio
        planned_data_final = pd.concat([planned_data_final, temp_df], ignore_index=True)
    planned_data_final = planned_data_final.sort_values(['Belt', 'Date'])
    return planned_data_final                                  


pdlist_fast_ton = [lt_pred_fast_ton, ct_pred_fast_ton.drop(columns=['Key']), rt_pred_fast_ton.drop(columns=['Key'])]
concat_pred_df_fast_ton = pd.concat((pdlist_fast_ton), axis=1)#.min(axis=1)


pdlist_slow_ton = [lt_pred_slow_ton, ct_pred_slow_ton.drop(columns=['Key']), rt_pred_slow_ton.drop(columns=['Key'])]
concat_pred_df_slow_ton = pd.concat((pdlist_slow_ton), axis=1)#.min(axis=1)

# Prediction using planned data
def advisory_tonnage(df = rt_pred_fast_ton):
    # Planned Tonnage Data

    tons_advisory = copy.deepcopy(df)
    tons_advisory['Belt'] = tons_advisory['Key'].apply(lambda x: x.split('_')[0])
    date_range_df_left_model_dt = copy.deepcopy(date_range_df_left_model)
    date_range_df_left_model_dt['date_range'] = date_range_df_left.reset_index(drop=True)['date_range'].values
    dt_rg = date_range_df_left_model_dt.pop('date_range')
    date_range_df_left_model_dt.insert(0, 'date_range', dt_rg)
    last_date = date_range_df_left_model_dt.groupby('Key').agg({'date_range':'last'})
    tons_advisory = pd.merge(tons_advisory,last_date,on='Key',how='left')
    tons_advisory = tons_advisory.rename(columns={'date_range':'test_date_utc'})
    planned_tons=planned_data_belt()

    planned_tons=pd.merge(planned_tons,tons_advisory[['Belt','Key']],on=['Belt'],how='left')
    planned_tons['planned_tons']=planned_tons['Tonnage']


    tons_advisory['date_to_critical_thickness']=np.nan
    tons_advisory = tons_advisory.rename(columns = {'Tons to Replace_7':'tons_to_replace'})

    ## Scenario Planning
    sprint1 = 21            
    sf1 = 1.3                       

    sprint2 = 42            
    sf2 = 1.3                   
    new_tons_to_replace = []
    for i in tons_advisory['Key'].unique():
        current_date = tons_advisory[tons_advisory['Key']==i]['test_date_utc'].values
        asset_id = i.split("_")[0]
        temp_tag_ton_melt_df = tag_ton_melt[tag_ton_melt['Belt'] == asset_id]
        tons_remaining = tons_advisory[tons_advisory['Key']==i]['tons_to_replace'].values[0]
        last_test_date = pd.Timestamp(tons_advisory[tons_advisory['Key'] == i]['test_date_utc'].max()).date()
        print(' ======> HERE! <======')
        print('tons_remaining: {}'.format(tons_remaining))
        print('last_test_date: {}'.format(last_test_date))
        print('last_test_date type: {}'.format(type(last_test_date)))
        print('last_test_date type: {}'.format(type(args_forecast_date)))
        print(temp_tag_ton_melt_df.info())
        print('temp_tag_ton_melt shape: {}'.format(temp_tag_ton_melt_df.shape))
        print('temp_tag_ton_melt columns: {}'.format(temp_tag_ton_melt_df.columns))

        if (last_test_date < args_forecast_date): 
            print('-----> last_test_date < args_forecast_date <-----')                                 
            last_recorded_cumul_tonnage = temp_tag_ton_melt_df['ton'].max()  
            print('last_recorded_cumul_tonnage: {}'.format(last_recorded_cumul_tonnage))        
            last_test_date_tonnage = temp_tag_ton_melt_df[temp_tag_ton_melt_df['Date'] == pd.to_datetime(last_test_date)]['ton'].unique()[0] 
            print('last_test_date_tonnage: {}'.format(last_test_date_tonnage)) 
            print((last_recorded_cumul_tonnage - last_test_date_tonnage))
            tons_remaining = tons_remaining - (last_recorded_cumul_tonnage - last_test_date_tonnage)
            print('tons_remaining: {}'.format(tons_remaining)) 

        new_tons_to_replace.append(tons_remaining)
        print('new_tons_to_replace: {}'.format(new_tons_to_replace))

        planned_tons_i = planned_tons[planned_tons['Key']==i]
        # planned_tons_i = planned_tons_i[planned_tons_i['Date']>=current_date[0]]
        planned_tons_i = planned_tons_i[planned_tons_i['Date']>(tag_ton_melt[tag_ton_melt['Belt'] == i.split('_')[0]]['Date'].max())]  #nl
        planned_tons_i['rank']=1
        planned_tons_i['days']=planned_tons_i['rank'].cumsum()
        
        # planned_tons_i['planned_tons'] = planned_tons_i['planned_tons']
        planned_tons_i['planned_tons_scn1'] = np.where(planned_tons_i['days'] <= sprint1, planned_tons_i['planned_tons'] * sf1, planned_tons_i['planned_tons'])   #nl
        planned_tons_i['planned_tons_scn2'] = np.where(planned_tons_i['days'] <= sprint2, planned_tons_i['planned_tons'] * sf2, planned_tons_i['planned_tons'])     #nl

        # new sec
        planned_tons_i['total_planned_tons']=planned_tons_i['planned_tons'].cumsum()
        planned_tons_i['total_planned_tons_scn1']=planned_tons_i['planned_tons_scn1'].cumsum()      #nl
        planned_tons_i['total_planned_tons_scn2']=planned_tons_i['planned_tons_scn2'].cumsum()      #nl
        # print('tons_remaining: {}'.format(tons_remaining))
        planned_tons_i_norm = planned_tons_i[planned_tons_i['total_planned_tons']<=tons_remaining]

        if len(planned_tons_i_norm)>0:
            date_to_critical_thickness = planned_tons_i_norm['Date'].max()
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness']]=date_to_critical_thickness
        else:
            # continue
            date_to_critical_thickness = args_forecast_date
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness']]=date_to_critical_thickness
       
        planned_tons_i_scn1 = planned_tons_i[planned_tons_i['total_planned_tons_scn1']<=tons_remaining]
        print(' ======> HERE! <======')
        print('tons_remaining: {}'.format(tons_remaining))
        print('planned_tons_i_scn1 columns: {}'.format(planned_tons_i_scn1.columns))
        print('planned_tons_i_scn1 shape: {}'.format(planned_tons_i_scn1.shape))

        
        if len(planned_tons_i_scn1)>0:
            date_to_critical_thickness_scn1 = planned_tons_i_scn1['Date'].max()
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness_scn1']]=date_to_critical_thickness_scn1
            
        else:
            # continue
            date_to_critical_thickness_scn1 = args_forecast_date
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness_scn1']]=date_to_critical_thickness_scn1


        planned_tons_i_scn2 = planned_tons_i[planned_tons_i['total_planned_tons_scn2']<=tons_remaining]
        if len(planned_tons_i_scn2)>0:
            date_to_critical_thickness_scn2 = planned_tons_i_scn2['Date'].max()
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness_scn2']]=date_to_critical_thickness_scn2
        else:
            # continue
            date_to_critical_thickness_scn2 = args_forecast_date
            tons_advisory.loc[tons_advisory['Key']==i,['date_to_critical_thickness_scn2']]=date_to_critical_thickness_scn2

        
    tons_advisory['tons_to_replace'] = new_tons_to_replace
    
    tons_advisory['date_to_critical_thickness']=pd.to_datetime(tons_advisory['date_to_critical_thickness'])
    tons_advisory['test_date_utc'] = pd.to_datetime(tons_advisory['test_date_utc'])
    tons_advisory['days_to_replace']= tons_advisory['date_to_critical_thickness']- tons_advisory['test_date_utc']
    # display(tons_advisory)

    tons_advisory['date_to_critical_thickness_scn1']=pd.to_datetime(tons_advisory['date_to_critical_thickness_scn1'])
    tons_advisory['days_to_replace_scn1']= tons_advisory['date_to_critical_thickness_scn1']- tons_advisory['test_date_utc']

    tons_advisory['date_to_critical_thickness_scn2']=pd.to_datetime(tons_advisory['date_to_critical_thickness_scn2'])
    tons_advisory['days_to_replace_scn2']= tons_advisory['date_to_critical_thickness_scn2']- tons_advisory['test_date_utc']

    ## new sec end
    return tons_advisory

## start copy
tons_advisory_right = advisory_tonnage()
tons_advisory_right['days_to_replace'] = tons_advisory_right['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right['days_to_replace_scn1'] = tons_advisory_right['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right['days_to_replace_scn2'] = tons_advisory_right['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right.columns = [x+'_rt' for x in tons_advisory_right.columns]


tons_advisory_centre = advisory_tonnage(ct_pred_fast_ton)
tons_advisory_centre['days_to_replace'] = tons_advisory_centre['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre['days_to_replace_scn1'] = tons_advisory_centre['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre['days_to_replace_scn2'] = tons_advisory_centre['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre.columns = [x+'_ct' for x in tons_advisory_centre.columns]


tons_advisory_left = advisory_tonnage(lt_pred_fast_ton)
tons_advisory_left['days_to_replace'] = tons_advisory_left['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left['days_to_replace_scn1'] = tons_advisory_left['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left['days_to_replace_scn2'] = tons_advisory_left['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left.columns = [x+'_lt' for x in tons_advisory_left.columns]



pd_list_tons_advisory = [tons_advisory_left, tons_advisory_centre, tons_advisory_right]
concat_pd_list_tons = pd.concat(pd_list_tons_advisory, axis=1)#.min(axis=1)
concat_pd_list_tons['days_to_replace_final'] = concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').min(axis=1)  ### Change regex so not to include _scn1 and _scn2

concat_pd_list_tons['days_to_replace_final_idx'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx'] == 'nan' else x['mm_per_ton_7_' + str(x['days_to_replace_final_idx'])], axis=1)
concat_pd_list_tons = concat_pd_list_tons.rename(columns = {'days_to_replace_final_idx':'mm_per_ton_final_fast'})

concat_pd_list_tons['tons_to_replace_final_idx'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['tons_to_replace_final_idx'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['tons_to_replace_final_idx'] == 'nan' else x['tons_to_replace_' + str(x['tons_to_replace_final_idx'])], axis=1)

concat_pd_list_tons['days_to_replace_final_idx_scn1'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?=.*_scn1)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx_scn1'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx_scn1'] == 'nan' else x['days_to_replace_scn1_' + str(x['days_to_replace_final_idx_scn1'])], axis=1)

concat_pd_list_tons['days_to_replace_final_idx_scn2'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?=.*_scn2)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx_scn2'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx_scn2'] == 'nan' else x['days_to_replace_scn2_' + str(x['days_to_replace_final_idx_scn2'])], axis=1)

concat_pd_list_tons = concat_pd_list_tons.rename(columns = {
                                                            'Key_rt':'Key', 
                                                            'tons_to_replace_final_idx':'tons_to_replace_final_fast', 
                                                            'days_to_replace_final':'days_to_replace_final_fast', 
                                                            'days_to_replace_final_idx_scn1' : 'days_to_replace_final_fast_scn1', 
                                                            'days_to_replace_final_idx_scn2' : 'days_to_replace_final_fast_scn2'
                                                            })
concat_pd_list_tons_fast = concat_pd_list_tons[['Key', 'days_to_replace_final_fast', 'mm_per_ton_final_fast', 
                                                'tons_to_replace_final_fast', 'days_to_replace_final_fast_scn1', 'days_to_replace_final_fast_scn2']]


tons_advisory_right = advisory_tonnage(rt_pred_slow_ton)
tons_advisory_right['days_to_replace'] = tons_advisory_right['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right['days_to_replace_scn1'] = tons_advisory_right['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right['days_to_replace_scn2'] = tons_advisory_right['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_right.columns = [x+'_rt' for x in tons_advisory_right.columns]


tons_advisory_centre = advisory_tonnage(ct_pred_slow_ton)
tons_advisory_centre['days_to_replace'] = tons_advisory_centre['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre['days_to_replace_scn1'] = tons_advisory_centre['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre['days_to_replace_scn2'] = tons_advisory_centre['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_centre.columns = [x+'_ct' for x in tons_advisory_centre.columns]


tons_advisory_left = advisory_tonnage(lt_pred_slow_ton)
tons_advisory_left['days_to_replace'] = tons_advisory_left['days_to_replace'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left['days_to_replace_scn1'] = tons_advisory_left['days_to_replace_scn1'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left['days_to_replace_scn2'] = tons_advisory_left['days_to_replace_scn2'].mask(lambda x: x.dt.days < 0, np.nan)
tons_advisory_left.columns = [x+'_lt' for x in tons_advisory_left.columns]


pd_list_tons_advisory = [tons_advisory_left, tons_advisory_centre, tons_advisory_right]
concat_pd_list_tons = pd.concat(pd_list_tons_advisory, axis=1)#.min(axis=1)
concat_pd_list_tons['days_to_replace_final'] = concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').min(axis=1)

concat_pd_list_tons['days_to_replace_final_idx'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx'] == 'nan' else x['mm_per_ton_7_' + str(x['days_to_replace_final_idx'])], axis=1)
concat_pd_list_tons = concat_pd_list_tons.rename(columns = {'days_to_replace_final_idx':'mm_per_ton_final_slow'})

concat_pd_list_tons['tons_to_replace_final'] = concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').min(axis=1)

concat_pd_list_tons['tons_to_replace_final_idx'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?!.*_scn)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['tons_to_replace_final_idx'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['tons_to_replace_final_idx'] == 'nan' else x['tons_to_replace_' + str(x['tons_to_replace_final_idx'])], axis=1)

concat_pd_list_tons['days_to_replace_final_idx_scn1'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?=.*_scn1)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx_scn1'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx_scn1'] == 'nan' else x['days_to_replace_scn1_' + str(x['days_to_replace_final_idx_scn1'])], axis=1)

concat_pd_list_tons['days_to_replace_final_idx_scn2'] = (concat_pd_list_tons.filter(regex='(?=.*days_to_replace)(?=.*_scn2)').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pd_list_tons['days_to_replace_final_idx_scn2'] = concat_pd_list_tons.apply(lambda x: 'nan' if x['days_to_replace_final_idx_scn2'] == 'nan' else x['days_to_replace_scn2_' + str(x['days_to_replace_final_idx_scn2'])], axis=1)

concat_pd_list_tons = concat_pd_list_tons.rename(columns = {
                                                            'Key_rt':'Key', 
                                                            'tons_to_replace_final_idx':'tons_to_replace_final_slow', 
                                                            'days_to_replace_final':'days_to_replace_final_slow', 
                                                            'days_to_replace_final_idx_scn1' : 'days_to_replace_final_slow_scn1', 
                                                            'days_to_replace_final_idx_scn2' : 'days_to_replace_final_slow_scn2'
                                                            })
concat_pd_list_tons_slow = concat_pd_list_tons[['Key', 'days_to_replace_final_slow', 'mm_per_ton_final_slow', 
                                                'tons_to_replace_final_slow', 'days_to_replace_final_slow_scn1', 'days_to_replace_final_slow_scn2']]


concat_pd_list_tons_final = pd.merge(concat_pd_list_tons_fast, concat_pd_list_tons_slow, on= 'Key', how='left')
concat_pd_list_tons_final['areaName'] = concat_pd_list_tons_final['Key'].apply(lambda x: x.split('_')[0])

belt_tech_specs = pd.read_csv(args.manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_length_specs = belt_tech_specs.loc[lambda x: x.Feature == 'Belt Length'].reset_index(drop=True)
belt_length_specs = belt_length_specs.pivot(index='Asset_ID', columns='Feature', values='Value').reset_index()
belt_length_specs = belt_length_specs.rename(columns = {'Asset_ID':'areaName'})
belt_length_specs['areaName'] = belt_length_specs['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
belt_length_specs['Belt Length'] = pd.to_numeric(belt_length_specs['Belt Length'])
belt_length_specs['fast_slow_flag'] = belt_length_specs['Belt Length'].apply(lambda x: 'Fast' if x < belt_length_specs['Belt Length'].max() * 0.1 else 'Slow')

concat_pd_list_tons_final = concat_pd_list_tons_final.merge(belt_length_specs[['areaName', 'fast_slow_flag']], on = ['areaName'], how='left')

concat_pd_list_tons_final['days_to_replace_ton'] = np.where(concat_pd_list_tons_final['fast_slow_flag'] == 'Fast', concat_pd_list_tons_final['days_to_replace_final_fast'], concat_pd_list_tons_final['days_to_replace_final_slow'])
concat_pd_list_tons_final['mm_per_Mton'] = np.where(concat_pd_list_tons_final['fast_slow_flag'] == 'Fast', concat_pd_list_tons_final['mm_per_ton_final_fast'], concat_pd_list_tons_final['mm_per_ton_final_slow']) * 1000000
concat_pd_list_tons_final['tons_to_replace(MT)'] = np.where(concat_pd_list_tons_final['fast_slow_flag'] == 'Fast', concat_pd_list_tons_final['tons_to_replace_final_fast'], concat_pd_list_tons_final['tons_to_replace_final_slow']).astype(float) / 1000000
concat_pd_list_tons_final['tons_to_replace(MT)'] = np.where(concat_pd_list_tons_final['tons_to_replace(MT)'] <0, 0, concat_pd_list_tons_final['tons_to_replace(MT)'])
concat_pd_list_tons_final['days_to_replace_ton_scn1'] = np.where(concat_pd_list_tons_final['fast_slow_flag'] == 'Fast', concat_pd_list_tons_final['days_to_replace_final_fast_scn1'], concat_pd_list_tons_final['days_to_replace_final_slow_scn1'])
concat_pd_list_tons_final['days_to_replace_ton_scn2'] = np.where(concat_pd_list_tons_final['fast_slow_flag'] == 'Fast', concat_pd_list_tons_final['days_to_replace_final_fast_scn2'], concat_pd_list_tons_final['days_to_replace_final_slow_scn2'])
concat_pd_list_tons_final = concat_pd_list_tons_final[['Key', 'days_to_replace_ton', 'mm_per_Mton', 'tons_to_replace(MT)', 'days_to_replace_ton_scn1', 'days_to_replace_ton_scn2']]

print('---> Tonnage model complete.')
print(concat_pd_list_tons_final)


## Export to output folder

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

concat_pd_list_tons_final.to_csv(output_folder+'/belt_tonnage_model_'+forecast_date+'.csv', index = False)
planned_tons_chk_belt=planned_data_belt()
planned_tons_chk_belt.to_csv(output_folder+'/planned_tons_chk_'+forecast_date+'.csv', index = False)

print("Belt Tonnage Script Ran Successfully!")
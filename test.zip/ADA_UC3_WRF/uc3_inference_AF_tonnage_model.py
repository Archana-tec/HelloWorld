import pandas as pd
import numpy as np
import os
from glob import glob
import openpyxl
import copy
import xlrd
import datetime
from datetime import timedelta
from pandas.tseries.offsets import MonthEnd
from sklearn.linear_model import LinearRegression
import math

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--input_data")
parser.add_argument("--manual_inputs")
parser.add_argument("--forecast_date")
parser.add_argument("--output_dir")
args = parser.parse_args()

if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


args_forecast_date = pd.Timestamp(forecast_date).date()

# Import outputs of data prep step
try:
    pds_chain_df = pd.read_csv(args.input_data+'/pds_chain_df.csv')
    pds_chain_df['test_date'] = pd.to_datetime(pds_chain_df['test_date'])
except:
    pass
pds_toppan_df = pd.read_csv(args.input_data+'/pds_toppan_df.csv')

pds_toppan_df['test_date'] = pd.to_datetime(pds_toppan_df['test_date'])

# Import forward looking tonnage plan

# Import PoC Degradation rates based on Cape Lambert B assets
df_poc_deg_rates = pd.read_csv(args.manual_inputs+'/CLB_Model_Files/CLB_AF_deg_rates.csv')

## Scenario Planning
# Scenario 1 - 3 weeks (21 days) of 30% extra tonnage
sprint1 = 21
sf1 = 1.3
# Scenario 2 - 6 weeks (21 days) of 30% extra tonnage
sprint2 = 42
sf2 = 1.3

# Create output directory
output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)
tag_ton_melt = pd.read_csv(args.input_data+'/tag_ton_melt.csv')
tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'], format = '%Y-%m-%d')
print(tag_ton_melt.columns)

# Calculating ratio dictionary
ratio_dict = {}
for i in tag_ton_melt['Belt'].unique():

    temp_df = tag_ton_melt[tag_ton_melt['Belt'] ==i]

    temp_max_date = temp_df['Date'].max()
    temp_max_ton = list(temp_df[temp_df['Date'] == temp_max_date]['ton'])[0]
    
    temp_cutoff_date = temp_max_date - timedelta(days = 29)
    temp_cutoff_ton = list(temp_df[temp_df['Date'] == temp_cutoff_date]['ton'])[0]
    
    tonn_30_days = temp_max_ton - temp_cutoff_ton
    ratio_dict[i] = tonn_30_days

ratio_dict = {k:v/ratio_dict.get('CV0622') for k,v in ratio_dict.items()}

### Preparing planned data
def planned_data_af():
    
    ## Importing, cleaning and converting to daily level - Forward Mine Plan 2022, 2023 
    fmp_files = []
    for root, dirs, files in os.walk(args.manual_inputs+'/Forward_Mine_Plan'):
        for name in files:
            fmp_files.append(os.path.join(root, name))

    year_list = []
    planned_data = pd.DataFrame()
    for i in fmp_files:
        dates = pd.read_excel(i, engine='openpyxl', skiprows=5, nrows=1)        ## Row conatins dates
        dates = dates.iloc[:, 5:17]
        dates = dates.loc[0, :].values.tolist()
        dates = pd.to_datetime(dates, format='%Y-%m-%d').to_list()

        values = pd.read_excel(i, engine='openpyxl', skiprows=84, nrows=1)       ## Row conatins values
        values = values.iloc[:, 5:17]
        values = values.loc[0, :].values.tolist()
        values = [a.replace(',', '') if "," in str(a) else a for a in values]
        
        temp_df = pd.DataFrame()
        temp_df['Date'] = dates
        temp_df['ton'] = values
        temp_df['ton'] = temp_df['ton'].astype(float)

        temp_df['end_date'] = pd.to_datetime(temp_df['Date'], format="%Y%m") + MonthEnd(0)
        temp_df['ton'] = temp_df['ton'].astype(float) * 1000
        temp_df['daily_ton'] = temp_df['ton']/temp_df['end_date'].dt.day

        
        temp_year = list(temp_df['Date'].dt.year.unique())[0]

        all_dates_df = pd.DataFrame(pd.date_range(start=str(temp_year)+'-01-01', end=str(temp_year)+'-12-31'), columns = ['Date'])

        temp_df = pd.merge(all_dates_df,
                            temp_df[['Date', 'daily_ton']],
                            on = ['Date'],
                            how = 'left')

        temp_df['daily_ton'] = temp_df['daily_ton'].ffill()                     
        planned_data = pd.concat([planned_data, temp_df], ignore_index=True)    

    planned_data = planned_data.sort_values(['Date']).reset_index(drop=True) 
    
    max_cur_yr = planned_data['Date'].dt.year.max()
    final_yr = planned_data['Date'].dt.year.max()+4

    base_data = planned_data[planned_data['Date'].dt.year == max_cur_yr]
    base_data['grp_col'] = base_data.groupby(base_data['Date'].dt.month)['Date'].transform('min')
    base_data = base_data.reset_index(drop=True)
    base_data = base_data.groupby([base_data['grp_col']], as_index=False).agg({'daily_ton' : 'sum'})
    base_data.rename(columns = {'grp_col' : 'Date', 'daily_ton' : 'ton'}, inplace=True)

    for i in list(range(max_cur_yr+1, final_yr+1)):

        temp_fwd_plan = pd.DataFrame(pd.date_range(start=str(i) + '-01-01', end=str(i) + '-12-31'), columns = ['Date'])
        temp_fwd_plan = pd.merge(temp_fwd_plan,
                                base_data[['Date', 'ton']],
                                left_on = [temp_fwd_plan['Date'].dt.month, temp_fwd_plan['Date'].dt.day],
                                right_on = [base_data['Date'].dt.month, base_data['Date'].dt.day],
                                how = 'left')
                                    
        temp_fwd_plan = temp_fwd_plan[['Date_x', 'ton']]
        temp_fwd_plan.rename(columns = {'Date_x' : 'Date'}, inplace=True)
        temp_fwd_plan['end_date'] = pd.to_datetime(temp_fwd_plan['Date'], format="%Y%m") + MonthEnd(0)
        temp_fwd_plan['ton'] = temp_fwd_plan['ton'].ffill()
        temp_fwd_plan['daily_ton'] = temp_fwd_plan['ton']/temp_fwd_plan['end_date'].dt.day
        temp_fwd_plan = temp_fwd_plan[['Date', 'daily_ton']]
        planned_data = pd.concat([planned_data, temp_fwd_plan], ignore_index=True)

    planned_data.rename(columns = {'Date' : 'Date',
                                    'daily_ton' : 'Tonnage'}, inplace=True)

    planned_data_final = pd.DataFrame()
    for i in ratio_dict.keys():

        temp_df = copy.deepcopy(planned_data)
        temp_df['Belt'] = i
        rel_ratio = ratio_dict.get(i)
        temp_df['Tonnage'] = temp_df['Tonnage']*rel_ratio
        planned_data_final = pd.concat([planned_data_final, temp_df], ignore_index=True)
    planned_data_final = planned_data_final.sort_values(['Belt', 'Date'])
    return planned_data_final                                  

planned_data = planned_data_af()    
print('planned_data shape: {}'.format(planned_data.shape))
print(planned_data.head())                           

try:
    try:
        ### Preparation of planned data   
        ### Calculating ratio from Tonnage data
            
            
        ## Function to run tonnage model for chain length
        def tons_prediction_chain(pds_chain_df,planned_data=planned_data):

            '''
            Chain Length Tonnage Model
            '''
            df_time_ch1=pd.DataFrame()
            for Key in pds_chain_df['Key'].unique():
                print(Key)
                asset_id = Key.split("_")[0]
                data_temp=pds_chain_df[pds_chain_df['Key']==Key]
                if len(data_temp)>=2:
                    df_time_ch=pd.DataFrame()
                    X=data_temp.Tonnage.values.reshape(-1,1)
                    y=data_temp.result_min
                    print("before reg")
                    trend=LinearRegression().fit(X,y)
                    print("after reg")
                    delta_var=data_temp['Delta_thick_variation'].max()
                    data_act=data_temp[data_temp['delta_thickness_per_day']!=0]
                    mn=data_act['delta_thickness_per_day'].mean()
                    data_act1=data_temp[data_temp['delta_thickness_per_tonn']!=0]
                    mn_tn=data_act1['delta_thickness_per_tonn'].mean()
                    
                    s=trend.coef_
                    i=trend.intercept_
                    print(trend.coef_,trend.intercept_)
                    final_thk = data_temp['Critial Thickness'].unique()[0]
                    last_test_date = data_temp['test_date'].max()
                    temp_tag_ton_melt_df = tag_ton_melt[tag_ton_melt['Belt'] == asset_id]
                    if s!=0:
                        critial_tonn = (final_thk-i)/s
                        print('here')
                        if (last_test_date < datetime.datetime.today().date()):                                     
                            last_recorded_cumul_tonnage = temp_tag_ton_melt_df['ton'].max()
                            last_test_date_tonnage = temp_tag_ton_melt_df[temp_tag_ton_melt_df['Date'] == last_test_date]['ton'].max()
                            tonn_rem = critial_tonn - (last_recorded_cumul_tonnage - last_test_date_tonnage)     
                            tonn_rem=tonn_rem[0]                                      
                        else:
                            tonn_rem=critial_tonn[0]
                    else:
                        tonn_rem = 999999999
                    
                    if 'AF0101'in Key:
                        k11='AF0101'
                        r = ratio_dict.get(k11)
                    if 'AF0201' in Key:
                        k11='AF0201'
                        r = ratio_dict.get(k11)
                    if 'AF0202' in Key:
                        k11='AF0202'
                        r = ratio_dict.get(k11)
                        
                    last_recorded_cumul_date = tag_ton_melt[tag_ton_melt['Belt'] == asset_id]['Date'].max()
                    temp_planned_df = planned_data[(planned_data['Belt']==asset_id) &
                                                (planned_data['Date']>last_recorded_cumul_date)].reset_index(drop=True)
                    
                    planned_tons_i = copy.deepcopy(temp_planned_df)
                    # pd1['Tonnage']=pd1['Tonnage']*r
                    planned_tons_i = planned_tons_i.sort_values(['Date'])

                    planned_tons_i['Tonnage_cumsum']=planned_tons_i['Tonnage'].cumsum()
                    planned_tons_i['Tonnage_scn1'] = np.where(planned_tons_i.index <= (sprint1-1), planned_tons_i['Tonnage'] * sf1, planned_tons_i['Tonnage'])
                    
                    planned_tons_i['Tonnage_cumsum_scn1'] = planned_tons_i['Tonnage_scn1'].cumsum()
                    print()
                    
                    planned_tons_i['Tonnage_scn2'] = np.where(planned_tons_i.index <= (sprint2-1), planned_tons_i['Tonnage'] * sf2, planned_tons_i['Tonnage'])
                    planned_tons_i['Tonnage_cumsum_scn2'] = planned_tons_i['Tonnage_scn2'].cumsum()
                    if tonn_rem>0:
                        if Key=='AF0201_Chain Length_54610_LHS':
                            planned_tons_i[['Tonnage_cumsum','Date']].to_csv('planned.csv')
                        print(tonn_rem)
                        days_date_norm = planned_tons_i[planned_tons_i['Tonnage_cumsum'].le(tonn_rem)]['Date'].iloc[-1]
                        days_left_norm = pd.to_datetime(days_date_norm) - pd.to_datetime(data_temp['test_date'].max())
                        print(days_date_norm)
                        days_date_scn1 = planned_tons_i[planned_tons_i['Tonnage_cumsum_scn1'].le(tonn_rem)]['Date'].iloc[-1]
                        days_left_scn1 = pd.to_datetime(days_date_scn1) - pd.to_datetime(data_temp['test_date'].max())

                        days_date_scn2 = planned_tons_i[planned_tons_i['Tonnage_cumsum_scn2'].le(tonn_rem)]['Date'].iloc[-1]
                        days_left_scn2 = pd.to_datetime(days_date_scn2) - pd.to_datetime(data_temp['test_date'].max())
                    else:
                        days_left_norm = 0
                        days_left_scn1 = 0
                        days_left_scn2 = 0
                    
                    latest_test_values = data_temp.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                        'result_min' : 'last', 'test_date':'max'})
                    df_time_ch['Key']=[Key]
                    df_time_ch[['areaName', 'wearSurface', 'equipmentID', 'Side']] = df_time_ch['Key'].str.split('_', expand=True)         
                    
                    df_time_ch = pd.merge(df_time_ch,
                                        latest_test_values,
                                        on = ['Key'],
                                        how = 'left')

                    df_time_ch['mm_per_Mton']=np.round(s*10**6,4)                
                    df_time_ch['days_to_replace_ton']=[days_left_norm]          

                    df_time_ch['tons_to_replace'] = tonn_rem/1000000                   

                    df_time_ch['date_to_critical_thickness']=[days_date_norm]
                    df_time_ch['days_to_replace_ton']=[days_left_norm.days]
                    
                    df_time_ch['date_to_critical_thickness_scn1']=[days_date_scn1]
                    df_time_ch['days_to_replace_ton_scn1']=[days_left_scn1.days]
                    
                    df_time_ch['date_to_critical_thickness_scn2']=[days_date_scn2]
                    df_time_ch['days_to_replace_ton_scn2']=[days_left_scn2.days]
                    
                    df_time_ch1=df_time_ch1.append(df_time_ch)
            df_time_ch1=df_time_ch1.sort_values(by='Key')
            
            return df_time_ch1

        chain_df_tons_output = tons_prediction_chain(pds_chain_df, planned_data)
        chain_df_tons_output=chain_df_tons_output.iloc[chain_df_tons_output.reset_index().groupby('areaName')['tons_to_replace'].idxmin()]
        print('Polyfit has been used for Chain Length!!')
    except Exception as error:
        exception_type, exception_object, exception_traceback = sys.exc_info()
        line_number = exception_traceback.tb_lineno
        print("Exception type: ", exception_type)
        print("Exception in try blockLine number: ", line_number)
        chain_df_tons_output = pds_chain_df.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                    'result_min' : 'last', 'test_date':'max'})
        chain_df_tons_output[['areaName', 'wearSurface', 'equipmentID', 'Side']] = chain_df_tons_output['Key'].str.split('_', expand=True)         
        chain_df_tons_output['mm_per_Mton'] = df_poc_deg_rates[df_poc_deg_rates['wearSurface'] == 'Chain Length']['deg_rate_ton'].mean()                                                                                      
        chain_df_tons_output['tons_to_replace'] = (chain_df_tons_output['Critial Thickness'] - chain_df_tons_output['result_min'])*1000000/chain_df_tons_output['mm_per_Mton']
        #print(chain_df_tons_output.head())#[['areaName','tons_to_replace']])
        chain_df_tons_output = chain_df_tons_output.loc[chain_df_tons_output.groupby('areaName')['tons_to_replace'].idxmax()]
        #print(chain_df_tons_output.head())#[['areaName','tons_to_replace']])
        chain_df_tons_output['Key'] = chain_df_tons_output['areaName'] + '_' + chain_df_tons_output['wearSurface']

        ratio_df = pd.DataFrame({'areaName' : k, 'ratio' : v} for k, v in ratio_dict.items())
        chain_df_tons_output = pd.merge(chain_df_tons_output,
                                        ratio_df,
                                        on = ['areaName'],
                                        how = 'left')

                                                
        
        critical_date_list_norm = []
        critical_date_list_scn1 = []
        critical_date_list_scn2 = []
        tons_to_replace_list = []
        chain_df_tons_output.head()
        for i in chain_df_tons_output['areaName'].unique():

            temp_planned_df = copy.deepcopy(planned_data.loc[lambda x: x.Belt==i].reset_index(drop=True))

            max_cur_ton_date = tag_ton_melt[tag_ton_melt['Belt']==i]['Date'].max()            
            temp_planned_df = temp_planned_df[temp_planned_df['Date'] > max_cur_ton_date].reset_index(drop=True)
            
            temp_planned_df['Tonnage_scn1'] = np.where(temp_planned_df.index <= (sprint1-1), temp_planned_df['Tonnage'] * sf1, temp_planned_df['Tonnage'])
            temp_planned_df['Tonnage_scn2'] = np.where(temp_planned_df.index <= (sprint2-1), temp_planned_df['Tonnage'] * sf2, temp_planned_df['Tonnage'])
            
            
            temp_planned_df['prop_cumul_tonnage_norm'] = temp_planned_df['Tonnage'].cumsum()
            temp_planned_df['prop_cumul_tonnage_scn1'] = temp_planned_df['Tonnage_scn1'].cumsum()
            temp_planned_df['prop_cumul_tonnage_scn2'] = temp_planned_df['Tonnage_scn2'].cumsum()

            rel_ton_replace = chain_df_tons_output[chain_df_tons_output['areaName']==i]['tons_to_replace'].values[0]
            latest_ton_value = tag_ton_melt[tag_ton_melt['Belt'] == i]['ton'].max()
            
            last_test_date = chain_df_tons_output[chain_df_tons_output['areaName'] == i]['test_date'].values[0]

            temp_tag_ton_melt_df = tag_ton_melt[tag_ton_melt['Belt'] == i]

            if (pd.to_datetime(last_test_date) < datetime.datetime.today().date()):                          #### args.forecast_date in pipeline  
                        
                last_recorded_cumul_tonnage = temp_tag_ton_melt_df['ton'].max()  
                
                last_test_date_tonnage = temp_tag_ton_melt_df[temp_tag_ton_melt_df['Date'] == last_test_date]['ton'].max()  
                    
                rel_ton_replace = rel_ton_replace - (last_recorded_cumul_tonnage - last_test_date_tonnage) 

            else:            
                rel_ton_replace = rel_ton_replace

            # rel_ton_replace = rel_ton_replace- latest_ton_value
            tons_to_replace_list.append(rel_ton_replace)
            # chain_df_tons_output['tons_to_replace'] = tons_to_replace_list
            rem_df_norm = temp_planned_df[temp_planned_df['prop_cumul_tonnage_norm'] <= rel_ton_replace]
            rem_df_scn1 = temp_planned_df[temp_planned_df['prop_cumul_tonnage_scn1'] <= rel_ton_replace]
            rem_df_scn2 = temp_planned_df[temp_planned_df['prop_cumul_tonnage_scn2'] <= rel_ton_replace]
            
            if not rem_df_norm.empty:
                crtitical_date_norm = rem_df_norm['Date'].iloc[-1]
                critical_date_list_norm.append(crtitical_date_norm)
            else:
                crtitical_date_norm = datetime.datetime.today().date()
                critical_date_list_norm.append(crtitical_date_norm)

            if not rem_df_scn1.empty:
                crtitical_date_scn1 = rem_df_scn1['Date'].iloc[-1]
                critical_date_list_scn1.append(crtitical_date_scn1)
            else:
                crtitical_date_scn1 = datetime.datetime.today().date()
                critical_date_list_scn1.append(crtitical_date_scn1)
            
            if not rem_df_scn2.empty: 
                crtitical_date_scn2 = rem_df_scn2['Date'].iloc[-1]
                critical_date_list_scn2.append(crtitical_date_scn2)
            else:
                crtitical_date_scn2 = datetime.datetime.today().date()
                critical_date_list_scn2.append(crtitical_date_scn2)
        
        
        chain_df_tons_output['date_to_critical_thickness'] = critical_date_list_norm
        chain_df_tons_output['date_to_critical_thickness_scn1'] = critical_date_list_scn1
        chain_df_tons_output['date_to_critical_thickness_scn2'] = critical_date_list_scn2
        chain_df_tons_output['test_date'] = pd.to_datetime(chain_df_tons_output['test_date'])
        chain_df_tons_output['days_to_replace_ton']= chain_df_tons_output['date_to_critical_thickness']- chain_df_tons_output['test_date']
        chain_df_tons_output['tons_to_replace'] = tons_to_replace_list
        chain_df_tons_output['tons_to_replace'] = chain_df_tons_output['tons_to_replace']/1000000
        chain_df_tons_output['tons_to_replace'] = np.where(chain_df_tons_output['tons_to_replace'] <0, 0, chain_df_tons_output['tons_to_replace'])
        
        print('Tons Prediction Chain Length -- PoC deg rates need to be used !!!')
except:
    pass



try:
    def tons_prediction_toppan(pds_toppan_df,planned_data=planned_data):
    
        '''
        Top of Pan Tonnage Model
        '''
        df_time_top1=pd.DataFrame()
        for Key in pds_toppan_df['Key'].unique():

            asset_id = Key.split("_")[0]
            data_temp=pds_toppan_df[pds_toppan_df['Key']==Key]
            
            if len(data_temp)>=2:
                df_time_top=pd.DataFrame()
                x = data_temp.Tonnage                
                trend = np.polyfit(x,data_temp.result_min,1)
                delta_var=data_temp['Delta_thick_variation'].max()
                data_act=data_temp[data_temp['delta_thickness_per_day']!=0]
                mn=data_act['delta_thickness_per_day'].mean()
                data_act1=data_temp[data_temp['delta_thickness_per_tonn']!=0]
                mn_tn=data_act1['delta_thickness_per_tonn'].mean()
                
                s=trend[0]
                i=trend[1]
                
                # mape_sum=0
                for day, thk in zip(x, data_temp.result_min):
                    prediction = s*day+i
                #     mape_sum += abs((thk - prediction)/delta_var)
                # mape = mape_sum / len(data_temp) 
            
                final_thk = data_temp['Critial Thickness'].unique()[0]
                critial_tonn = (final_thk-i)/s    

                last_test_date = data_temp['test_date'].max()
                temp_tag_ton_melt_df = tag_ton_melt[tag_ton_melt['Belt'] == asset_id]
                if (last_test_date < args_forecast_date):                                     
                    last_recorded_cumul_tonnage = temp_tag_ton_melt_df['ton'].max()
                    last_test_date_tonnage = temp_tag_ton_melt_df[temp_tag_ton_melt_df['Date'] == last_test_date]['ton'].max()
                    tonn_rem = critial_tonn - (last_recorded_cumul_tonnage - last_test_date_tonnage)                                           
                else:
                    tonn_rem=critial_tonn   
                print('===> critial_tonn >===: {}' .format(critial_tonn))
                print('===> last_recorded_cumul_tonnage >===: {}' .format(last_recorded_cumul_tonnage))
                print('===> last_test_date_tonnage >===: {}' .format(last_test_date_tonnage))
                print('===> mn_tn >===: {}' .format(mn_tn)) 
                print('===> last_test_date >===: {}' .format(last_test_date))
                print('===> last_test_date type >===: {}' .format(type(last_test_date)))                                    
                if s > 0:
                    tonn_rem = 999999999
                         
                if 'AF0101'in Key:
                    k11='AF0101'
                    r = ratio_dict.get(k11)
                if 'AF0201' in Key:
                    k11='AF0201'
                    r = ratio_dict.get(k11)
                if 'AF0202' in Key:
                    k11='AF0202'
                    r = ratio_dict.get(k11)
                    
                last_recorded_cumul_date = tag_ton_melt[tag_ton_melt['Belt'] == asset_id]['Date'].max()
                temp_planned_df = planned_data[(planned_data['Belt']==asset_id) &
                                            (planned_data['Date']>last_recorded_cumul_date)].reset_index(drop=True)
                    
                planned_tons_i = copy.deepcopy(temp_planned_df)
                # pd1['Tonnage']=pd1['Tonnage']*r
                planned_tons_i = planned_tons_i.sort_values(['Date'])

                planned_tons_i['Tonnage_cumsum']=planned_tons_i['Tonnage'].cumsum()
                
                planned_tons_i['Tonnage_scn1'] = np.where(planned_tons_i.index <= (sprint1-1), planned_tons_i['Tonnage'] * sf1, planned_tons_i['Tonnage'])
                planned_tons_i['Tonnage_cumsum_scn1'] = planned_tons_i['Tonnage_scn1'].cumsum()
                
                planned_tons_i['Tonnage_scn2'] = np.where(planned_tons_i.index <= (sprint2-1), planned_tons_i['Tonnage'] * sf2, planned_tons_i['Tonnage'])
                planned_tons_i['Tonnage_cumsum_scn2'] = planned_tons_i['Tonnage_scn2'].cumsum()

                print('===> tonn_rem >===: {}' .format(tonn_rem))
                if tonn_rem>0:
                    days_date_norm = planned_tons_i[planned_tons_i['Tonnage_cumsum']<=tonn_rem]['Date'].iloc[-1]
                    days_left_norm = pd.to_datetime(days_date_norm) - pd.to_datetime(data_temp['test_date'].max())

                    days_date_scn1 = planned_tons_i[planned_tons_i['Tonnage_cumsum_scn1']<=tonn_rem]['Date'].iloc[-1]
                    days_left_scn1 = pd.to_datetime(days_date_scn1) - pd.to_datetime(data_temp['test_date'].max())

                    days_date_scn2 = planned_tons_i[planned_tons_i['Tonnage_cumsum_scn2']<=tonn_rem]['Date'].iloc[-1]
                    days_left_scn2 = pd.to_datetime(days_date_scn2) - pd.to_datetime(data_temp['test_date'].max())
                else:
                    days_left_norm = 0
                    days_left_scn1 = 0
                    days_left_scn2 = 0
                                                
                # print(Key, mape*100,round(mn*30,4),round(mn_tn*10**6,4),round(tonn_rem,1),days_left_norm) 
                print('===> days_left_norm >===: {}' .format(days_left_norm))
                print('===> days_left_scn1 >===: {}' .format(days_left_scn1))
                print('===> days_left_scn2 >===: {}' .format(days_left_scn2))
                
                latest_test_values = data_temp.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                        'result_min' : 'last', 'test_date':'max'})

                df_time_top['Key']=[Key]
                df_time_top[['areaName', 'wearSurface', 'equipmentID', 'Side']] = df_time_top['Key'].str.split('_', expand=True)         
                
                df_time_top = pd.merge(df_time_top,
                                        latest_test_values,
                                        on = ['Key'],
                                        how = 'left')
                                        
                df_time_top['mm_per_Mton']=[np.round(s*10**6,4)]                
                df_time_top['days_to_replace_ton']=[days_left_norm]   

                df_time_top['tons_to_replace'] = tonn_rem/1000000     
                df_time_top['tons_to_replace'] = np.where(df_time_top['tons_to_replace'] <0, 0, df_time_top['tons_to_replace'])

                df_time_top['date_to_critical_thickness']=[days_date_norm]
                df_time_top['days_to_replace_ton']=[days_left_norm.days]
                
                df_time_top['date_to_critical_thickness_scn1']=[days_date_scn1]
                df_time_top['days_to_replace_ton_scn1']=[days_left_scn1]
                
                df_time_top['date_to_critical_thickness_scn2']=[days_date_scn2]
                df_time_top['days_to_replace_ton_scn2']=[days_left_scn2]

                df_time_top1=df_time_top1.append(df_time_top)
        
        
        df_time_top1=df_time_top1.sort_values(by='Key')
        
        return df_time_top1
        
    
    toppan_df_tons_output = tons_prediction_toppan(pds_toppan_df, planned_data)
    print(' --> Generated through polyfit <---')

except:
    toppan_df_tons_output = pds_toppan_df.groupby(['Key'], as_index = False).agg({'Critial Thickness' : 'min',
                                                                                  'result_min' : 'last', 'test_date':'max'})
    toppan_df_tons_output[['areaName', 'wearSurface', 'equipmentID','Side']] = toppan_df_tons_output['Key'].str.split('_', expand=True)         
    toppan_df_tons_output['mm_per_Mton'] = df_poc_deg_rates[df_poc_deg_rates['wearSurface'] == 'Top of Pan']['deg_rate_ton'].mean()                                                                                      
    toppan_df_tons_output['tons_to_replace'] = (toppan_df_tons_output['result_min'] - toppan_df_tons_output['Critial Thickness'])*1000000/toppan_df_tons_output['mm_per_Mton']

    ratio_df = pd.DataFrame({'areaName' : k, 'ratio' : v} for k, v in ratio_dict.items())
    toppan_df_tons_output = pd.merge(toppan_df_tons_output,
                                    ratio_df,
                                    on = ['areaName'],
                                    how = 'left')


    
    critical_date_list_norm = []
    critical_date_list_scn1 = []
    critical_date_list_scn2 = []
    tons_to_replace_list = []

    for i in toppan_df_tons_output['areaName'].unique():

        temp_planned_df = copy.deepcopy(planned_data.loc[lambda x: x.Belt==i].reset_index(drop=True))

        max_cur_ton_date = tag_ton_melt[tag_ton_melt['Belt']==i]['Date'].max()
        temp_planned_df = temp_planned_df[temp_planned_df['Date'] > max_cur_ton_date].reset_index(drop=True)
        
        temp_planned_df['Tonnage_scn1'] = np.where(temp_planned_df.index <= (sprint1-1), temp_planned_df['Tonnage'] * sf1, temp_planned_df['Tonnage'])
        temp_planned_df['Tonnage_scn2'] = np.where(temp_planned_df.index <= (sprint2-1), temp_planned_df['Tonnage'] * sf2, temp_planned_df['Tonnage'])
        
        
        temp_planned_df['prop_cumul_tonnage_norm'] = temp_planned_df['Tonnage'].cumsum()
        temp_planned_df['prop_cumul_tonnage_scn1'] = temp_planned_df['Tonnage_scn1'].cumsum()
        temp_planned_df['prop_cumul_tonnage_scn2'] = temp_planned_df['Tonnage_scn2'].cumsum()

        rel_ton_replace = toppan_df_tons_output[toppan_df_tons_output['areaName']==i]['tons_to_replace'].values[0]
        print('===> rel_ton_replace before edit<===: {}'.format(rel_ton_replace))
        latest_ton_value = tag_ton_melt[tag_ton_melt['Belt'] == i]['ton'].max()
        rel_ton_replace = rel_ton_replace- latest_ton_value
        print('===> i <===: ', i)
        print('===> rel_ton_replace after edit<===: {}'.format(rel_ton_replace))
        tons_to_replace_list.append(rel_ton_replace)
        # toppan_df_tons_output['tons_to_replace'] = tons_to_replace_list
        rem_df_norm = temp_planned_df[temp_planned_df['prop_cumul_tonnage_norm'] <= rel_ton_replace]
        rem_df_scn1 = temp_planned_df[temp_planned_df['prop_cumul_tonnage_scn1'] <= rel_ton_replace]
        rem_df_scn2 = temp_planned_df[temp_planned_df['prop_cumul_tonnage_scn2'] <= rel_ton_replace]
        
        crtitical_date_norm = rem_df_norm['Date'].iloc[-1]
        critical_date_list_norm.append(crtitical_date_norm)

        crtitical_date_scn1 = rem_df_scn1['Date'].iloc[-1]
        critical_date_list_scn1.append(crtitical_date_scn1)

        crtitical_date_scn2 = rem_df_scn2['Date'].iloc[-1]
        critical_date_list_scn2.append(crtitical_date_scn2)
    
    
    toppan_df_tons_output['date_to_critical_thickness'] = critical_date_list_norm
    toppan_df_tons_output['date_to_critical_thickness_scn1'] = critical_date_list_scn1
    toppan_df_tons_output['date_to_critical_thickness_scn2'] = critical_date_list_scn2

    toppan_df_tons_output['test_date'] = pd.to_datetime(toppan_df_tons_output['test_date'])
    toppan_df_tons_output['days_to_replace_ton']= toppan_df_tons_output['date_to_critical_thickness']- toppan_df_tons_output['test_date']
    toppan_df_tons_output['tons_to_replace'] = tons_to_replace_list
    toppan_df_tons_output['tons_to_replace'] = toppan_df_tons_output['tons_to_replace']/1000000
    toppan_df_tons_output['tons_to_replace'] = np.where(toppan_df_tons_output['tons_to_replace'] <0, 0, toppan_df_tons_output['tons_to_replace'])
    
    print('Tons Prediction Top of Pan -- PoC deg rates need to be used !!!')

    print(toppan_df_tons_output)

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)
chain_df_tons_output['days_to_replace_ton']=chain_df_tons_output['days_to_replace_ton'].dt.days.astype('int64')
if toppan_df_tons_output.empty:         
    final_output_af = chain_df_tons_output
elif chain_df_tons_output.empty:
    final_output_af = toppan_df_tons_output
else:                
    final_output_af = pd.concat([chain_df_tons_output, toppan_df_tons_output], ignore_index=True)

# final_output_af['days_to_replace_ton'] = pd.to_timedelta(concat_pd_list_days_final['days_to_replace_time'].apply(math.ceil), 'D')
final_output_af.to_csv(output_folder+'/final_af_tons_output_'+forecast_date+'.csv', index=False)

print("AF Tonnage Script Ran Successfully!")
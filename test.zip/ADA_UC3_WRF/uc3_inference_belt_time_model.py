# Standard Packages
import numpy as np
import pandas as pd
import datetime
import joblib
import os

import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--input_data")
parser.add_argument("--manual_inputs")
parser.add_argument("--forecast_date")
parser.add_argument("--output_dir")
args = parser.parse_args()

if args.forecast_date == 'default':
    forecast_date = datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')
else:
    forecast_date = args.forecast_date


# Load input data

input_folder = args.input_data

tag_ton_melt = pd.read_csv(input_folder+'/tag_ton_melt.csv')
date_range_df_right_model = pd.read_csv(input_folder+'/date_range_df_right_model.csv')
date_range_df_centre_model = pd.read_csv(input_folder+'/date_range_df_centre_model.csv')
date_range_df_left_model = pd.read_csv(input_folder+'/date_range_df_left_model.csv')
date_range_df_left = pd.read_csv(input_folder+'/date_range_df_left.csv')
df_shutdown = pd.read_csv(input_folder+'/df_shutdown.csv')


#### Regression (time based: days_prediction):
print('---> Prediction Section: Time Based')
def days_prediction(test,section = '7',belt_category = 'fast'):
    """
    Parameters
    ----------
    test : TYPE
        DESCRIPTION.
    section : TYPE
        DESCRIPTION.

    Returns
    -------
    advisory : TYPE
        DESCRIPTION.

    """
    poa = test['part_of_asset'].unique()[0]

    pkl_key = str(poa) + '_' + str(belt_category)

    def get_pkl(pkl_key = pkl_key):
        return{
            'left_fast':'days_model_fast_1.pkl',
            'left_slow':'days_model_slow_1.pkl',
            'centre_fast':'days_model_fast_2.pkl',
            'centre_slow':'days_model_slow_2.pkl',
            'right_fast':'days_model_fast_3.pkl',
            'right_slow':'days_model_slow_3.pkl'
        }.get(pkl_key, lambda: None)

    pkl_path = get_pkl()
    test = test.drop(columns = 'part_of_asset')
    reg = joblib.load(args.manual_inputs+'/B4_Model_Files/'+pkl_path)
    c = reg.intercept_[0]
    m1 = reg.coef_[0][0]
    m2 = reg.coef_[0][1]
    m3 = reg.coef_[0][2]
    m4 = reg.coef_[0][3]
    m5 = reg.coef_[0][4]
    m6 = reg.coef_[0][5]
    
    coef_df = pd.DataFrame({'c' : [c], 'm1' : [m1], 'm2' :  [m2], 'm3' : [m3], 'm4' : [m4], 'm5' : [m5], 'm6' : [m6]})
    print(coef_df)    
    
    advisory = pd.DataFrame()

    for k in test['Key'].unique():
        
        tst = test[test['Key']==k]
        deg_rate = tst['deg_rate'+'_'+section + '_time'].unique()[0]
        
        y_belt =float(tst['Critial Thickness'].unique()[0])
        
        end_thickness = tst.iloc[-1]['result_min'+'_'+section]
        out=(y_belt-end_thickness)/(m1+(m5*deg_rate))
        slope = m1+(m5*deg_rate)
        
        if (len(tst)>=4) & (belt_category=='slow'):
        
            # Polyfit for cycle k
            x = tst.num_date - tst.num_date.min()
            trend = np.polyfit(x,tst['result_min'+'_'+section],1)
            y=tst['result_min'+'_'+section]
            s=trend[0]
            i=trend[1]
        
            #Polyfit for last 5 points
     
            if len(tst[tst.shape[0]-5:]) > 1:
                
                trend_rt = np.polyfit(x[tst.shape[0]-5:],tst[tst.shape[0]-5:]['result_min'+'_'+section],1)
                x=x[tst.shape[0]-5:]
                y=tst[tst.shape[0]-5:]['result_min'+'_'+section]
            else:
                trend_rt = np.polyfit(x,tst['result_min'+'_'+section],1)
            s_rt=trend_rt[0]
            i_rt=trend_rt[1]
            
            out1 = (y_belt-end_thickness)/s

            out1 = (y_belt-end_thickness)/s
            out1 = np.where(out1<0,9999,out1)
            out2 = (y_belt-end_thickness)/s_rt
            out2 = np.where(out2<0,9999,out2)
            out = np.where(out1<out2,out1,out2)
            slope = np.where(out1<out2,s,s_rt)

        
        d = {'Key':[k],'Days to Replace'+'_'+section:out,'mm_per_day'+'_'+section:slope}
        df = pd.DataFrame(data=d)
        advisory=advisory.append(df)
    return advisory



rt_pred_fast = days_prediction(date_range_df_right_model)
rt_pred_fast



rt_pred_slow = days_prediction(date_range_df_right_model, belt_category='slow')
rt_pred_slow



ct_pred_fast = days_prediction(date_range_df_centre_model)
ct_pred_fast



ct_pred_slow = days_prediction(date_range_df_centre_model, belt_category='slow')
ct_pred_slow



lt_pred_fast = days_prediction(date_range_df_left_model)
lt_pred_fast



lt_pred_slow = days_prediction(date_range_df_left_model, belt_category='slow')
lt_pred_slow


lt_pred_fast = lt_pred_fast.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})
ct_pred_fast = ct_pred_fast.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})
rt_pred_fast = rt_pred_fast.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})

lt_pred_fast['days_to_replace'] = lt_pred_fast['days_to_replace'].mask(lambda x: x < 0, np.nan)
ct_pred_fast['days_to_replace'] = ct_pred_fast['days_to_replace'].mask(lambda x: x < 0, np.nan)
rt_pred_fast['days_to_replace'] = rt_pred_fast['days_to_replace'].mask(lambda x: x < 0, np.nan)

lt_pred_fast.columns = [_+'_lt' for _ in lt_pred_fast.columns]
ct_pred_fast.columns = [_+'_ct' for _ in ct_pred_fast.columns]
rt_pred_fast.columns = [_+'_rt' for _ in rt_pred_fast.columns]
pdlist_fast = [lt_pred_fast, ct_pred_fast, rt_pred_fast]
concat_pred_df_fast = pd.concat((pdlist_fast), axis=1)#.min(axis=1)


concat_pred_df_fast['days_to_replace_final'] = concat_pred_df_fast.filter(regex='days_to_replace').min(axis=1)
concat_pred_df_fast['days_to_replace_final_idx'] = (concat_pred_df_fast.filter(regex='days_to_replace').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pred_df_fast['days_to_replace_final_idx'] = concat_pred_df_fast.apply(lambda x: 'nan' if x['days_to_replace_final_idx'] == 'nan' else x['mm_per_day_' + str(x['days_to_replace_final_idx'])], axis=1)
concat_pred_df_fast = concat_pred_df_fast.rename(columns = {'Key_rt':'Key', 'days_to_replace_final_idx':'mm_per_day_fast', 'days_to_replace_final': 'days_to_replace_fast'})
concat_pred_df_fast = concat_pred_df_fast[['Key', 'days_to_replace_fast', 'mm_per_day_fast']]


lt_pred_slow = lt_pred_slow.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})
ct_pred_slow = ct_pred_slow.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})
rt_pred_slow = rt_pred_slow.rename(columns={'Days to Replace_7':'days_to_replace', 'mm_per_day_7':'mm_per_day'})

lt_pred_slow['days_to_replace'] = lt_pred_slow['days_to_replace'].mask(lambda x: x < 0, np.nan)
ct_pred_slow['days_to_replace'] = ct_pred_slow['days_to_replace'].mask(lambda x: x < 0, np.nan)
rt_pred_slow['days_to_replace'] = rt_pred_slow['days_to_replace'].mask(lambda x: x < 0, np.nan)

lt_pred_slow.columns = [_+'_lt' for _ in lt_pred_slow.columns]
ct_pred_slow.columns = [_+'_ct' for _ in ct_pred_slow.columns]
rt_pred_slow.columns = [_+'_rt' for _ in rt_pred_slow.columns]
pdlist_slow = [lt_pred_slow, ct_pred_slow, rt_pred_slow]
concat_pred_df_slow = pd.concat((pdlist_slow), axis=1)


concat_pred_df_slow['days_to_replace_final'] = concat_pred_df_slow.filter(regex='days_to_replace').min(axis=1)
concat_pred_df_slow['days_to_replace_final_idx'] = (concat_pred_df_slow.filter(regex='days_to_replace').idxmin(axis=1)).apply(lambda x: str(x).split('_')[-1])
concat_pred_df_slow['days_to_replace_final_idx'] = concat_pred_df_slow.apply(lambda x: 'nan' if x['days_to_replace_final_idx'] == 'nan' else x['mm_per_day_' + str(x['days_to_replace_final_idx'])], axis=1)
concat_pred_df_slow = concat_pred_df_slow.rename(columns = {'Key_rt':'Key', 'days_to_replace_final_idx':'mm_per_day_slow', 'days_to_replace_final': 'days_to_replace_slow'})

concat_pred_df_slow = concat_pred_df_slow[['Key', 'days_to_replace_slow', 'mm_per_day_slow']]

concat_pd_list_days_final = pd.merge(concat_pred_df_fast, concat_pred_df_slow, on= 'Key', how='left')
concat_pd_list_days_final['areaName'] = concat_pd_list_days_final['Key'].apply(lambda x: x.split('_')[0])

belt_tech_specs = pd.read_csv(args.manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_length_specs = belt_tech_specs.loc[lambda x: x.Feature == 'Belt Length'].reset_index(drop=True)
belt_length_specs = belt_length_specs.pivot(index='Asset_ID', columns='Feature', values='Value').reset_index()
belt_length_specs = belt_length_specs.rename(columns = {'Asset_ID':'areaName'})
belt_length_specs['areaName'] = belt_length_specs['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
belt_length_specs['Belt Length'] = pd.to_numeric(belt_length_specs['Belt Length'])
belt_length_specs['fast_slow_flag'] = belt_length_specs['Belt Length'].apply(lambda x: 'Fast' if x < belt_length_specs['Belt Length'].max() * 0.1 else 'Slow')

concat_pd_list_days_final = concat_pd_list_days_final.merge(belt_length_specs[['areaName', 'fast_slow_flag']], on = ['areaName'], how='left')

concat_pd_list_days_final['days_to_replace_time'] = np.where(concat_pd_list_days_final['fast_slow_flag'] == 'Fast', concat_pd_list_days_final['days_to_replace_fast'], concat_pd_list_days_final['days_to_replace_slow'])
concat_pd_list_days_final['mm_per_month'] = np.where(concat_pd_list_days_final['fast_slow_flag'] == 'Fast', concat_pd_list_days_final['mm_per_day_fast'], concat_pd_list_days_final['mm_per_day_slow']) * 30
concat_pd_list_days_final = concat_pd_list_days_final[['Key', 'days_to_replace_time', 'mm_per_month']]

print('---> Time Based Prediction Complete')
print(concat_pd_list_days_final)


## Export to output folder

output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

concat_pd_list_days_final.to_csv(output_folder+'/belt_days_model_'+forecast_date+'.csv', index = False)
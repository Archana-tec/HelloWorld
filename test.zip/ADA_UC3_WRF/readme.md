# ADA Use Case 3: Wear Rate Forecasting
<br>
MVP model code for Gudai-Darri Advanced Data Analytics <b>Use Case 3: Wear Rate Forecasting.</b>
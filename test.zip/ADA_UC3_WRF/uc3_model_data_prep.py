# Standard Packages
import numpy as np
import pandas as pd
import datetime
from pandas.tseries import offsets
from datetime import timedelta
import re
import copy
import matplotlib.dates as mdates
import ast
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
import os

# Our Custom Libraries
import load_ADA_data

# Parse Arguments
import argparse
parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--PDS")
parser.add_argument("--shutdowns")
parser.add_argument("--UC3_manual_inputs")
parser.add_argument("--output_dir")
args = parser.parse_args()

#### Create Output folders
output_folder = args.output_dir
os.makedirs(output_folder, exist_ok=True)

# Date range for data import - take largest available range of data
dt_start = datetime.datetime(2022,1,1)
dt_now = datetime.datetime.now()
date_range = load_ADA_data.hdfs_range(dt_start, dt_now)

# Start Spark Session
os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
spark = SparkSession.builder \
                .appName('app_name') \
                .master('local[*]') \
                .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                .config('spark.sql.session.timeZone', 'UTC') \
                .config('spark.driver.memory','32G') \
                .config('spark.ui.showConsoleProgress', True) \
                .config('spark.sql.repl.eagerEval.enabled', True) \
                .config('spark.driver.maxResultSize','0')\
                .getOrCreate()


#### GD PDS Data Load

print('---> Begin PDS data preparation...')

hdfs_path = "/Pds-ada-"+date_range
sdf_pds = spark.read.option("multiline", "true").json(args.PDS+hdfs_path).withColumn("filename", input_file_name())
sdf_pds = load_ADA_data.NormaliseJsonSpark(sdf_pds).normalise_pds_spark()
df_pds = sdf_pds.toPandas()

# Asset Scope for UC3
UC3_belts = ['CV0101', 'CV0102', 'CV0211', 'CV0312', 'CV0313', 'CV0316', 'CV0514', 'CV0517', 'CV0622', 'CV21 (RC0601)', 'CV15 (SK0501)', 'CV18 (SK0502)', 'BF0401', 'BF0402']
UC3_AFs = ['AF0101', 'AF0201', 'AF0202']

# Filter for only relevant assets
df_pds_belt = df_pds[df_pds.areaName.isin(UC3_belts)].reset_index(drop=True)

# Strip time out of testDate
df_pds_belt['test_date'] = pd.to_datetime(df_pds_belt['testDate'].dt.date, format = "%Y-%m-%d")




#### POC PDS Data Load
df_poc_pds = pd.read_csv(args.UC3_manual_inputs+'/PoC_PDS.csv', low_memory=False)

poc_asset_list = [
                  'BCV110','BCV120','BCV210','BCV310','BCV301','BCV410','BCV420',
                  'BCV501','BCV430','BCV520','BCV502','BCV510','BCV530','BCV503'
                 ]

df_poc_pds = df_poc_pds[df_poc_pds['area_name'].isin(poc_asset_list)].reset_index(drop=True)
print(df_poc_pds.shape)

rename_dictionary = {
                    'area_functionallocation' : 'areaFunctionalLocation',
                    'area_id' : 'areaId',
                    'area_name' : 'areaName',
                    'area_sortorder' : 'areaSortOrder',
                    'area_type' : 'areaType',
                    'average_result_difference' : 'averageResultDifference',
                    'business_functionallocation' : 'businessFunctionalLocation',
                    'business_name' : 'businessName',
                    'business_sortorder' : 'businessSortOrder',
                    'department_functionallocation' : 'departmentFunctionalLocation',
                    'department_name' : 'departmentName',
                    'department_sortorder' : 'departmentSortOrder', 
                    'equipment_description' : 'equipmentDescription',
                    'equipment_id' : 'equipmentId', 
                    'equipment_type' : 'equipmentType', 
                    'group_functionallocation' : 'groupFunctionalLocation', 
                    'group_name' : 'groupName',
                    'group_sortorder' : 'groupSortOrder', 
                    'installed' : 'installed', 
                    'last_saved_by' : 'lastSavedBy', 
                    'last_saved_date_utc' : 'lastSavedDateTime',
                    'ref' : 'ref', 
                    'result' : 'result', 
                    'result_difference' : 'resultDifference', 
                    'result_invalid' : 'resultIsInvalid', 
                    'test_date_utc' : 'testDate',
                    'test_id' : 'testId', 
                    'wear_measurement_type' : 'wearMeasurementType', 
                    'wear_surface' : 'wearSurface', 
                    'x' : 'x',
                    'y' : 'y',                    
}

df_poc_pds.rename(columns= rename_dictionary, inplace=True)
df_poc_pds = df_poc_pds[df_pds.columns]
df_poc_pds['test_date'] = pd.to_datetime(df_poc_pds['testDate'])#, format = "%m/%d/%Y")
df_poc_pds['test_date'] = df_poc_pds['test_date'].dt.date

df_poc_pds = df_poc_pds[df_poc_pds['test_date']>=datetime.date(2017, 5, 1)]
df_poc_pds = df_poc_pds[df_poc_pds['test_date']<datetime.date(2021, 10, 30)]



#### Append GD PDS and POC PDS
df_pds_belt = pd.concat([df_pds_belt, df_poc_pds], ignore_index=True)




#### Create PDS Summary - Pivot PDS
pds_summary = pd.pivot_table(df_pds_belt,index=['areaName','wearSurface', 'test_date', 'testId', 'equipmentId',
                             'averageResultDifference'],
                             values=['result','resultDifference'],aggfunc= {'min','max',np.mean, np.median, np.std })

pds_summary.columns = list(map("_".join, pds_summary.columns))
pds_summary=pds_summary.reset_index()       

pds_summary = pds_summary.sort_values(['areaName', 'wearSurface', 'test_date', 'testId']).reset_index(drop=True)#.drop_duplicates('test_date').sort_index()




#### Create PDS Sectional
n_section = 3

df_pds_belt = df_pds_belt[['areaName', 'wearSurface', 'x', 'result', 'resultDifference', 'averageResultDifference','test_date']]
df_pds_belt['belt_width'] = df_pds_belt.groupby('areaName')['x'].transform('max')

df_pds_belt['threshold'] = np.ceil(df_pds_belt['belt_width']/n_section)
df_pds_belt['belt_section']=((np.ceil(df_pds_belt['x']/df_pds_belt['threshold'])).astype(int)).astype(str)
df_pds_belt = df_pds_belt[df_pds_belt['belt_section'] != '0']

df_pds_belt['x'] = df_pds_belt['x'].astype(str)

pds_section_df = pd.pivot_table(df_pds_belt,index=['areaName', 'wearSurface', 'test_date'],columns=['belt_section'],
                                values=['result'],aggfunc= {'min'})


pds_section_df.columns = list(map("_".join, pds_section_df.columns))
pds_section_df = pds_section_df.reset_index()



#### Merge PDS Summary with PDS Sectional
pds_model_df = pd.merge(pds_summary,
                        pds_section_df,
                        on = ['areaName', 'wearSurface', 'test_date'],
                        how = 'left')




#### Load UC3 Tags
uc3_tag_list_speed = {}

# Pipeline version
uc3_tags =  os.path.join(os.path.dirname(__file__), 'UC3_Tags.txt')
# Notebook version
#uc3_tags = './UC3_Tags.txt'

with open(uc3_tags) as f:
    tag_dict = f.read()#.splitlines()
f.close()
# uc3_tag_dict = json.loads(tag_dict)
uc3_tag_dict = ast.literal_eval(tag_dict)
uc3_tag_list_speed = uc3_tag_dict['speed']
uc3_tag_list_ton = uc3_tag_dict['ton']
print('---> Tag lists loaded.')




#### Load Tonnage Data
tag_ton = pd.read_csv(args.UC3_manual_inputs+'/GD_Historical_Tonnage.csv')
tag_ton.columns = [_.replace('-', '_') for _ in tag_ton.columns]
tag_ton_val_cols = [_ for _ in tag_ton.columns if 'Date_Time' not in _]
tag_ton['Date_Time'] = pd.to_datetime(tag_ton['Date_Time'])
tag_ton = tag_ton.sort_values(by='Date_Time')
period_start_ton = tag_ton['Date_Time'].max()

period_start = (tag_ton.Date_Time.max()+pd.DateOffset(minutes=1)).to_pydatetime()
sdf_tags = spark.read.parquet(args.PCS_tags)
sdf_tags = sdf_tags[sdf_tags.tagid.isin(uc3_tag_list_ton)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start, dt_now)]
df_tags_ton = sdf_tags.toPandas()
print(df_tags_ton.tail())
print('Num rows live data: '+str(len(df_tags_ton)))

df_tags_ton = df_tags_ton.rename(columns = {'tagid':'areaName', 'time_rio':'Date_Time', 'value_rio':'ton'})
df_tags_ton = df_tags_ton.drop(columns = 'file_timestamp')
df_tags_ton = df_tags_ton[['areaName', 'ton', 'Date_Time']]
df_tags_ton['Date_Time'] = pd.to_datetime(df_tags_ton['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
df_tags_ton['ton'] = pd.to_numeric(df_tags_ton['ton'])
df_tags_ton_pivot = df_tags_ton.pivot_table(index='Date_Time', columns='areaName', values='ton', aggfunc = 'max')#.reset_index()
df_tags_ton_pivot = df_tags_ton_pivot.resample('D').max()
df_tags_ton_pivot = df_tags_ton_pivot.reset_index()
df_tags_ton_pivot = df_tags_ton_pivot.iloc[1:].reset_index(drop=True)
df_tags_ton_pivot['Date_Time'] = pd.to_datetime(df_tags_ton_pivot['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
df_tags_ton_pivot.head()
print('---> Loaded live Tonnage data')

tag_ton = pd.concat((tag_ton, df_tags_ton_pivot), ignore_index=True)
tag_ton = tag_ton.sort_values('Date_Time')

#### Clean & Pre Process Tonnage Data
print('---> Processing the tonnage data')
for col in tag_ton_val_cols:
    tag_ton[col] = tag_ton[col].ffill().fillna(0)
    tag_ton[col] = np.where(tag_ton[col] < 0, 0, tag_ton[col])
    tag_ton[col] = tag_ton[col].mask(tag_ton[col].diff() < 0, np.nan).ffill()

tag_ton_melt = tag_ton.melt(id_vars='Date_Time', value_vars=tag_ton_val_cols, value_name='ton', var_name='areaName')
tag_ton_melt['Date_Time'] = pd.to_datetime(tag_ton_melt['Date_Time'])
month_start_ton = tag_ton_melt.dropna().sort_values(['areaName','Date_Time'], ascending=True).groupby('areaName').apply(lambda x: pd.to_datetime(x.Date_Time.iloc[0], format='%Y-%m-%d').month_name())
tag_ton_melt = tag_ton_melt.sort_values(['areaName','Date_Time'], ascending=True)
tag_ton_melt['ton'] = tag_ton_melt['ton'].fillna(0)
tag_ton_melt.reset_index(drop=True, inplace = True)
tag_ton_melt['Date'] = tag_ton_melt.Date_Time.dt.date
tag_ton_melt['Asset'] = tag_ton_melt['areaName'].apply(lambda x: re.findall(r'(\.[A-Z]+[0-9]+)', x)[0].split('.')[1])
period_start_ton = tag_ton_melt['Date_Time'].max()
tag_ton_melt.drop(columns={'Date_Time'}, inplace=True)
tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'], format='%Y-%m-%d')
tag_ton_melt.head()

tag_ton_mapping_dict = {
                        'BF0401' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'BF0402' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'CV0101' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'CV0102' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'CV0211' : ['KD1.PPCS.CV0211WT03_TOTNRST'],
                        'CV0312' : ['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'],
                        'CV0313' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'CV0316' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'CV0514' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'CV0517' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'CV0622' : ['KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST'],
                        'RC0601-CV21' : ['KD1.PPCS.CV0622WT01_ACTDAT_TOTNRST'],
                        'SK0501-CV15' : ['KD1.PPCS.CV0313WT01_ACTDAT_TOTNRST'],
                        'SK0502-CV18' : ['KD1.PPCS.CV0316WT01_ACTDAT_TOTNRST'],
                        'AF0101' : ['KD1.PPCS.CV0101WT01_TOTNRST'],
                        'AF0201' : ['KD1.PPCS.CV0211WT01_TOTNRST'],
                        'AF0202' : ['KD1.PPCS.CV0211WT01_TOTNRST', 'KD1.PPCS.CV0211WT03_TOTNRST']
                        }

df_tonnage = pd.DataFrame()

for i in list(tag_ton_mapping_dict.keys()):

    rel_belt = tag_ton_mapping_dict.get(i)
    print('rel_belt: {}'.format(tag_ton_mapping_dict.get(i)))
    temp_df = tag_ton_melt[tag_ton_melt['areaName'].isin(rel_belt)].reset_index()
    print('=======> tag_ton_melt areaName: {}'.format(tag_ton_melt.areaName.unique()))
    temp_df['Belt'] = i
    print(temp_df.head())
    if i == 'AF0202':
        temp_df_pivo = temp_df.pivot(index=['Date', 'Belt'], columns=['areaName'], values='ton')
        temp_df_pivo_cols = list(temp_df_pivo.select_dtypes('float').columns)
        print('===> temp_df_pivo_cols: ', temp_df_pivo_cols)
        print('===> temp_df_pivo_cols_all: ', temp_df_pivo.columns)
        print(temp_df_pivo.head())
        temp_df_pivo['ton'] = temp_df_pivo.apply(lambda x: x[temp_df_pivo_cols[1]] - x[temp_df_pivo_cols[0]], axis=1)
        temp_df = temp_df_pivo.reset_index()[['Date', 'Belt', 'ton']]
    df_tonnage = pd.concat([df_tonnage, temp_df], axis = 0)
    print(i, tag_ton_mapping_dict.get(i))
df_tonnage['ton'] = np.where(df_tonnage['Belt'].isin(['BF0401', 'BF0402']), df_tonnage['ton']/2, df_tonnage['ton'])
tag_ton_melt_copy = copy.deepcopy(tag_ton_melt)
tag_ton_melt = copy.deepcopy(df_tonnage)
tag_ton_melt['Belt'] = tag_ton_melt['Belt'].replace({'RC0601-CV21':'CV21 (RC0601)', 'SK0501-CV15':'CV15 (SK0501)', 'SK0502-CV18':'CV18 (SK0502)'})
tag_ton_melt = tag_ton_melt.groupby(['Belt', 'Date'], as_index = False).agg({'ton' : 'max'})

tag_ton_melt['ton_diff'] = tag_ton_melt.groupby('Belt').agg({'ton':'diff'}).values
tag_ton_melt.loc[:, 'Date'] = pd.to_datetime(tag_ton_melt['Date'], format='%Y-%m-%d')
tag_ton_melt.tail()
print('---> Tonnage data processed')



#### Merge Tonnage Data with PDS Model Data
tag_ton_melt_gd = copy.deepcopy(tag_ton_melt)

# Load POC Tonnage Data
tag_ton_melt_poc = pd.read_csv(args.UC3_manual_inputs+'/tag_ton_melt_poc.csv')

tag_ton_melt = pd.concat([tag_ton_melt_gd, tag_ton_melt_poc], ignore_index=True)
tag_ton_melt['Date'] = pd.to_datetime(tag_ton_melt['Date'])

pds_model_df = pd.merge(pds_model_df,
                        tag_ton_melt[['Belt', 'Date', 'ton']],
                        left_on = ['areaName', 'test_date'],
                        right_on = ['Belt', 'Date'],
                        how='left'
                        )

pds_model_df.drop(columns = ['Belt', 'Date'], axis = 1, inplace=True)



#### Create Key in PDS Model Data
pds_model_df['Key'] = pds_model_df['areaName'] + '_' + pds_model_df['wearSurface']




#### Functions for 'Diff Days' and 'Cumsum'
def diff_ton_cal(df_model):
    cols = list(df_model.columns)
    df_model['key'] = df_model['areaName'] + "_" + df_model['wearSurface']
    df_model = df_model.sort_values(['areaName', 'wearSurface', 'test_date'])

    res = df_model.groupby(['Key']).agg({'ton' : 'diff'})
    res.columns = ['ton_diff']
    df_model = pd.concat([df_model, res], axis = 1)
    # df_model['ton_diff'] = df_model['ton_diff'].dt.total_seconds()/60

    df_model['cumsum_ton_key'] = np.where(df_model['averageResultDifference'] ==0, df_model['Key'] + "_" + df_model['test_date'].astype(str), np.NaN)
    df_model['cumsum_ton_key'] = (df_model['cumsum_ton_key']).ffill(axis=0)
    df_model['ton_diff_tweaked'] = np.where(df_model['averageResultDifference'] ==0, 0, df_model['ton_diff'])

    res = df_model.groupby(['cumsum_ton_key']).agg({'ton_diff_tweaked' : 'cumsum'})
    res.columns = ['Cumsum']
    df_model = pd.concat([df_model, res], axis = 1)
    cols = cols + ['Cumsum']
    return df_model[cols]


def diff_days_cal(df_model):
    cols = list(df_model.columns)
    df_model['key'] = df_model['areaName'] + "_" + df_model['wearSurface']
    df_model = df_model.sort_values(['areaName', 'wearSurface', 'test_date'])

    res = df_model.groupby(['Key']).agg({'test_date' : 'diff'})
    res.columns = ['Run_Time']
    df_model = pd.concat([df_model, res], axis = 1)
    df_model['Run_Time'] = df_model['Run_Time'].dt.total_seconds()/60

    df_model['cumsum_time_key'] = np.where(df_model['averageResultDifference'] ==0, df_model['Key'] + "_" + df_model['test_date'].astype(str), np.NaN)
    df_model['cumsum_time_key'] = (df_model['cumsum_time_key']).ffill(axis=0)
    df_model['Run_Time_tweaked'] = np.where(df_model['averageResultDifference'] ==0, 0, df_model['Run_Time'])

    res = df_model.groupby(['cumsum_time_key']).agg({'Run_Time_tweaked' : 'cumsum'})
    res.columns = ['Cumsum_Time']
    df_model = pd.concat([df_model, res], axis = 1)
    df_model['diff_days'] = df_model['Cumsum_Time']/(60*24)
    cols = cols + ['diff_days']
    return df_model[cols]

pds_model_df = diff_ton_cal(pds_model_df)
pds_model_df = diff_days_cal(pds_model_df)




#### Load Belt Speed Data for GD
tag_speed = pd.read_csv(args.UC3_manual_inputs+'/GD_Historical_Belt_Speed_ms.csv')
tag_speed.columns = [_.replace('-', '_') for _ in tag_speed.columns]

tag_speed_melt = tag_speed.melt(id_vars='Date_Time', value_vars=[_ for _ in tag_speed.columns if 'Date_Time' not in _], value_name='speed', var_name='areaName')
tag_speed_melt['Date_Time'] = pd.to_datetime(tag_speed_melt['Date_Time'])
month_start = tag_speed_melt.dropna().sort_values(['areaName','Date_Time'], ascending=True).groupby('areaName').apply(lambda x: pd.to_datetime(x.Date_Time.iloc[0], format='%Y-%m-%d').month_name())
tag_speed_melt = tag_speed_melt.sort_values(['areaName','Date_Time'], ascending=True)
tag_speed_melt['speed'] = tag_speed_melt['speed'].fillna(0)
tag_speed_melt.reset_index(drop=True, inplace=True)
# tag_speed_melt['Date'] = tag_speed_melt.Date_Time.dt.date
tag_speed_melt.head()

print('---> Historical Belt Speed data load complete.')

# Load live tag data from the daily data load pipeline outputs (through integration INT054)
print('---> Load live Belt Speed data.')

# Period start = last datetime of the manual input file
period_start = (tag_speed_melt.Date_Time.max()+pd.DateOffset(minutes=1)).to_pydatetime()
sdf_tags = spark.read.parquet(args.PCS_tags)
sdf_tags = sdf_tags[sdf_tags.tagid.isin(uc3_tag_list_speed)]
sdf_tags = sdf_tags[sdf_tags.time_rio.between(period_start, dt_now)]
df_tags_speed = sdf_tags.toPandas()
print(df_tags_speed.tail())
print('Num rows live data: '+str(len(df_tags_speed)))
df_tags_speed = df_tags_speed.rename(columns = {'tagid':'areaName', 'time_rio':'Date_Time', 'value_rio':'speed'})
df_tags_speed = df_tags_speed.drop(columns = 'file_timestamp')
df_tags_speed = df_tags_speed[['Date_Time', 'areaName', 'speed']]
df_tags_speed['Date_Time'] = pd.to_datetime(df_tags_speed['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
# df_tags_speed['Date_Time'] = pd.to_datetime(df_tags_speed['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
# df_tags_speed['Date'] = df_tags_speed.Date_Time.dt.date
df_tags_speed['speed'] = df_tags_speed['speed'].astype(float)

print('---> Live Belt Speed data load complete.')

print(tag_speed_melt.info())

print(df_tags_speed.info())

# Appending historical data to live data (Belt Speed)
tag_speed = pd.concat((tag_speed_melt, df_tags_speed), ignore_index=True)
# tag_speed['Date'] = pd.to_datetime(tag_speed['Date'], format = '%Y-%m-%d')
tag_speed['speed'] = pd.to_numeric(tag_speed['speed'])
tag_speed = tag_speed.sort_values(['areaName','Date_Time'], ascending=True)
# tag_speed['speed'] = tag_speed['speed'].fillna(0)



# Convert Melt into Wide format
# tags_speed['Date_Time'] = pd.to_datetime(df_tags_speed['Date_Time'], format = '%Y-%m-%d %H:%M:%S')
tag_speed = tag_speed.pivot(index = 'Date_Time', columns = 'areaName', values = ['speed'])

# print(tag_speed.head())
tag_speed.columns = [a[1] for a in tag_speed.columns]

# print('Tag speed info ----', tag_speed.info())

for i in tag_speed.columns:
    tag_speed[i] = tag_speed[i].astype(float)

tag_speed = tag_speed.resample('1T').max()
tag_speed['Date_Time'] = tag_speed.index
tag_speed = tag_speed.reset_index(drop=True)



#### Create Downtime_1_hr feature
Down_timef=pd.DataFrame()

belt_speed_data = copy.deepcopy(tag_speed)
speed_cols = [a for a in belt_speed_data if 'Date' not in a]

for col in speed_cols:
    # # blt_spd=pd.read_csv(file) 
    blt_spd = belt_speed_data[['Date_Time', col]]
    blt_spd['Date_Time'] = pd.to_datetime(blt_spd['Date_Time'])
    ast = re.findall(r'(\.[A-Z]+[0-9]+)', col)[0].split('.')[1]
    if (ast == 'RC0601'):
        ast = 'CV21 (RC0601)'
    elif (ast == 'SK0501'):
        ast = 'CV15 (SK0501)'
    elif (ast == 'SK0502'):
        ast = 'CV18 (SK0502)'
    
    ### Downtown Logic
    blt_spd['lag_value']=blt_spd[col].shift(1)
    blt_spd['future_value']=blt_spd[col].shift(-1)
    blt_spd['Status']=np.nan
    blt_spd['Status1']=np.nan
    blt_spd.loc[(blt_spd[col]==0) & (blt_spd['lag_value']!=0),'Status']='On'
    blt_spd.loc[(blt_spd[col]==0) & (blt_spd['future_value']!=0),'Status1']='Off'
    l1=list(blt_spd[blt_spd['Status']=='On']['Date_Time'])
    l2=list(blt_spd[blt_spd['Status1']=='Off']['Date_Time'])
    Down_time = pd.DataFrame(
    {'Start_Time': l1,
     'End_Time': l2,
    })
    Down_time['Diff']=((Down_time['End_Time'])-(Down_time['Start_Time'])).astype('timedelta64[h]')
    Down_time=Down_time[Down_time['Diff']>0]
    Down_time['Asset']=ast
    Down_timef=Down_timef.append(Down_time,ignore_index=True)
    del Down_time

Down_timef['Start_Time']=pd.to_datetime(Down_timef['Start_Time'])
pds_summary=copy.deepcopy(pds_model_df)

pds_summary['Key']=pds_summary['areaName']+"_"+pds_summary['wearSurface']
# asst=['BCV110','BCV120','BCV310','BCV410','BCV420','BCV430']
asst=list(Down_timef['Asset'].unique())
list_unq=[]
for as1 in asst:
    l1=pds_summary[pds_summary['areaName']==as1]['Key'].unique()
    for itm in l1:
        list_unq.append(itm)
        
## Updating PDS data with downtime >1 hour
dtemp1=pds_summary.groupby('Key')
df_out=pd.DataFrame()
for uq in list_unq:
    ast=uq.split('_')[0]
    # print(uq, ast)
    dt=dtemp1.get_group(uq)
    dt=dt.sort_values(by='test_date')
    dt_list=list(dt['test_date'].unique())
    if len(dt_list) >3:  
        for i,d in enumerate(dt_list):
            df_tmp=pd.DataFrame()
            if i==len(dt_list)-1:
                break
            data_temp=Down_timef[Down_timef['Asset']==ast]
            data_temp=data_temp[(data_temp['Start_Time']>=d) & (data_temp['Start_Time']<=dt_list[i+1])]
            diff_len=len(data_temp)
            df_tmp['Time']=[dt_list[i+1]]
            df_tmp['Key']=uq
            df_tmp['Downtime_1_hr']=diff_len
            df_out=df_out.append(df_tmp,ignore_index=True)

### Append PoC Downtime to GD Downtime
df_downtime_poc = pd.read_csv(args.UC3_manual_inputs+'/Belt_final_7_ACN.csv')
df_downtime_poc = df_downtime_poc[['area_name', 'wear_surface', 'test_date_utc', 'Downtime_1_hr']]
df_downtime_poc['Key'] = df_downtime_poc['area_name'] + '_' + df_downtime_poc['wear_surface']
df_downtime_poc['Time'] = pd.to_datetime(df_downtime_poc['test_date_utc'], format = '%m/%d/%Y')

df_downtime = pd.concat([df_out, df_downtime_poc], ignore_index=True)

pds_model_df = pd.merge(pds_model_df,
                        df_downtime,
                        left_on = ['Key', 'test_date'],
                        right_on = ['Key', 'Time'],
                        how = 'left')



#### Load and Merge Critical Thickness

## Gudai Darri Critical Thickness
belt_tech_specs = pd.read_csv(args.UC3_manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_critical_gd = belt_tech_specs[belt_tech_specs['Feature'].str.contains('Critical Thickness')]
belt_critical_gd['wearSurface'] = belt_critical_gd.Feature.apply(lambda x: x.split(' ')[0])
belt_critical_gd['wearSurface'] = belt_critical_gd['wearSurface'].replace({'Pan': 'Top of Pan', 'Chain': 'Chain Length'})
belt_critical_gd = belt_critical_gd.rename(columns = {'Asset_ID':'areaName', 'Value':'Critial Thickness'})
belt_critical_gd.reset_index(drop=True, inplace=True)
belt_critical_gd['areaName'] = belt_critical_gd['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
belt_critical_gd['Critial Thickness'] = belt_critical_gd['Critial Thickness'].astype('float')

## PoC Critical Thickness
belt_critical_poc = pd.read_csv(args.UC3_manual_inputs+'/Critical Thickness.csv')
belt_critical_poc['wearSurface'] = 'Top'
belt_critical_poc.rename(columns = {
                                    'area_name' : 'areaName'
                                    }, inplace = True)

## Append the critical datasets
belt_critical_df = pd.concat([belt_critical_gd[['areaName', 'wearSurface', 'Critial Thickness']], 
                              belt_critical_poc], axis = 0, ignore_index=True)
pds_model_df = pd.merge(pds_model_df,
                        belt_critical_df[['areaName', 'wearSurface', 'Critial Thickness']],
                        on=['areaName', 'wearSurface'],
                        how='left'
                        )



#### Load and Merge Belt Length Parameters

## GD Belt Length
belt_tech_specs = pd.read_csv(args.UC3_manual_inputs+'/GD_Belt_Technical_Specs.csv')
belt_length_gd = belt_tech_specs.loc[lambda x: x.Feature == 'Belt Length'].reset_index(drop=True)
belt_length_gd = belt_length_gd.pivot(index='Asset_ID', columns='Feature', values='Value').reset_index()
belt_length_gd.columns = ['areaName', 'Belt_Length']
# belt_length_gd = belt_length_gd.rename(columns = {'Asset_ID':'areaName'})
belt_length_gd['areaName'] = belt_length_gd['areaName'].replace({'CV15':'CV15 (SK0501)', 'CV18':'CV18 (SK0502)', 'CV21':'CV21 (RC0601)'})
# belt_length_gd = belt_length_gd.reset_index(drop=True)

## PoC Belt Length
belt_length_poc = pd.read_csv(args.UC3_manual_inputs+'/Belt Desing Param.csv')
belt_length_poc.rename(columns = {
                                  'area_name' : 'areaName'                                  
                                 }, inplace=True)

## Append the belt length data
belt_length_df = pd.concat([belt_length_gd, belt_length_poc], ignore_index=True)


pds_model_df = pd.merge(pds_model_df,
                        belt_length_df[['areaName', 'Belt_Length']],
                        on=['areaName'],
                        how='left'
                        )



#### Drop records till first belt change
pds_model_df = pds_model_df.dropna(subset=['Cumsum'])      



#### Creating Cycle Number and Key
pds_model_df = pds_model_df.sort_values(['areaName', 'wearSurface', 'equipmentId', 'test_date', 'testId'])
pds_model_df['belt_change_flag'] = pds_model_df.groupby(['areaName', 'wearSurface'])['equipmentId'].diff().ge(1).astype(int)

# pds_model_df['belt_change_flag']=np.where(pds_model_df['averageResultDifference']==0,1,0)
pds_model_df['cycle_number'] = pds_model_df.groupby(['areaName','wearSurface'])['belt_change_flag'].cumsum()+1

pds_model_df['key'] = pds_model_df['areaName'] + '_' + pds_model_df['wearSurface'] + '_' + pds_model_df['cycle_number'].astype(str)
# pds_model_df = pds_model_df[pds_model_df['wearSurface']=='Top'].reset_index(drop=True)



#### Filter out bottom surface
pds_model_df = pds_model_df[pds_model_df['wearSurface']=='Top'].reset_index(drop=True)



#### Creating 'num_date'
# pds_model_df['diff_days'] = pds_model_df['Cumsum_Time']/(60*24)       ## already created above
pds_model_df['num_date'] = mdates.date2num(pds_model_df['test_date'])




#### Create Average Throughput
pds_model_df['total_throughput'] = pds_model_df.groupby('areaName')['Cumsum'].transform('sum')
pds_model_df['total_days'] = pds_model_df.groupby('areaName')['diff_days'].transform('sum')
pds_model_df['daily_throughput'] = pds_model_df['total_throughput']/pds_model_df['total_days']





#### Creating complete cycles and filter out keys with <3 data points
complete_cycle=pd.DataFrame()

d1=pds_model_df.groupby('areaName')

for arnm in pds_model_df['areaName'].unique():
    # print(arnm)
    dtemp=d1.get_group(arnm)

    tr=pd.DataFrame()
    
    if (dtemp.iloc[-1]['averageResultDifference']!=0):
        key=dtemp.iloc[-1]['key']
        tr=dtemp[dtemp['key']!=key]

    else:
        tr=dtemp

    complete_cycle=complete_cycle.append(tr,ignore_index=True)

cycle_3p=[]
for k in complete_cycle['key'].unique():
    if len(complete_cycle[complete_cycle['key']==k])<3:
        # print(k)
        cycle_3p.append(k)

for k in complete_cycle['key'].unique():
    if k in cycle_3p:
        complete_cycle=complete_cycle[complete_cycle['key']!=k]

print(complete_cycle['areaName'].unique())
print([a for a in complete_cycle['areaName'].unique() if a in UC3_belts])  



#### Remove Premature Replacement Cycles
thickness_cols = [col for col in pds_model_df.columns if 'result_min_' in col]

complete_cycle['result_min_max'] = complete_cycle[thickness_cols].min(axis=1)
complete_cycle['start_thickness'] = complete_cycle.groupby('key')['result_min_max'].transform('first')
complete_cycle['end_thickness'] = complete_cycle.groupby('key')['result_min_max'].transform('last')
complete_cycle['actual_reduction'] = complete_cycle['start_thickness']-complete_cycle['end_thickness']
complete_cycle['expected_reduction'] = complete_cycle['start_thickness']-complete_cycle['Critial Thickness']
complete_cycle['%_reduction'] = complete_cycle['actual_reduction']/complete_cycle['expected_reduction']*100

complete_cycle = complete_cycle[complete_cycle['%_reduction']>30]



#### Remove Incorrect Thickness Readings
# for col in thickness_cols:
#     complete_cycle = bw.remove_incorrect_thickness(complete_cycle,col)

complete_cycle=complete_cycle[complete_cycle['key']!='BCV501_Top_2']
complete_cycle=complete_cycle[complete_cycle['key']!='BCV502_Top_2']

complete_cycle = complete_cycle.reset_index(drop=True)

complete_cycle = complete_cycle[complete_cycle['Downtime_1_hr'].notna()].reset_index(drop=True)




#### Calculate Average Degradation Rate
def avg_degradation_rate_model(complete_cycle,param,col):
    
    avg_dgradation = pd.DataFrame()
    for k in complete_cycle['key'].unique():

        tst=complete_cycle[complete_cycle['key']==k]

        x = tst[param] - tst[param].min()
        trend = np.polyfit(x,tst[col],1)
        s=trend[0]
        tst['deg_rate']=s
        avg_dgradation = avg_dgradation.append(tst)
        
    return avg_dgradation

for col in thickness_cols:
    print('avg_deg_rate_time', col)
    belt_section = col.split('_')[-1]
    avg_dgradation = avg_degradation_rate_model(complete_cycle,'num_date',col).groupby('areaName').agg({'deg_rate':'mean'}).reset_index()
    avg_dgradation.rename(columns={'deg_rate':'deg_rate_time_'+belt_section},inplace=True)
    print(avg_dgradation)
    complete_cycle=pd.merge(complete_cycle,avg_dgradation,how='left',on='areaName')

    pds_model_df = pd.merge(pds_model_df,
                            avg_dgradation,
                            on='areaName',
                            how='left',
                            )

for col in thickness_cols:
    print('avg_deg_rate_ton', col)
    belt_section = col.split('_')[-1]
    avg_dgradation = avg_degradation_rate_model(complete_cycle,'Cumsum',col).groupby('areaName').agg({'deg_rate':'mean'}).reset_index()
    avg_dgradation.rename(columns={'deg_rate':'deg_rate_ton_'+belt_section},inplace=True)
    print(avg_dgradation)
    complete_cycle=pd.merge(complete_cycle,avg_dgradation,how='left',on='areaName')

    pds_model_df = pd.merge(pds_model_df,
                            avg_dgradation,
                            on='areaName',
                            how='left',
                            )                            




#### Split into Fast and Slow Wear
complete_cycle_fast = complete_cycle[complete_cycle['areaName'].isin(['BCV420','BCV502','BCV503','BCV501','BCV110', 'BF0401', 'BF0402', 
                                                                      'CV15 (SK0501)', 'CV18 (SK0502)', 'CV21 (RC0601)'])]
complete_cycle_slow = complete_cycle[~complete_cycle['areaName'].isin(['BCV420','BCV502','BCV503','BCV501','BCV110', 'BF0401', 'BF0402', 
                                                                      'CV15 (SK0501)', 'CV18 (SK0502)', 'CV21 (RC0601)'])]

# Remove cycles with < 3 points
complete_cycle_fast['data_count']=complete_cycle_fast.groupby('key')['key'].transform('count')
complete_cycle_fast = complete_cycle_fast[complete_cycle_fast['data_count']>=3]

complete_cycle_slow['data_count']=complete_cycle_slow.groupby('key')['key'].transform('count')
complete_cycle_slow = complete_cycle_slow[complete_cycle_slow['data_count']>=3]



# Filter for fast wear belts
belt_wear_fast = pds_model_df[pds_model_df['areaName'].isin(['BCV420','BCV502','BCV503','BCV501','BCV110', 'BF0401', 'BF0402', 
                                                             'CV15 (SK0501)', 'CV18 (SK0502)', 'CV21 (RC0601)'])]

# Filter for slow wear belts
belt_wear_slow = pds_model_df[~pds_model_df['areaName'].isin(['BCV420','BCV502','BCV503','BCV501','BCV110', 'BF0401', 'BF0402', 
                                                             'CV15 (SK0501)', 'CV18 (SK0502)', 'CV21 (RC0601)'])]

print('belt_wear_fast shape ----', belt_wear_fast.shape)
print('belt_wear_slow shape ----', belt_wear_slow.shape)

print('complete_cycle_fast shape ----', complete_cycle_fast.shape)
print('complete_cycle_slow shape ----', complete_cycle_slow.shape)

#### Export interim outputs
belt_wear_fast.to_csv(output_folder+'/belt_wear_fast.csv', index=False)
belt_wear_slow.to_csv(output_folder+'/belt_wear_slow.csv', index=False)

complete_cycle_fast.to_csv(output_folder+'/complete_cycle_fast.csv', index=False)
complete_cycle_slow.to_csv(output_folder+'/complete_cycle_slow.csv', index=False)

print('Code Complete !')


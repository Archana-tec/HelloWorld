import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Dataset
import argparse
from azureml.core import Run
from pyspark.sql.types import IntegerType, DoubleType, StructField, StructType, TimestampType, LongType, StringType


start_time = datetime.datetime.now()

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--alarms")
parser.add_argument("--environment")
parser.add_argument("--output_dir")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.parquet.enableVectorizedReader", "false")

print(f"[{datetime.datetime.now()}] Input Mount point from arguments: {args.alarms}")
print(f"[{datetime.datetime.now()}] Output Mount point from arguments: {args.output_dir}")

input_mount_point = args.alarms
output_dir = args.output_dir.replace('.blob.', '.dfs.')
output_dir = output_dir.replace('wasbs', 'abfss')

### ALARMS LOAD ###
sdf_alarms2 = None
try:
    print(f"[{datetime.datetime.now()}] Reading the latest date from previous data load ...")
    current_alarms_file = spark.read.parquet(output_dir + '/alarms/**')
    current_alarms_max_date = current_alarms_file.select(max('vt_start')).first()[0]
    period_start_utc = current_alarms_max_date - datetime.timedelta(days=1)
    sdf_alarms2 = current_alarms_file.alias('sdf_alarms2')
except:
    period_start_utc = datetime.datetime(2022, 7, 1)   # default to start of July if no file is found

# The pipeline runs every day at 5AM
period_end_utc = datetime.datetime.now()

# this part is used to handle sync delay between prod and dev
if args.environment=='DEV':
    if period_end_utc.hour < 6:
        period_end_utc = period_end_utc.replace(hour=0, minute=0, second=0, microsecond=0) - datetime.timedelta(seconds=1)

print(f'[{datetime.datetime.now()}] Start Date: {period_start_utc.strftime("%Y-%m-%d")}')
print(f'[{datetime.datetime.now()}] End Date: {period_end_utc.strftime("%Y-%m-%d")}')

# Create hdfs date range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
print(f'[{datetime.datetime.now()}] Tags range: {date_range}')

# Load PCS Tags and append to previous iterations
dr = (date_range.replace("{", "").replace("}", "").replace("*", "")).split(",")
sources = [input_mount_point + sub + "*" for sub in dr] # replace * with / for parquet source
sources = [x.replace('blob', 'dfs') for x in sources]
sources = [x.replace('wasbs', 'abfss') for x in sources]
print(f'[{datetime.datetime.now()}] Sources: {sources}')

# print(f"[{datetime.datetime.now()}] Going to read parquet files ...")
# sdf_alarms = spark.read.parquet(*pq_sources)
# print(f"[{datetime.datetime.now()}] Finished reading parquet files ... ")

# print(f"[{datetime.datetime.now()}] Going to read json files ...")
# sdf_alarms = spark.read.option("multiline", "true").json(sources).withColumn("filename", input_file_name())
# print(f"[{datetime.datetime.now()}] Finished reading json files ... ")
# sdf_alarms = load_ADA_data.NormaliseJsonSpark(sdf_alarms).normalise_alarms_spark()
#

sdf_alarms = None

for source in sources:
    print(f"[{datetime.datetime.now()}] Going to read json file {source} ...")
    try:
        if sdf_alarms is None:
            sdf_alarms_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_alarms_temp = load_ADA_data.NormaliseJsonSpark(sdf_alarms_temp).normalise_alarms_spark()
            sdf_alarms = sdf_alarms_temp.alias('sdf_alarms')
        else:
            sdf_alarms_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_alarms_temp = load_ADA_data.NormaliseJsonSpark(sdf_alarms_temp).normalise_alarms_spark()
            sdf_alarms = sdf_alarms.union(sdf_alarms_temp)
    except Exception as e:
        print(f"[{datetime.datetime.now()}] Failed to read json file {source}: {e}")
print(f"[{datetime.datetime.now()}] Finished reading json files ... ")


sdf_alarms = sdf_alarms.withColumn("eventid", col("eventid").cast(LongType()))
sdf_alarms = sdf_alarms.withColumn("tagname", col("tagname").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("unit", col("unit").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("description", col("description").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("area", col("area").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("name", col("name").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("vt_start", to_timestamp("vt_start"))
sdf_alarms = sdf_alarms.withColumn("vt_end", to_timestamp("vt_end"))
sdf_alarms = sdf_alarms.withColumn("priority", col("priority").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("message", col("message").cast(StringType()))
sdf_alarms = sdf_alarms.withColumn("file_timestamp", col("file_timestamp").cast(StringType()))

if sdf_alarms2 is None:
    print(f"[{datetime.datetime.now()}] Going to read the old Alarms data ...")
    sdf_alarms2 = spark.read.parquet(output_dir + '/alarms')
    print(f"[{datetime.datetime.now()}] Finished reading the old Alarms data ...")

sdf_alarms2.createOrReplaceTempView("old_alarm_df")
sdf_alarms.createOrReplaceTempView("new_alarm_df")

# print(f'Count of existing data in alarms folder: {sdf_alarms2.count()}')
# print(f'Count of the output of normalise_alarms_spark: {sdf_alarms.count()}')

new_alarm_data = spark.sql("""
            select n.*
            from  new_alarm_df n
            where not exists (
                select * from old_alarm_df o 
                where o.eventid = n.eventid
                  and o.tagname = n.tagname
                  and o.unit = n.unit
                  and o.description = n.description
                  and o.area = n.area
                  and o.name = n.name
                  and o.vt_start = n.vt_start
                  and o.vt_end = n.vt_end
                  and o.priority = n.priority
                  and o.message = n.message
            )
""")

# print(f'Count of the new unique alarm data: {new_alarm_data.count()}')

print(f"[{datetime.datetime.now()}] Going to append the new data into the Alarms data ...")
new_alarm_data.write.mode('append').parquet(f'{output_dir}/alarms')

print(f'[{datetime.datetime.now()}] Optimization - Start reading parquet...')
df = spark.read.parquet(f'{output_dir}/alarms')
df = df.dropDuplicates(['eventid', 'tagname', 'unit', 'description', 'area', 'name', 'vt_start', 'vt_end', 'priority', 'message'])


print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df.repartition(50).write.mode('overwrite').parquet(f'{output_dir}_temp/alarms')

print(f'[{datetime.datetime.now()}] Optimization - Moving to actual table ...')
df2 = spark.read.parquet(f'{output_dir}_temp/alarms')

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df2.repartition(50).write.mode('overwrite').parquet(f'{output_dir}/alarms')

print(f"[{datetime.datetime.now()}] Alarms load complete.")
end_time = datetime.datetime.now()
print(f"[{datetime.datetime.now()}] DONE in {(end_time-start_time)}...")
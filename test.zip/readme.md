# Gudai-Darri Advanced Data Analytics: Model Repository

## 1) Introduction 

Gudai-Darri (Koodaideri) is being developed as an ‘intelligent mine’ with a high emphasis on technology and innovation to deliver operational improvements. 
The Advanced Data Analytics (ADA) workstream has been established to provide near real time decision support and future projections for a range of business use cases. 
These seek to optimise assets and processes, improving quality and reliability and preventing failures – all of which increase productivity.
<br><br>
This repositiory contains the model code for the first 3 use cases of the Advanced Data Analytics project:<br>
- Use Case 1: Train Load Out Forecasting<br>
- Use Case 2: Conveyor Downtime Prediction<br>
- Use Case 3: Wear Rate Forecasting (Belts, Apron Feeders and Liners)<br>

## 2) Repository Structure

Overview of folders and files in the Repository:
- <b>ADA_UC1_TLO:</b> Model source code for Use Case 1: TLO Forecasting
- <b>ADA_UC2_CDP:</b> Model source code for Use Case 2: Conveyor Downtime Prediction
- <b>ADA_UC3_WRF:</b> Model source code for Use Case 3: Wear Rate Forecasting
- <b>ADA_ADO:</b> Model deployment files for Azure DevOps pipeline deployments
- <b>IAC:</b> Infrastructure deployment files for Azure DevOps pipeline deployments (Infrastructure as Code)
- <b>config:</b> Configuration parameters referenced by model source code
- <b>load_ADA_data.py:</b> Library of common functions to access ADA input data (file based) and transform it to a tabular format appropriate for analysis and model inputs. Used across all use cases
- <b>daily_data_load_pipeline.py:</b> Source code for a daily data transformation pipeline which converts PCS Tag and Alarm json files to Parquet format, significantly reducing training pipeline run times. These two datasets are specifically targeted due to their high volume of data.


## 3) Technical Overview

All three use cases are deployed on the PACE Azure platform, predominantly using Azure Machine Learning for model training and inference. 
Key components in the solution are linked below, however this is not exhaustive. See the ADA Technial Architecture document for a full description of all Azure services required.

<b>Resource Groups:</b> These contain all Azure services required for the solution<br>
- [Dev Resource Group](https://portal.azure.com/#@riotinto.onmicrosoft.com/resource/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-rtio-ada/overview)
- [Prod Resource Group](https://portal.azure.com/#@riotinto.onmicrosoft.com/resource/subscriptions/73a47890-99f5-4d07-a74b-b33243ab840f/resourceGroups/arg-rt-paceprd-rtio-ada/overview)

<b>Azure Machine Learning:</b> Model training and inference
- [Dev Environment - Azure Machine Learning](https://ml.azure.com/?wsid=/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourcegroups/arg-rt-pacedev-rtio-ada/workspaces/mlw-rt-dsdev-ae-rtio-ada02) - Primary workspace for project Data Scientists for model development
- [UAT Environment - Azure Machine Learning](https://ml.azure.com/?wsid=/subscriptions/73a47890-99f5-4d07-a74b-b33243ab840f/resourcegroups/arg-rt-paceprd-rtio-ada/providers/Microsoft.MachineLearningServices/workspaces/mlw-ae-dsprod-rtio-ada01) - Pre-Prod environment within the Prod Resource Group, where production model training takes place and inference is tested
- [Prod Environment - Azure Machine Learning](https://ml.azure.com/?wsid=/subscriptions/73a47890-99f5-4d07-a74b-b33243ab840f/resourcegroups/arg-rt-paceprd-rtio-ada/providers/Microsoft.MachineLearningServices/workspaces/mlw-ae-dsprod-rtio-ada02) - Inference only, final deployed models

<b>Azure Data Lake Storage:</b> Data lake containing input data and model results
- [Prod - ADA Landed Data Storage Container](https://portal.azure.com/#view/Microsoft_Azure_Storage/ContainerMenuBlade/~/overview/storageAccountId/%2Fsubscriptions%2F73a47890-99f5-4d07-a74b-b33243ab840f%2FresourceGroups%2Farg-rt-paceprd-rtio-ada%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fsrtdsprdrtioada01/path/ada-landed-data-storage-prod/etag/%220x8DA03201ACC2DE4%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride~/false/defaultId//publicAccessVal/None) - Input data for all ADA use cases. Accessed from the Dev, UAT and Prod environments
- [UAT - ADA Results Container](https://portal.azure.com/#view/Microsoft_Azure_Storage/ContainerMenuBlade/~/overview/storageAccountId/%2Fsubscriptions%2F73a47890-99f5-4d07-a74b-b33243ab840f%2FresourceGroups%2Farg-rt-paceprd-rtio-ada%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fsrtdsprdrtioada01/path/ada-results-storage-uat/etag/%220x8DAADD4EAE8CFEE%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride~/false/defaultId//publicAccessVal/None) - Model results from the UAT inference pipelines
- [Prod - ADA Results Container](https://portal.azure.com/#view/Microsoft_Azure_Storage/ContainerMenuBlade/~/overview/storageAccountId/%2Fsubscriptions%2F73a47890-99f5-4d07-a74b-b33243ab840f%2FresourceGroups%2Farg-rt-paceprd-rtio-ada%2Fproviders%2FMicrosoft.Storage%2FstorageAccounts%2Fsrtdsprdrtioada01/path/ada-results-storage-prod/etag/%220x8DA5E3CCBEE5A43%22/defaultEncryptionScope/%24account-encryption-key/denyEncryptionScopeOverride~/false/defaultId//publicAccessVal/None) - Model results from the Prod inference pipelines

<b>Azure SQL:</b> SQL database for final storage of model results before Visualisation layer
- [Prod - SQL Database](https://portal.azure.com/#@riotinto.onmicrosoft.com/resource/subscriptions/73a47890-99f5-4d07-a74b-b33243ab840f/resourceGroups/arg-rt-paceprd-rtio-ada/providers/Microsoft.Sql/servers/sql-ae-dsprod-rtio-ada01-hqka26bdoteqw/overview)
- [Dev - SQL Database](https://portal.azure.com/#@riotinto.onmicrosoft.com/resource/subscriptions/7704663e-8944-4300-b951-6462d41ab638/resourceGroups/arg-rt-pacedev-rtio-ada/providers/Microsoft.Sql/servers/sql-rt-dsdev-ae-rtio-uy7isegoogtxe/overview)


## 4) Build and Test

See readme files in each of the use case folders for instructions on how to run the model code.
<br><br>
<b>Software Dependencies</b><br>
All three use cases are written in Python. Specific package and version dependencies for running the use cases are managed using the 'Environments' capability of Azure Machine Learning,
using a Docker file base and Conda dependencies. The Environments are deployed via Azure DevOps pipeline (see ADA_ADO folder), and are then used for model training and inferencing.

## 5) Contributing 

Contributions to this Repo must be made in a Branch, and then merged with the main Branch via a Pull Request. Direct commits into the main Branch are not possible. 
All Pull Requests into the main Branch require approval from 2 distinct team members.

## 6) PoC Branch

The Proof of Concept branch (PoC) is retained for reference purposes only, and is not directly used in the Gudai-Darri deployments in any way. 

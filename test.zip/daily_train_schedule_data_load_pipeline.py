import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Dataset
import argparse
from azureml.core import Run
from pyspark.sql.types import IntegerType, DoubleType, StructField, StructType, TimestampType, LongType, StringType

start_time = datetime.datetime.now()

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--train_schedule")
parser.add_argument("--environment")
parser.add_argument("--output_dir")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.parquet.enableVectorizedReader","false")

print(f"[{datetime.datetime.now()}] Input Mount point from arguments: {args.train_schedule}")
print(f"[{datetime.datetime.now()}] Output Mount point from arguments: {args.output_dir}")

input_mount_point = args.train_schedule
output_dir = args.output_dir.replace('.blob.', '.dfs.')
output_dir = output_dir.replace('wasbs', 'abfss')

### TRAIN SCHEDULE LOAD ###
sdf_ts2 = None
try:
    print(f"[{datetime.datetime.now()}] Reading the latest date from previous data load ...")
    current_ts_file = spark.read.parquet(output_dir+'/train_schedule')
    current_ts_max_date = current_ts_file.select(max('UPDATED_ON_UTC')).first()[0]
    period_start_utc = current_ts_max_date - datetime.timedelta(days=1)
    sdf_ts2 = current_ts_file.alias('sdf_ts2')
except:
    period_start_utc = datetime.datetime(2022,7,1) # default to start of July if no file is found

# The pipeline runs every day at 5AM
period_end_utc = datetime.datetime.now()

# this part is used to handle sync delay between prod and dev
if args.environment=='DEV':
    if period_end_utc.hour < 6:
        period_end_utc = period_end_utc.replace(hour=0, minute=0, second=0, microsecond=0) - datetime.timedelta(seconds=1)

print(f'[{datetime.datetime.now()}] Start Date: {period_start_utc.strftime("%Y-%m-%d")}')
print(f'[{datetime.datetime.now()}] End Date: {period_end_utc.strftime("%Y-%m-%d")}')

# Create hdfs date range
date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
print(f'[{datetime.datetime.now()}] Trains schedule date range: {date_range}')

# Load PCS Tags and append to previous iterations
dr = (date_range.replace("{", "").replace("}", "").replace("*", "")).split(",")
sources = [input_mount_point + sub + "*" for sub in dr] # replace * with / for parquet source
sources = [x.replace('blob', 'dfs') for x in sources]
sources = [x.replace('wasbs', 'abfss') for x in sources]
print(f'[{datetime.datetime.now()}] Sources: {sources}')

# print(f"[{datetime.datetime.now()}] Going to read parquet files ...")
# sdf_ts = spark.read.parquet(*pq_sources)
# print(f"[{datetime.datetime.now()}] Finished reading parquet files ... ")
# print(f"[{datetime.datetime.now()}] Going to read json files ...")
# sdf_ts = spark.read.option("multiline", "true").json(sources).withColumn("filename", input_file_name())
# print(f"[{datetime.datetime.now()}] Finished reading json files ... ")
# sdf_ts = load_ADA_data.NormaliseJsonSpark(sdf_ts).normalise_trainschedule_spark()

sdf_ts = None

for source in sources:
    print(f"[{datetime.datetime.now()}] Going to read json file {source} ...")
    try:
        if sdf_ts is None:
            sdf_ts_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_ts_temp = load_ADA_data.NormaliseJsonSpark(sdf_ts_temp).normalise_trainschedule_spark()
            sdf_ts = sdf_ts_temp.alias('sdf_ts')
        else:
            sdf_ts_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_ts_temp = load_ADA_data.NormaliseJsonSpark(sdf_ts_temp).normalise_trainschedule_spark()
            sdf_ts = sdf_ts.union(sdf_ts_temp)
    except Exception as e:
        print(f"[{datetime.datetime.now()}] Failed to read json file {source}: {e}")
print(f"[{datetime.datetime.now()}] Finished reading json files ... ")



sdf_ts = sdf_ts.withColumn("UPDATED_ON_UTC", to_timestamp("UPDATED_ON_UTC"))
sdf_ts = sdf_ts.withColumn("PLANNED_ARRIVAL_TIME_UTC", to_timestamp("PLANNED_ARRIVAL_TIME_UTC"))
sdf_ts = sdf_ts.withColumn("PLANNED_COMMENCE_LOAD_UTC", to_timestamp("PLANNED_COMMENCE_LOAD_UTC"))
sdf_ts = sdf_ts.withColumn("PLANNED_COMPLETE_LOAD_UTC", to_timestamp("PLANNED_COMPLETE_LOAD_UTC"))
sdf_ts = sdf_ts.withColumn("PLANNED_DEPARTURE_TIME_UTC", to_timestamp("PLANNED_DEPARTURE_TIME_UTC"))
sdf_ts = sdf_ts.withColumn("TD_ACT_ARRIVALTIME", to_timestamp("TD_ACT_ARRIVALTIME"))
sdf_ts = sdf_ts.withColumn("TD_ACT_COMMLOAD", to_timestamp("TD_ACT_COMMLOAD"))
sdf_ts = sdf_ts.withColumn("TD_ACT_COMPLOAD", to_timestamp("TD_ACT_COMPLOAD"))
sdf_ts = sdf_ts.withColumn("TD_ACT_DEPMINE", to_timestamp("TD_ACT_DEPMINE"))
sdf_ts = sdf_ts.withColumn("CREATED_ON_UTC", to_timestamp("CREATED_ON_UTC"))
sdf_ts = sdf_ts.withColumn("DELETED_ON_UTC", to_timestamp("DELETED_ON_UTC"))
sdf_ts = sdf_ts.withColumn("SCHEDULE_TRAIN_ID", col("SCHEDULE_TRAIN_ID").cast(LongType()))
sdf_ts = sdf_ts.withColumn("NUMBER_OF_CARS", col("NUMBER_OF_CARS").cast(LongType()))
sdf_ts = sdf_ts.withColumn("NUMBER_OF_CARS_COMPLETED", col("NUMBER_OF_CARS_COMPLETED").cast(LongType()))
sdf_ts = sdf_ts.withColumn("TRAIN_ID", col("TRAIN_ID").cast(StringType()))
sdf_ts = sdf_ts.withColumn("LOCOS", col("LOCOS").cast(StringType()))
sdf_ts = sdf_ts.withColumn("file_timestamp", col("file_timestamp").cast(StringType()))
sdf_ts = sdf_ts.withColumn("PRODUCT_NAME", col("PRODUCT_NAME").cast(StringType()))
sdf_ts = sdf_ts.withColumn("TRAINSTATUS", col("TRAINSTATUS").cast(StringType()))

if sdf_ts2 is None:
    print(f"[{datetime.datetime.now()}] Going to read the old train_schedule data ...")
    sdf_ts2 = spark.read.parquet(output_dir+'/train_schedule')
    print(f"[{datetime.datetime.now()}] Finished reading the old train_schedule data ...")

sdf_ts2.createOrReplaceTempView("old_df")
sdf_ts.createOrReplaceTempView("new_df")

new_data = spark.sql("""
            select n.*
            from  new_df n
            where not exists (
                select * from old_df o 
                where o.SCHEDULE_TRAIN_ID = n.SCHEDULE_TRAIN_ID
                  and o.TRAIN_ID = n.TRAIN_ID
                  and o.UPDATED_ON_UTC = n.UPDATED_ON_UTC
                  and o.PLANNED_ARRIVAL_TIME_UTC= n.PLANNED_ARRIVAL_TIME_UTC
                  and o.PLANNED_COMMENCE_LOAD_UTC = n.PLANNED_COMMENCE_LOAD_UTC
                  and o.PLANNED_COMPLETE_LOAD_UTC = n.PLANNED_COMPLETE_LOAD_UTC
                  and o.PLANNED_DEPARTURE_TIME_UTC = n.PLANNED_DEPARTURE_TIME_UTC
                  and o.TD_ACT_ARRIVALTIME = n.TD_ACT_ARRIVALTIME
                  and o.TD_ACT_COMMLOAD = n.TD_ACT_COMMLOAD
                  and o.TD_ACT_COMPLOAD = n.TD_ACT_COMPLOAD
                  and o.TD_ACT_DEPMINE= n.TD_ACT_DEPMINE
                  and o.CREATED_ON_UTC= n.CREATED_ON_UTC
                  and o.DELETED_ON_UTC= n.DELETED_ON_UTC
                  and o.NUMBER_OF_CARS= n.NUMBER_OF_CARS
                  and o.NUMBER_OF_CARS_COMPLETED= n.NUMBER_OF_CARS_COMPLETED
                  and o.LOCOS= n.LOCOS
                  and o.PRODUCT_NAME = n.PRODUCT_NAME
                  and o.TRAINSTATUS = n.TRAINSTATUS
            )
""")

print(f"[{datetime.datetime.now()}] Going to append the new data into the Train Schedule data ...")
new_data.write.mode('append').parquet(f'{output_dir}/train_schedule')

print(f'[{datetime.datetime.now()}] Optimization - Start reading parquet...')
df = spark.read.parquet(f'{output_dir}/train_schedule')
df = df.dropDuplicates(['SCHEDULE_TRAIN_ID', 'TRAIN_ID', 'LOCOS', 'NUMBER_OF_CARS',
                                  'NUMBER_OF_CARS_COMPLETED', 'PRODUCT_NAME', 'PLANNED_ARRIVAL_TIME_UTC',
                                  'PLANNED_COMMENCE_LOAD_UTC', 'PLANNED_COMPLETE_LOAD_UTC',
                                  'PLANNED_DEPARTURE_TIME_UTC', 'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                                  'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE', 'TRAINSTATUS', 'CREATED_ON_UTC',
                                  'UPDATED_ON_UTC', 'DELETED_ON_UTC'])

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df.repartition(50).write.mode('overwrite').parquet(f'{output_dir}_temp/train_schedule')

print(f'[{datetime.datetime.now()}] Optimization - Moving to actual table ...')
df2 = spark.read.parquet(f'{output_dir}_temp/train_schedule')

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df2.repartition(50).write.mode('overwrite').parquet(f'{output_dir}/train_schedule')

print(f"[{datetime.datetime.now()}] Train schedule load complete.")
end_time = datetime.datetime.now()
print(f"[{datetime.datetime.now()}] DONE in {(end_time-start_time)}...")
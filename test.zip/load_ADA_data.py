# -*- coding: utf-8 -*-
"""
Created on Tues June 21 2022

@author: Ruoyu.Zhao
"""

import pandas as pd
import json
import os
import datetime
import tempfile
import configparser
import shutil
# azureml-core of version 1.0.72 or higher is required
from azureml.core import Workspace, Dataset, Datastore
from azure.storage.blob import BlobServiceClient
from azureml.dataprep.api.errorhandlers import ExecutionError
from pyspark.sql import SQLContext, SparkSession
from pyspark.sql.functions import *
from azureml.core.authentication import ServicePrincipalAuthentication

from key_vault_reader import KeyVaultReader


class NormaliseJson:
    def __init__(self, filename):
        self.filename = filename
        with open(self.filename) as f:
            self.data = json.load(f)

        self.table = pd.json_normalize(self.data)

    def normalise_tag(self):
        df = pd.DataFrame()

        for i in range(len(self.table)):
            temp = pd.json_normalize(self.table.loc[i, 'Items'])
            df = df.append(temp)

        output = df[['Name', 'Value.Timestamp', 'Value.Value']].reset_index(drop=True)
        output.rename(columns={'Name': 'tagid', 'Value.Timestamp': 'time_rio', 'Value.Value': 'value_rio'},
                      inplace=True)
        output.time_rio = pd.to_datetime(output.time_rio)
        output = output.assign(time_rio=output.time_rio.dt.round('s'))  # adjust datetime rounding

        return output

    def normalise_trainschedule(self):
        x = self.table.loc[0, 'data.OreData.Data']

        output = pd.json_normalize(x)
        # Columns in Scope
        col = ['SCHEDULE_TRAIN_ID', 'TRAIN_ID', 'LOCOS', 'NUMBER_OF_CARS',
               'NUMBER_OF_CARS_COMPLETED', 'PRODUCT_NAME',
               'PLANNED_ARRIVAL_TIME_UTC', 'PLANNED_COMMENCE_LOAD_UTC',
               'PLANNED_COMPLETE_LOAD_UTC', 'PLANNED_DEPARTURE_TIME_UTC',
               'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
               'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE', 'TRAINSTATUS',
               'CREATED_ON_UTC', 'UPDATED_ON_UTC', 'DELETED_ON_UTC']

        # Take only those columns above and sort values
        output = output[col]
        output.sort_values(by='PLANNED_ARRIVAL_TIME_UTC', inplace=True)

        return output

    def normalise_fptu(self):
        x = self.table.loc[0, 'ResultSet']
        x = pd.json_normalize(x)
        x = x.loc[0, 'Data']
        output = pd.json_normalize(x)

        return output

    def normalise_alarms(self):
        x = self.table.loc[0, 'Data.ResultSet']
        x = pd.json_normalize(x)
        x = x.loc[0, 'Data']

        output = pd.json_normalize(x)
        # Select only columns required:
        col = ['eventid', 'tagname', 'unit', 'description',
               'area', 'name', 'vt_start', 'vt_end',
               'priority', 'message']

        return output[col]

    def normalise_stockpile_builds(self):
        output = self.table

        return output

    def normalise_weather(self):
        x = self.table.loc[0, 'data.weather.countries.country.location.point_forecast']
        table2 = pd.json_normalize(x)
        table2['forecast_location'] = self.table.loc[0, 'data.weather.countries.country.location.name']
        table2['forecast_at_time_utc'] = self.table.loc[0, 'MessageHeader.dateTime']
        table2.forecast_at_time_utc = pd.to_datetime(table2.forecast_at_time_utc)

        table2.rename(columns={'wind_dir_degrees.value': 'wind_dir_degrees', 'utc_time': 'forecast_for_time_utc', \
                               'cloud_cover_percent.value': 'cloud_cover_perc',
                               'feels_like_c.value': 'feels_like_temp_c', \
                               'wind_speed_kph.value': 'wind_speed_kph', 'wind_gust_kph.value': 'wind_gust_kph', \
                               'pressure_msl_hpa.value': 'pressure_msl_hpa',
                               'rain_rate_mm.value': 'rain_rate_mm_per_hour', \
                               'prob_precip.value': 'prob_precip_perc', 'temp_c.value': 'temp_c',
                               'rh.value': 'rel_humity_perc'}, inplace=True)

        output = table2[
            ['forecast_location', 'forecast_at_time_utc', 'forecast_for_time_utc', 'temp_c', 'feels_like_temp_c',
             'rel_humity_perc', 'wind_dir_compass', \
             'wind_dir_degrees', 'wind_speed_kph', 'wind_gust_kph', 'pressure_msl_hpa', 'cloud_cover_perc',
             'prob_precip_perc', \
             'rain_rate_mm_per_hour']]

        return output

    def normalise_pds(self):
        x = self.table.loc[0, 'data']
        output = pd.json_normalize(x)
        output.lastSavedDateTime = pd.to_datetime(output.lastSavedDateTime)
        output.testDate = pd.to_datetime(output.testDate)

        return output


class NormaliseJsonSpark:
    def __init__(self, sdf):
        self.sdf = sdf

    def normalise_tags_spark(self):
        sdf = self.sdf.withColumn("normalize", explode("Items"))

        sdf = sdf.withColumn("tagid", col("normalize.Name")) \
            .withColumn("timestamp", col("normalize.Value.Timestamp")) \
            .withColumn("time_rio", to_timestamp("timestamp")) \
            .withColumn("time_rio", date_trunc("second", col("time_rio"))) \
            .withColumn("value_rio", col("normalize.Value.Value")) \
            .withColumn("file_timestamp", col("filename").substr(-33, 19))

        sdf = sdf.orderBy("time_rio")
        sdf = sdf.filter(~col("value_rio").contains("{"))
        sdf = sdf.select("tagid", "time_rio", "value_rio", "file_timestamp")
        sdf = sdf.dropDuplicates(['tagid', 'time_rio', 'value_rio'])

        return sdf

    def normalise_alarms_spark(self):
        sdf = self.sdf.withColumn("normalize", explode("Data.ResultSet")) \
            .withColumn("normalize2", explode("normalize.Data"))

        sdf = sdf.withColumn("eventid", col("normalize2.eventid")) \
                    .withColumn("tagname", col("normalize2.tagname")) \
                    .withColumn("unit", col("normalize2.unit")) \
                    .withColumn("description", col("normalize2.description")) \
                    .withColumn("area", col("normalize2.area")) \
                    .withColumn("name", col("normalize2.name")) \
                    .withColumn("vt_start", col("normalize2.vt_start")) \
                    .withColumn("vt_end", col("normalize2.vt_end")) \
                    .withColumn("priority", col("normalize2.priority")) \
                    .withColumn("message", col("normalize2.message")) \
                    .withColumn("file_timestamp", col("filename").substr(-33, 19))

        sdf = sdf.select('eventid', 'tagname', 'unit', 'description',
                         'area', 'name', 'vt_start', 'vt_end',
                         'priority', 'message', "file_timestamp")

        sdf = sdf.orderBy("vt_start")

        sdf = sdf.dropDuplicates(
            ['eventid', 'tagname', 'unit', 'description', 'area', 'name', 'vt_start', 'vt_end', 'priority', 'message'])

        return sdf

    def normalise_trainschedule_spark(self):
        sdf = self.sdf.withColumn("normalize", explode("data.OreData.Data"))

        sdf = sdf.withColumn("SCHEDULE_TRAIN_ID", col("normalize.SCHEDULE_TRAIN_ID")) \
            .withColumn("TRAIN_ID", col("normalize.TRAIN_ID")) \
            .withColumn("LOCOS", col("normalize.LOCOS")) \
            .withColumn("TRAINSTATUS", col("normalize.TRAINSTATUS")) \
            .withColumn("NUMBER_OF_CARS", col("normalize.NUMBER_OF_CARS")) \
            .withColumn("NUMBER_OF_CARS_COMPLETED", col("normalize.NUMBER_OF_CARS_COMPLETED")) \
            .withColumn("PRODUCT_NAME", col("normalize.PRODUCT_NAME")) \
            .withColumn("PLANNED_ARRIVAL_TIME_UTC", col("normalize.PLANNED_ARRIVAL_TIME_UTC")) \
            .withColumn("PLANNED_COMMENCE_LOAD_UTC", col("normalize.PLANNED_COMMENCE_LOAD_UTC")) \
            .withColumn("PLANNED_COMPLETE_LOAD_UTC", col("normalize.PLANNED_COMPLETE_LOAD_UTC")) \
            .withColumn("PLANNED_DEPARTURE_TIME_UTC", col("normalize.PLANNED_DEPARTURE_TIME_UTC")) \
            .withColumn("PLANNED_ARRIVAL_TIME_UTC", col("normalize.PLANNED_ARRIVAL_TIME_UTC")) \
            .withColumn("TD_ACT_ARRIVALTIME", col("normalize.TD_ACT_ARRIVALTIME")) \
            .withColumn("TD_ACT_COMMLOAD", col("normalize.TD_ACT_COMMLOAD")) \
            .withColumn("TD_ACT_COMPLOAD", col("normalize.TD_ACT_COMPLOAD")) \
            .withColumn("TD_ACT_DEPMINE", col("normalize.TD_ACT_DEPMINE")) \
            .withColumn("CREATED_ON_UTC", col("normalize.CREATED_ON_UTC")) \
            .withColumn("UPDATED_ON_UTC", col("normalize.UPDATED_ON_UTC")) \
            .withColumn("DELETED_ON_UTC", col("normalize.DELETED_ON_UTC")) \
            .withColumn("file_timestamp", col("filename").substr(-33, 19))

        sdf = sdf.select('SCHEDULE_TRAIN_ID', 'TRAIN_ID', 'LOCOS', 'NUMBER_OF_CARS',
                         'NUMBER_OF_CARS_COMPLETED', 'PRODUCT_NAME', 'PLANNED_ARRIVAL_TIME_UTC',
                         'PLANNED_COMMENCE_LOAD_UTC', 'PLANNED_COMPLETE_LOAD_UTC',
                         'PLANNED_DEPARTURE_TIME_UTC', 'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                         'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE', 'TRAINSTATUS', 'CREATED_ON_UTC',
                         'UPDATED_ON_UTC', 'DELETED_ON_UTC', "file_timestamp")

        sdf = sdf.dropDuplicates(['SCHEDULE_TRAIN_ID', 'TRAIN_ID', 'LOCOS', 'NUMBER_OF_CARS',
                                  'NUMBER_OF_CARS_COMPLETED', 'PRODUCT_NAME', 'PLANNED_ARRIVAL_TIME_UTC',
                                  'PLANNED_COMMENCE_LOAD_UTC', 'PLANNED_COMPLETE_LOAD_UTC',
                                  'PLANNED_DEPARTURE_TIME_UTC', 'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                                  'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE', 'TRAINSTATUS', 'CREATED_ON_UTC',
                                  'UPDATED_ON_UTC', 'DELETED_ON_UTC'])

        return sdf

    def normalise_fptu_spark(self):
        sdf = self.sdf.withColumn("normalize", explode("ResultSet.Data")) \
            .withColumn("normalize2", explode("normalize"))

        sdf = sdf.withColumn("SourceIdentifier", col("normalize2.SourceIdentifier")) \
                    .withColumn("Shift_SK", col("normalize2.Shift_SK")) \
                    .withColumn("FixedPlantTimeUsageEventStart", col("normalize2.FixedPlantTimeUsageEventStart")) \
                    .withColumn("FixedPlantTimeUsageEventStart", to_timestamp("FixedPlantTimeUsageEventStart")) \
                    .withColumn("FixedPlantTimeUsageEventFinish", col("normalize2.FixedPlantTimeUsageEventFinish")) \
                    .withColumn("FixedPlantTimeUsageEventFinish", to_timestamp("FixedPlantTimeUsageEventFinish")) \
                    .withColumn("FixedPlantTimeUsageGroupEventStart",
                                col("normalize2.FixedPlantTimeUsageGroupEventStart")) \
                    .withColumn("FixedPlantTimeUsageGroupEventStart",
                                to_timestamp("FixedPlantTimeUsageGroupEventStart")) \
                    .withColumn("FixedPlantTimeUsageGroupEventFinish",
                                col("normalize2.FixedPlantTimeUsageGroupEventFinish")) \
                    .withColumn("FixedPlantTimeUsageGroupEventFinish",
                                to_timestamp("FixedPlantTimeUsageGroupEventFinish")) \
                    .withColumn("cTimeUsageGroupEvent", col("normalize2.cTimeUsageGroupEvent")) \
                    .withColumn("sTimeUsage", col("normalize2.sTimeUsage")) \
                    .withColumn("FixedPlantTimeUsageComments", col("normalize2.FixedPlantTimeUsageComments")) \
                    .withColumn("FixedPlantTimeUsageExplanation", col("normalize2.FixedPlantTimeUsageExplanation")) \
                    .withColumn("FixedPlantAssetCode", col("normalize2.FixedPlantAssetCode")) \
                    .withColumn("FixedPlantAssetDescription", col("normalize2.FixedPlantAssetDescription")) \
                    .withColumn("SubEquipment", col("normalize2.SubEquipment")) \
                    .withColumn("TPPSEquipmentCode", col("normalize2.TPPSEquipmentCode")) \
                    .withColumn("CauseFixedPlantAssetCode", col("normalize2.CauseFixedPlantAssetCode")) \
                    .withColumn("CauseFixedPlantAssetDescription", col("normalize2.CauseFixedPlantAssetDescription")) \
                    .withColumn("CauseArea", col("normalize2.CauseArea")) \
                    .withColumn("Cause", col("normalize2.Cause")) \
                    .withColumn("Effect", col("normalize2.Effect")) \
                    .withColumn("TPPSTrainId", col("normalize2.TPPSTrainId")) \
                    .withColumn("TUM0Code", col("normalize2.TUM0Code")) \
                    .withColumn("TUM0DisplayName", col("normalize2.TUM0DisplayName")) \
                    .withColumn("TUM1Code", col("normalize2.TUM1Code")) \
                    .withColumn("TUM1DisplayName", col("normalize2.TUM1DisplayName")) \
                    .withColumn("TUM5Code", col("normalize2.TUM5Code")) \
                    .withColumn("TUM5DisplayName", col("normalize2.TUM5DisplayName")) \
                    .withColumn("SourceUpdatedAt", col("normalize2.SourceUpdatedAt")) \
                    .withColumn("SourceUpdatedAt", to_timestamp("SourceUpdatedAt")) \
                    .withColumn("ModifiedAt", col("normalize2.ModifiedAt")) \
                    .withColumn("ModifiedAt", to_timestamp("ModifiedAt")) \
                    .withColumn("file_timestamp", col("filename").substr(-33, 19))

        sdf = sdf.select("SourceIdentifier", "Shift_SK", "FixedPlantTimeUsageEventStart",
                         "FixedPlantTimeUsageEventFinish", "FixedPlantTimeUsageGroupEventStart",
                         "FixedPlantTimeUsageGroupEventFinish", \
                         "cTimeUsageGroupEvent", "sTimeUsage", "FixedPlantTimeUsageComments",
                         "FixedPlantTimeUsageExplanation", "FixedPlantAssetCode", "FixedPlantAssetDescription",
                         "SubEquipment", \
                         "TPPSEquipmentCode", "CauseFixedPlantAssetCode", "CauseFixedPlantAssetDescription",
                         "CauseArea", "Cause", "Effect", "TPPSTrainId", "TUM0Code", "TUM0DisplayName", "TUM1Code", \
                         "TUM1DisplayName", "TUM5Code", "TUM5DisplayName", "SourceUpdatedAt", "ModifiedAt",
                         "file_timestamp")

        sdf = sdf.orderBy("FixedPlantTimeUsageEventStart")
        sdf = sdf.dropDuplicates(
            ["SourceIdentifier", "Shift_SK", "FixedPlantTimeUsageEventStart", "FixedPlantTimeUsageEventFinish",
             "FixedPlantTimeUsageGroupEventStart", "FixedPlantTimeUsageGroupEventFinish",
             "cTimeUsageGroupEvent", "sTimeUsage", "FixedPlantTimeUsageComments", "FixedPlantTimeUsageExplanation",
             "FixedPlantAssetCode", "FixedPlantAssetDescription", "SubEquipment",
             "TPPSEquipmentCode", "CauseFixedPlantAssetCode", "CauseFixedPlantAssetDescription", "CauseArea", "Cause",
             "Effect", "TPPSTrainId", "TUM0Code", "TUM0DisplayName", "TUM1Code",
             "TUM1DisplayName", "TUM5Code", "TUM5DisplayName", "SourceUpdatedAt", "ModifiedAt"])

        return sdf

    def normalise_weather_spark(self):
        sdf = self.sdf.withColumn('forecast_location', col('data.weather.countries.country.location.name')) \
            .withColumn('point_forecast', col('data.weather.countries.country.location.point_forecast')) \
            .withColumn('normalize', explode('point_forecast')) \
            .withColumn('forecast_at_time_utc', col('MessageHeader.dateTime')) \
            .withColumn('forecast_at_time_utc', to_timestamp('forecast_at_time_utc')) \
            .withColumn('forecast_for_time_utc', col('normalize.utc_time')) \
            .withColumn('temp_c', col('normalize.temp_c.value')) \
            .withColumn('feels_like_temp_c', col('normalize.feels_like_c.value')) \
            .withColumn('rel_humity_perc', col('normalize.rh.value')) \
            .withColumn('wind_dir_compass', col('normalize.wind_dir_compass')) \
            .withColumn('wind_dir_degrees', col('normalize.wind_dir_degrees.value')) \
            .withColumn('wind_speed_kph', col('normalize.wind_speed_kph.value')) \
            .withColumn('wind_gust_kph', col('normalize.wind_gust_kph.value')) \
            .withColumn('pressure_msl_hpa', col('normalize.pressure_msl_hpa.value')) \
            .withColumn('cloud_cover_perc', col('normalize.cloud_cover_percent.value')) \
            .withColumn('prob_precip_perc', col('normalize.prob_precip.value')) \
            .withColumn('rain_rate_mm_per_hour', col('normalize.rain_rate_mm.value'))

        sdf = sdf.select('forecast_location', 'forecast_at_time_utc', 'forecast_for_time_utc', 'temp_c',
                         'feels_like_temp_c', 'rel_humity_perc', 'wind_dir_compass', \
                         'wind_dir_degrees', 'wind_speed_kph', 'wind_gust_kph', 'pressure_msl_hpa', 'cloud_cover_perc',
                         'prob_precip_perc', \
                         'rain_rate_mm_per_hour')

        sdf = sdf.dropDuplicates(
            ['forecast_location', 'forecast_at_time_utc', 'forecast_for_time_utc', 'temp_c', 'feels_like_temp_c',
             'rel_humity_perc', 'wind_dir_compass', 'wind_dir_degrees', 'wind_speed_kph', 'wind_gust_kph',
             'pressure_msl_hpa', 'cloud_cover_perc',
             'prob_precip_perc', 'rain_rate_mm_per_hour'])

        return sdf

    def normalise_pds_spark(self):
        sdf = self.sdf.withColumn("normalize", explode(col("data"))).select("normalize.*") \
            .withColumn('lastSavedDateTime', to_timestamp('lastSavedDateTime')) \
            .withColumn('testDate', to_timestamp('testDate'))

        return sdf

    def normalise_wear_management_spark(self):
        sdf = self.sdf.withColumn("normalize", explode(col("Data"))).select("normalize.*") \
            .withColumn('lastSavedDateTime', to_timestamp('lastSavedDateTime')) \
            .withColumn('testDate', to_timestamp('testDate'))

        return sdf

    def normalise_wear_managementbelt_spark(self):
        sdf = self.sdf.withColumn("normalize", explode(col("data.changedRecords"))).select("normalize.*") \
            .withColumn('installDate', to_timestamp('installDate')) \
            .withColumn('lastSavedDateTime', to_timestamp('lastSavedDateTime')) \
            .withColumn('lastTestDate', to_timestamp('lastTestDate')) \
            .withColumn('originalDate', to_timestamp('originalDate'))

        return sdf

    def normalise_daily_mine_schedule_spark(self):
        sdf = self.sdf.withColumn("normalize", explode(col("ResultSet"))).select("normalize.*") \
            .withColumn("normalize2", explode(col("Data"))).select("normalize2.*") \
            .withColumn('ModifiedAt', to_timestamp('ModifiedAt')) \
            .withColumn('ProductionDate', to_timestamp('ProductionDate')) \
            .withColumn('SourceUpdatedAt', to_timestamp('SourceUpdatedAt'))

        return sdf

    def normalise_weekly_mine_schedule_spark(self):
        sdf = self.sdf.withColumn("normalize", explode(col("ResultSet"))).select("normalize.*") \
            .withColumn("normalize2", explode(col("Data"))).select("normalize2.*") \
            .withColumn('ModifiedAt', to_timestamp('ModifiedAt')) \
            .withColumn('ProductionDate', to_timestamp('ProductionDate')) \
            .withColumn('SourceUpdatedAt', to_timestamp('SourceUpdatedAt'))

        return sdf

    def normalise_shutdown_spark(self):
        sdf = self.sdf.select("data.*") \
            .withColumn("normalize", explode(col("equipments"))) \
            .select(["normalize.*", 'interface_id', 'shut_data.*'])

        return sdf


def hdfs_range(t1, t2):
    """
    inputs: 2 datetimes with t1 < t2
    outputs: A date range in the hdfs format for filtering data import by time between t1 and t2 with Spark

    """

    if t2 - t1 > datetime.timedelta(days=365 * 2):
        year_range = '202[' + str(t1)[3] + '-' + str(t2)[3] + ']'
        rng = year_range + '*'

    elif t2 - t1 > datetime.timedelta(days=30):
        def month_year_iter(start_month, start_year, end_month, end_year):
            ym_start = 12 * start_year + start_month - 1
            ym_end = 12 * end_year + end_month
            for ym in range(ym_start, ym_end):
                y, m = divmod(ym, 12)
                yield str(y) + '-' + str(m + 1).zfill(2)

        lst = list(month_year_iter(t1.month, t1.year, t2.month, t2.year))
        rng = '{'
        for i in range(len(lst)):
            rng = rng + (lst[i]) + ','

        rng = rng[:-1] + '}*'

    elif t2 - t1 > datetime.timedelta(days=1):
        rng = '{'
        while t1.date() <= t2.date():
            t = str(t1)[:10] + ','
            rng = rng + t
            t1 += datetime.timedelta(days=1)

        rng = rng[:-1] + '}*'

    elif t2 - t1 > datetime.timedelta(hours=1):
        rng = '{'
        while t1 <= t2:
            t = str(t1)[:10] + 'T' + str(t1)[11:13] + ','
            rng = rng + t
            t1 += datetime.timedelta(hours=1)

        rng = rng[:-1] + '}*'

    else:
        rng = '{'
        while t1 <= t2:
            t = str(t1)[:10] + 'T' + str(t1)[11:16] + ','
            rng = rng + t
            t1 += datetime.timedelta(minutes=1)

        rng = rng[:-1] + '}*'
        rng = rng.replace(':', '_')

    return rng


def hdfs_range_day(t1, t2):
    """
    inputs: 2 datetimes with t1 < t2
    outputs: A date range in the hdfs format for filtering data import by time between t1 and t2 with Spark

    """

    if t2 - t1 > datetime.timedelta(days=365 * 2):
        year_range = '202[' + str(t1)[3] + '-' + str(t2)[3] + ']'
        rng = year_range + '*'

    elif t2 - t1 > datetime.timedelta(days=30):
        def month_year_iter(start_month, start_year, end_month, end_year):
            ym_start = 12 * start_year + start_month - 1
            ym_end = 12 * end_year + end_month
            for ym in range(ym_start, ym_end):
                y, m = divmod(ym, 12)
                yield str(y) + '-' + str(m + 1).zfill(2)

        lst = list(month_year_iter(t1.month, t1.year, t2.month, t2.year))
        rng = '{'
        for i in range(len(lst)):
            rng = rng + (lst[i]) + ','

        rng = rng[:-1] + '}*'

    else:
        rng = '{'
        while t1.date() <= t2.date():
            t = str(t1)[:10] + ','
            rng = rng + t
            t1 += datetime.timedelta(days=1)

        rng = rng[:-1] + '}*'

    return rng


def blob_range(t1, t2, datastore_name, blob_folder, blob_prefix):
    """
    inputs:
        t1, t2: 2 datetimes with t1 < t2
        datastore_name: Datastore to load data from
        blob_folder: Dataset folder within the Datastore
        blob_prefix: Prefix of blobs before the timestamp
    outputs:
        blob_path_list: A list of blob path patterns with the above properties between the timestamps t1 and t2, for creation of FileDataset.
                        Blob path patterns are validated to ensure files exist in the datastore under each pattern
    """

    if t2 - t1 > datetime.timedelta(days=365 * 2):
        rng = [*range(t1.year, t2.year + 1)]

    elif t2 - t1 > datetime.timedelta(days=30):
        def month_year_iter(start_month, start_year, end_month, end_year):
            ym_start = 12 * start_year + start_month - 1
            ym_end = 12 * end_year + end_month
            for ym in range(ym_start, ym_end):
                y, m = divmod(ym, 12)
                yield str(y) + '-' + str(m + 1).zfill(2)

        rng = list(month_year_iter(t1.month, t1.year, t2.month, t2.year))

    elif t2 - t1 > datetime.timedelta(days=1):
        rng = [(t1 + datetime.timedelta(days=x)).strftime('%Y-%m-%d')
               for x in range((t2 - t1).days + 1)]

    elif t2 - t1 > datetime.timedelta(hours=1):
        rng = [(t1 + datetime.timedelta(hours=x)).strftime('%Y-%m-%dT%H')
               for x in range(int((t2 - t1).total_seconds() / 3600) + 1)]

    else:
        rng = [(t1 + datetime.timedelta(minutes=x)).strftime('%Y-%m-%dT%H_%M')
               for x in range(int((t2 - t1).total_seconds() / 60) + 1)]

    blob_path_list = [(datastore_name, blob_folder + "/" + blob_prefix + date + '**')
                      for date in rng]

    filtered_blob_path_list = []
    for blob_path in blob_path_list:
        dataset = Dataset.File.from_files(path=blob_path, validate=False)
        try:
            dataset_path_list = dataset.to_path()
            filtered_blob_path_list.append(blob_path)
        except ExecutionError as e:
            pass

    return filtered_blob_path_list


class LoadData:
    def __init__(self, dataset_name, timestamp, last_min, env, tag_list=[]):
        """
        inputs:
            dataset_name : Azure ML Registered Dataset Name
            timestamp: Timestamp of the load (in prod would be current timestamp) format YYYY-MM-DD HH:MM:SS
            last_min: Number of minutes before the timestamp, this defines the loading period [timestamp -lastmin, timestamp]
            tag_list: PCS tags list used for filtering tag data  (if loading PCS tag adata)
        """

        # Get Config locations and paths
        cfg_path = os.path.join(os.path.dirname(__file__), 'config/config-gd.ini')
        config_obj = configparser.ConfigParser()
        config_obj.read(cfg_path)

        # Environment - Workspace in which which the script is being executed in
        self.env = env
        print("cfg path:", cfg_path)
        print("env:", env)

        # Get credentials information
        cred_info = config_obj['credentials' + '_' + self.env]
        print("cred_info:", cred_info)
        subscription_id = cred_info['subscription_id']
        resource_group = cred_info['resource_group']
        workspace_name = cred_info['workspace_name']
        '''
        # Get dataset Config items 
        # Datasets from the Dev Landed Data Storage Container are prefaced with 'DEV'
        if dataset_name[:3] == 'DEV':
            # Define Workspace
            self.workspace = Workspace(subscription_id, resource_group, workspace_name) 
            self.datastore = Datastore.get(self.workspace, 'ada_landed_data_storage_dev') 
            Account_uri = config_obj['credentials_dev']['Account_uri']
            self.container_name = config_obj['credentials_dev']['container_name']
            # config_ds config items are common between Dev and Prod datasets
            config_ds = dataset_name.replace('DEV-','')

        # Prod datasets should be used the majority of the time, and should use Prod URI and container name from Prod environment, even if being accessed from the Dev workspace
        else:
        '''
        if env == 'dev':  ### env = {prod, uat, dev}
            #### Temporary solution while MS is fixing the search issue on PurView.
            # When it is fixed, commented line 556 and uncomment line 557
            storage_name_id = 'ada_landed_data_storage_prod_gen2'
            # storage_name_id = 'ada_landed_data_storage_dev'
            ###############################################
            kv_name = 'kv-rt-dsdev-ae-ada01'
            alt_env = 'dev'
        else:
            storage_name_id = 'ada_landed_data_storage_prod'
            kv_name = 'kvaedsprodrtioada'
            if env == 'prd':
                alt_env = 'prod'
            else:
                alt_env = 'uat'

        tenant_id = os.environ.get('adasprdtenantid')
        principal_id = os.environ.get('adaspprdclientid')
        client_secret = os.environ.get('adaspprdclientsecret')

        # Get Service Principle Credentials from environment variables
        try:  # try to autenticate to the workspace using service principals (uat and prd aks)
            sp = ServicePrincipalAuthentication(tenant_id=tenant_id,
                                                service_principal_id=principal_id,
                                                service_principal_password=client_secret)

            self.workspace = Workspace.get(name=workspace_name,
                                           auth=sp,
                                           subscription_id=subscription_id,
                                           resource_group=resource_group)
        except:  # for uat training pipeline
            self.workspace = Workspace(subscription_id, resource_group, workspace_name)

        kv_reader = KeyVaultReader(tenant_id=tenant_id,
                                   keyvault_name=kv_name)

        self.datastore = Datastore.get(self.workspace, storage_name_id)
        #### Temporary solution while MS is fixing the search issue on PurView.
        # When it is fixed, commented line 592 and uncomment line 593
        Account_uri = config_obj['credentials_prd']['Account_uri'] ### Erwin 19 April - why prd is hardcoded?
        # Account_uri = kv_reader.get_secret(f'config-sa-account-uri-{alt_env}')  ### env = {prod, uat, dev}
        #####################################

        #### Temporary solution while MS is fixing the search issue on PurView.
        # When it is fixed, commented line 598 and uncomment line 599
        self.container_name = 'ada-landed-data-storage-prod'
        # self.container_name = config_obj[f'credentials_{env}']['container_name']
        #####################################
        config_ds = dataset_name
        print(f'container name = {self.container_name}')

        # Get Blob,file and prefix info
        self.blob_folder = config_obj[config_ds]['blob_folder']
        self.file_prefix = config_obj[config_ds]['file_prefix']
        self.file_type = config_obj[config_ds]['file_type']

        print(f'blob_folder = {self.blob_folder}')
        print(f'file_prefix = {self.file_prefix}')
        print(f'file_type = {self.file_type}')

        # Connect to blob service client
        self.blob_service = BlobServiceClient.from_connection_string(Account_uri)
        # Connect to container client
        self.container_client = self.blob_service.get_container_client(self.container_name)
        # Get Dataset by path on Datastore
        self.dataset = Dataset.File.from_files(path=(self.datastore, self.blob_folder + '/**'), validate=False)
        # Create a temporary mount path for dataset
        self.mounted_path = tempfile.mkdtemp()
        # Timestamp of data extraction
        self.timestamp = timestamp
        # Minutes in advance of timestamp to extract data for
        self.last_min = last_min
        # Tags list for filtering when importing PCS tags
        self.tag_list = tag_list
        print(f'timestamp = {self.timestamp}')
        print(f'last_min = {self.last_min}')

    def find_all_files_with_prefix(self):
        """
        outputs:
            mounted_list: return the list of files from the mounted path that fall
                          in the loading period. [timestamp -lastmin, timestamp]
        """
        file_list = []
        ts = self.timestamp - datetime.timedelta(minutes=self.last_min)

        while ts <= self.timestamp:
            ts_date = str(ts.date())
            ts_HrMin = str(ts.time())
            prefix = self.blob_folder + "/" + self.file_prefix + ts_date + 'T' + ts_HrMin[
                                                                                 0:5]  # Ignore second in timestamp
            prefix = prefix.replace(':', '_')
            # print(prefix)
            blob_list = self.container_client.list_blobs(name_starts_with=prefix)
            for blob in blob_list:
                # Loop through each blob files
                blob_client = self.blob_service.get_blob_client(container=self.container_name, blob=blob.name)
                size = blob_client.get_blob_properties().size  # Get file size
                if ('.' + self.file_type in blob.name) & (
                        size > 1000):  # (ignore files that are empty and only take matching file type)
                    file_list.append(blob.name)

            ts = ts + datetime.timedelta(minutes=1)  # Loop through each minute

        # Convert file path into mounted path
        mounted_list = list(map(lambda x: x.replace(self.blob_folder, self.mounted_path), file_list))
        # Display how many files on the list
        print("Number of Files:" + str(len(file_list)))

        return mounted_list

    def read_all_files_into_dataframe(self, file_list, norm_fnc):
        """
        inputs:
            file_list: List of files to be combined
            norm_fnc: Json normalisation function
        outputs:
            df: Dataframe combining all of the data in the file list
        """
        df = pd.DataFrame()

        if self.file_type == 'json':
            # loop through all files and combine data into a dataframe
            for f in file_list:
                try:  # some json files are empty
                    temp = norm_fnc(NormaliseJson(f))
                    if self.file_prefix == 'KD-INT054_':  # indicating it is a tag file
                        temp = temp[temp['tagid'].isin(self.tag_list)]  # Only take specific tags
                    else:
                        pass
                    # Combined Dataframes & Remove all duplicated entries
                    df = df.append(temp).drop_duplicates()
                except:
                    pass
        else:  # can add other file type in the future
            pass
        print('Dataset is loaded into dataframe.')
        return df

    def load_data_to_df(self, data_load_method='mount'):
        # Get Normalisation function based on dataset
        ds_normfunc_dict = {'kd-int080-process-control-alarms-and-events': NormaliseJson.normalise_alarms,
                            'kd-int058-ordw-fixed-plant-time-usage-ada': NormaliseJson.normalise_fptu,
                            'kd-int071-tpps-train-schedule-ada': NormaliseJson.normalise_trainschedule,
                            'kd-int099-tpps-stockpile-builds-ada': NormaliseJson.normalise_stockpile_builds,
                            'kd-int054-process-control-data-from-osisoft-pi-ada': NormaliseJson.normalise_tag,
                            'kd-int056-weatherzone-forecasts-ada': NormaliseJson.normalise_weather,
                            'kd-int075-pds-ada': NormaliseJson.normalise_pds
                            }
        norm_func = ds_normfunc_dict.get(self.blob_folder)

        ts_start = self.timestamp - datetime.timedelta(minutes=self.last_min)

        # Use mount for long time periods
        if data_load_method == 'mount':
            # Get all Json file list
            file_list = self.find_all_files_with_prefix()
            # Mount Dataset
            data_mount = self.dataset.mount(self.mounted_path)
            data_mount.start()
            # read all files into dataframe
            df = self.read_all_files_into_dataframe(file_list, norm_func)
            df = df.reset_index(drop=True)
            # Unmount Dataset
            data_mount.stop()

        # Use download for short time periods i.e. inferencing
        elif data_load_method == 'download':
            blob_path_list = blob_range(ts_start, self.timestamp, self.datastore, self.blob_folder, self.file_prefix)
            dataset = Dataset.File.from_files(path=blob_path_list, validate=False)
            download_point = tempfile.mkdtemp()
            dataset.download(download_point)
            # Get file list from download directory
            file_list = []
            for root, dirs, files in os.walk(download_point):
                for name in files:
                    file_list.append(os.path.join(root, name))
            # Read all files into dataframe
            df = self.read_all_files_into_dataframe(file_list, norm_func)
            df = df.reset_index(drop=True)
            # Delete all file from the temp directory
            shutil.rmtree(download_point)
        return df

    def load_data_spark(self):
        # Get Spark normalisation function based on dataset
        ds_spark_normfunc_dict = {
            'kd-int080-process-control-alarms-and-events': NormaliseJsonSpark.normalise_alarms_spark,
            'kd-int058-ordw-fixed-plant-time-usage-ada': NormaliseJsonSpark.normalise_fptu_spark,
            'kd-int071-tpps-train-schedule-ada': NormaliseJsonSpark.normalise_trainschedule_spark,
            'kd-int054-process-control-data-from-osisoft-pi-ada': NormaliseJsonSpark.normalise_tags_spark,
            'kd-int056-weatherzone-forecasts-ada': NormaliseJsonSpark.normalise_weather_spark,
            'kd-int075-pds-ada': NormaliseJsonSpark.normalise_pds_spark,
            'kd-int101-wear-management-pds-ada': NormaliseJsonSpark.normalise_wear_management_spark,
            'kd-int102-wear-managementbelt-pds-ada': NormaliseJsonSpark.normalise_wear_managementbelt_spark,
            'kd-int064-ordw-daily-mine-schedule-ada': NormaliseJsonSpark.normalise_daily_mine_schedule_spark,
            'kd-int065-ordw-weekly-mine-schedule-ada': NormaliseJsonSpark.normalise_weekly_mine_schedule_spark,
            'kd-int066-msf-shutdown-plans-ada': NormaliseJsonSpark.normalise_shutdown_spark
            }

        norm_func = ds_spark_normfunc_dict.get(self.blob_folder)

        ts_start = self.timestamp - datetime.timedelta(minutes=self.last_min)

        path = "/" + self.file_prefix + hdfs_range(ts_start, self.timestamp)
        env = os.environ("ENV")
        if env == 'DEV':
            storage_name_id = 'ada_landed_data_storage_dev'
        else:
            storage_name_id = 'ada_landed_data_storage_prod'

        ada_prod = Datastore.get(self.workspace, storage_name_id)
        dataset = Dataset.File.from_files(path=(ada_prod, self.blob_folder + '/**'), validate=False)
        mountpoint = tempfile.mkdtemp()
        dataset_mnt = dataset.mount(mountpoint)
        dataset_mnt.start()

        spark = SparkSession.builder \
            .appName('app_name') \
            .master('local[*]') \
            .config('spark.sql.execution.arrow.pyspark.enabled', True) \
            .config('spark.sql.session.timeZone', 'UTC') \
            .config('spark.driver.memory', '32G') \
            .config('spark.ui.showConsoleProgress', True) \
            .config('spark.sql.repl.eagerEval.enabled', True) \
            .config('spark.driver.maxResultSize', '0') \
            .getOrCreate()

        sdf = spark.read.option("multiline", "true").json(mountpoint + path).withColumn("filename", input_file_name())

        sdf = norm_func((NormaliseJsonSpark(sdf)))

        if self.file_prefix == 'KD-INT054_':  # indicating it is a tag file
            results = sdf[sdf.tagid.isin(self.tag_list)]
            df = results.toPandas()
        else:
            df = sdf.toPandas()

        dataset_mnt.stop()

        return df


class LoadDataDirect:
    def __init__(self, dataset_name, timestamp, last_min, tag_list=[]):
        """
        inputs:
            dataset_name : Folder name on blob store
            timestamp: Timestamp of the load (in prod would be current timestamp) format YYYY-MM-DD HH:MM:SS
            last_min: Number of minutes before the timestamp, this defines the loading period [timestamp -lastmin, timestamp]
            tag_list: PCS tags list used for filtering tag data  (if loading PCS tag adata)
        """

        # Get Config locations and paths
        cfg_path = os.path.join(os.path.dirname(__file__), 'config/config-gd.ini')
        config_obj = configparser.ConfigParser()
        config_obj.read(cfg_path)

        # Get config items for the dataset
        # Account_uri = config_obj['credentials_prd']['Account_uri']

        if env == 'dev':  ### env = {prod, uat, dev}
            storage_name_id = 'ada_landed_data_storage_dev'
            kv_name = 'kv-rt-dsdev-ae-ada01'
            alt_env = 'dev'
        else:
            storage_name_id = 'ada_landed_data_storage_prod'
            kv_name = 'kvaedsprodrtioada'
            if env == 'prd':
                alt_env = 'prod'
            else:
                alt_env = 'uat'

        # As prd is hardcoded, the changes below assume the code is for prod env
        tenant_id = os.environ.get('adasprdtenantid')
        kv_reader = KeyVaultReader(tenant_id=tenant_id, keyvault_name=kv_name)
        Account_uri = kv_reader.get_secret(f'config-sa-account-uri-{alt_env}')

        self.container_name = config_obj[f'credentials_{env}']['container_name']
        self.blob_folder = config_obj[dataset_name]['blob_folder']
        self.file_prefix = config_obj[dataset_name]['file_prefix']
        self.file_type = config_obj[dataset_name]['file_type']

        # Connect to blob service client
        self.blob_service = BlobServiceClient.from_connection_string(Account_uri)
        # Connect to container client
        self.container_client = self.blob_service.get_container_client(self.container_name)

        # Timestamp of data extraction
        self.timestamp = timestamp
        # Minutes in advance of timestamp to extract data for
        self.last_min = last_min
        # Tags list for filtering when importing PCS tags
        self.tag_list = tag_list

    def find_all_files_with_prefix(self):
        """
        outputs:
            file_list: return the list of files from the mounted path that fall
                          in the loading period. [timestamp -lastmin, timestamp]
        """
        file_list = []
        ts = self.timestamp - datetime.timedelta(minutes=self.last_min)

        while ts <= self.timestamp:
            ts_date = str(ts.date())
            ts_HrMin = str(ts.time())
            prefix = self.blob_folder + "/" + self.file_prefix + ts_date + 'T' + ts_HrMin[
                                                                                 0:5]  # Ignore second in timestamp
            prefix = prefix.replace(':', '_')
            # print(prefix)
            blob_list = self.container_client.list_blobs(name_starts_with=prefix)
            for blob in blob_list:
                # Loop through each blob files
                blob_client = self.blob_service.get_blob_client(container=self.container_name, blob=blob.name)
                size = blob_client.get_blob_properties().size  # Get file size
                if ('.' + self.file_type in blob.name) & (
                        size > 1000):  # (ignore files that are empty and only take matching file type)
                    file_list.append(blob.name)

            ts = ts + datetime.timedelta(minutes=1)  # Loop through each minute

        # Display how many files on the list
        print("Number of Files:" + str(len(file_list)))

        return file_list

    def read_all_files_into_dataframe(self, file_list, norm_fnc):
        """
        inputs:
            file_list: List of files to be combined
            norm_fnc: Json normalisation function
        outputs:
            df: Dataframe combining all of the data in the file list
        """
        df = pd.DataFrame()

        if self.file_type == 'json':
            # loop through all files and combine data into a dataframe
            for f in file_list:
                try:  # some json files are empty
                    temp = norm_fnc(NormaliseJson(f))
                    if self.file_prefix == 'KD-INT054_':  # indicating it is a tag file
                        temp = temp[temp['tagid'].isin(self.tag_list)]  # Only take specific tags
                    else:
                        pass
                    # Combined Dataframes & Remove all duplicated entries
                    df = df.append(temp).drop_duplicates()
                except:
                    pass
        else:  # can add other file type in the future
            pass
        print('Dataset is loaded into dataframe.')
        return df

    def load_data_to_df(self):
        # Get Normalisation function based on dataset
        ds_normfunc_dict = {'kd-int080-process-control-alarms-and-events': NormaliseJson.normalise_alarms,
                            'kd-int058-ordw-fixed-plant-time-usage-ada': NormaliseJson.normalise_fptu,
                            'kd-int071-tpps-train-schedule-ada': NormaliseJson.normalise_trainschedule,
                            'kd-int099-tpps-stockpile-builds-ada': NormaliseJson.normalise_stockpile_builds,
                            'kd-int054-process-control-data-from-osisoft-pi-ada': NormaliseJson.normalise_tag,
                            'kd-int056-weatherzone-forecasts-ada': NormaliseJson.normalise_weather,
                            'kd-int075-pds-ada': NormaliseJson.normalise_pds
                            }
        norm_func = ds_normfunc_dict.get(self.blob_folder)

        # Create blob list from input data
        blob_list = self.find_all_files_with_prefix()

        download_point = tempfile.mkdtemp()

        def save_blob(file_name, file_content, download_point):
            # Get full path to the file
            download_file_path = os.path.join(download_point, file_name)
            # for nested blobs, create local path as well
            os.makedirs(os.path.dirname(download_file_path), exist_ok=True)
            # Save file
            with open(download_file_path, "wb") as file:
                file.write(file_content)

        for blob in blob_list:
            bytes = self.container_client.get_blob_client(blob).download_blob().readall()
            save_blob(blob, bytes, download_point)

        file_list = [download_point + '/' + f for f in blob_list]

        # Read all files into dataframe
        df = self.read_all_files_into_dataframe(file_list, norm_func)
        df = df.reset_index(drop=True)

        # Delete all file from the temp directory
        shutil.rmtree(download_point)
        return df


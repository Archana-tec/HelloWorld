import pandas as pd
import json
import pandas.io.json as pd_json


class NormaliseJson:
    def __init__(self, blob_json_text):
        self.blob_json_text = str(blob_json_text).encode(encoding = 'UTF-8', errors = 'strict')
        # self.data = json.loads(blob_json_text)
        self.data = pd_json.loads(blob_json_text)
        self.table = pd.json_normalize(self.data)
        

        

        
    def normalise_trainschedule(self,filename):
        x = self.table.loc[0,'data.OreData.Data']
        if x != []:
            output = pd.json_normalize(x)
            # Columns in Scope 

            col = [ 'SCHEDULE_TRAIN_ID','TRAIN_ID','LOCOS', 'NUMBER_OF_CARS',
                    'NUMBER_OF_CARS_COMPLETED',  'PRODUCT_NAME',
                    'PLANNED_ARRIVAL_TIME_UTC', 'PLANNED_COMMENCE_LOAD_UTC',
                    'PLANNED_COMPLETE_LOAD_UTC', 'PLANNED_DEPARTURE_TIME_UTC',
                    'TD_ACT_ARRIVALTIME', 'TD_ACT_COMMLOAD',
                    'TD_ACT_COMPLOAD', 'TD_ACT_DEPMINE','TRAINSTATUS',
                    'CREATED_ON_UTC', 'UPDATED_ON_UTC', 'DELETED_ON_UTC']
            
            # Take only those columns above and sort values
            output = output[col]
            output.sort_values(by='PLANNED_ARRIVAL_TIME_UTC',inplace=True)

            file_ts_1=filename.split('.')[0].split('TrainSchedule-')[-1]
            output['file_timestamp'] = file_ts_1
            

            output['UPDATED_ON_UTC']=pd.to_datetime(output['UPDATED_ON_UTC'])
            output['PLANNED_ARRIVAL_TIME_UTC']=pd.to_datetime(output['PLANNED_ARRIVAL_TIME_UTC'])
            output['PLANNED_COMMENCE_LOAD_UTC']=pd.to_datetime(output['PLANNED_COMMENCE_LOAD_UTC'])
            output['PLANNED_COMPLETE_LOAD_UTC']=pd.to_datetime(output['PLANNED_COMPLETE_LOAD_UTC'])
            output['PLANNED_DEPARTURE_TIME_UTC']=pd.to_datetime(output['PLANNED_DEPARTURE_TIME_UTC'])
            output['TD_ACT_ARRIVALTIME']=pd.to_datetime(output['TD_ACT_ARRIVALTIME'])
            output['TD_ACT_COMMLOAD']=pd.to_datetime(output['TD_ACT_COMMLOAD'])
            output['TD_ACT_DEPMINE']=pd.to_datetime(output['TD_ACT_DEPMINE'])
            output['TD_ACT_COMPLOAD']=pd.to_datetime(output['TD_ACT_COMPLOAD'])
            output['CREATED_ON_UTC']=pd.to_datetime(output['CREATED_ON_UTC'])
            output['DELETED_ON_UTC']=pd.to_datetime(output['DELETED_ON_UTC'])
            output['SCHEDULE_TRAIN_ID']=output.SCHEDULE_TRAIN_ID.astype('int64')
            output['NUMBER_OF_CARS']=output.NUMBER_OF_CARS.astype('int64')
            output['NUMBER_OF_CARS_COMPLETED']=pd.to_numeric(output['NUMBER_OF_CARS_COMPLETED'])
            output['TRAIN_ID']=output.TRAIN_ID.astype('object')
            output['LOCOS']=output.LOCOS.astype('object')
            output['file_timestamp']=output.file_timestamp.astype('object')
        else:
            output= None
            
        
        return output       
    
    def normalise_fptu(self,filename):
        x = self.table.loc[0,'ResultSet']
        if x != [{'Data': []}]:
            x = pd.json_normalize(x)
            x = x.loc[0,'Data']
            output = pd.json_normalize(x)
            file_ts_1=filename.split('.')[0].split('FixedPlantTimeUsage-')[-1]
            output['file_timestamp'] = file_ts_1
            
            cols = ["SourceIdentifier","Shift_SK","FixedPlantTimeUsageEventStart","FixedPlantTimeUsageEventFinish","FixedPlantTimeUsageGroupEventStart","FixedPlantTimeUsageGroupEventFinish",\
        "cTimeUsageGroupEvent","sTimeUsage","FixedPlantTimeUsageComments","FixedPlantTimeUsageExplanation","FixedPlantAssetCode","FixedPlantAssetDescription","SubEquipment",\
        "TPPSEquipmentCode","CauseFixedPlantAssetCode","CauseFixedPlantAssetDescription","CauseArea","Cause","Effect","TPPSTrainId","TUM0Code","TUM0DisplayName","TUM1Code",\
        "TUM1DisplayName","TUM5Code","TUM5DisplayName","SourceUpdatedAt","ModifiedAt","file_timestamp"]
            
            output['SourceIdentifier']=output.SourceIdentifier.astype('int64')
            output['Shift_SK']=output.Shift_SK.astype('int64')
            output['FixedPlantTimeUsageEventStart']=pd.to_datetime(output['FixedPlantTimeUsageEventStart'])
            output['FixedPlantTimeUsageEventFinish']=pd.to_datetime(output['FixedPlantTimeUsageEventFinish'])
            output['FixedPlantTimeUsageGroupEventStart']=pd.to_datetime(output['FixedPlantTimeUsageGroupEventStart'])
            output['FixedPlantTimeUsageGroupEventFinish']=pd.to_datetime(output['FixedPlantTimeUsageGroupEventFinish'])
            output['cTimeUsageGroupEvent']=output.cTimeUsageGroupEvent.astype('boolean')
            output['sTimeUsage']=output.sTimeUsage.astype('int64')
            
            
            output['SourceUpdatedAt']=pd.to_datetime(output['SourceUpdatedAt'])
            output['ModifiedAt']=pd.to_datetime(output['ModifiedAt'])
            output['file_timestamp']=output.file_timestamp.astype('object')
            output=output[cols]
        else:
            output= None
        return output   
    
    def normalise_alarms(self,filename):
        x = self.table.loc[0,'Data.ResultSet']
        if x != [{'Data': []}]:
            x = pd.json_normalize(x)
            x = x.loc[0,'Data']

            output = pd.json_normalize(x)
            # Select only columns required:
            col = ['eventid',  'tagname', 'unit', 'description',
                    'area', 'name', 'vt_start',  'vt_end', 
                    'priority',  'message']
            output = output[col] 
            file_ts_1=filename.split('.')[0].split('PCDB-')[-1]
            output['file_timestamp'] = file_ts_1
            
            output['eventid']=output.eventid.astype('int64')
            output['tagname']=output.tagname.astype('object')
            output['unit']=output.unit.astype('object')
            output['area']=output.area.astype('object')
            output['name']=output.name.astype('object')
            output['vt_start']=pd.to_datetime(output['vt_start'])
            # output['vt_end']=pd.to_datetime(output['vt_end'])
            output['vt_end']=output.vt_end.astype('object') 
            # output['vt_end']=output.vt_end.astype('datetime64')
            output['priority']=output.priority.astype('object')
            output['name']=output.name.astype('object')
            output['message']=output.message.astype('object')
            output['file_timestamp']=output.file_timestamp.astype('object')
        else:
            output = None

        return output


    def normalise_weather(self,filename):
        x = self.table.loc[0,'data.weather.countries.country.location.point_forecast']
        # if x != []:
        table2 = pd.json_normalize(x)
        if len(table2) != 0:
            table2['forecast_location'] = self.table.loc[0,'data.weather.countries.country.location.name']
            table2['forecast_at_time_utc'] = self.table.loc[0,'MessageHeader.dateTime']
            table2.forecast_at_time_utc = pd.to_datetime(table2.forecast_at_time_utc)

            table2.rename(columns={'wind_dir_degrees.value':'wind_dir_degrees','utc_time':'forecast_for_time_utc',\
                                'cloud_cover_percent.value':'cloud_cover_perc', 'feels_like_c.value':'feels_like_temp_c',\
                                'wind_speed_kph.value':'wind_speed_kph', 'wind_gust_kph.value':'wind_gust_kph',\
                                'pressure_msl_hpa.value':'pressure_msl_hpa', 'rain_rate_mm.value':'rain_rate_mm_per_hour',\
                                'prob_precip.value':'prob_precip_perc', 'temp_c.value':'temp_c', 'rh.value':'rel_humity_perc'}, inplace=True)

            
            output = table2[['forecast_location','forecast_at_time_utc','forecast_for_time_utc','temp_c','feels_like_temp_c','rel_humity_perc','wind_dir_compass',\
                        'wind_dir_degrees','wind_speed_kph','wind_gust_kph','pressure_msl_hpa','cloud_cover_perc','prob_precip_perc',\
                        'rain_rate_mm_per_hour']]
            file_ts_1=filename.split('.')[0].split('WeatherForecast-')[-1]
            output['file_timestamp'] = file_ts_1
            
            output['forecast_location']=output.forecast_location.astype('object')
            
            # output['forecast_for_time_utc']=output.forecast_for_time_utc.astype('datetime64[ns]')
            # output['forecast_at_time_utc']=pd.to_datetime(output['forecast_at_time_utc']).round('S')
            
            # output['forecast_at_time_utc']=output.forecast_at_time_utc.astype('datetime64[ns]')
            output['forecast_at_time_utc']=pd.to_datetime(output['forecast_at_time_utc']).dt.tz_localize(None).round('S')
            output['forecast_for_time_utc']=pd.to_datetime(output['forecast_for_time_utc'])
            output['temp_c'] = pd.to_numeric(output['temp_c'])
            output['feels_like_temp_c'] = pd.to_numeric(output['feels_like_temp_c'])
            output['rel_humity_perc'] = pd.to_numeric(output['rel_humity_perc'])
            output['wind_dir_compass']=output.wind_dir_compass.astype('object')
            output['temp_c'] = pd.to_numeric(output['temp_c'])
            output['wind_dir_degrees'] = pd.to_numeric(output['wind_dir_degrees'])
            output['wind_speed_kph'] = pd.to_numeric(output['wind_speed_kph'])
            output['wind_gust_kph'] = pd.to_numeric(output['wind_gust_kph'])
            output['pressure_msl_hpa'] = pd.to_numeric(output['pressure_msl_hpa'])
            output['cloud_cover_perc'] = pd.to_numeric(output['cloud_cover_perc'])
            output['prob_precip_perc'] = pd.to_numeric(output['prob_precip_perc'])
            output['rain_rate_mm_per_hour'] = pd.to_numeric(output['rain_rate_mm_per_hour'])

            output['file_timestamp']=output.file_timestamp.astype('object')
        else:
            output = None
        return output


    def normalise_tag(self,filename):
        df = self.table
        if len(df) != 0:
            rs = df['Items']
            df=pd.DataFrame()
            for item in rs:
                df_temp = pd.json_normalize(item)
                df = pd.concat([df_temp, df], ignore_index=True)
            df = df[["Name", "Value.Timestamp", "Value.Value"]]
            file_ts_1=filename.split('.')[0].split('_')[2]
            file_ts_2=filename.split('.')[0].split('_')[3]
            file_ts_3=filename.split('.')[0].split('_')[4]
            df['file_timestamp'] = f'{file_ts_1}_{file_ts_2}_{file_ts_3}'
            df['Value.Timestamp']= pd.to_datetime(df['Value.Timestamp'].str.slice(0, 19))
            df.rename(columns={"Name": "tagid", "Value.Timestamp": "time_rio", "Value.Value" : "value_rio"}, inplace=True)
            # if str(df["value_rio"].dtype ) != 'float64':
            #     df2 = df[df["value_rio"].str.contains("{")==False]
            #     df = pd.merge(df, df2, indicator=True, how='outer').query('_merge=="left_only"').drop('_merge', axis=1)
            df = df.sort_values(by=['time_rio'],ignore_index=True)
            df = df.drop_duplicates(subset=['tagid', 'time_rio', 'value_rio'])
            df['value_rio'] = pd.to_numeric(df['value_rio'],errors='coerce')
            output=df
            output['file_timestamp']=output.file_timestamp.astype('object')
            output['tagid']=output.tagid.astype('object')
                
            # else: 
            #     output=df
        else:
            output = None
        return output

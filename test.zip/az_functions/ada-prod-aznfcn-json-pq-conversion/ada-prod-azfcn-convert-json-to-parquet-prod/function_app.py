import azure.functions as func
import logging
from azure.storage.blob import   BlobServiceClient,ContainerClient
import pyarrow 
import pandas as pd
import json
import re
from helper import NormaliseJson
import datetime
app = func.FunctionApp()


@app.function_name(name="ada-prod-azfcn-convert-json-to-parquet-prod")
@app.event_hub_message_trigger(arg_name="myhub",
                               event_hub_name="evh-ae-dsprod-rtio-ada03",
                               connection="EventHubConnectionString") 

def test_function(myhub: func.EventHubEvent): 
   
   start_time = datetime.datetime.now()

   # String processing of incoming blob meta data
   event_string_output = str(myhub.get_body().decode('utf-8')).replace(']','').replace('[','')
   meta_data = json.loads(event_string_output)
   
   # Get Conatiner Client
   container_name='ada-landed-data-storage-prod'
   containerClient=ContainerClient(account_url=f'https://srtdsprdrtioada01.blob.core.windows.net/',
                                   credential='CAshgXLUMQCBe+ol6x7UAJwiy7B+qenhwVExElJcbtue/U05wlosb7zvZBM41N+1ODR9+FRvtHKDHT9E8cEcjg==',
                                   container_name=container_name)
   # Extract file path of JSON blob file path to be converted to parquet
   blob_name=meta_data['subject'].split(f'blobs/')[-1]
   logging.info(f"[{datetime.datetime.now()}] File Path of Blob: {blob_name}")
   
   # Extract file name of JSON file from file path
   filename=blob_name.split('/')[-1]
   logging.info(f"[{datetime.datetime.now()}] Name of JSON File: {filename}")
   
   # Extract creation date of JSON file from filename
   filedate=re.search("([0-9]{4}\-[0-9]{2}\-[0-9]{2})", filename)
   filedate=filedate[0]
   logging.info(f"[{datetime.datetime.now()}] Created Date of File: {filedate}")
   
   # Extract data folder type of JSON file from file path
   data_folder_type = blob_name.split('/')[0]
   logging.info(f"[{datetime.datetime.now()}] Data Type: {data_folder_type}")
   # Download JSON file content as a string
   blob_json_text = containerClient.download_blob(blob_name).content_as_text().encode(encoding = 'UTF-8', errors = 'strict')
   


   # Create target folder file path for parquet to be saved in
   target_folder= f'parquet/{data_folder_type}/{filedate}'
   logging.info(f"[{datetime.datetime.now()}] Target Folder Path: {target_folder}")
   

          
   # Create Parquet file name from JSON filename
   pq_filename=filename.split('.')[0]+'.'+filename.split('.')[1]
   logging.info(f"[{datetime.datetime.now()}] Parquet File Name: {pq_filename}")
   
   # Create blob client for target folder to save Parquet to 
   dest_source =containerClient.get_blob_client(f'{target_folder}/{pq_filename}.parquet')
   logging.info(f"[{datetime.datetime.now()}] Parquet File Path: {target_folder}/{pq_filename}.parquet")
   
   # Transform JSON file to parquet depending on data_folder type and save to target folder
   logging.info(f"[{datetime.datetime.now()}] Commence JSON file conversion to Parquet")
   conversion_start = datetime.datetime.now()
   if data_folder_type =='kd-int054-process-control-data-from-osisoft-pi-ada':
      
      output= NormaliseJson(blob_json_text).normalise_tag(filename)
      if isinstance(output, pd.DataFrame):
            
            dest_source.upload_blob(output.to_parquet(engine='pyarrow',index=False),overwrite=True)
      else:
               logging.info(f'[{datetime.datetime.now()}] No conversion since there is not data to extract: {filename}')         
               
   elif data_folder_type =='kd-int056-weatherzone-forecasts-ada':
            
      output= NormaliseJson(blob_json_text).normalise_weather(filename)
      if isinstance(output, pd.DataFrame):
               dest_source.upload_blob(output.to_parquet(engine='pyarrow',index=False,coerce_timestamps='us', allow_truncated_timestamps=True),overwrite=True)
      else:
               logging.info(f'[{datetime.datetime.now()}] No conversion since there is not data to extract: {filename}')
      
   elif data_folder_type =='kd-int080-process-control-alarms-and-events':
            
      output= NormaliseJson(blob_json_text).normalise_alarms(filename)
      if isinstance(output, pd.DataFrame):
               dest_source.upload_blob(output.to_parquet(engine='pyarrow',index=False),overwrite=True)
      else:
               logging.info(f'[{datetime.datetime.now()}] No conversion since there is not data to extract: {filename}')   
                     
   elif data_folder_type =='kd-int071-tpps-train-schedule-ada':
            
      output= NormaliseJson(blob_json_text).normalise_trainschedule(filename)
      if isinstance(output, pd.DataFrame):
               dest_source.upload_blob(output.to_parquet(engine='pyarrow',index=False),overwrite=True)
      else:
               logging.info(f'[{datetime.datetime.now()}] No conversion since there is not data to extract: {filename}')         
            
   elif data_folder_type =='kd-int058-ordw-fixed-plant-time-usage-ada':
            
      output= NormaliseJson(blob_json_text).normalise_fptu(filename)
      if isinstance(output, pd.DataFrame):
               dest_source.upload_blob(output.to_parquet(engine='pyarrow',index=False),overwrite=True)
      else:
               logging.info(f'[{datetime.datetime.now()}] No conversion since there is not data to extract: {filename}')
               
   else:
            logging.info(f'[{datetime.datetime.now()}] No conversion since we are not interesting in this file: {filename}')
               
   end_time = datetime.datetime.now()          
   logging.info(f"[{datetime.datetime.now()}] Finish JSON file conversion to Parquet in {(end_time-conversion_start)}")
   logging.info(f"[{datetime.datetime.now()}] Function finished in {(end_time-start_time)}...")

   
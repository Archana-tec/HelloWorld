import azure.functions as func
import datetime
import logging
import sys
from sys import path
import os

dir_path = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, dir_path)

from shared.UC2 import UC2

def main(mytimer: func.TimerRequest) -> None:
    logging.info('Azure Function starts')
    utc_timestamp = datetime.datetime.utcnow()

    if mytimer.past_due:
        logging.info('The timer is past due!')

    logging.info('Python timer trigger function ran at %s', utc_timestamp)

    model_deployment = 'ada-uc2-cdp-cv0316-prod' 
    url = os.environ["uc2_inference_endpoint_url_cv0316_prd"]
    api_key = os.environ["uc2_inference_endpoint_apikey_cv0316_prd"]

    logging.info('+ Endpoint URL: '+url)
    logging.info('+ Model Deployment: '+model_deployment)

    uc2 = UC2(
        url = url,
        api_key = api_key,
        model_deployment = model_deployment
    )

    result = uc2.send_request(utc_timestamp=utc_timestamp)
    
    if 'status' not in result:
        logging.info(f'+ Result = {result}')
        logging.info('Azure Function ends')
    else:
        error_message = result["error_message"]
        error_type = result["error_type"]
        logging.error(f'Error Message: {error_message}')
        logging.error(f'Error Type: {error_type}')
        raise Exception(error_message)
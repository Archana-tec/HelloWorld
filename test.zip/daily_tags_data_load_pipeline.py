import os
import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Dataset
import argparse
from azureml.core import Run
from pyspark.sql.types import IntegerType, DoubleType, StructField, StructType, TimestampType, LongType, StringType

start_time = datetime.datetime.now()
# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--tags")
parser.add_argument("--environment")
parser.add_argument("--output_dir")
args = parser.parse_args()

os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

# Start spark session
spark = SparkSession.builder.getOrCreate()
spark.conf.set("spark.sql.parquet.enableVectorizedReader", "false")

print(f"[{datetime.datetime.now()}] Input Mount point from arguments: {args.tags}")
print(f"[{datetime.datetime.now()}] Output Mount point from arguments: {args.output_dir}")

input_mount_point = args.tags
output_dir = args.output_dir.replace('.blob.', '.dfs.')
output_dir = output_dir.replace('wasbs', 'abfss')

### TAGS LOAD ###
sdf_tags2 = None
try:
    print(f"[{datetime.datetime.now()}] Reading the latest date from previous data load ...")
    current_tags_file = spark.read.parquet(output_dir + '/PCS_tags')
    current_tags_max_date = current_tags_file.select(max('time_rio')).first()[0]
    period_start_utc = current_tags_max_date - datetime.timedelta(days=1)
    sdf_tags2 = current_tags_file.alias('sdf_tags2')
except:
    period_start_utc = datetime.datetime(2022, 7, 1)  # default to start of July if no file is found

# The pipeline runs every day at 5AM
period_end_utc = datetime.datetime.now()

# this part is used to handle sync delay between prod and dev
if args.environment=='DEV':
    if period_end_utc.hour < 6:
        period_end_utc = period_end_utc.replace(hour=0, minute=0, second=0, microsecond=0) - datetime.timedelta(seconds=1)

print(f'[{datetime.datetime.now()}] Start Date: {period_start_utc.strftime("%Y-%m-%d")}')
print(f'[{datetime.datetime.now()}] End Date: {period_end_utc.strftime("%Y-%m-%d")}')

# Create hdfs date range
date_range = load_ADA_data.hdfs_range_day(period_start_utc, period_end_utc) # using hdfs_range_day instead of hdfs_range
print(f'[{datetime.datetime.now()}] Tags range: {date_range}')

# Load PCS Tags and append to previous iterations
dr = (date_range.replace("{", "").replace("}", "").replace("*", "")).split(",")
sources = [input_mount_point + sub + "*" for sub in dr] # replace * with / for parquet source
sources = [x.replace('blob', 'dfs') for x in sources]
sources = [x.replace('wasbs', 'abfss') for x in sources]
print(f'[{datetime.datetime.now()}] Sources: {sources}')

# print(f"[{datetime.datetime.now()}] Going to read parquet files ...")
# sdf_tags = spark.read.parquet(*pq_sources)
# print(f"[{datetime.datetime.now()}] Finished reading parquet files ... ")

# print(f"[{datetime.datetime.now()}] Going to read json files ...")
# sdf_tags = spark.read.option("multiline", "true").json(sources).withColumn("filename", input_file_name())
# print(f"[{datetime.datetime.now()}] Finished reading json files ... ")
# sdf_tags = load_ADA_data.NormaliseJsonSpark(sdf_tags).normalise_tags_spark()

sdf_tags = None

for source in sources:
    print(f"[{datetime.datetime.now()}] Going to read json file {source} ...")
    try:
        if sdf_tags is None:
            sdf_tags_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_tags_temp = load_ADA_data.NormaliseJsonSpark(sdf_tags_temp).normalise_tags_spark()
            sdf_tags = sdf_tags_temp.alias('sdf_tags')
        else:
            sdf_tags_temp = spark.read.option("multiline", "true").json(source).withColumn("filename", input_file_name())
            sdf_tags_temp = load_ADA_data.NormaliseJsonSpark(sdf_tags_temp).normalise_tags_spark()
            sdf_tags = sdf_tags.union(sdf_tags_temp)
    except Exception as e:
        print(f"[{datetime.datetime.now()}] Failed to read json file {source}: {e}")
print(f"[{datetime.datetime.now()}] Finished reading json files ... ")


sdf_tags = sdf_tags.withColumn("tagid", col("tagid").cast(StringType()))
sdf_tags = sdf_tags.withColumn("time_rio", to_timestamp("time_rio"))
sdf_tags = sdf_tags.withColumn("value_rio", col("value_rio").cast(DoubleType()))
sdf_tags = sdf_tags.withColumn("file_timestamp", col("file_timestamp").cast(StringType()))

if sdf_tags2 is None:
    print(f"[{datetime.datetime.now()}] Going to read the old Tags data ...")
    sdf_tags2 = spark.read.parquet(output_dir + '/PCS_tags')
    print(f"[{datetime.datetime.now()}] Finished reading the old Tags data ...")

sdf_tags2.createOrReplaceTempView("old_df")
sdf_tags.createOrReplaceTempView("new_df")

# print(f'Count of existing data in PCS_tags: {sdf_tags2.count()}')
# print(f'Count of the output of normalise_tags_spark: {sdf_tags.count()}')
# add remove null values here
# the below query is to identify the new data.
# the output of normalize_tags_spark contains data which is already exist in the output folder

new_data = spark.sql("""
            select n.*
            from  new_df n
            where not exists (
                select * from old_df o 
                where o.tagid = n.tagid
                  and o.time_rio = n.time_rio
                  and o.value_rio = n.value_rio
            )
""")

print(f"[{datetime.datetime.now()}] Going to append the new data into the Tags data ...")
new_data.write.mode('append').parquet(f'{output_dir}/PCS_tags')

print(f'[{datetime.datetime.now()}] Optimization - Start reading parquet...')
df = spark.read.parquet(f'{output_dir}/PCS_tags')
df = df.dropDuplicates(['tagid', 'time_rio', 'value_rio'])

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df.repartition(50).write.mode('overwrite').parquet(f'{output_dir}_temp/PCS_tags')

print(f'[{datetime.datetime.now()}] Optimization - Moving to actual table ...')
df2 = spark.read.parquet(f'{output_dir}_temp/PCS_tags')

print(f"[{datetime.datetime.now()}] Optimization -  Going to write data to temp folder ...")
df2.repartition(50).write.mode('overwrite').parquet(f'{output_dir}/PCS_tags')

print(f"[{datetime.datetime.now()}] Tags load complete.")
end_time = datetime.datetime.now()
print(f"[{datetime.datetime.now()}] DONE in {(end_time-start_time)}...")
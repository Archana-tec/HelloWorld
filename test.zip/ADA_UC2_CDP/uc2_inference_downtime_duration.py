import os
import pandas as pd

def downtime_duration_forecast(belt, prediction):
    # If Normal operation predicted, no downtime duration forecast
    if prediction == 'Normal':
        duration_median = 0
        duration_q1 = 0
        duration_q3 = 0
        duration_iqr = 0

    # If downtime is predicted, load downtime duration lookup file from trained components
    else:
        duration_path = os.path.join(os.path.dirname(__file__), 'gd_delay_duration_lookup.csv')
        duration_path = duration_path.replace('ADA_UC2_CDP/','UC2_trained_components/')
        df_duration = pd.read_csv(duration_path)

        # If there are greater than 5 occurences for the (belt, trip_type) combination, take the statistics for that combination
        if df_duration.loc[(df_duration.belt == belt)&(df_duration.trip_type == prediction),'event_count'].values[0] > 5:
                df = df_duration.loc[(df_duration.trip_type == prediction)&(df_duration.belt == belt),\
                                            ['trip_type','belt','duration_median_mins','duration_q1_mins','duration_q3_mins','duration_iqr_mins']]

        # If 5 or fewer occurences for the (belt, trip_type) combination, take the statistics for the trip type across all belts
        else:
                    df = df_duration.loc[(df_duration.trip_type == prediction)&(df_duration.belt.isnull()),\
                                                ['trip_type','belt','duration_median_mins','duration_q1_mins','duration_q3_mins','duration_iqr_mins']]

        duration_median = df.duration_median_mins.values[0]
        duration_q1 = df.duration_q1_mins.values[0]
        duration_q3 = df.duration_q3_mins.values[0]
        duration_iqr = df.duration_iqr_mins.values[0]

    return duration_median, duration_q1, duration_q3, duration_iqr
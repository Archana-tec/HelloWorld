import datetime
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (confusion_matrix, f1_score, precision_score,
                             recall_score)
from sklearn.model_selection import (GridSearchCV, StratifiedKFold,
                                     cross_val_predict, train_test_split)
from xgboost import XGBClassifier



class UC2_Model:
    """The UC2 Model class

    The purpose of this class is to make it easier to interact with the UC2 model and make updates.
    Primarily it exists for oragnisational purposes and allowing us to create functions that can work for all future models.

    The idea is that we can interact with the class the same way that we would for a model in sklearn or and write code that would be able to handle the specifics of our implementation. 

    In future we can consider if we want to keep using this class structure for the modelling or try a different approach.
    """    
    def __init__(
        self,
        df_model_input:pd.DataFrame,
        model_type:str,
        tt_split_dates:Optional[Dict[str, pd.Timestamp]]=None,
        hparam_tuning:bool=True,
        cross_validation:bool=False,
        oversample:Optional[float]=None,
        validation_size:float = 0.2):

        # Models we are trying: Random Forest, XGBoost, Logistic Regression
        assert model_type in ['rf', 'xgb', 'lg'], "model_type parameter must be in ['rf','xgb' 'lg']"
        
        # Defining Constants
        self.df_model_input = df_model_input
        self.model_type = model_type
        self.tt_split_dates = tt_split_dates
        self.hparam_tuning = hparam_tuning
        self.cross_validation = cross_validation
        self.oversample = oversample
        self.validation_size = validation_size

        # Seeding
        self.random_state = 42

        # List Classes
        self.classes = list(df_model_input.trip_type.unique())

        # Maps classes to int 
        self.class_mapping = {k: v for v, k in enumerate(self.classes)}
        # Maps int to classes
        self.inv_class_mapping = {v: k for k, v in self.class_mapping.items()}

        # Get class weights
        self.class_weights = self.get_class_weights(simple=False)

        # Assign model_type specific values
        if self.model_type == 'rf':
    
            # Parameters for Grid Search
            self.hparam_grid = [{
                'n_estimators':[50,100,200],
                'max_features':['sqrt','log2'],
                'max_depth':[8,10,5],
                'min_samples_leaf':[0.01,0.1]
                },
                {'bootstrap':[False],
                'n_estimators':[50,100,200], 
                'max_depth':[8,10,5],
                'max_features':['sqrt','log2'], 
                'min_samples_leaf':[0.01,0.1]
                }]
            
            # Set default params if not using hyper parameter tuning
            if not self.hparam_tuning:
                self.default_hparams = {
                    'bootstrap': False,
                    'max_depth': 10,
                    'max_features': 'log2',
                    'min_samples_leaf': 0.01,
                    'n_estimators': 200
                    }

        if self.model_type == 'xgb':

            # Set Objective function and evaluation metric
            self.xgb_obj = 'binary:logistic' if len(self.classes) == 2 else 'multi:softproba'
            self.xgb_eval_metric = 'aucpr'

            # Parameters for Grid Search
            self.hparam_grid = {
                'max_depth': range (2, 6, 2),
                'n_estimators': range(100, 200, 50),
                'learning_rate': [0.1, 0.05,0.2],
                'gamma': [0, 0.5],
                'reg_alpha': [0, 0.5],
                'reg_lambda': [0.5, 1],
                }

            # Set default params if not using hyper parameter tuning
            if not self.hparam_tuning:
                self.default_hparams = {
                    'gamma': 0,
                    'learning_rate': 0.1,
                    'max_depth': 2,
                    'n_estimators': 100,
                    'reg_alpha': 0,
                    'reg_lambda': 0.5
                    }
            
        if self.model_type == 'lg':
            # Parameters for Grid Search
            self.hparam_grid = {
                    'max_iter': [100, 200, 500, 1000],
                    'solver': ['lbfgs', 'sag'],
                    'C': [0.5, 1, 2]
                    }
            
            # Set default params if not using hyper parameter tuning
            if not self.hparam_tuning:
                self.default_hparams = {
                    'max_iter': 200,
                    'solver': 'lbfgs',
                    'C': 1.0
                    }

                    
    def model_train_test_split(self):
        """Create the model train and test split using the input data.
        """

        # If we don't provide dates for a train test split then we will use a 20% split instead
        if self.tt_split_dates is None:
            self.test_size=0.2

            self.df_train, self.df_test = train_test_split(
                self.df_model_input, 
                test_size=self.test_size,
                random_state=self.random_state, 
                shuffle=False)

        else:
            # If we are provided with dates then we will split on those dates.
            self.df_train = self.df_model_input.loc[
                self.tt_split_dates['train_start']:self.tt_split_dates['train_end']]

            self.df_test = self.df_model_input.loc[
                self.tt_split_dates['test_start']:self.tt_split_dates['test_end']]

        if self.oversample is not None:
            # Class imbalance
            train_belt_drifts = self.df_train[
                self.df_train['trip_type'] == 'belt drift']
                
            belt_drift_count = len(train_belt_drifts)
            
            self.df_train = pd.concat([
                self.df_train,
                train_belt_drifts.sample(self.oversample*belt_drift_count, replace=True)
            ])

            # shuffle the DataFrame rows
            self.df_train = self.df_train.sample(frac = 1)

        # One quick test to determine if there is any data leakage.
        # We are looking for index's that exist in both train and test and if so flagging an error
        matching_indexs = [idx for idx in self.df_train.index if idx in self.df_test.index]
        assert len(matching_indexs) == 0, f"There is overlapping data in the train/test split for index(s) {matching_indexs}"
            

    def split_data_and_labels(self):
        """Split the data into the model input data and the labels for the train and test sets.
        """

        # Get the model input data
        self.df_train_x = self.df_train.drop(columns=['trip_type'])
        self.df_test_x = self.df_test.drop(columns=['trip_type'])

        # Get the labels
        # Note that this is not a dataframe, but instead a pd.Series object 
        self.df_train_y = self.df_train.trip_type.map(self.class_mapping)
        self.df_test_y = self.df_test.trip_type.map(self.class_mapping)


    def get_class_weights(self, simple:bool=True) -> Union[str, Dict[str, Any]]:
        """Gets the class weights for the model.

        Parameters
        ----------
        simple : bool, optional
            Option to use a simple method i.e. "balanced" in sklearn, by default True

        Returns
        -------
        Union[str, Dict[str, Any]]
            Either a string "balanced" or a dict containing the class weights.
        """        
        # This is to use the "balanced" weight as defined in sklearn
        if simple: return "balanced" # Optinally you can use "balanced_subsample" instead.

        # Update the values to match the weight that you want to give each class
        class_weights = {
            'not belt drift': 1,
            'belt drift': 1
            }

        return class_weights


    def encode_class_weights(self) -> Optional[Union[Dict[int, float], str]]:
        """Format the class weights to match the class names used in the model

        Returns
        -------
        Optional[Union[Dict[int, float], str]]
            If self.class_weights is "balanced" then we return "balanced".
            If it is a dict we use self.class_mapping to remap the names. 
        """        
        if type(self.class_weights) == str or self.class_weights is None: 
            return self.class_weights
        else: 
            return {self.class_mapping[k]: v for (k, v) in self.class_weights.items()}


    def initialise_model(self):
        """Initialise the model
        """        
        if self.model_type == 'rf':
            self.model = RandomForestClassifier(
                n_jobs=-1,
                class_weight=self.class_weights_encoded,
                random_state=self.random_state)

        if self.model_type == 'xgb':
            self.model = XGBClassifier(
                random_state=self.random_state,
                objective= self.xgb_obj,
                eval_metric=self.xgb_eval_metric,
                n_jobs=-1,
                use_label_encoder=False)

        if self.model_type == 'lg':
            self.model = LogisticRegression(
                random_state=self.random_state,
                n_jobs=-1,
                class_weight=self.class_weights_encoded)

    def get_test_hparams(self) -> Dict[str, List[Any]]:
        """Get the hyper parameters we want to test.

        Returns
        -------
        Dict[str, List[Any]]
            A dict containing the list of hyper params to test.
        """      
        if self.hparam_tuning:
            return self.hparam_grid
        else:
            # Convert the values for the hyper parameters to a list with one element
            # We do this because we are using GridSeachCV and it expects a list of hyperparams
            # Since we are not doing hyper parameter tuning we give it a list of one element.
            return {k: list([v]) for k, v in self.default_hparams.items()}
    

    def get_cv_splitter(self) -> Any:
        """Create the cross validation splits

        The output of this function is given to GridSeachCV as the cv parameter

        Returns
        -------
        Any
            Typically a list or generator of some sort containing the cross validation splits.
        """        

        if self.cross_validation:
            return TimeSeriesCrossValidation(self.df_train).ts_split_data
        
        else:
            # Do a normal train/validation/test split
            # We are going to use GridSearchCV for training.
            # We need to set this up like we are doing cv with 1 fold

            data_idxs = list(np.arange(len(self.df_train)))

            train_idxs, valid_idxs = train_test_split(
                data_idxs, 
                test_size=self.validation_size, 
                random_state=self.random_state, 
                shuffle=False)

            cv_splitter = zip([train_idxs], [valid_idxs])

            # Create a variable for the training and validation set 
            self.df_true_train = self.df_train.iloc[train_idxs]
            self.df_true_valid = self.df_train.iloc[valid_idxs]
                        
            return cv_splitter


    def initilialise_validation_split(self):
        """ Used to setup the cross validation and hparam tuning using GridSearchCV
        """

        # Set up scoring function, CV and hyper params to test
        self.grid_search_scoring_function = 'f1_macro'
        self.cv_splitter = self.get_cv_splitter()
        self.hparams_to_test = self.get_test_hparams()
        
        # Define GridSearchCV using the info provided
        self.GridSearchCV = GridSearchCV(
            self.model, 
            self.hparams_to_test,
            n_jobs=-1, 
            cv=self.cv_splitter,
            scoring=self.grid_search_scoring_function,
            verbose=2,
            refit=True)


    def prepare_for_training(self):
        """Set up the correct values for all the variables to prepare for training
        """

        # Train and test split
        self.model_train_test_split()

        # Encode the class weights
        self.class_weights_encoded = self.encode_class_weights()

        # Split df_train and df_test into train_x 
        self.split_data_and_labels()

        # Intialise the model to use
        self.initialise_model()

        # Define GridSearchCV based on options for cross validation and hyperparameter tuning
        self.initilialise_validation_split()


    def fit(self):
        """Fit the model to the data
        """        
        self.prepare_for_training()

        # Fit the model
        self.GridSearchCV.fit(
            self.df_train_x, 
            self.df_train_y
            )

        # Get the Best Model
        self.best_estimator_ = self.GridSearchCV.best_estimator_

        # Show the parameter values of the best model
        self.final_hparams = self.GridSearchCV.best_params_
        print(self.final_hparams)

        # Save CV results and show the best model score
        self.cv_results = pd.DataFrame(self.GridSearchCV.cv_results_)
        print('best model score: '+str(self.GridSearchCV.best_score_))       


    def predict(
        self, 
        df:pd.DataFrame, 
        probability:bool=False, 
        threshold:Optional[float]=None) -> np.ndarray:

        """Use the model to make a prediction.

        Parameters
        ----------
        df : pd.DataFrame
            The input data for the model
        probability : bool, optional
            Option to output the prediction probabilities, by default False

        Returns
        -------
        np.ndarray
            A list of predictions
        """        
        # Make sure that we have trained a model first
        assert self.best_estimator_ is not None, "The model has not been trained yet!"

        # Make a temporary dataframe so that we can do some quick processing
        df_temp = df

        # If 'trip_type' column was included then we should remove it before making the prediction
        if 'trip_type' in df_temp.columns:
            # If the trip_type column is included we want to remove it
            df_temp = df_temp.drop(columns=['trip_type'])

        # Optional to return either the prediction or a array of probabilties
        if probability:
            return self.best_estimator_.predict_proba(df_temp)
        else:
            # Prediction given the threshold 
            if threshold is None:
                return self.best_estimator_.predict(df_temp)

            if threshold is not None:
                predictions = [1 if prob > threshold else 0 for prob in self.best_estimator_.predict_proba(df_temp)[:, 1]]
                
                return np.array(predictions)

    def predict_proba(self, df:pd.DataFrame) -> np.ndarray:
        """Use the model to make predictions and output the probabilities

        Parameters
        ----------
        df : pd.DataFrame
            Input data

        Returns
        -------
        np.ndarray
            A list of prediction probabilities.
        """        
        return self.predict(df, probability=True)

    
    def make_confusion_matrix(self, df:pd.DataFrame) -> np.ndarray:
        """Make a confusion matrix of predictions and actuals with the input data

        Parameters
        ----------
        df : pd.DataFrame
            Input data.

        Returns
        -------
        np.ndarray
            The output confusion matrix.
        """        
        cfmx = confusion_matrix(
            df.trip_type.replace(self.class_mapping),
            self.predict(df)
            )
        return cfmx

    
    def calc_metrics(self, df:pd.DataFrame, average:Optional[str]=None) -> Tuple[np.ndarray]:
        """Calculate metrics for the model on the input data

        Parameters
        ----------
        df : pd.DataFrame
            The input data.
        average : Optional[str], optional
            How we aggregate the metrics for multi class predictions, by default None

        Returns
        -------
        Tuple[np.ndarray]
            A tuple containing all the relevant metrics.
        """        
        actuals = np.array(df.trip_type.replace(self.class_mapping))
        predictions = np.array(self.predict(df))

        precision = precision_score(actuals, predictions, average=average)
        recall = recall_score(actuals, predictions,  average=average)
        f1 = f1_score(actuals, predictions,  average=average)

        return actuals, predictions, precision, recall, f1



    def get_model_metrics(self, df:pd.DataFrame) -> pd.DataFrame:
        """Get the model metrics using the input data.

        Parameters
        ----------
        df : pd.DataFrame
            The input data,

        Returns
        -------
        pd.DataFrame
            A data frame containing all the metrics.
        """        
        
        # Make sure that we have trained a model first
        assert self.best_estimator_ is not None, "The model has not been trained yet!"
        
        # Get the metrics 
        actuals, predictions, precision, recall, f1 = self.calc_metrics(df)

        # Need to get all labels for pred and actuals for df_accuracy dataframe index
        all_labels = np.concatenate([actuals, predictions])

        # Get back the names of the classes 
        class_names = [self.inv_class_mapping[x] for x in self.inv_class_mapping.keys() if x in all_labels]

        df_accuracy = pd.DataFrame(
            data={
                'Precision': precision,
                'Recall': recall,
                'F1': f1
                },
            index=class_names
            )

        return df_accuracy

    def find_best_threshold(self, obs, df, granularity=0.01, metric='f1_score'):

        metric_map = {
            'f1_score': f1_score, 
            'precision': precision_score, 
            'recall': recall_score
        }

        best_metric = 0
        best_threshold = None

        for threshold in np.arange(0, 1, granularity):
            preds = self.predict(df, threshold=threshold)
            if f1_score(obs ,preds) > best_metric:
                best_metric = metric_map[metric](obs ,preds)
                best_threshold = threshold

        return best_threshold, best_metric
                    
    def save_model(self, filename:str):
        """Save the model

        Parameters
        ----------
        filename : str
            File name of the model when we save it.
        """        
        joblib.dump(value=self, filename=filename)

    def save_data(self, train_path:str, test_path:str):
        """Save the data used to train and test the model

        Parameters
        ----------
        train_path : str
            Training data save file name.
        test_path : str
            Test data save file name.
        """        
        self.df_train.to_csv(train_path)
        self.df_test.to_csv(test_path)


class TimeSeriesCrossValidation:
  def __init__(
    self,
    df_train: pd.DataFrame,
    val_duration:int = 4, # weeks
    max_val_proportion:float = 0.4 # proportion of test data relative to train data
    ):
    
    assert df_train.index.has_duplicates == False, "df_train has duplicate index values. Cannot do time series cross validation" 

    self.val_duration = val_duration 
    self.max_val_proportion = max_val_proportion 
    
    self.ts_split_data = self.ts_split(df_train.sort_index())

  def combine_arrays(self, 
    indices):
    combined_indices=[]
    for i in indices:
        if i.size != 0:
            combined_indices = np.concatenate((combined_indices, i))

    combined_indices = combined_indices.astype(int)

    return combined_indices


  def ts_split(self, df_train):
        """
        Yields indices for train and test folds. Continues to create new fold until the test proportion relative to the train proportion is greater than "max_val_proportion" 

        Args:
            self.df_train: model training data
            self.val_duration: duration of validation set in weeks
            self.max_val_proportion: proportion of validation set relative to train set
        """
        # Initialising variables
        val_prop = 0 
        df_train_fold = df_train

        # Creating splits 
        while val_prop < self.max_val_proportion:
            
            df_train_fold_end = df_train_fold.index.max() - datetime.timedelta(weeks=self.val_duration)
            df_val_start = df_train_fold_end + datetime.timedelta(minutes=1) 
            df_val_fold = df_train_fold[df_val_start:]
            df_train_fold = df_train_fold[df_train_fold.index.min():df_train_fold_end]

            train_indices = [np.where(df_train.index.values == x)[0] for x in df_train_fold.index.values]
            test_indices = [np.where(df_train.index.values == x)[0] for x in df_val_fold.index.values]

            train_indices = self.combine_arrays(train_indices)
            test_indices = self.combine_arrays(test_indices)

            matching_indexs = [idx for idx in train_indices if idx in test_indices]

            assert len(matching_indexs) == 0, f"There is overlapping data in the cross validation train/test split for index(s) {matching_indexs}"
           
            yield (train_indices, test_indices)

            val_prop = len(df_val_fold)/len(df_train_fold)

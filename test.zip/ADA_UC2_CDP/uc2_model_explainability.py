# -*- coding: utf-8 -*-
"""
Created on 07/02/2023

@author: Awal.Singh
"""

from pathlib import Path, PurePath
from typing import List, Dict, Tuple, Any
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import lime
import shap
import xgboost as xgb


def plot_graph(plot_func, *args, **kwargs):
    """
    Generic function for plotting graphs which is used for all the following plots
    """
    addtional_args = ('title', 'save_dir', 'fontsize', 'x', 'trip_types')
    plot_func_kwargs = dict((k, kwargs[k]) for k in kwargs if k not in addtional_args)
    title_kwargs = dict((k, kwargs[k]) for k in kwargs if k in ('fontsize', 'x'))
    print(f"plot function: {plot_func.__name__}")

    plot_func(*args, **plot_func_kwargs)

    # Add title and optionally save or show plot
    plt.title(kwargs.get('title'), **title_kwargs)
    if 'save_dir' in kwargs and kwargs['save_dir'] is not None:
        kwargs['save_dir'].mkdir(parents=True, exist_ok=True)
        plt.savefig(kwargs['save_dir'] / (kwargs['title'] + '.png')) 
    else: 
        plt.show()
    plt.close()
    

class FeatureImportance:
    def __init__(self, model, save_dir:Path=None):
        self.model = model
        self.importance_types=['weight', 'gain', 'cover', 'total_gain', 'total_cover']
        self.save_dir = save_dir 
        if self.save_dir is not None: 
            assert isinstance(self.save_dir, PurePath), f"save_dir must be a pathlib path object"
            self.save_dir = self.save_dir / Path(f'{self.model.__class__.__name__}')

    def rf_get_feature_importances(self):
        importances = self.model.feature_importances_
        std = np.std([tree.feature_importances_ for tree in self.model.estimators_], axis=0)
        feature_importances = pd.DataFrame({
            "importances": importances,
            "std": std}, 
            index=self.model.feature_names_in_)

        return feature_importances

    def xgb_get_feature_impotances(self, importance_types:List[str]=None) -> Dict[str, int]:
        # Handle defaults
        if importance_types == None: importance_types = self.importance_types
        
        # Get all feature importance data per importance type
        feature_importances = dict()
        for importance_type in importance_types:
            feature_importances[importance_type] = self.model.get_booster().get_score(importance_type=importance_type)
            
        return feature_importances

    def rf_plot_feature_importances(self, max_num_features:int=10):
        """
        Plot feature importance of a sklearn Random Forest Classifier 
        """
        def rf_plotting_func(max_num_features:int=max_num_features):
            feature_importances = self.rf_get_feature_importances()

            top_features = feature_importances["importances"].abs().sort_values(ascending=False).head(max_num_features).index
            feature_importances = feature_importances.loc[top_features]

            feature_importances["importances"].sort_values().plot.barh(yerr=feature_importances['std'])

        plot_graph(
                rf_plotting_func,
                max_num_features=max_num_features, 
                title=f"Feature Importance {self.model.__class__.__name__}".title(),
                save_dir=self.save_dir)

    def xgb_plot_feature_importances(self, importance_types:List[str]=None, max_num_features:int=10):
        """
        Plot feature importance of a xgboost classifier
        """
        # Handle defaults
        if importance_types == None: importance_types = self.importance_types
        
        # Plot figure
        for importance_type in importance_types:
            plot_graph(
                xgb.plot_importance,
                self.model, 
                max_num_features=max_num_features, 
                importance_type=importance_type,
                title=f"Feature Importance {importance_type}".title(),
                save_dir=self.save_dir)

class LimeExplainer:
    def __init__(self, model, training_set_all_df: pd.DataFrame, save_dir:Path=None):
        self.model = model
        self.training_set_all_df = training_set_all_df
        self.class_mapping = {'normal': 0,'belt drift': 1,'operational blockage': 2}
        self.predict_fn = lambda x: model.predict_proba(x)
        self.num_features = 10
        self.num_samples = 5000
        self.save_dir = save_dir
        if self.save_dir is not None: 
            assert isinstance(self.save_dir, PurePath), f"save_dir must be a pathlib path object"
            self.save_dir = self.save_dir / Path(f'{self.model.__class__.__name__}')

    def get_explainer(self) -> lime.lime_tabular.LimeTabularExplainer:
        # Extract class names of response variable
        class_names = xgb_train['trip_type'].unique().tolist()
        # Remove the response variable
        train_df = self.training_set_all_df.drop(columns=['trip_type']).round(4) # Round is necessary to prevent issues with very small values

        return lime.lime_tabular.LimeTabularExplainer(train_df.values, feature_names=train_df.columns, class_names=class_names, verbose=False, mode='classification')

    def explain_instance(
        self, 
        row_df: pd.DataFrame, 
        label:str='normal', 
        num_features:int=None, 
        num_samples:int=None) -> lime.explanation.Explanation:
        
        assert len(row_df) == 1, "Input dataframe must only contain one row of data."

        # Handle defaults to use 
        if num_features is None: num_features = self.num_features
        if num_samples is None: num_samples = self.num_samples
        
        # Convert label to int to represent the model output
        label = self.class_mapping[label]
        # Return explaination
        return self.get_explainer().explain_instance(row_df.values[0], self.predict_fn, labels=[label], num_features=num_features, num_samples=num_samples)

    def get_weights(self, explaination: lime.explanation.Explanation, label:str) -> pd.DataFrame:
        # Dict of ordered numbers (0, 1, 2, etc.) and feature names. Used to map index numbers to feature names
        feature_idx_name = dict(zip(np.arange(len(explaination.domain_mapper.feature_names)), explaination.domain_mapper.feature_names))
        
        # List of integers associated to each trip type
        label = self.class_mapping[label]
        
        # Extract all the relevant data out of the model explainer to put in a dataframe
        idxs = [x[0] for x in explaination.as_map()[label]]
        weights = [x[1] for x in explaination.as_map()[label]]
        features = [feature_idx_name[x] for x in idxs]
        ranges = [explaination.domain_mapper.discretized_feature_names[x] for x in idxs]

        return pd.DataFrame({'idxs': idxs, 'features': features, 'weights': weights, 'ranges': ranges})

    def get_explanations(self, row_df: pd.DataFrame) -> Tuple[Dict[str, lime.explanation.Explanation], Dict[str, pd.DataFrame]]:
        # List of trip types
        labels = list(self.class_mapping.keys())

        # List of model explainers per trip types
        explainations = [self.explain_instance(row_df, label=label) for label in labels]
        # List of weight (dataframes) per trip type
        weights = [self.get_weights(explanation, label=label) for label, explanation in zip(labels, explainations)]

        # Convert to dict for association of trip types and relevant data
        explainations = dict(zip(labels, explainations))
        weights = dict(zip(labels, weights))

        return explainations, weights

class ShapExplainer:
    def __init__(self, model, input_df: pd.DataFrame, save_dir:Path=None):
        self.model = model.best_estimator_
        self.model_type = model.model_type
        self.class_mapping = model.class_mapping
        self.inv_class_mapping = {v: k for k, v in self.class_mapping.items()}
        self.input_X = input_df.drop(['trip_type'], axis=1)
        self.input_y = input_df['trip_type'].replace(self.class_mapping)
        self.predict_fn = lambda x: self.model.predict_proba(x)
        self.explainer = shap.TreeExplainer(self.model)
        self.shap_values = self.explainer.shap_values(self.input_X, y=self.input_y)
        self.shap_expected_value = self.explainer.expected_value
        self.save_dir = save_dir
        if self.save_dir is not None: 
            assert isinstance(self.save_dir, PurePath), f"save_dir must be a pathlib path object"
            self.save_dir = self.save_dir / Path(f'{self.model.__class__.__name__}')

        if self.model_type == 'xgb' and (len(self.class_mapping) == 2):
            self.shap_values = [-self.shap_values, self.shap_values]
            self.shap_expected_value = [-self.shap_expected_value, self.shap_expected_value]

        
    def summary_plot(self, *args, **kwargs):
        # Feature importance
        plot_graph(
            shap.summary_plot,
            self.shap_values, 
            self.input_X, 
            class_names=list(self.class_mapping.keys()), # List of trip types
            show = False,
            *args, 
            **kwargs,
            title="Shap summary plot".title(),
            save_dir=self.save_dir)

    def summary_plot_classes(self, trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        for trip_type in trip_types:
            # Feature importance
            plot_graph(
                shap.summary_plot,
                self.shap_values[trip_type],
                self.input_X,
                *args, 
                **kwargs,
                show = False,
                title = f"shap summary plot for {self.inv_class_mapping[trip_type]}".title(),
                fontsize = 20,
                save_dir=self.save_dir)
            print('')

    def general_decision_plot(self, row_indexs:List[int]=None, highlight:List[bool]=None, trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        # If no index given use all data
        if row_indexs is None: row_indexs = list(range(len(self.input_X)))

        for trip_type in trip_types:
            plot_graph(
                shap.decision_plot,
                self.shap_expected_value[trip_type], 
                self.shap_values[trip_type][row_indexs], 
                self.input_X.iloc[row_indexs],
                *args, 
                **kwargs,
                highlight=highlight,
                show = False,
                title = f"shap decision plot for {self.inv_class_mapping[trip_type]}".title(),
                fontsize = 20,
                save_dir=self.save_dir)
            print('')
    
    def force_plot(self, row_indexs:List[int], trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        # Convert row_indexs to list if not list. If it is an int this function still works.
        if type(row_indexs) is not list: row_indexs = [row_indexs]

        for row_index in row_indexs:
            for trip_type in trip_types:
                plot_graph(
                    shap.force_plot,
                    self.shap_expected_value[trip_type], 
                    self.shap_values[trip_type][row_index], 
                    self.input_X.iloc[row_index], 
                    matplotlib=True,
                    show=False,
                    *args, 
                    **kwargs,
                    title=f"shap force plot for {self.inv_class_mapping[trip_type]}".title(),
                    fontsize = 20,
                    x=0.2,
                    save_dir=self.save_dir)

                print('')


    def single_decision_plot(self, row_indexs:List[int], trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        # Convert row_indexs to list if not list. If it is an int this function still works.
        if type(row_indexs) is not list: row_indexs = [row_indexs]

        for row_index in row_indexs:
            for trip_type in trip_types:
                plot_graph(
                    shap.decision_plot,
                    self.shap_expected_value[trip_type], 
                    self.shap_values[trip_type][row_index], 
                    self.input_X.iloc[row_index],
                    *args, 
                    **kwargs,
                    highlight=0,
                    show=False,
                    title=f"shap decision plot for {self.inv_class_mapping[trip_type]}, row_index:{row_index}".title(),
                    fontsize = 20,
                    save_dir=self.save_dir)
                print('')
    
    def multi_output_decision_plot(self, row_indexs: List[int], *args, **kwargs):
        # Convert row_indexs to list if not list. If it is an int this function still works.
        if type(row_indexs) is not list: row_indexs = [row_indexs]

        # Plot multioutput decision plot
        for row_index in row_indexs:
            plot_graph(
                shap.multioutput_decision_plot,
                self.shap_expected_value, 
                self.shap_values,
                *args,
                **kwargs,
                show=False,
                row_index=row_index,
                feature_names=list(self.input_X.columns),
                legend_labels=self.class_mapping.keys(),
                legend_location='lower right',
                title=f"shap multi decision plot, row_index:{row_index}".title(),
                fontsize = 20,
                save_dir=self.save_dir)
    
    def dependance_plot(self, feature:str, trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        for trip_type in trip_types:
            plot_graph(
                shap.dependence_plot,
                feature, 
                self.shap_values[trip_type], 
                self.input_X,
                *args, 
                **kwargs,
                show=False,
                title=f"shap dependance plot for {self.inv_class_mapping[trip_type]}, feature: {feature}".title(),
                save_dir=self.save_dir)
    
    def top_dependance_plots(self, top_n:int=5, trip_types:List[int]=None, *args, **kwargs):
        if trip_types is None: trip_types = self.inv_class_mapping

        top_features = dict()
        for trip_type in trip_types:
            top_features[trip_type] = self.input_X.columns[np.argsort(-np.abs(self.shap_values[trip_type]).mean(0))]
            for feature in top_features[trip_type][:top_n]:
                plot_graph(
                shap.dependence_plot,
                feature, 
                self.shap_values[trip_type], 
                self.input_X,
                *args, 
                **kwargs,
                show=False,
                title=f"shap dependance plot for {self.inv_class_mapping[trip_type]}, feature: {feature}".title(),
                save_dir=self.save_dir)
            print('')


def run_model_explainer(explainer_dir:Path, input_df:pd.DataFrame, model:Any, model_type:str):
    # Run Model Explainability
    explainer_data = input_df

    importance = FeatureImportance(model, save_dir=explainer_dir)
    shap_explainer = ShapExplainer(model, explainer_data, save_dir=explainer_dir)
    # lime_explainer = LimeExplainer(model, input_df, save_dir=explainer_dir)

    # Plot Feature Importances
    if model_type == 'rf': importance.rf_plot_feature_importances()
    if model_type == 'xgb': importance.xgb_plot_feature_importances()
    
    # Save plots for Shap explainer
    shap_explainer.summary_plot()
    shap_explainer.summary_plot_classes()
    shap_explainer.general_decision_plot()
    shap_explainer.top_dependance_plots()


# ADA Use Case 2: Conveyor Downtime Prediction

<br>

MVP model code for Gudai-Darri Advanced Data Analytics <b>Use Case 2: Conveyor Downtime Prediction.</b>
<br><br>
Model files consist of training pipeline steps, inference code and 
utility functions and reference files used by both training and inference.
<br>

##<b>Training Pipeline</b>

The UC2 training pipeline consists of 4 Python script steps:

1. <b>uc2_pipeline_dataload.py:</b> Data load step for the PCS Tag, Weather and Fixed Plant Time Usage input data<br>
2. <b>uc2_pipeline_dataprep.py:</b> Data pre-processing to transform data before the training step<br>
3. <b>uc2_pipeline_train.py:</b> Training step which creates the training and test datasets, trains the Machine Learning components of the use case and performs accuracy tests. The algorithms trained are the Random Forest and XGBoost classifiers, and the training step also trains the downtime duration component <br>
4. <b>uc2_pipeline_register.py:</b> Registers the trained components of the UC2 model to the Models section of the ML Workspace, along with the model source code<br>

The Training Pipeline is intended to deployed in Azure Machine Learning by DevOps pipeline, see the ADA_ADO folder for deployment scripts, which contain the data input references.
Manual deployments via Notebook are also possible. <br>
<br>
Pipeline data inputs are as follows:<br>
-   <b>PCS Tags:</b> Input is the Parquet file of consolidated and normalized Json PCS Tag data files, which is the output of the Daily Data Load pipeline. This greatly reduces the pipeline run time compared to access the Json files directly due to the size of the PCS Tag dataset<br>
-   <b>Weather:</b> Accessed directly from the Landed Data Storage container<br>
-   <b>Fixed Plant Time Usage:</b> Accessed directly from the Landed Data Storage container. This dataset provides the labelling for the historical time period (i.e. presence and type of downtime event)<br>

The date range arguments take the format ‘yyyy-mm-dd’. To allow for dynamic pipelines, the preferred approach is for the following arguments take the value ‘default’ as follows:<br>
-   Period_end = ‘default’: Current date minus 1 day<br>

##<b>Inference Code</b>

Inference is by AKS real-time endpoint, see ADO_ADA folder for deployment files and scoring script. Endpoint is triggered every 3 minutes by an Azure Function. The scoring script for inference reference the following Python files<br>

- <b>uc2_inference_model.py:</b> Unifying function which pulls together all component parts of the solution to produce the required output. This function within the file allows for section of the different classifiers that are trained in the training step via parameter. The function references the uc2_inference_dataprep.py and uc2_inference_downtime_duration.py as component parts
- <b>uc2_inference_dataprep.py:</b> Data pre-processing for the inference function.<br>
- <b>uc2_inference_downtime_duration.py:</b> Attributes the appropriate downtime duration from the trained components for a given downtime event.<br>


##<b>Common Libraries</b>

- <b>uc2_utils.py:</b> Utility functions used by multiple use case Python files<br>

##<b>Reference Files</b>

- <b>uc2_tag_lists folder:</b> Full tag lists for each belt <br>
- <b>model selected features folder:</b> Exact list of final features used for training and inference, ensuring consistent feature sets between the two.<br>



import load_ADA_data
import datetime
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import argparse
import os
import ADA_UC2_CDP.uc2_utils as uc2_utils
import ADA_UC2_CDP.uc2_utils_processing as uc2_utils_processing 

# Parse Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--PCS_tags")
parser.add_argument("--FPTU")
parser.add_argument("--Weather")
parser.add_argument("--belt")
parser.add_argument("--data_prep_interim")
parser.add_argument("--raw_data_interim")
parser.add_argument("--period_start")
parser.add_argument("--period_end")
args = parser.parse_args()

# Set path variables
raw_data_interim = args.raw_data_interim
data_prep_interim = args.data_prep_interim

# Start spark session
spark = uc2_utils_processing.create_spark_env()

# Get start and end dates as UTC
period_start_utc, period_end_utc = uc2_utils_processing.transform_dates(args.period_start, args.period_end)

# Load Data
df_tags = uc2_utils_processing.load_pcs_tag_data(spark, args.belt, args.PCS_tags, period_start_utc, period_end_utc, save_dir=raw_data_interim)
df_weather = uc2_utils_processing.load_weather(spark, args.Weather, period_start_utc, period_end_utc, save_dir=raw_data_interim)
df_FPTU = uc2_utils_processing.load_fptu(spark, args.FPTU, period_start_utc, period_end_utc, file_type='parquet', save_dir=raw_data_interim)

# Create gd_delay_duration_lookup.csv
gd_delay_duration_lookup = uc2_utils_processing.get_gd_delay_duration_lookup(df_FPTU, period_start_utc, period_end_utc, save_dir=data_prep_interim)

# Process the data
df_FPTU_processed = uc2_utils_processing.process_fptu_raw(df_FPTU, args.belt, period_start_utc, period_end_utc, save_dir=data_prep_interim)

df_combined = uc2_utils_processing.combine_tag_weather(spark, args.belt, df_tags, df_weather, period_start_utc, period_end_utc, save_dir=data_prep_interim)

import os
import pandas as pd
import numpy as np
import datetime
import load_ADA_data
import ADA_UC2_CDP.uc2_utils as uc2_utils

def uc2_dataload(dt, belt):
        # Load PCS Tags - last 30 minutes
        belt_tag_list_name = 'uc2_tag_lists/UC2_'+belt+'_Tags.txt'
        uc2_tags_list = os.path.join(os.path.dirname(__file__), belt_tag_list_name)
        tag_list = []
        with open(uc2_tags_list) as f:
            tag_list = f.read().splitlines() 
        f.close()

        df_tags = load_ADA_data.LoadDataDirect("kd-int054-process-control-data-from-osisoft-pi-ada", dt, 30, tag_list).load_data_to_df()
        
        # Load Weather data - last 61 minutes to ensure latest forecast is captured (forecast is hourly)
        df_weather = load_ADA_data.LoadDataDirect("kd-int056-weatherzone-forecasts-ada", dt, 181).load_data_to_df()
           
        return df_tags, df_weather

def uc2_dataprep(df_tags, df_weather, dt, belt):        
        # Tag data preparation
        df_tags_pivoted = uc2_utils.pivot_pcs_tags(df_tags)

        # Extend index to datetime of prediction if it doesn't reach and forward fill data 
        dt_awst = dt + datetime.timedelta(hours=8)
        ext_index = pd.date_range(start=df_tags_pivoted.index.min(), end=dt_awst, freq="T")
        df_tags_pivoted = df_tags_pivoted.reindex(ext_index, fill_value=np.nan)
        df_tags_pivoted = df_tags_pivoted.fillna(method='ffill')

        df_tags_pivoted = uc2_utils.tags_data_prep(df_tags_pivoted,belt,inference=True)

        # Weather data preparation
        df_weather = uc2_utils.weather_data_prep(df_weather)

        # Merge Tag and Weather data
        df_combined = df_tags_pivoted.merge(df_weather,left_index=True,right_index=True)
        
        # Load final feature lists used for model training and filter
        selected_features_list_file = os.path.join(os.path.dirname(__file__), 'model_selected_features/'+belt +'_selected_features_list.txt')
        selected_features_list = []
        with open(selected_features_list_file) as f:
                selected_features_list = f.read().splitlines() 
                f.close()
        df_combined_feat = df_combined[selected_features_list]

        # Look Up Belt Speed
        beltspeed_tags_file = os.path.join(os.path.dirname(__file__), 'uc2_tag_lists/UC2_Tags_TQBS.csv') 
        df_beltspeed = pd.read_csv(beltspeed_tags_file)
        beltspeed_tags_name = df_beltspeed[df_beltspeed['Tag_Desc'].isin([belt+'_BeltSpeed'])]['Tag_Name'].head(1)# get the belt speed tag for the belt (take only one if there are multiples)
        belt_speed = df_combined_feat[beltspeed_tags_name.values[0]].sort_index().tail(1).values[0] # get the belt speed for the max timestamp

        # Feature Engineering for UC2 model
        
        T = 30 # looks at max 30 mins before downtime event
        P = 15 # looks at values of the past 15 mins from each Interval within 30mins of the delay
        I = 3 # Number of minute per each interval
        G = 3
        
        df_features = uc2_utils.create_sample_range(df_combined_feat, [dt_awst], T, P, I, G, inference=True)

        # fillna for missing kurtosis variables
        df_features.fillna(0, inplace=True)

        # Remove Mean feature for non-resettable totalisers
        non_reset_ton = df_features.filter(regex= r'^mean.*?TOTNRST$').columns
        df_features.drop(columns=non_reset_ton, inplace=True)

        return df_features,belt_speed
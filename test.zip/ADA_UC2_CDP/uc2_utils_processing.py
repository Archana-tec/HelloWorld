# TODO: Install repo as a package so that we don't have to do relative imports!
# Note: This module will only work if run from the RTIOKoodaideriAdvancedDataAnalytics directory!
# Set the appropriate path for imports
import sys

sys.path.append('../RTIOKoodaideriAdvancedDataAnalytics')

import datetime
import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import ADA_UC2_CDP.uc2_inference_dataprep as uc2_inference_dataprep
import ADA_UC2_CDP.uc2_model as uc2_model
import ADA_UC2_CDP.uc2_utils as uc2_utils
import joblib
import load_ADA_data
import numpy as np
import pandas as pd
import pyspark
import scipy.stats as stats
from pandas.tseries.offsets import Hour, Minute
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import input_file_name
from pyspark.sql.types import (BooleanType, DoubleType, IntegerType, LongType,
                               StringType, StructField, StructType,
                               TimestampType)
from scipy.stats import iqr
from tqdm import tqdm

## Constants
# How far back in time we look when we aggregate data
agg_time_range = pd.Timedelta(minutes=29)
# Prediction time before event
pred_time_before_event = pd.Timedelta(minutes=30)
# AMPLA offset time
ampla_offset = pd.Timedelta(minutes=3)
# Functions used to aggregate data
agg_stats = ['mean','std']

# Categorisations of the BDS data
bds_groups = {
    "CV0313": {
        'switches': [
            'KD1.PPCS.CV0313BDS01_I', 'KD1.PPCS.CV0313BDS02_I',
            'KD1.PPCS.CV0313BDS03_I', 'KD1.PPCS.CV0313BDS04_I',
            'KD1.PPCS.CV0313BDS09_I', 'KD1.PPCS.CV0313BDS10_I',
            'KD1.PPCS.CV0313BDS11_I', 'KD1.PPCS.CV0313BDS12_I'],
        
        'alarms': [
            'KD1.PPCS.CV0313BDS01_A', 'KD1.PPCS.CV0313BDS02_A',
            'KD1.PPCS.CV0313BDS03_A', 'KD1.PPCS.CV0313BDS04_A',
            'KD1.PPCS.CV0313BDS09_A', 'KD1.PPCS.CV0313BDS10_A',
            'KD1.PPCS.CV0313BDS11_A', 'KD1.PPCS.CV0313BDS12_A',

            'KD1.PPCS.CV0313BDS01_FIL', 'KD1.PPCS.CV0313BDS02_FIL',
            'KD1.PPCS.CV0313BDS03_FIL', 'KD1.PPCS.CV0313BDS04_FIL',
            'KD1.PPCS.CV0313BDS09_FIL', 'KD1.PPCS.CV0313BDS10_FIL'],

        'bcs': [
            'KD1.PPCS.CV0313CH02BCS01YI01_A', 'KD1.PPCS.CV0313CH02BCS01_24V_A',
            'KD1.PPCS.CV0313CH02BCS01_A', 'KD1.PPCS.CV0313CH02BCS01_FIL',
            'KD1.PPCS.CV0313CH02BCS02_24V_A', 'KD1.PPCS.CV0313CH02BCS02_A',
            'KD1.PPCS.CV0313CH02BCS02_FIL']
            },

    "CV0316": {
        "switches": [
            'KD1.PPCS.CV0316BDS01_I', 'KD1.PPCS.CV0316BDS02_I',
            'KD1.PPCS.CV0316BDS03_I', 'KD1.PPCS.CV0316BDS04_I',
            'KD1.PPCS.CV0316BDS07_I', 'KD1.PPCS.CV0316BDS08_I',
            'KD1.PPCS.CV0316BDS11_I', 'KD1.PPCS.CV0316BDS12_I',
            'KD1.PPCS.CV0316BDS13_I', 'KD1.PPCS.CV0316BDS14_I'],

        'alarms': [
            'KD1.PPCS.CV0316BDS01_A', 'KD1.PPCS.CV0316BDS02_A',
            'KD1.PPCS.CV0316BDS03_A', 'KD1.PPCS.CV0316BDS04_A',
            'KD1.PPCS.CV0316BDS07_A', 'KD1.PPCS.CV0316BDS08_A',
            'KD1.PPCS.CV0316BDS11_A', 'KD1.PPCS.CV0316BDS12_A',
            'KD1.PPCS.CV0316BDS13_A', 'KD1.PPCS.CV0316BDS14_A',
            
            'KD1.PPCS.CV0316BDS01_FIL', 'KD1.PPCS.CV0316BDS02_FIL',
            'KD1.PPCS.CV0316BDS03_FIL', 'KD1.PPCS.CV0316BDS04_FIL',
            'KD1.PPCS.CV0316CH02BCS01_FIL', 'KD1.PPCS.CV0316CH02BCS02_FIL'],
            
        'bcs': [
            'KD1.PPCS.CV0316CH02BCS01YI01_A', 'KD1.PPCS.CV0316CH02BCS01_24V_A',
            'KD1.PPCS.CV0316CH02BCS01_A', 'KD1.PPCS.CV0316CH02BCS01_FIL',
            'KD1.PPCS.CV0316CH02BCS02_24V_A', 'KD1.PPCS.CV0316CH02BCS02_A',
            'KD1.PPCS.CV0316CH02BCS02_FIL']
    }
}

# Tags we aquired outside of the integration which we are now using. These are seperated by resmaple method (last or sum) and tag type
hist_tags = {
    "CV0313": {
        'resample_sum':  {
            'bds_i': [
            'KD1.PPCS.CV0313BDS01_I', 'KD1.PPCS.CV0313BDS02_I',
            'KD1.PPCS.CV0313BDS03_I', 'KD1.PPCS.CV0313BDS04_I',
            'KD1.PPCS.CV0313BDS09_I', 'KD1.PPCS.CV0313BDS10_I',
            'KD1.PPCS.CV0313BDS11_I', 'KD1.PPCS.CV0313BDS12_I', 
            ],
            'bds_alarm': [
            'KD1.PPCS.CV0313BDS01_A', 'KD1.PPCS.CV0313BDS02_A',
            'KD1.PPCS.CV0313BDS03_A', 'KD1.PPCS.CV0313BDS04_A',
            'KD1.PPCS.CV0313BDS09_A', 'KD1.PPCS.CV0313BDS10_A',
            'KD1.PPCS.CV0313BDS11_A', 'KD1.PPCS.CV0313BDS12_A',
            
            'KD1.PPCS.CV0313BDS01_FIL', 'KD1.PPCS.CV0313BDS02_FIL',
            'KD1.PPCS.CV0313BDS03_FIL', 'KD1.PPCS.CV0313BDS04_FIL',
            'KD1.PPCS.CV0313BDS09_FIL', 'KD1.PPCS.CV0313BDS10_FIL'
            ],
            'other': [ 
            'KD1.PPCS.GA0301_OPND','KD1.PPCS.GA0302_OPND',
            'KD1.PPCS.GA0303_OPND','KD1.PPCS.GA0304_OPND',
            'KD1.PPCS.GA0305_OPND','KD1.PPCS.GA0306_OPND',
            'KD1.PPCS.GA0307_OPND'
            ]
        },
        'resample_last': [
            'KD1.PPCS.CV0313BDT13_I', 'KD1.PPCS.CV0313BDT14_I', 
            'KD1.PPCS.CV0313BDT13_DRIFT', 'KD1.PPCS.CV0313BDT14_DRIFT', 
            'KD1.PPCS.CV0313WT01_OT1DENAVG', 'KD1.PPCS.CV0313WT02_ACTDAT_TONRT',
            'KD1.PPCS.CV0313WT02_ACTDAT_LFB', 'KD1.PPCS.CV0313WT02_ACTDAT_RFB', 
            'KD1.PPCS.CV0313_VF01ESTRT', 'KD1.PPCS.CV0313_VF02ESTRT', 
            'KD1.PPCS.CV0313_VF03ESTRT', 'KD1.PPCS.CV0313_VF04ESTRT',
            'KD1.PPCS.CV0313_VF05ESTRT', 'KD1.PPCS.CV0313_VF06ESTRT', 
            'KD1.PPCS.CV0313_VF07ESTRT','KD1.PPCS.VF0301SS01_SPD', 
            'KD1.PPCS.VF0302SS01_SPD','KD1.PPCS.VF0303SS01_SPD',
            'KD1.PPCS.VF0304SS01_SPD', 'KD1.PPCS.VF0305SS01_SPD',
            'KD1.PPCS.VF0306SS01_SPD','KD1.PPCS.VF0307SS01_SPD',
            'KD1.PPCS.BN0301LT0X','KD1.PPCS.BN0302LT0X',
            'KD1.PPCS.BN0303LT0X', 'KD1.PPCS.BN0304LT0X',
            'KD1.PPCS.BN0305LT0X', 'KD1.PPCS.BN0306LT0X',
            'KD1.PPCS.BN0307LT0X'
        ]
    },
    
    "CV0316": {
        'resample_sum':  {
            'bds_i': [
                'KD1.PPCS.CV0316BDS01_I', 'KD1.PPCS.CV0316BDS02_I',
                'KD1.PPCS.CV0316BDS03_I', 'KD1.PPCS.CV0316BDS04_I',
                'KD1.PPCS.CV0316BDS07_I', 'KD1.PPCS.CV0316BDS08_I',
                'KD1.PPCS.CV0316BDS11_I', 'KD1.PPCS.CV0316BDS12_I',
                'KD1.PPCS.CV0316BDS13_I', 'KD1.PPCS.CV0316BDS14_I'
            ],
            'bds_alarm': [
                'KD1.PPCS.CV0316BDS01_A', 'KD1.PPCS.CV0316BDS02_A',
                'KD1.PPCS.CV0316BDS03_A', 'KD1.PPCS.CV0316BDS04_A',
                'KD1.PPCS.CV0316BDS07_A', 'KD1.PPCS.CV0316BDS08_A',
                'KD1.PPCS.CV0316BDS11_A', 'KD1.PPCS.CV0316BDS12_A',
                'KD1.PPCS.CV0316BDS13_A', 'KD1.PPCS.CV0316BDS14_A',
                
                'KD1.PPCS.CV0316BDS01_FIL', 'KD1.PPCS.CV0316BDS02_FIL',
                'KD1.PPCS.CV0316BDS03_FIL', 'KD1.PPCS.CV0316BDS04_FIL',
                'KD1.PPCS.CV0316CH02BCS01_FIL', 'KD1.PPCS.CV0316CH02BCS02_FIL'
            ],
            'other': [ 
                'KD1.PPCS.GA0301_OPND','KD1.PPCS.GA0302_OPND',
                'KD1.PPCS.GA0303_OPND','KD1.PPCS.GA0304_OPND',
                'KD1.PPCS.GA0305_OPND','KD1.PPCS.GA0306_OPND',
                'KD1.PPCS.GA0307_OPND'
            ]
        },
        'resample_last': [
            'KD1.PPCS.CV0316_VF01ESTRT', 'KD1.PPCS.CV0316_VF02ESTRT', 
            'KD1.PPCS.CV0316_VF03ESTRT', 'KD1.PPCS.CV0316_VF04ESTRT',
            'KD1.PPCS.CV0316_VF05ESTRT', 'KD1.PPCS.CV0316_VF06ESTRT',
            'KD1.PPCS.CV0316_VF07ESTRT', 
            
            'KD1.PPCS.CV0316WT02_ACTDAT_LFB', 'KD1.PPCS.CV0316WT02_ACTDAT_RFB', 

            'KD1.PPCS.CV0316BDT15_I', 'KD1.PPCS.CV0316BDT15_DRIFT',
            'KD1.PPCS.CV0316BDT16_I', 'KD1.PPCS.CV0316BDT16_DRIFT',
            
            'KD1.PPCS.CV0316WT02_ACTDAT_TONRT',

            'KD1.PPCS.VF0301SS01_SPD', 'KD1.PPCS.VF0302SS01_SPD',
            'KD1.PPCS.VF0303SS01_SPD', 'KD1.PPCS.VF0304SS01_SPD', 
            'KD1.PPCS.VF0305SS01_SPD','KD1.PPCS.VF0306SS01_SPD',
            'KD1.PPCS.VF0307SS01_SPD',
            
            'KD1.PPCS.BN0301LT0X','KD1.PPCS.BN0302LT0X',
            'KD1.PPCS.BN0303LT0X', 'KD1.PPCS.BN0304LT0X',
            'KD1.PPCS.BN0305LT0X', 'KD1.PPCS.BN0306LT0X',
            'KD1.PPCS.BN0307LT0X'
        ]

    }
}

def create_spark_env(existing_session:bool=False) -> SparkSession:
    """Used to create a spark session for data processing.

    Initially you can create a spark session by running below.
    spark = create_spark_env()

    However this function doesn't need to be run twice on the same instance if a spark session is already created.
    If so you can connect to it again by running below.
    
    spark = create_spark_env(existing_session=True)

    Parameters
    ----------
    existing_session : bool, optional
        Option if spark session already exists, by default False

    Returns
    -------
    SparkSession
        The spark session we created.
    """    

    if existing_session:
        # Connect to existing spark session 
        os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
        spark = SparkSession.builder.getOrCreate()
        return spark


    else:
        # Start spark session
        spark = SparkSession.builder \
                        .appName('app_name') \
                        .master('local[*]') \
                        .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                        .config('spark.sql.session.timeZone', 'UTC') \
                        .config('spark.driver.memory','64G') \
                        .config('spark.executor.memory', '64G') \
                        .config('spark.ui.showConsoleProgress', True) \
                        .config('spark.sql.repl.eagerEval.enabled', True) \
                        .config('spark.driver.maxResultSize','0')\
                        .config("spark.sql.parquet.enableVectorizedReader","false")\
                        .getOrCreate()

        # Set spark session IP
        os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'

        return spark

def transform_dates(period_start_str:str, period_end_str:str) -> Tuple[datetime.datetime]:
    """Turn dates from string to datetime format.

    This assumes that the date is in UTC time with the format '%Y-%m-%d'.

    If given 'default' as the end time we use one day previous to when it is run.

    Parameters
    ----------
    period_start_str : str
        Start time as a string.
    period_end_str : str
        End time as a string.

    Returns
    -------
    Tuple[datetime.datetime]
        Returns the new start and end time
    """

    if period_end_str == 'default':
        period_end_str = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1), '%Y-%m-%d')

    period_start_utc = datetime.datetime.strptime(period_start_str,'%Y-%m-%d')
    period_end_utc = datetime.datetime.strptime(period_end_str,'%Y-%m-%d')
    return period_start_utc, period_end_utc

def dates_utc_to_awst(
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime) -> Tuple[datetime.datetime]:
    """Converts datetime from UTC to Perth/Singapore time.

    The input is the expected output of transform_dates

    Parameters
    ----------
    period_start_utc : datetime.datetime
        Start time in UTC
    period_end_utc : datetime.datetime
        End time in UTC

    Returns
    -------
    Tuple[datetime.datetime]
        The updated Perth/Singapore time.
    """
    
    dt_start_awst = period_start_utc + datetime.timedelta(hours=8)
    dt_end_awst = period_end_utc + datetime.timedelta(hours=8)

    return dt_start_awst, dt_end_awst

def drop_subsequent_timestamps(df:pd.DataFrame, minutes:int=1):
    # Drop all data where the diffence in time is only 1 minute (by default)
    df = pd.concat([
        df.iloc[[1]],
        df[1:][df.index[1:] - df.index[:-1] != pd.Timedelta(minutes=minutes)]
    ])
    return df
    
def load_pcs_tag_data(
    spark: SparkSession,
    belt:str, 
    PCS_tags_path:str, 
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Load the PCS tag data after the daily data load has formatted it into parquet files.

    Parameters
    ----------
    spark : SparkSession
        The spark session used for processing.
    belt : str
        Name of the belt.
    PCS_tags_path : str
        Folder location of the PCS data we will load.
    period_start_utc : datetime.datetime
        Start time in UTC for loading the data.
    period_end_utc : datetime.datetime
        End time in UTC for loading the data.
    save_dir : Optional[str], optional
        Directory we want to save the data into if we want to save after loading, by default None

    Returns
    -------
    pd.DataFrame
        The PCS tag data as a dataframe.
    """

    ### Load PCS Tags
    belt_tag_list_name = 'uc2_tag_lists/UC2_'+belt+'_Tags.txt'
    uc2_tags_list = os.path.join('ADA_UC2_CDP', belt_tag_list_name)
    tag_list = []
    with open(uc2_tags_list) as f:
        tag_list = f.read().splitlines() 
    f.close()
    # Load Pcs tag data from saved data cache
    sdf_tags = spark.read.parquet(PCS_tags_path)
    # Filter for time period and tags that are in-scope
    sdf_tags = sdf_tags[(sdf_tags.tagid.isin(tag_list))& (sdf_tags.time_rio.between(period_start_utc, period_end_utc))]

    if save_dir is not None:
        if os.path.exists((save_dir+'/PCS_tags')):
            sdf_tags.write.format("parquet").mode('overwrite').save(save_dir+'/PCS_tags')
        else:
            sdf_tags.write.parquet(save_dir+'/PCS_tags')

    # Pivot Tag data to one column per one tag
    df_tags = sdf_tags.toPandas()
    df_tags = uc2_utils.pivot_pcs_tags(df_tags)
    
    if save_dir is not None:
        df_tags.to_parquet(save_dir+'/'+belt+'_tags_pivot',index=True)

    # df_tags = uc2_utils.tags_data_prep(df_tags_pivot, belt)

    return df_tags

def load_bds_data(
    spark:SparkSession,
    belt:str, 
    BDS_path:str,
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Load the historical belt drift switch data (BDS).

    Parameters
    ----------
    spark : SparkSession
        The spark session required for loading and processing the data.
    BDS_path : str
        The folder path of the BDS data 
    period_start_utc : datetime.datetime
        The start time we want to load from.
    period_end_utc : datetime.datetime
        The end time we want to load from.
    save_dir : Optional[str], optional
        Directory we can save to if we want to save the output, by default None

    Returns
    -------
    pd.DataFrame
        The BDS data.
    """

    tags_to_load = bds_groups[belt]['switches'] + bds_groups[belt]['alarms']   

    df_BDS = spark.read.parquet(*[BDS_path + f"/{x}*" for x in tags_to_load])
    df_BDS = df_BDS[df_BDS.time_rio.between(period_start_utc, period_end_utc)]
    df_BDS = df_BDS.toPandas()

    if save_dir is not None:
        df_BDS.to_parquet(save_dir+'/'+belt+'_BDS_data',index=True)

    return df_BDS

def load_new_data_tmp(
    spark:SparkSession,
    belt:str, 
    data_path:str,
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Load the data that is not in the integration.

    Parameters
    ----------
    spark : SparkSession
        The spark session required for loading and processing the data.
    data_path : str
        The folder path of the data 
    period_start_utc : datetime.datetime
        The start time we want to load from.
    period_end_utc : datetime.datetime
        The end time we want to load from.
    save_dir : Optional[str], optional
        Directory we can save to if we want to save the output, by default None

    Returns
    -------
    pd.DataFrame
        Output dataframe
    """

    # For this ingestion we only loaded data up to '01-08-2023' so we should remove data after this.
    # Because of forward filling this causes a bug and hence we need to update period_end_utc to be '01-08-2023' 
    if period_end_utc > datetime.datetime(2023, 8, 1):
        period_end_utc = datetime.datetime(2023, 8, 1)

    tags_to_load = hist_tags[belt]['resample_sum']['bds_i'] + hist_tags[belt]['resample_sum']['other'] + hist_tags[belt]['resample_last']    
    
    df = spark.read.parquet(*[data_path + f"/{x}*"  for x in tags_to_load])
    df = df[df.time_rio.between(period_start_utc, period_end_utc)]
    df = df.toPandas()

    if save_dir is not None:
        df.to_parquet(save_dir+'/'+belt+'_data_outside_integration',index=True)

    return df


def process_new_data_tmp(df:pd.DataFrame, 
    belt: str
    ) -> pd.DataFrame:
    """Process the new data
    
    Parameters
    ----------
    df : pd.DataFrame
        The dataframe after running load_bds_data or load_new_data_tmp
    belt : str
        The conveyor name

    Returns
    -------
    pd.DataFrame
        The processed data, resampled and forward filled.
    """

    # Drop duplicates, convert to Perth time and pivot 
    df = df.drop_duplicates(subset=['tagid', 'time_rio'], keep='first')
    df['time_rio'] = df['time_rio'] + datetime.timedelta(hours=8) 
    df['time_rio'] = [dt.tz_localize(None) for dt in df['time_rio']]
    df = df.pivot(index='time_rio', columns='tagid', values='value_rio')

    ## Data cleaning for categorical tags
    # Swapping 0's with ones for the '_I' tags
    df.loc[:, hist_tags[belt]['resample_sum']['bds_i']] = df.loc[:, hist_tags[belt]['resample_sum']['bds_i']].replace([0,1],[1,0])

    # List of categorical tag names
    resample_sum_columns = df.columns[df.columns.isin(hist_tags[belt]['resample_sum']['bds_i'] + hist_tags[belt]['resample_sum']['other'] + hist_tags[belt]['resample_sum']['bds_alarm'])]

    # Resampling to a 1 minute frequency and summing. Ensuring at least 1 value in that min is availble to sum, if not then NaN is returned
    df_resample_sum = df[resample_sum_columns].resample('T').sum(min_count=1)

    # Resampling to a 1 minute frequency and extracting the last value. Merging resample sum and resample last
    df_resample_last = df[resample_sum_columns].resample('T').last()
    df_resample_sum = df_resample_sum.merge(df_resample_last, how='left', on='time_rio', suffixes=('_sum', '_last'))

    # Shifting values down 1 minute and merging shifted values
    df_resmaple_sum_shift = df_resample_sum.shift(1)
    df_resample_sum = df_resample_sum.merge(df_resmaple_sum_shift, on='time_rio', how='left', suffixes=('_noshift',"_shift"))

    # Logic to handle if value jumps from 1 to 0 in the same minute. 
    # If the current value is null and the previous sum is > 0 and the previous last value = 0, then replace current sum value with 0. This ensures we are forward filling correctly.
    sum_columns_no_shift = df_resample_sum.columns[df_resample_sum.columns.str.endswith('_sum_noshift')]
    for column in sum_columns_no_shift:
        column_sum_shift = column.replace('_noshift', '_shift')
        column_last_shift = column.replace('_sum_noshift', '_last_shift')
        df_resample_sum[column] = df_resample_sum.apply(lambda x: 0 if ((np.isnan(x[column])) & (x[column_sum_shift]>0) & (x[column_last_shift]==0)) else x[column], axis=1)

    # Only selecting "sum_noshift" columns
    df_resample_sum = df_resample_sum[sum_columns_no_shift]

    # Renaming columns
    df_resample_sum.columns = df_resample_sum.columns.str.strip('_sum_noshift')

    # Forward filling null values
    df_resample_categorical = df_resample_sum.fillna(method='ffill')

    ## Data cleaning for continuous tags
    # List of continuous tag names
    resample_last_columns = df.columns[df.columns.isin(hist_tags[belt]['resample_last'])]

    # Resmapling at a 1 minute frequency taking the last value and forward filling
    df_resample_continuous = df[resample_last_columns].resample('T').last().fillna(method='ffill')

    # Merging categorical and continuous tags  
    df = df_resample_categorical.merge(df_resample_continuous, how='outer', on='time_rio')
    
    return df

def load_fptu(
    spark:SparkSession, 
    FPTU_path:str, 
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime,
    file_type:str='json',
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Load the fixed plant time usage data (FPTU).

    Parameters
    ----------
    spark : SparkSession
        The spark session required for loading and processing the data.
    FPTU_path : str
        The folder path of the FPTU data 
    period_start_utc : datetime.datetime
        The start time we want to load from.
    period_end_utc : datetime.datetime
        The end time we want to load from.
    file_type : str, optional
        We can use this option to load either the json or parquet data we are using, by default 'json'.
    save_dir : Optional[str], optional
        Directory we can save to if we want to save the output, by default None

    Returns
    -------
    pd.DataFrame
        The FPTU data.
    """    
    
    if file_type == 'json':
        date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)
        
        hdfs_path = "/FixedPlantTimeUsage-"+date_range
        sdf_fptu = spark.read.option("multiline", "true").json(FPTU_path+hdfs_path).withColumn("filename", input_file_name())
        sdf_fptu = load_ADA_data.NormaliseJsonSpark(sdf_fptu).normalise_fptu_spark()
    
    elif file_type == 'parquet':
        # Define schema for the data
        FPTUCustomSchema = StructType([
                StructField("SourceIdentifier", LongType(), True),
                StructField("Shift_SK", LongType(), True),
                StructField("FixedPlantTimeUsageEventStart", TimestampType(), True),
                StructField("FixedPlantTimeUsageEventFinish", TimestampType(), True),
                StructField("FixedPlantTimeUsageGroupEventStart", TimestampType(), True),
                StructField("FixedPlantTimeUsageGroupEventFinish", TimestampType(), True),
                StructField("cTimeUsageGroupEvent", BooleanType(), True),
                StructField("sTimeUsage", LongType(), True),
                StructField("FixedPlantTimeUsageComments", StringType(), True),
                StructField("FixedPlantTimeUsageExplanation", StringType(), True),
                StructField("FixedPlantAssetCode", StringType(), True),
                StructField("FixedPlantAssetDescription", StringType(), True),
                StructField("SubEquipment", StringType(), True),
                StructField("TPPSEquipmentCode", StringType(), True),
                StructField("CauseFixedPlantAssetCode", StringType(), True),
                StructField("CauseFixedPlantAssetDescription", StringType(), True),
                StructField("CauseArea", StringType(), True),
                StructField("Cause", StringType(), True),
                StructField("Effect", StringType(), True),
                StructField("TPPSTrainId", StringType(), True),
                StructField("TUM0Code", StringType(), True),
                StructField("TUM0DisplayName", StringType(), True),
                StructField("TUM1Code", StringType(), True),
                StructField("TUM1DisplayName", StringType(), True),
                StructField("TUM5Code", StringType(), True),
                StructField("TUM5DisplayName", StringType(), True),
                StructField("SourceUpdatedAt", TimestampType(), True),
                StructField("ModifiedAt", TimestampType(), True),
                StructField("file_timestamp", StringType(), True)
                ])

        # Read data, filter by time and order by start time
        sdf_fptu = spark.read.schema(FPTUCustomSchema).parquet(FPTU_path)
        sdf_fptu = sdf_fptu.orderBy("FixedPlantTimeUsageEventStart")
        sdf_fptu = sdf_fptu[(sdf_fptu.FixedPlantTimeUsageEventStart.between(period_start_utc, period_end_utc))]


    # sdf_fptu = sdf_fptu[sdf_fptu.TUM5Code.isin(['ULO','PFL','ULF'])]
    cv_inscope = ['CV0101', 'CV0102', 'CV0514', 'CV0316', 'CV0622', 'CV21', 'CV0211','CV0313', 'CV0312', 'CV18', 'CV15', 'CV0517']
    sdf_fptu = sdf_fptu[sdf_fptu.CauseFixedPlantAssetCode.isin(cv_inscope)]

    if save_dir is not None:
        if os.path.exists((save_dir+'/FPTU')):
            sdf_fptu.write.format("parquet").mode('overwrite').save(save_dir+'/FPTU')
        else:
            sdf_fptu.write.parquet(save_dir+'/FPTU')

    df_FPTU = sdf_fptu.toPandas()

    return df_FPTU
    
    
def process_fptu(
    df_FPTU:pd.DataFrame, 
    df_tags_pivoted:pd.DataFrame, 
    belt:str,
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Process the FPTU data to prepare for modelling.

    This function is deprecated (only here for reference, consider deleting). 
    Refer to process_fptu_raw instead.

    Parameters
    ----------
    df_FPTU : pd.DataFrame
        The FPTU data as loaded by load_fptu_data.
    df_tags_pivoted : pd.DataFrame
        The tag data after being pivoted.
    belt : str
        The name of the belt.
    period_start_utc : datetime.datetime
        The start time in UTC.
    period_end_utc : datetime.datetime
        The end time in UTC.
    save_dir : Optional[str], optional
        The directory we can save the result into, by default None

    Returns
    -------
    pd.DataFrame
        The FPTU data after processing.
    """    
    
    dt_start_awst, dt_end_awst = dates_utc_to_awst(period_start_utc, period_end_utc)

    df_FPTU = df_FPTU[df_FPTU.CauseFixedPlantAssetCode == belt[belt.find('CV'):len(belt)]]

    df_FPTU = df_FPTU[['SourceIdentifier','CauseFixedPlantAssetCode','Cause','Effect','FixedPlantTimeUsageEventStart','FixedPlantTimeUsageEventFinish','FixedPlantTimeUsageExplanation']].drop_duplicates()
    df_FPTU=df_FPTU.sort_values('FixedPlantTimeUsageEventFinish').drop_duplicates(subset = ['SourceIdentifier'],keep='last')
    df_FPTU = df_FPTU[df_FPTU['FixedPlantTimeUsageEventStart'].between(dt_start_awst,dt_end_awst)]
    df_FPTU['Effect'] = df_FPTU['Effect'].apply(lambda x:x.replace('Fault -','Trip -'))
    # Look for In scope Belt Trips
    df_FPTU = df_FPTU[df_FPTU.Effect.isin(['Trip - Belt Drift','Operational - Blockage','Trip - Overspeed or Underspeed'])]  
    # Round FixedPlantTimeUsageEventStart to Minute
    df_FPTU.FixedPlantTimeUsageEventStart = df_FPTU.FixedPlantTimeUsageEventStart.round('T')

    if belt == 'CV0313':
        try: # For Belt CV0313 only
            # Correct Downtime Event Starts by cross checking when the belt speed = 0 and the alarm goes on
            df_FPTU.loc[df_FPTU.SourceIdentifier==7715629,'FixedPlantTimeUsageEventStart']= datetime.datetime(2022,8,18,4,10)
            df_FPTU.loc[df_FPTU.SourceIdentifier==7716278,'FixedPlantTimeUsageEventStart']= datetime.datetime(2022,8,18,14,47)
            df_FPTU.loc[df_FPTU.SourceIdentifier==7775256,'FixedPlantTimeUsageEventStart']= datetime.datetime(2022,9,26,19,12)
            df_FPTU.loc[df_FPTU.SourceIdentifier==7697364,'FixedPlantTimeUsageEventStart']= datetime.datetime(2022,8,4,5,55)
        except: 
            pass


    # Reset Index to Delay event start
    df_FPTU.set_index('FixedPlantTimeUsageEventStart', inplace=True)

    # Clean at Asset level (Combine Delay that are less than 70 min aparts as one delay)
    min_time_diff = datetime.timedelta(minutes= 70)
    CV_DT =  df_FPTU.copy()
    CV_DT = pd.concat([CV_DT.drop_duplicates(),CV_DT[CV_DT.index.duplicated()].shift(freq='T')]).sort_index()
    dt_reduced = CV_DT[(CV_DT.index - CV_DT.shift(1, fill_value=CV_DT.index[0] - min_time_diff)['FixedPlantTimeUsageEventFinish']) >= min_time_diff]
    events_periods = [pd.date_range(dt_reduced.index[i], dt_reduced.index[i+1]-Minute(), freq='T')
                        for i in range(len(dt_reduced)-1)] + [pd.date_range(dt_reduced.index[-1], CV_DT.index[-1], freq='T')]
    # Find revised delay end time for aggregated delay events                    
    end_dt = [CV_DT[CV_DT.index.isin(p)]['FixedPlantTimeUsageEventFinish'].max() for p in events_periods]
    dt_reduced = dt_reduced.assign(FixedPlantTimeUsageEventFinishRevised=end_dt)
    # Calculate the delay duration of each delay
    dt_reduced['agg_duration'] = dt_reduced['FixedPlantTimeUsageEventFinishRevised'] - dt_reduced.index
    dt_reduced['agg_duration']  = dt_reduced['agg_duration'].apply(lambda x:x.total_seconds()/60)

    # Correct Delay Trip Type Based on Explanation

    ## Belt Drift
    bd_df = dt_reduced[dt_reduced.FixedPlantTimeUsageExplanation.notna() & 
                    dt_reduced.FixedPlantTimeUsageExplanation.str.contains(r'belt\s+drift\s?#\s?\d+|belt\s+switch\s?#\s?\d+|bds\d+', case=False)]
    bd_df[bd_df.Effect != 'Trip - Belt Drift']
    dt_reduced.loc[bd_df[bd_df.Effect != 'Trip - Belt Drift'].index, ['Effect']] = 'Trip - Belt Drift'
    ## Operational - Blockage
    ob_df = dt_reduced[dt_reduced.FixedPlantTimeUsageExplanation.notna() &
                    dt_reduced.FixedPlantTimeUsageExplanation.str.contains(r'blocked\s+chute', case=False)]
    ob_df[ob_df.Effect != 'Operational - Blockage']
    dt_reduced.loc[ob_df[ob_df.Effect != 'Operational - Blockage'].index, ['Effect']] = 'Operational - Blockage' 

    if belt == 'CV0313':
        # Find Delay Event that the belt speed is still normal
        error = df_tags_pivoted[(df_tags_pivoted.index.isin(dt_reduced.index+datetime.timedelta(minutes=1)))&(df_tags_pivoted['KD1.PPCS.CV0313WT01_ACTDAT_BELTSPD']>3)]['KD1.PPCS.CV0313WT01_ACTDAT_BELTSPD']
        error_sourceid = dt_reduced[dt_reduced.index.isin(error.index-datetime.timedelta(minutes=1))]['SourceIdentifier']
    else: 
        error_sourceid=[]

    dt_reduced = dt_reduced[~dt_reduced.SourceIdentifier.isin(error_sourceid)]

    if save_dir is not None:
        # Export to Output Folder
        dt_reduced.to_parquet(save_dir+'/'+belt+'_FPTU_Processed',index=True)

    return dt_reduced

def process_fptu_raw(
    df_FPTU:pd.DataFrame,  
    belt:str,
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """Process the FPTU data and prepare for modelling.

    Filters raw data for belt, required columns and downtime events in scope.
    Drops duplicate start and finish time pairs. 
    Rounds event start and event end to nearest minute.
    Note: Overlap between events is present.

    Parameters
    ----------
    df_FPTU : pd.DataFrame
        The FPTU data that we loaded with load_fptu_data
    belt : str
        The name of the belt.
    period_start_utc : datetime.datetime
        The start time in UTC.
    period_end_utc : datetime.datetime
        The end time in UTC.
    save_dir : Optional[str], optional
        The directory we can save to if required, by default None

    Returns
    -------
    pd.DataFrame
        The Processed FPTU data.
    """    

    # Dates to AWST
    dt_start_awst, dt_end_awst = dates_utc_to_awst(period_start_utc, period_end_utc)
    
    # Filter by belt
    df_FPTU = df_FPTU[df_FPTU.CauseFixedPlantAssetCode == belt[belt.find('CV'):len(belt)]]

    # Filter by columns and drop duplicate rows
    df_FPTU = df_FPTU[['SourceIdentifier','CauseFixedPlantAssetCode', 'TUM5Code', 'Cause','Effect','FixedPlantTimeUsageEventStart','FixedPlantTimeUsageEventFinish', 'FixedPlantTimeUsageComments', 'FixedPlantTimeUsageExplanation']].drop_duplicates()

    # Account for the AMPLA offset
    df_FPTU['FixedPlantTimeUsageEventStart'] = df_FPTU['FixedPlantTimeUsageEventStart'] - ampla_offset
    df_FPTU['FixedPlantTimeUsageEventFinish'] = df_FPTU['FixedPlantTimeUsageEventFinish'] - ampla_offset

    # Filter by times provided
    df_FPTU = df_FPTU[df_FPTU['FixedPlantTimeUsageEventStart'].between(dt_start_awst,dt_end_awst)]
    
    # Rename values in effect coloum
    df_FPTU['Effect'] = df_FPTU['Effect'].apply(lambda x:x.replace('Fault -','Trip -'))
    
    # Round timestamps to nearest minute
    df_FPTU.FixedPlantTimeUsageEventStart = df_FPTU.FixedPlantTimeUsageEventStart.round('T')
    df_FPTU.FixedPlantTimeUsageEventFinish = df_FPTU.FixedPlantTimeUsageEventFinish.round('T')

    # Drop rows with duplicate start and end times
    df_FPTU = df_FPTU.drop_duplicates(subset=['FixedPlantTimeUsageEventStart','FixedPlantTimeUsageEventFinish'])

    # Calculate the delay duration of each delay
    df_FPTU['event_duration'] = df_FPTU['FixedPlantTimeUsageEventFinish'] - df_FPTU['FixedPlantTimeUsageEventStart']
    
    # Convert duration to minutes 
    df_FPTU['event_duration']  = df_FPTU['event_duration'].apply(lambda x:x.total_seconds()/60)

    # Set index as start time and sort
    df_FPTU = df_FPTU.set_index('FixedPlantTimeUsageEventStart').sort_index()

    # # Correct Delay Trip Type Based on Explanation
    # ## Belt Drift
    # bd_df = df_FPTU[df_FPTU.FixedPlantTimeUsageExplanation.notna() & 
    #                 df_FPTU.FixedPlantTimeUsageExplanation.str.contains(r'belt\s+drift\s?#\s?\d+|belt\s+switch\s?#\s?\d+|bds\d+', case=False)]
    # bd_df[bd_df.Effect != 'Trip - Belt Drift']
    # df_FPTU.loc[bd_df[bd_df.Effect != 'Trip - Belt Drift'].index, ['Effect']] = 'Trip - Belt Drift'
    # ## Operational - Blockage
    # ob_df = df_FPTU[df_FPTU.FixedPlantTimeUsageExplanation.notna() &
    #                 df_FPTU.FixedPlantTimeUsageExplanation.str.contains(r'blocked\s+chute', case=False)]
    # ob_df[ob_df.Effect != 'Operational - Blockage']
    # df_FPTU.loc[ob_df[ob_df.Effect != 'Operational - Blockage'].index, ['Effect']] = 'Operational - Blockage' 

    if save_dir is not None:
        # Export to output Folder
        df_FPTU.to_parquet(save_dir+'/'+belt+'_FPTU_Processed',index=True)

    return df_FPTU

def load_weather(
    spark:SparkSession,
    Weather_path:str,
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None):
    """Load the weather data for modelling.

    We are curently not using the weather data in the model, howeever this may change in the future.

    Parameters
    ----------
    spark : SparkSession
        The spark session required to load and process the data.
    Weather_path : str
        The folder path of the Weather data.
    period_start_utc : datetime.datetime
        The start time in UTC.
    period_end_utc : datetime.datetime
        The end time in UTC.
    save_dir : Optional[str], optional
        The directory we could optionally save to, by default None

    Returns
    -------
    _type_
        The weather data as a dataframe.
    """     

    date_range = load_ADA_data.hdfs_range(period_start_utc, period_end_utc)

    ### Load Weather
    hdfs_path = f"{Weather_path}/WeatherForecast-{date_range}"
    sdf_weather = spark.read.option("multiline", "true").json(hdfs_path).withColumn("filename", input_file_name())
    sdf_weather = load_ADA_data.NormaliseJsonSpark(sdf_weather).normalise_weather_spark()

    ### Load Weather (Need to remove)
    # hdfs_path = "/WeatherForecast-"+date_range
    # sdf_weather = spark.read.option("multiline", "true").json(Weather_path+hdfs_path).withColumn("filename", input_file_name())
    # sdf_weather = load_ADA_data.NormaliseJsonSpark(sdf_weather).normalise_weather_spark()

    if save_dir is not None:
        if os.path.exists((save_dir+'/Weather')):
            sdf_weather.write.format("parquet").mode('overwrite').save(save_dir+'/Weather')
        else:
            sdf_weather.write.parquet(save_dir+'/Weather')

    df_weather = sdf_weather.toPandas()
    df_weather = uc2_utils.weather_data_prep(df_weather)

    return df_weather

def get_gd_delay_duration_lookup(
    df_FPTU:pd.DataFrame, 
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime, 
    save_dir:Optional[str]=None) -> pd.DataFrame:
    """This is used to estimate the duration of the delay event predicted.

    Parameters
    ----------
    df_FPTU : pd.DataFrame
        The FPTU data
    period_start_utc : datetime.datetime
        The start time in UTC.
    period_end_utc : datetime.datetime
        The end time in UTC.
    save_dir : Optional[str], optional
        The directory we can optionall save to, by default None

    Returns
    -------
    pd.DataFrame
        A dataframe containing information about the duration of historical delay events.
    """     
    
    dt_start_awst, dt_end_awst = dates_utc_to_awst(period_start_utc, period_end_utc)
        
    df_FPTU=df_FPTU.sort_values('FixedPlantTimeUsageEventFinish').drop_duplicates(subset = ['SourceIdentifier','CauseFixedPlantAssetCode','Cause','Effect','FixedPlantTimeUsageEventStart'],keep='last')
    df_FPTU = df_FPTU[df_FPTU['FixedPlantTimeUsageEventStart'].between(dt_start_awst,dt_end_awst)]
    df_FPTU['Effect'] = df_FPTU['Effect'].apply(lambda x:x.replace('Fault -','Trip -'))
    # Look for In scope Belt Trips
    df_FPTU = df_FPTU[df_FPTU.Effect.isin(['Trip - Belt Drift','Operational - Blockage'])]  
    # Calculate the delay duration of each delay
    df_FPTU['duration_in_minutes'] = df_FPTU['FixedPlantTimeUsageEventFinish'] - df_FPTU['FixedPlantTimeUsageEventStart']
    df_FPTU['duration_in_minutes']  = df_FPTU['duration_in_minutes'].apply(lambda x:x.total_seconds()/60)
    # Reset Index to Delay event start
    df_FPTU.set_index('FixedPlantTimeUsageEventStart', inplace=True)

    def q1(x):
        return x.quantile(0.25)

    def q3(x) :
        return x.quantile(0.75)

    f = {'duration_in_minutes': ['count','median', q1, q3, iqr]}
    df1 = df_FPTU.groupby(['Effect','CauseFixedPlantAssetCode']).agg(f).reset_index()
    df2 = df_FPTU.groupby(['Effect']).agg(f).reset_index()
    df2['CauseFixedPlantAssetCode'] = None
    df = pd.concat([df1,df2])
    df.columns= ['belt','trip_type','event_count','duration_iqr_mins','duration_median_mins','duration_q1_mins','duration_q3_mins']
    df = df[['trip_type','belt','event_count','duration_median_mins','duration_q1_mins','duration_q3_mins','duration_iqr_mins']]

    if save_dir is not None:
        os.makedirs(save_dir, exist_ok=True)
        df.to_csv(save_dir+'/gd_delay_duration_lookup.csv')

    return df

def get_selected_features(belt, selected_features_list:Optional[List[str]] = None):
    """Get the features we want to use in modelling.

    We can use this funciton to manually provide a list of features we want to use.
    If we do not provide a list then it will load the list in the model_selected_features folder. 

    Parameters
    ----------
    belt : _type_
        The name of the belt.
    selected_features_list : Optional[List[str]], optional
        A list of the features we want to use, by default None

    Returns
    -------
    _type_
        A list of features we will be using for modelling.
    """    
    if selected_features_list is None:
        selected_features_list_file = os.path.join('ADA_UC2_CDP', 'model_selected_features/'+belt+'_selected_features_list.txt')
        selected_features_list = []
        with open(selected_features_list_file) as f:
            selected_features_list = f.read().splitlines() 
        f.close()
    
    return selected_features_list

def combine_pcs_and_ingested_data(df_tags, df_ingested):

    # If duplicate columns use df_ingested
    cols_to_use = df_tags.columns.difference(df_ingested.columns)

    # Combine PCS tags with ingested data
    df_tags = df_ingested.merge(df_tags[cols_to_use], left_index=True, right_index=True)

    return df_tags

def add_screenhouse_features(
    df_combined: pd.DataFrame
    ) -> pd.DataFrame:
    """Creates a column to determine if screen is running based on bin level, gate opened and vibe feeder speed

    Parameters
    ----------
    df_combined : pd.DataFrame
        PCS tag data filtered for selected features and merged with weather data

    Returns
    -------
    pd.DataFrame
        df combined with "screen_x_running" feature added and bin level, gate opened and vibe feeder speed dropped.
    """  

    screenhouse_tags = {
    'screen_1': ['KD1.PPCS.BN0301LT0X', 'KD1.PPCS.VF0301SS01_SPD', 'KD1.PPCS.GA0301_OPND'],
    'screen_2': ['KD1.PPCS.BN0302LT0X', 'KD1.PPCS.VF0302SS01_SPD', 'KD1.PPCS.GA0302_OPND'],
    'screen_3': ['KD1.PPCS.BN0303LT0X', 'KD1.PPCS.VF0303SS01_SPD', 'KD1.PPCS.GA0303_OPND'],
    'screen_4': ['KD1.PPCS.BN0304LT0X', 'KD1.PPCS.VF0304SS01_SPD', 'KD1.PPCS.GA0304_OPND'],
    'screen_5': ['KD1.PPCS.BN0305LT0X', 'KD1.PPCS.VF0305SS01_SPD', 'KD1.PPCS.GA0305_OPND'],
    'screen_6': ['KD1.PPCS.BN0306LT0X', 'KD1.PPCS.VF0306SS01_SPD', 'KD1.PPCS.GA0306_OPND'],
    'screen_7': ['KD1.PPCS.BN0307LT0X', 'KD1.PPCS.VF0307SS01_SPD', 'KD1.PPCS.GA0307_OPND'],
    }
    
    # For each screen adding column "screen_x_running" and dropping bin level, gate opened and vibe feeder speed tags. 
    # NOTE: If gate opened, bin level or vibe feeder speed is "nan" then "nan" will be returned in column
    for screen in screenhouse_tags.keys():
        bin_level = screenhouse_tags[screen][0]
        vibe_feeder_speed = screenhouse_tags[screen][1]
        gate_opened = screenhouse_tags[screen][2]

        df_combined[f'{screen}_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x[gate_opened])) | (np.isnan(x[bin_level])) | (np.isnan(x[vibe_feeder_speed]))) else (1 if ((x[gate_opened] > 0) & (x[bin_level] > 0) & (x[vibe_feeder_speed] > 0)) else 0), axis=1)
        df_combined = df_combined.drop([bin_level, vibe_feeder_speed, gate_opened], axis=1)

    # If both screens are running column returns 1
    df_combined['screen_6_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_6_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_6_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    # df_combined['screen_1_2_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_2_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_2_running']==1)) else 0), axis=1)
    # df_combined['screen_1_3_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_3_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_3_running']==1)) else 0), axis=1)
    # df_combined['screen_1_4_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_4_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_4_running']==1)) else 0), axis=1)
    # df_combined['screen_1_5_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_5_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_5_running']==1)) else 0), axis=1)
    # df_combined['screen_1_6_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_6_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_6_running']==1)) else 0), axis=1)
    # df_combined['screen_1_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_1_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    # df_combined['screen_2_3_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_3_running']))) else (1 if ((x['screen_2_running']==1) & (x['screen_3_running']==1)) else 0), axis=1)
    # df_combined['screen_2_4_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_4_running']))) else (1 if ((x['screen_2_running']==1) & (x['screen_4_running']==1)) else 0), axis=1)
    # df_combined['screen_2_5_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_5_running']))) else (1 if ((x['screen_2_running']==1) & (x['screen_5_running']==1)) else 0), axis=1)
    # df_combined['screen_2_6_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_6_running']))) else (1 if ((x['screen_2_running']==1) & (x['screen_6_running']==1)) else 0), axis=1)
    # df_combined['screen_2_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_2_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    # df_combined['screen_3_4_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_3_running'])) | (np.isnan(x['screen_4_running']))) else (1 if ((x['screen_3_running']==1) & (x['screen_4_running']==1)) else 0), axis=1)
    # df_combined['screen_3_5_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_3_running'])) | (np.isnan(x['screen_5_running']))) else (1 if ((x['screen_3_running']==1) & (x['screen_5_running']==1)) else 0), axis=1)
    # df_combined['screen_3_6_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_3_running'])) | (np.isnan(x['screen_6_running']))) else (1 if ((x['screen_3_running']==1) & (x['screen_6_running']==1)) else 0), axis=1)
    # df_combined['screen_3_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_3_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_3_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    # df_combined['screen_4_5_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_4_running'])) | (np.isnan(x['screen_5_running']))) else (1 if ((x['screen_4_running']==1) & (x['screen_5_running']==1)) else 0), axis=1)
    # df_combined['screen_4_5_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_4_running'])) | (np.isnan(x['screen_5_running']))) else (1 if ((x['screen_4_running']==1) & (x['screen_5_running']==1)) else 0), axis=1)
    # df_combined['screen_4_6_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_4_running'])) | (np.isnan(x['screen_6_running']))) else (1 if ((x['screen_4_running']==1) & (x['screen_6_running']==1)) else 0), axis=1)
    # df_combined['screen_4_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_4_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_4_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    # df_combined['screen_5_6_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_5_running'])) | (np.isnan(x['screen_6_running']))) else (1 if ((x['screen_5_running']==1) & (x['screen_6_running']==1)) else 0), axis=1)
    # df_combined['screen_5_7_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_5_running'])) | (np.isnan(x['screen_7_running']))) else (1 if ((x['screen_5_running']==1) & (x['screen_7_running']==1)) else 0), axis=1)
    
    # counts the number of screens running for a given minute
    df_combined['number_screens_running'] = df_combined.apply(lambda x: np.nan if ((np.isnan(x['screen_1_running'])) | (np.isnan(x['screen_2_running'])) | (np.isnan(x['screen_3_running'])) | (np.isnan(x['screen_4_running'])) | (np.isnan(x['screen_5_running'])) | (np.isnan(x['screen_6_running'])) | (np.isnan(x['screen_7_running']))) else (x[['screen_1_running', 'screen_2_running', 'screen_3_running', 'screen_4_running', 'screen_5_running', 'screen_6_running', 'screen_7_running']].sum()), axis=1)
    
    return df_combined


def outlier_removal(df: pd.DataFrame, belt:str):

    if belt == "CV0313":
        tags_categories = {
            'screenhouse_tags': ['screen_1_running', 'screen_2_running', 'screen_3_running', 'screen_4_running', 'screen_5_running', 'screen_6_running', 'screen_7_running', 'KD1.PPCS.CV0313_VF01ESTRT', 'KD1.PPCS.CV0313_VF02ESTRT', 'KD1.PPCS.CV0313_VF03ESTRT', 'KD1.PPCS.CV0313_VF04ESTRT', 'KD1.PPCS.CV0313_VF05ESTRT', 'KD1.PPCS.CV0313_VF06ESTRT', 'KD1.PPCS.CV0313_VF07ESTRT'],

            'transmitter_I_tags': ['KD1.PPCS.CV0313BDT05_I', 'KD1.PPCS.CV0313BDT06_I', 'KD1.PPCS.CV0313BDT07_I', 'KD1.PPCS.CV0313BDT08_I', 'KD1.PPCS.CV0313BDT13_I','KD1.PPCS.CV0313BDT14_I'],

            'transmitter_drift_tags': ['KD1.PPCS.CV0313BDT05_DRIFT', 'KD1.PPCS.CV0313BDT06_DRIFT', 'KD1.PPCS.CV0313BDT07_DRIFT', 'KD1.PPCS.CV0313BDT08_DRIFT', 'KD1.PPCS.CV0313BDT13_DRIFT', 'KD1.PPCS.CV0313BDT14_DRIFT'],

            'switch_tags': ['KD1.PPCS.CV0313BDS01_I', 'KD1.PPCS.CV0313BDS02_I', 'KD1.PPCS.CV0313BDS03_I', 'KD1.PPCS.CV0313BDS04_I', 'KD1.PPCS.CV0313BDS09_I', 'KD1.PPCS.CV0313BDS10_I', 'KD1.PPCS.CV0313BDS11_I', 'KD1.PPCS.CV0313BDS12_I', 'bds_i_sum'],

            'freeboard_sensors': ['KD1.PPCS.CV0313WT01_ACTDAT_LFB','KD1.PPCS.CV0313WT02_ACTDAT_LFB','KD1.PPCS.CV0313WT01_ACTDAT_RFB','KD1.PPCS.CV0313WT02_ACTDAT_RFB'],

            'tonnage': ['gdit_tph', 'KD1.PPCS.CV0313WT02_ACTDAT_TONRT', 'KD1.PPCS.CV0313WT01_ACTDAT_TONRT'],

            'density': ['KD1.PPCS.CV0313WT01_ACTDAT_DEN', 'KD1.PPCS.CV0313WT01_OT1DENAVG'],

            'volume':['KD1.PPCS.CV0313WT01_ACTDAT_VOL'],

            'volbdnavg': ['KD1.PPCS.CV0313WT01_OT1VOLBDNAVG'],

            'bdnavg':['KD1.PPCS.CV0313WT01_OT1BDNAVG'],

            'vsd': ['KD1.PPCS.CV0313VSD01_ACTDAT_I'],

            'belt_speed': ['KD1.PPCS.CV0313WT01_ACTDAT_BELTSPD']
            }
    
    if belt == "CV0316":
        tags_categories = {
            'screenhouse_tags': ['screen_1_running', 'screen_2_running', 'screen_3_running', 'screen_4_running', 'screen_5_running', 'screen_6_running', 'screen_7_running', 'KD1.PPCS.CV0316_VF01ESTRT', 'KD1.PPCS.CV0316_VF02ESTRT', 'KD1.PPCS.CV0316_VF03ESTRT', 'KD1.PPCS.CV0316_VF04ESTRT', 'KD1.PPCS.CV0316_VF05ESTRT', 'KD1.PPCS.CV0316_VF06ESTRT', 'KD1.PPCS.CV0316_VF07ESTRT'],

            'transmitter_I_tags': [    'KD1.PPCS.CV0316BDT05_I', 'KD1.PPCS.CV0316BDT06_I', 'KD1.PPCS.CV0316BDT09_I', 'KD1.PPCS.CV0316BDT10_I', 'KD1.PPCS.CV0316BDT15_I', 'KD1.PPCS.CV0316BDT16_I'],

            'transmitter_drift_tags': ['KD1.PPCS.CV0316BDT05_DRIFT', 'KD1.PPCS.CV0316BDT06_DRIFT', 'KD1.PPCS.CV0316BDT09_DRIFT', 'KD1.PPCS.CV0316BDT10_DRIFT', 'KD1.PPCS.CV0316BDT15_DRIFT', 'KD1.PPCS.CV0316BDT16_DRIFT'],

            'switch_tags': ['KD1.PPCS.CV0316BDS01_I', 'KD1.PPCS.CV0316BDS02_I', 'KD1.PPCS.CV0316BDS03_I', 'KD1.PPCS.CV0316BDS04_I', 'KD1.PPCS.CV0316BDS07_I', 'KD1.PPCS.CV0316BDS08_I', 'KD1.PPCS.CV0316BDS11_I', 'KD1.PPCS.CV0316BDS12_I', 'KD1.PPCS.CV0316BDS13_I', 'KD1.PPCS.CV0316BDS14_I', 'bds_i_sum'],

            'freeboard_sensors': ['KD1.PPCS.CV0316WT01_ACTDAT_LFB', 'KD1.PPCS.CV0316WT02_ACTDAT_LFB', 'KD1.PPCS.CV0316WT01_ACTDAT_RFB', 'KD1.PPCS.CV0316WT02_ACTDAT_RFB'],

            'tonnage': ['gdit_tph', 'KD1.PPCS.CV0316WT01_ACTDAT_TONRT', 'KD1.PPCS.CV0316WT02_ACTDAT_TONRT'],

            'density': ['KD1.PPCS.CV0316WT01_ACTDAT_DEN', 'KD1.PPCS.CV0316WT01_OT1DENAVG'],

            'volume':['KD1.PPCS.CV0316WT01_ACTDAT_VOL'],

            'volbdnavg': ['KD1.PPCS.CV0316WT01_OT1VOLBDNAVG'],

            'bdnavg':['KD1.PPCS.CV0316WT01_OT1BDNAVG'],

            'vsd': ['KD1.PPCS.CV0316VSD01_ACTDAT_I'],

            'belt_speed': ['KD1.PPCS.CV0313WT01_ACTDAT_BELTSPD']
            }

    outliers = {
        'screenhouse_tags': None,
        'transmitter_I_tags': None,
        'transmitter_drift_tags': (-130,130),
        'switch_tags': None,
        'freeboard_sensors': (0, 1000),
        'tonnage': (0, 10000),
        'density': None,
        'volume': None,
        'volbdnavg': None,
        'bdnavg': (0,500),
        'vsd': None,
        'belt_speed': (0, 10)
        }

    for key in tags_categories.keys():
        # Continue if outliers is None i.e. No outlier removal
        if outliers[key] is None: continue

        # Filter for features included in df
        features = [x for x in tags_categories[key] if x in df.columns]
        if len(features) == 0: continue

        print(outliers[key])

        # Remove Outliers
        df[features] = df[features].applymap(
            lambda x: x if x <= outliers[key][1] and x >= outliers[key][0] else np.nan).ffill()

    ## Based on the EDA there is some early data which should be removed.

    # Remove FBS data before '2022-11-13'
    df.loc[:'2022-11-13', tags_categories['freeboard_sensors']] = np.nan

    # Remove volume data before '2022-11-13'
    df.loc[:'2022-11-13', tags_categories['volume']] = np.nan

    # Remove VOLBDNAVG data before '2022-11-29'
    df.loc[:'2022-11-29', tags_categories['volbdnavg']] = np.nan

    return df 

def additional_feature_engineering(belt:str, df_combined:pd.DataFrame):
        # Add screenhouse features and GDIT tph if CV0313 or CV0316
    if belt == 'CV0313':
        df_combined = add_screenhouse_features(df_combined)
        df_combined['gdit_tph'] = df_combined['KD1.PPCS.CV0313WT02_ACTDAT_TONRT'] - df_combined['KD1.PPCS.CV0313WT01_ACTDAT_TONRT']

    elif belt == 'CV0316':
        df_combined = add_screenhouse_features(df_combined)
        df_combined['gdit_tph'] = df_combined['KD1.PPCS.CV0316WT02_ACTDAT_TONRT'] - df_combined['KD1.PPCS.CV0316WT01_ACTDAT_TONRT']

    # Adding sum of BDS_I tag feature
    df_combined['bds_i_sum'] = df_combined[hist_tags[belt]['resample_sum']['bds_i']].sum(axis=1)

    addtional_features_list = ['gdit_tph', 'bds_i_sum', 'screen_1_running', 'screen_2_running', 'screen_3_running', 'screen_4_running', 'screen_5_running', 'screen_6_running', 'screen_7_running', 'screen_6_7_running', 'number_screens_running']

    return df_combined, addtional_features_list


def combine_tag_weather(
    spark: SparkSession, 
    belt:str, 
    df_tags:pd.DataFrame, 
    df_weather:pd.DataFrame, 
    period_start_utc:datetime.datetime, 
    period_end_utc:datetime.datetime,
    additional_features:bool = True,
    selected_features_list:Optional[List[str]] = None,
    save_dir:Optional[str] = None) -> pd.DataFrame:
    """Merge the tag and weather data into one data frame.

    Parameters
    ----------
    spark : SparkSession
        The spark session we will use for data processing.
    belt : str
        The name of the belt.
    df_tags : pd.DataFrame
        The tag data.
    df_weather : pd.DataFrame
        The weather data.
    period_start_utc : datetime.datetime
        The start time in UTC.
    period_end_utc : datetime.datetime
        The end time in UTC.
    selected_features_list : Optional[List[str]], optional
        A list of selected features we want to keep and use in the modelling, by default None
    save_dir : Optional[str], optional
        The directory we can optionally save the result, by default None

    Returns
    -------
    pd.DataFrame
        The combined tag and weather data.
    """    

    ## Combine PCS tags with Weather Data
    df_combined = df_tags.merge(df_weather, left_index=True, right_index=True) 

    ## Import selected features list of this belt
    selected_features_list = get_selected_features(belt, selected_features_list)

    if additional_features:
        # Add additional features
        df_combined, addtional_features_list = additional_feature_engineering(belt, df_combined)
        selected_features_list = selected_features_list + addtional_features_list
        dropped_screenhouse_features = ['KD1.PPCS.BN0301LT0X', 
        'KD1.PPCS.VF0301SS01_SPD',
        'KD1.PPCS.GA0301_OPND',
        'KD1.PPCS.BN0302LT0X',
        'KD1.PPCS.VF0302SS01_SPD',
        'KD1.PPCS.GA0302_OPND',
        'KD1.PPCS.BN0303LT0X',
        'KD1.PPCS.VF0303SS01_SPD',
        'KD1.PPCS.GA0303_OPND',
        'KD1.PPCS.BN0304LT0X',
        'KD1.PPCS.VF0304SS01_SPD',
        'KD1.PPCS.GA0304_OPND',
        'KD1.PPCS.BN0305LT0X',
        'KD1.PPCS.VF0305SS01_SPD',
        'KD1.PPCS.GA0305_OPND',
        'KD1.PPCS.BN0306LT0X',
        'KD1.PPCS.VF0306SS01_SPD',
        'KD1.PPCS.GA0306_OPND',
        'KD1.PPCS.BN0307LT0X',
        'KD1.PPCS.VF0307SS01_SPD',
        'KD1.PPCS.GA0307_OPND']
        selected_features_list = [ele for ele in selected_features_list if ele not in dropped_screenhouse_features]

    # Filter on features
    df_combined = df_combined[selected_features_list]

    # Outlier removal
    df_combined = outlier_removal(df_combined, belt)

    # Save the result 
    if save_dir is not None:
        df_combined.to_parquet(save_dir+'/'+belt+'_tags_weather_processed',index=True)

    return df_combined



def filter_df_by_timestamp(
    df:pd.DataFrame, 
    time:pd.Timestamp, 
    delta:pd.Timedelta=agg_time_range) -> pd.DataFrame:
    """Filter data between the time provided and the aggregation window (15 minutes).

    The output of this is to be passed to another function for aggregation (aggregate_data)

    Parameters
    ----------
    df : pd.DataFrame
        Input data frame (probably df_combined)
    time : pd.Timestamp
        The timestamp we want to end on. This represents the time of the prediction.
    delta : pd.Timedelta, optional
        The window we want to aggregate data from, by default agg_time_range

    Returns
    -------
    pd.DataFrame
        The filtered data.
    """    

    return df.loc[time - delta: time]

def aggregate_data(df: pd.DataFrame, time:pd.Timestamp, agg_stats:List[str]=agg_stats) -> pd.DataFrame:
    """Aggregate all the data in df with the functions defined (such as mean and standard deviation).

    Parameters
    ----------
    df : pd.DataFrame
        The input data to aggregate (likely the output of filter_df_by_timestamp)
    agg_stats : List[str], optional
        A list of strings containing names of aggreation functions (like 'mean' and 'sd'), by default agg_stats
    time : pd.Timestamp
        The timestamp we want to end on. This represents the time of the prediction.

    Returns
    -------
    pd.DataFrame
        The aggregated data. 
    """    
    
    
    # List of functions used to aggregate data, required to use df.apply and get the correct format.
    def agg_function(x, time):
        
        # Dividing look back period into subsets
        last_6_min = x.loc[time - pd.Timedelta(minutes=5):time]
        last_15_min = x.loc[time - pd.Timedelta(minutes=14):time]
        last_24_min = x.loc[time - pd.Timedelta(minutes=23):time]
        first_15_min = x.loc[time - pd.Timedelta(minutes=29):time - pd.Timedelta(minutes=15)]

        # If data frame is empty return nan
        if last_6_min.shape[0] == 0:
            last_6_min = np.nan
        if last_15_min.shape[0] == 0:
            last_15_min = np.nan
        if last_24_min.shape[0] == 0:
            last_24_min = np.nan
        if first_15_min.shape[0] == 0:
            first_15_min = np.nan
        if x.shape[0] == 0:
            x = np.nan

        # This dict maps function names to functions to run
        # We can create new features by adding to this list and adding the corresponding name to agg_stats
        function_map = {
            'mean_30': np.mean(x),
            'mean_24': np.mean(last_24_min),
            'mean_15': np.mean(last_15_min),
            'mean_6': np.mean(last_6_min),
            'std_30': np.std(x),
            'std_24': np.std(last_24_min),
            'std_15': np.std(last_15_min),
            'std_6': np.std(last_6_min),
            'skew_30': stats.moment(x, 3),
            'skew_24': stats.moment(last_24_min, 3),
            'skew_15': stats.moment(last_15_min, 3),
            'skew_6': stats.moment(last_6_min, 3),
            'kurtosis_30': stats.kurtosis(x),
            'kurtosis_24': stats.kurtosis(last_24_min),
            'kurtosis_15': stats.kurtosis(last_15_min),
            'kurtosis_6': stats.kurtosis(last_6_min),
            'min_30': np.min(x),
            'min_24': np.min(last_24_min),
            'min_15': np.min(last_15_min),
            'min_6': np.min(last_6_min),
            'max_30': np.max(x),
            'max_24': np.max(last_24_min),
            'max_15': np.max(last_15_min),
            'max_6': np.max(last_6_min),
            'q1_30': np.quantile(x, q=0.25),
            'q1_24': np.quantile(last_24_min, q=0.25),
            'q1_15': np.quantile(last_15_min, q=0.25),
            'q1_6': np.quantile(last_6_min, q=0.25),
            'median_30': np.median(x),
            'median_24': np.median(last_24_min),
            'median_15': np.median(last_15_min),
            'median_6': np.median(last_6_min),
            'q3_30': np.quantile(x, q=0.75),
            'q3_24': np.quantile(last_24_min, q=0.75),
            'q3_15': np.quantile(last_15_min, q=0.75),
            'q3_6': np.quantile(last_6_min, q=0.75),
            'iqr_30': np.subtract(np.quantile(x, q=0.75), np.quantile(x, q=0.25)),
            'iqr_24': np.subtract(np.quantile(last_24_min, q=0.75), np.quantile(last_24_min, q=0.25)),
            'iqr_15': np.subtract(np.quantile(last_15_min, q=0.75), np.quantile(last_15_min, q=0.25)),
            'iqr_6': np.subtract(np.quantile(last_6_min, q=0.75), np.quantile(last_6_min, q=0.25)),
            'range_30': np.subtract(np.max(x), np.min(x)),
            'range_24': np.subtract(np.max(last_24_min), np.min(last_24_min)),
            'range_15': np.subtract(np.max(last_15_min), np.min(last_15_min)),
            'range_6': np.subtract(np.max(last_6_min), np.min(last_6_min)),
            'sum_30': np.sum(x),
            'sum_24': np.sum(last_24_min),
            'sum_15': np.sum(last_15_min),
            'sum_6': np.sum(last_6_min),
            # roc_santhosh = mean (last 15 minutes) / mean (full 30 minutes)
            'roc_santhosh': np.divide(np.mean(last_15_min), np.mean(x)),
            # roc_awal = mean (last 15 minutes) - mean (first 15 minutes)
            'roc_awal': np.subtract(np.mean(last_15_min), np.mean(first_15_min)),
            # roc_mynka = (mean(last 15 minutes) - mean(first 15 minutes)) / mean(first 15 minutes)
            'roc_mynka': np.divide(np.subtract(np.mean(last_15_min), np.mean(first_15_min)), np.mean(first_15_min)),
        }

        return [function_map[stat] for stat in agg_stats]

    # Aggregate the data
    result = df.apply(lambda x: pd.Series(agg_function(x, time), index=agg_stats)).melt(ignore_index=False)
    
    # Create column names for aggregate data e.g. 'mean_feature1'
    columns = ['_'.join(x).strip() for x in zip(result.index, result.variable)]
    
    # Reshape the data to be one row and multiple columns.
    df_agg = pd.DataFrame(result.value.values.reshape(1,-1), columns=columns, index=df.index[-1:])

    # Handling the case if last index (label timestamp) is dropped due to belt speed = 0
    if df_agg.index != time:
       df_agg.index = [time]

    return df_agg


# Old list of functions used to aggregate data
def old_agg_function(x):

    # Index to split data in half
    halfway_idx = int(len(x)/2)

    # This dict maps function names to functions to run
    # We can create new features by adding to this list and adding the corresponding name to agg_stats
    function_map = {
        'mean': np.mean(x),
        'std': np.std(x),
        'skew': stats.moment(x, 3),
        'kurtosis': stats.kurtosis(x),
        'min': np.min(x),
        'max': np.max(x),
        'q1': np.quantile(x, q=0.25),
        'median': np.median(x),
        'q3': np.quantile(x, q=0.75),
        'iqr': np.subtract(np.quantile(x, q=0.75), np.quantile(x, q=0.25)),
        'first': x.iloc[0],
        'last': x.iloc[-1],
        'change': np.subtract(x.iloc[-1], x.iloc[0]),
        'recent_mean': np.mean(x.iloc[halfway_idx:]),
        # roc_santhosh = mean (last 15 minutes) / mean (full 30 minutes)
        'roc_santhosh': np.divide(np.mean(x.iloc[halfway_idx:]), np.mean(x)),
        # roc_awal = mean (last 15 minutes) - mean (first 15 minutes)
        'roc_awal': np.subtract(np.mean(x.iloc[halfway_idx:]), np.mean(x.iloc[:halfway_idx])),
        # roc_mynka = (mean(last 15 minutes) - mean(first 15 minutes)) / mean(first 15 minutes)
        'roc_mynka': np.divide(np.subtract(np.mean(x.iloc[halfway_idx:]), np.mean(x.iloc[:halfway_idx])), np.mean(x.iloc[:halfway_idx])),
    }

    return [function_map[stat] for stat in agg_stats]


def filter_and_aggregate(df:pd.DataFrame, time: pd.Timestamp) -> pd.DataFrame:
        df = filter_df_by_timestamp(df, time)
        df = aggregate_data(df, time, agg_stats=agg_stats)
        return df

def drop_belt_stopped_rows(df_combined: pd.DataFrame,
    belt: str,
    uc2_tags_tqbs_path:str = 'ADA_UC2_CDP/uc2_tag_lists/UC2_Tags_TQBS.csv') -> pd.DataFrame:
    """Creates a data frame without rows in which belt speed = 0

    Parameters
    ----------
    df_combined : pd.DataFrame
        The tag and weather data at a one minute level (output of combine_tag_weather)
    belt : str
        The name of the belt.
    uc2_tags_tqbs_path : str, optional
        The path of the file containing the list of tags we are using, by default 'ADA_UC2_CDP/uc2_tag_lists/UC2_Tags_TQBS.csv'

    Returns
    -------
    pd.DataFrame
        A data frame containing features at a one minute level with rows in which belt speed = 0 removed
    """    
    
    df_beltspeed = pd.read_csv(uc2_tags_tqbs_path)
    beltspeed_tags_name = df_beltspeed[df_beltspeed['Tag_Desc'].isin([belt+'_BeltSpeed'])]['Tag_Name'].head(1)# get the belt speed tag for the belt (take only one if there are multiples)
    df_combined = df_combined[df_combined[beltspeed_tags_name.values[0]]!=0]
    
    return df_combined


def get_model_input_data(df:pd.DataFrame, y_labels:pd.Series, agg_stats:List[str]=agg_stats):
    """
    Get the data the the model will be using for training and testing.
    
    Args:
        df: The tag and weather data at a one minute level (output of combine_tag_weather)
        y_label: A pd.Series object with the timestamps and labels from the timestamps (output of create_y_labels)
    """
    
    df_final = pd.DataFrame()

    for time in y_labels.index:
        df_current = filter_df_by_timestamp(df, time)
        df_current = aggregate_data(df_current, time, agg_stats=agg_stats)
        df_final = df_final.append(df_current)
    
    # Final bits of cleaning 
    df_final['trip_type'] = y_labels
    df_final = df_final.sort_index()
    df_final = df_final.fillna(method='ffill')

    return df_final

def remove_correlated_features(df:pd.DataFrame, threshold:float=0.8) -> pd.DataFrame:
    # create correlation matrix
    corr_matrix = df.corr().abs()
    # select upper traingle of correlation matrix
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(np.bool))
    # Find index of columns with correlation greater than 0.95
    to_drop = [column for column in upper.columns if any(upper[column] > threshold)]
    print(len(to_drop))
    # Drop columns
    df = df.drop(to_drop, axis=1)

    return df

def normalise_data(df:pd.DataFrame) -> pd.DataFrame:
    # Normalise Data
    df = df.apply(lambda x: (x-x.min())/(x.max()-x.min()))
    # Drop columns that are unchanging (max-min==0)
    df = df.dropna(axis=1, how='all')

    return df

def uc2_data_processing_all(
    belt:str, 
    period_start:str, 
    period_end:str,
    PCS_tags_path:str,
    Weather_path:str,
    FPTU_path:str,
    BDS_path:str,
    selected_features_list:Optional[List[str]] = None,
    agg_stats:List[str] = agg_stats,
    existing_spark_session:bool=False) -> pd.DataFrame:
    """Do all the data processing start to finish for the model.

    Last Updated: 2023-07-12
    
    Note that this is used for testing purposes only.
    This will likely fall out of date as we update the pipeline code directly.

    Parameters
    ----------
    belt : str
        Name of the belt.
    period_start : str
        Start day as a string in Perth/Singapore time.
    period_end : str
        End day as as string in Perth/Singapore time.
    PCS_tags_path : str
        Folder path of the PCS tag data.
    Weather_path : str
        Folder path of the Weather data.
    FPTU_path : str
        Folder path of the FPTU data.
    BDS_path : str
        Folder path of the historical BDS data.
    selected_features_list : Optional[List[str]], optional
        Optional list of features to use in the model, by default None
    agg_stats : List[str], optional
        List of aggregation methods to use in the model, by default agg_stats
    existing_spark_session : bool, optional
        Option to connect to an existing spark session instead of creating a new one, by default False

    Returns
    -------
    pd.DataFrame
        Final dataframe to input into the model (UC2_model class)
    """    
    
    # Start spark session
    spark = create_spark_env(existing_session=False)

    # Get start and end dates as UTC
    period_start_utc, period_end_utc = transform_dates(period_start, period_end)

    # Load Data
    df_tags = load_pcs_tag_data(spark, belt, PCS_tags_path, period_start_utc, period_end_utc)

    df_weather = load_weather(spark, Weather_path, period_start_utc, period_end_utc)

    df_BDS = load_bds_data(spark, belt, BDS_path, period_start_utc, period_end_utc)

    df_ingested = load_new_data_tmp(spark, belt, BDS_path, period_start_utc, period_end_utc)

    df_FPTU = load_fptu(spark, FPTU_path, period_start_utc, period_end_utc, file_type='parquet')

    df_FPTU_processed = process_fptu_raw(df_FPTU, belt, period_start_utc, period_end_utc)

    df_BDS = process_new_data_tmp(df_BDS, belt)

    df_ingested = process_new_data_tmp(df_ingested, belt)

    df_tags = combine_pcs_and_ingested_data(df_tags, df_ingested)

    df_combined = combine_tag_weather(spark, belt, df_tags, df_weather, period_start_utc, period_end_utc, selected_features_list=selected_features_list)

    timestamp_info = label_timestamps(df_combined, df_BDS, df_FPTU_processed, belt)

    bd_event_start_time = define_bd_events(timestamp_info)

    bd_labels = bd_event_labels(bd_event_start_time, timestamp_info, period=3)

    # y_labels = create_y_labels(timestamp_info, belt, period=3)

    df_combined_belt_running = drop_belt_stopped_rows(df_combined, belt)

    df_model_input = get_model_input_data(df_combined_belt_running, bd_labels, agg_stats=agg_stats)
    
    return df_model_input

def get_inference_data(dt:datetime.datetime, belt:str) -> pd.DataFrame:
    """Get the inference data for the model inference pipeline.

    This function was used for the previous modelling approach and will likely need to be updated. 

    Parameters
    ----------
    dt : datetime.datetime
        Datetime of prediction
    belt : str
        Name of the belt.

    Returns
    -------
    pd.DataFrame
        Data frame to input into the model.
    """    
    """
    Get the input data for the model for the inference pipeline.
    """
    # Convert to UTC time
    dt = dt - datetime.timedelta(hours=8)
    
    # Load Tag and Weather Data
    df_tags, df_weather = uc2_inference_dataprep.uc2_dataload(dt, belt)
    
    # Data Preparation and Feature Engineering
    df_features, belt_speed = uc2_inference_dataprep.uc2_dataprep(df_tags, df_weather, dt, belt)
    
    return df_features, belt_speed

def make_prediction(model: Any, df: pd.DataFrame) -> pd.DataFrame:
    """Make a prediction using the model and input data.

    This function was used for the previous modelling approach and will likely need to be updated. 

    Parameters
    ----------
    model : Any 
        UC2 model (note that this is the model itself not the UC2_Model class)
    df : pd.DataFrame
        Input data for the model.

    Returns
    -------
    pd.DataFrame
        Data frame which contains the prediction and prediction probabilties. 
    """    
    """
    Make a prediction using the model and output a dataframe with the results.
    """
    pred = model.predict(df)
    pred_proba = model.predict_proba(df)
    result = pd.DataFrame(pred_proba, columns=['Test Normal Prob', 'Test BD Prob', 'Test OB Prob'], index=df.index)
    result['Test Pred'] = pred
    
    return result

def load_preprocesed_fptu(spark:SparkSession, data_path:str) -> pd.DataFrame:
    """Load the preprocessed FPTU data

    The assumption is that we have run load_fptu and process_fptu_raw then saved the result.
    The data is assumed to be in the parquet format. 

    Parameters
    ----------
    spark : SparkSession
        Spark session used to load and process the data.
    data_path : str
        Path location of the data.

    Returns
    -------
    pd.DataFrame
        Preprocessed FPTU data frame. 
    """    
    # Load FPTU Data
    fptu_sdf = spark.read.parquet(data_path)
    df_fptu = fptu_sdf.toPandas()
    df_fptu.set_index('FixedPlantTimeUsageEventStart', inplace=True)
    return df_fptu

def load_preprocessed_combined(spark:SparkSession, data_path:str) -> pd.DataFrame:
    """Load the preprocessed PCS tag and Weather data after they have been combined.

    The assumption is that we have loaded the PCS and Weather data with load_pcs_tag_data and load_weather,
    then combined them using combine_tag_weather and saved the result.

    This function can then be used to load the data (assuming it is saved as a parquet file).

    Parameters
    ----------
    spark : SparkSession
        Spark session used to load and process the data.  
    data_path : str
        The file path of the data.

    Returns
    -------
    pd.DataFrame
        The preprocessed and combined tag and weather data.
    """    
    # Load Tags and Weather Data
    combine_sdf = spark.read.parquet(data_path)
    df_combined = combine_sdf.toPandas()
    df_combined.set_index('__index_level_0__',inplace=True)
    return df_combined


def filter_by_threshold(df_combined:pd.DataFrame, uc2_tags_tqbs_path:str, belt:str) -> pd.DataFrame:
    """Filter out the data that is outside of the given threshold range.

    Note that this function is currently unused in the modelling.
    We will likely have to update this if we want to use it again.

    Parameters
    ----------
    df_combined : pd.DataFrame
        Combined tag and weather data.
    uc2_tags_tqbs_path : str
        Path of the file that contains information about the threshold ranges.
    belt : str
        The Name of the belt.

    Returns
    -------
    pd.DataFrame
        Data frame where the data outside of the given threshold has been removed.
    """    
    beltspeed_torque_tags = pd.read_csv(uc2_tags_tqbs_path)
    beltspeed_torque_tags = beltspeed_torque_tags[beltspeed_torque_tags['Tag_Desc'].isin([belt+'_Torque', belt+'_BeltSpeed'])]

    df = df_combined.copy()
    for i in beltspeed_torque_tags.index:
        df = df[df[beltspeed_torque_tags.loc[i,'Tag_Name']]>pd.to_numeric(beltspeed_torque_tags.loc[i,'Threshold'])]
    
    return df

def find_timestamps_for_downtimes(df_FPTU:pd.DataFrame, T:int=30, P:int=15, G:int=3):
    """Label the times we classify as downtimes for the model to predict.

    This function is depreated and no longer used. Instead we use the create_y_labels function to do this.
    Consider deleting.
    
    # Create Sample Dats
    T = 30  looks at max T mins before downtime event
    P = 15 # looks at values of the past P mins from each Interval
    G = 3 # Number of minutes between a belt trip and the event getting recorded in AMPLA

    Parameters
    ----------
    df_FPTU : pd.DataFrame
        The FPTU data after processing.
    T : int, optional
        The time before a event that we want to predict, by default 30
    P : int, optional
        The aggregation window, by default 15
    G : int, optional
        The AMPLA delay, by default 3

    Returns
    -------
    _type_
        Timestamps for the events.
    """

    # Find Datetime Range that are flagged as Delay in Progress
    timestamps_for_events = [pd.date_range(start=ix-datetime.timedelta(minutes = (P+T+G)), end=ix+datetime.timedelta(minutes = df_FPTU.loc[ix ,'agg_duration']), freq='T') for ix in df_FPTU.index]
    # Flatten the ranges
    timestamps_for_events = timestamps_for_events[0].append(timestamps_for_events[1:])

    return timestamps_for_events

def label_timestamps(
    df_combined: pd.DataFrame,
    df_BDS: pd.DataFrame,
    df_FPTU_processed: pd.DataFrame, 
    belt:str,
    uc2_tags_tqbs_path:str = 'ADA_UC2_CDP/uc2_tag_lists/UC2_Tags_TQBS.csv') -> pd.DataFrame:
    """Create a data frame that labels points in time with useful information.

    The output dataframe can be used to understand how we want to label the data in create_y_labels
    or diagnose issues in the data or modelling.

    Parameters
    ----------
    df_combined : pd.DataFrame
        The combined tag and weather data.
    df_BDS : pd.DataFrame
        The belt drift switch and alarm data.
    df_FPTU_processed : pd.DataFrame
        The processed FPTU data.
    belt : str
        The name of the belt.
    uc2_tags_tqbs_path : str, optional
        The path of the file containing the list of tags we are using, by default 'ADA_UC2_CDP/uc2_tag_lists/UC2_Tags_TQBS.csv'

    Returns
    -------
    pd.DataFrame
        A data frame containing useful information about what happens at points in time (1-minute level)
    """    

    df_beltspeed = pd.read_csv(uc2_tags_tqbs_path)
    beltspeed_tags_name = df_beltspeed[df_beltspeed['Tag_Desc'].isin([belt+'_BeltSpeed'])]['Tag_Name'].head(1)# get the belt speed tag for the belt (take only one if there are multiples)
    
    # Create empty dataframe
    timestamp_info = pd.DataFrame(index=df_combined.index)

    # These are the columns from df_FPTU_processed that we want to use when labelling timestamps
    FPTU_cols_to_expand = ['SourceIdentifier', 'CauseFixedPlantAssetCode', 'TUM5Code', 'Effect', 'Cause', 'FixedPlantTimeUsageComments', 'FixedPlantTimeUsageExplanation', 'event_duration']
    
    # For all the data in df_FPTU_processed get the relevant information 
    for index, row in df_FPTU_processed.iterrows():
        timestamp_info.loc[index:row['FixedPlantTimeUsageEventFinish'], FPTU_cols_to_expand] = row[FPTU_cols_to_expand].values

    # Make column for if belt stops and another if there is a belt drift 
    timestamp_info['belt_stopped'] = (df_combined[beltspeed_tags_name.values[0]] < 0.1)
    timestamp_info['bd_event'] = (timestamp_info['Effect'] == 'Trip - Belt Drift').fillna(False).astype(bool)

    # Align df_BDS with df_combined
    df_BDS = df_BDS.loc[df_combined.loc[df_BDS.index.min():].index]

    # Label timestamps for when the switches and alarms go off
    bd_switch_on = (df_BDS[bds_groups[belt]['switches']] > 0).any(axis=1).fillna(False).astype(bool).rename('bd_switch_on')
    bd_alarm_on = (df_BDS[bds_groups[belt]['alarms']] > 0).any(axis=1).fillna(False).astype(bool).rename('bd_alarm_on')

    # Concatentate the columns, note we have to make sure the index's align, which is why we are doing it like this
    timestamp_info = pd.concat([timestamp_info, bd_switch_on], axis=1)
    timestamp_info = pd.concat([timestamp_info, bd_alarm_on], axis=1)

    # We need to replace NaN's with False. But note that this is only because we have more PCS data than BDS data
    # Once we have the live ingestion of BDS data this will not be necessary
    # TODO: Update or remove this once the BDS data is in the integration! 
    timestamp_info['bd_switch_on'] = timestamp_info['bd_switch_on'].fillna(False).astype(bool)
    timestamp_info['bd_alarm_on'] = timestamp_info['bd_alarm_on'].fillna(False).astype(bool)

    return timestamp_info

def define_bd_events(timestamp_info: pd.DataFrame) -> pd.DataFrame:
    """
    New approach for defining belt drifts using only belt drift switch data
    """
    # We noticed that the events before this date had problems and so did not want to include them
    start_date = '2022-08-01'

    # Calculate cases where the alarm goes off and the belt does stop in the next 3 minutes.
    results = pd.DataFrame()
    for index, alarm in timestamp_info['bd_alarm_on'].loc[start_date:].items():
        if alarm:
            stop = timestamp_info['belt_stopped'].loc[index:index+pd.Timedelta(minutes=3)].any()
            if stop:
                results = pd.concat([
                    results,
                    pd.DataFrame({
                        'bd_alarm_on': [alarm],
                        'belt_stopped': [stop]
                    }, 
                    index=[index])])

    # Drop all data where the diffence in time is only 1 minute
    results = drop_subsequent_timestamps(results)
    
    # Get timestamps for when the event starts
    bd_event_start_time = results['bd_alarm_on']

    bd_event_start_time = bd_event_start_time[~bd_event_start_time.index.duplicated(keep='first')]
    bd_event_start_time = bd_event_start_time.rename('Belt Drift Start Times')

    return bd_event_start_time

def create_y_labels(timestamp_info, belt:str, period:int=3) -> pd.Series:
    """Create the labels we want to use in the modelling.

    This function creates the response variable for the model. 
    This is exactly what the model is trying to predict.

    Parameters
    ----------
    timestamp_info : _type_
        A dataframe containing useful information about what is happening at different points in time (output of label_timestamps)
    belt : str
        The name of the belt.
    period : int, optional
        The period we want to resample the data to. This also controls the prediction frequency of the model, by default 3

    Returns
    -------
    pd.Series
        A list of timestamps and labels for what is happening at that time, to be used as the response variable in the model.
    """

    # Make empty pd.Series for labels
    y_labels = pd.Series(index=timestamp_info.index, dtype=str)

    # Rename labels to match with the rest of the code. Note that we might want to refactor the names. 
    class_rename = {
        'Trip - Belt Drift': 'belt drift', 
        'Operational - Blockage': 'operational blockage'
        }
    timestamp_info['Effect'] = timestamp_info['Effect'].replace(class_rename)

    # Define the event types we want to predict using the model
    event_types = ['belt drift', 'operational blockage']

    # Get the AMPLA data for the start of the event
    ampla_event_start = timestamp_info.loc[timestamp_info['SourceIdentifier'].drop_duplicates(keep='first').dropna().index]

    # Filter on events we want to classify
    # TODO: Properly understand what is required to identify an event for modelling  
    # ampla_event_start = ampla_event_start[
    #     (ampla_event_start['Effect'].isin(event_types)) &
    #     (ampla_event_start['TUM5Code'].isin(['ULO','PFL','ULF']))
    #     ]
    
    ampla_event_start = ampla_event_start[ampla_event_start['Effect'].isin(event_types)]

    # Label the times before the event that we want to predict.
    for event_start_time in ampla_event_start.index:
        start_label_time = event_start_time - pred_time_before_event
    
        y_labels.loc[start_label_time:event_start_time] = ampla_event_start.loc[event_start_time]['Effect']

    # label times when event is happening
    for event in event_types:
        event_times = timestamp_info[timestamp_info['Effect'] == event].dropna().index
        y_labels.loc[event_times] = event + ' happening'

    # Label the times for the other events which are outside the scope of our model
    other_event_times = timestamp_info[~timestamp_info['Effect'].isin(event_types)].dropna().index
    y_labels.loc[other_event_times] = 'other event happening'

    # TODO: Add a label for the event just finishing
    # Get indexs after 'event_happening' and add agg_time_range
    # events_happening = y_labels.str.contains('happening')
    
    # Label times when belt speed is 0
    y_labels.loc[timestamp_info[timestamp_info['belt_stopped']].index] = 'belt stopped'

    # For any of the remaining times that we have not yet labeled, label them as 'normal'
    y_labels.loc[y_labels.isna()] = 'normal'

    # Resample to the period given (3 minutes by default)
    y_labels = y_labels.resample(str(period) + 'T').first()

    return y_labels

def create_y_labels_v2(df_FPTU: pd.DataFrame, df_combined: pd.DataFrame, belt:str, period:int=30) -> pd.Series:
    """
    Creates intervals every 30 minutes. Assigns event to interval if event occured within that 30 minute interval. If no downtime event occured within that interval then labelled as "normal"

    NOTE: If event start = 10:30 then labelled in 10:00 interval. If event start = 10:00 then labelled in 9:30 interval. If event start = 10:12 then labelled in 10:00 interval. If event start = 10:35 then labelled in 10:30 interval.
    """ 
    range_start = df_combined.index.min() + agg_time_range + datetime.timedelta(minutes=1) #TODO: Write code to ensure the range start is at 00 or 30 minutes
    range_end = df_combined.index.max()

    # Defining 30 min intervals
    thirty_min_intervals = pd.date_range(start=range_start, end=range_end, freq=str(period)+'T') 

    y_labels = pd.Series(index=thirty_min_intervals)

    # Iterate through each row. Assign to a 30 minute interval based on timestamp. Label 30 min interval as event type
    for index, row in df_FPTU.iterrows():
        event_type = row['Effect']
        if index.minute == 0:
            interval_start = index - datetime.timedelta(minutes=period)
        elif (index.minute >= 1) & (index.minute <= period):
            interval_start = index - datetime.timedelta(minutes=index.minute)
        elif index.minute > period:
            interval_start = index - datetime.timedelta(minutes=index.minute) + datetime.timedelta(minutes=30)
            
        y_labels.loc[interval_start] = event_type

    # Label all null events as Normal
    y_labels.loc[y_labels.isna()] = 'Normal'

    # Rename labels to match with the rest of the code. Note that we might want to refactor the names. 
    class_rename = {
        'Normal': 'normal', 
        'Trip - Belt Drift': 'belt drift', 
        'Operational - Blockage': 'operational blockage'
        }
    y_labels = y_labels.replace(class_rename)    

    return y_labels

def bd_event_labels(
    bd_event_start_time: pd.Series, 
    timestamp_info: pd.DataFrame, 
    period:int=3, 
    pred_time_before_event:pd.Timedelta = pred_time_before_event) -> pd.Series:
    """
    New labelling approach for only predicting belt drifts 
    """
    # Create and empty pd.Series for the labels
    bd_labels = pd.Series(index=timestamp_info.index, dtype=str)

    for event_start_time in bd_event_start_time.index:
        start_label_time = event_start_time - pred_time_before_event

        # Label an event as belt drift 30 minutes before a switch goes off
        bd_labels.loc[start_label_time:event_start_time] = 'belt drift'

        # label timestamps as "no prediction" agg_time_range min after downtime event has ended
        bd_labels.loc[event_start_time + pd.Timedelta(minutes=1):event_start_time + agg_time_range] = 'no prediction'

    # Label times when belt speed is 0
    bd_labels.loc[timestamp_info[timestamp_info['belt_stopped']].index] = 'belt stopped'

    # For any of the remaining times that we have not yet labeled, label them as 'normal'
    bd_labels.loc[bd_labels.isna()] = 'not belt drift'

    # Resample to the period given (3 minutes by default)
    bd_labels = bd_labels.resample(str(period) + 'T').first()

    return bd_labels


def bd_event_labels_approach_2(bd_event_start_time, timestamp_info):
    # Create and empty pd.Series for the labels
    bd_labels = pd.Series(index=timestamp_info.index, dtype=str)

    for event_start_time in bd_event_start_time.index:
        # lq - Label an event as belt drift from the time a switch goes off (i.e. 11:00:00 am)
        bd_labels.loc[event_start_time] = 1

    # For other events, label them as 0 first
    bd_labels.loc[bd_labels.isna()] = 0

    # Resample to the period given (3 minutes by default) , use sum so that we can keep all the belt drift events
    bd_labels = bd_labels.resample('3T').sum()

    bd_label_df = pd.DataFrame(bd_labels)
    bd_label_df.columns = ['trip_type']
    # Replace trip type to belt drift
    bd_label_df.loc[bd_label_df['trip_type'] > 0, 'trip_type'] = 'belt drift'

    # label belt stopped event
    # find common dates between the datetime index of belt stopping and new_bd_label_df
    common_belt_stop_idx = bd_label_df.index.intersection(timestamp_info[timestamp_info['belt_stopped']].index)
    # replace the value in new_bd_label_df as belt stopped
    bd_label_df.loc[common_belt_stop_idx, 'trip_type'] = 'belt stopped'

    # label other as non belt drift events
    bd_label_df.loc[bd_label_df['trip_type'] == 0, 'trip_type'] = 'not belt drift'

    # label 30 minutes before belt drift event as "to be removed"
    bd_event_only = bd_label_df.loc[bd_label_df.trip_type == 'belt drift']
    bd_event_only['remove_start_time'] = [dt - pd.Timedelta(minutes=29, seconds=59) for dt in bd_event_only.index]
    bd_event_only['remove_end_time'] = [dt - pd.Timedelta(seconds=1) for dt in bd_event_only.index]

    # loop through bd_event_only to label the rows as "to be removed"
    for idx, row in bd_event_only.iterrows():
        remove_bool_df = pd.DataFrame(
            (bd_label_df.index >= row['remove_start_time']) & (bd_label_df.index <= row['remove_end_time']),
            columns=['remove_bool'])
        bd_label_df = pd.concat([bd_label_df.reset_index(), remove_bool_df], axis=1)
        bd_label_df.loc[bd_label_df['remove_bool'] == True, 'trip_type'] = 'to be removed'
        bd_label_df = bd_label_df.set_index('index').drop(columns=['remove_bool'])

    bd_labels = bd_label_df.trip_type

    return bd_labels


def bd_event_labels_approach_3(
    bd_event_start_time: pd.Series, 
    timestamp_info: pd.DataFrame,
    period:int=3 
    ) -> pd.Series:
    """
    Labelling approach in which timestamps where the belt is down due to a belt drift are labelled as "belt drft." Labels are then shifted 30 minutes back 
    """
    # Create and empty pd.Series for the labels
    bd_labels = pd.Series(index=timestamp_info.index, dtype=str)

    # Label times when belt speed is 0
    bd_labels.loc[timestamp_info[timestamp_info['belt_stopped']].index] = 'belt stopped'

    for i in bd_event_start_time.index:
        # handling case if belt stops 3 min prior to belt drift event start
        if bd_labels.loc[i-pd.Timedelta(minutes=1)] == 'belt stopped':
            bd_labels.loc[i-pd.Timedelta(minutes=1)] = 'belt drift'
        if (bd_labels.loc[i-pd.Timedelta(minutes=1)] == 'belt stopped') & (bd_labels.loc[i-pd.Timedelta(minutes=2)] == 'belt stopped'):
            bd_labels.loc[i-pd.Timedelta(minutes=2)] = 'belt drift'
        if (bd_labels.loc[i-pd.Timedelta(minutes=1)] == 'belt stopped') & (bd_labels.loc[i-pd.Timedelta(minutes=2)] == 'belt stopped') & (bd_labels.loc[i-pd.Timedelta(minutes=3)] == 'belt stopped'):
            bd_labels.loc[i-pd.Timedelta(minutes=3)] = 'belt drift'
        start_index = i + pd.Timedelta(minutes=1)
        next_index = i + pd.Timedelta(minutes=2)
        belt_stopped = True
        if bd_labels.loc[start_index] == 'belt stopped': # case where belt drift event duration is greater than 1 minute
            while belt_stopped: # labelling consecutive 'belt stopped' events as belt drift
                if bd_labels.loc[start_index] != bd_labels[next_index]:
                    belt_stopped = False
                    bd_labels.loc[i:start_index] = 'belt drift'
                else:
                    start_index = start_index + pd.Timedelta(minutes=1)
                    next_index = start_index + pd.Timedelta(minutes=1)
        else: # case where belt drift event duration is 1 min (the start minute)
            bd_labels.loc[i] = 'belt drift'

    # For any of the remaining times that we have not yet labeled, label them as 'not belt drift'
    bd_labels.loc[bd_labels.isna()] = 'not belt drift'

    # Labelling 'belt stopped' events not related to belt drift as 'not belt drift' # TODO: test this
    bd_labels.loc[bd_labels == 'belt stopped'] = 'not belt drift'

    # Resample to the period given (3 minutes by default)
    bd_labels = bd_labels.resample(str(period) + 'T').first()

    # Shift indexes 30min behind
    bd_labels = bd_labels.shift(periods=-30, freq='T')

    return bd_labels

def get_results_training_pipeline(model_name:str, model:uc2_model.UC2_Model, df:pd.DataFrame) -> Dict[str, Any]:
    """Calculate metrics for the model on the given data so we can log the performance.

    Parameters
    ----------
    model_name : str
        The name of the model
    model : uc2_model.UC2_Model
        The model class for UC2
    df : pd.DataFrame
        The data frame we are making predictions on. This should contain the dependant variables and response variable.

    Returns
    -------
    Dict[str, Any]
        A dictionary containing lots of relevant metrics and information we would want to log. 
    """     
    actuals, predictions, precision, recall, f1 = model.calc_metrics(df)
    df_accuracy = model.get_model_metrics(df)
    cfmx = model.make_confusion_matrix(df)

    cfmx_log = {
        "schema_type": "confusion_matrix",
        "schema_version": "1.0.0",
        "data": {"class_labels": model.classes,
                "matrix": [[int(y) for y in x] for x in cfmx]}
        }

    results = {
        'model_name': model_name,
        'model': model,
        'df': df,
        'df_accuracy': df_accuracy,
        'actuals': actuals,
        'predictions': predictions, 
        'precision': precision, 
        'recall': recall, 
        'f1': f1,
        'cfmx': cfmx,
        'cfmx_log': cfmx_log,
        'df_with_predictions': df.assign(predictions=predictions)
    }

    return results


def load_data_locally(save_dir:Optional[Union[Path, str]]=None) -> Tuple[str]:
    """Load the data to the local compute.

    This function downloads the PCS tag data, the FPTU data and the Weather data onto the compute it is run on.
    This is mostly used for testing purposes.

    Returns
    -------
    Tuple[str]
        The location of the file paths for the PCS tag data, BDS data, FPTU data and Weather data that was downloaded locally.
        
    """    
    from azureml.core import Dataset, Workspace
    from azureml.core.datastore import Datastore

    ws = Workspace.from_config()
    ws.sync_keys()
    print(ws.name, ws.resource_group, ws.location, ws.subscription_id, sep = '  /  ')

    # Default datastore (Azure blob storage)
    def_blob_store = Datastore(ws, "ada_results_storage_dev_blob")
    ada_prod = Datastore.get(ws, 'ada_test_data_storage_blob')

    # Define save path
    if save_dir is None:
        save_dir = Path.cwd().parents[0]

    if type(save_dir) == str:
        Path(save_dir)
    
    assert 'Users/' in str(save_dir), "The save path must be in shared files e.g. Users/Firstname.Lastname/"

    print(save_dir)

    PCS_tags_path = str(save_dir / 'PCS_tags_dataset')
    BDS_path = str(save_dir / 'BDS_dataset')
    FPTU_path = str(save_dir / 'FPTU_dataset')
    Weather_path = str(save_dir / 'Weather_dataset')

    # Download data
    PCS_tags_dataset = Dataset.File.from_files(path=(def_blob_store, 'ADA_processed_datasets/PCS_tags/**'))
    PCS_tags_dataset.download(target_path=PCS_tags_path, overwrite=True)

    BDS_dataset = Dataset.File.from_files(path=(def_blob_store, 'UC2_historical_tag_data/**'))
    BDS_dataset.download(target_path=BDS_path, overwrite=True)

    FPTU_dataset = Dataset.File.from_files(path=(def_blob_store, 'ADA_processed_datasets/fptu/**'))
    FPTU_dataset.download(target_path=FPTU_path, overwrite=True)

    # FPTU_dataset = Dataset.File.from_files(path=(ada_prod,'kd-int058-ordw-fixed-plant-time-usage-ada/**'), validate=False)
    # FPTU_dataset.download(target_path=FPTU_path, overwrite=True)

    Weather_dataset = Dataset.File.from_files(path=(ada_prod,'kd-int056-weatherzone-forecasts-ada/**'), validate=False)
    Weather_dataset.download(target_path=Weather_path, overwrite=True)
    
    return PCS_tags_path, BDS_path, FPTU_path, Weather_path


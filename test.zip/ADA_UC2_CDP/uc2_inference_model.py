import os
import pandas as pd
import joblib
import datetime
import ADA_UC2_CDP.uc2_inference_dataprep as uc2_inference_dataprep
import ADA_UC2_CDP.uc2_inference_downtime_duration as uc2_inference_downtime_duration

def uc2_cdp_model(dt, belt, classifier='rf'):
    # Load Tag and Weather Data
    df_tags, df_weather = uc2_inference_dataprep.uc2_dataload(dt, belt)
    
    # Data Preparation and Feature Engineering
    df_features,belt_speed = uc2_inference_dataprep.uc2_dataprep(df_tags, df_weather, dt, belt)
    if belt_speed == 0: # belt stop
        prediction = 'Belt Stopped'

        # Produce Output Dataframe
        dt_awst = dt + datetime.timedelta(hours=8)
        output = pd.DataFrame({'datetime_of_prediction':[dt_awst],'belt':[belt],'prediction': [prediction],\
                            'probability_normal':[0],\
                            'probability_belt_drift':[0],\
                            'probability_operational_blockage':[0],\
                            'downtime_duration_median_mins':[0],\
                            'downtime_duration_q1_mins':[0],\
                            'downtime_duration_q3_mins': [0],\
                            'downtime_duration_iqr_mins': [0]})
    else:
        # Load Classifier Model
        if classifier=='rf':
            model_file = belt+'_CDP_RandomForestClassifier_Model.pkl'
        elif classifier=='xgb':
            model_file = belt+'_CDP_XGBoostClassifier_Model.pkl'
        model_path = os.path.join(os.path.dirname(__file__), model_file)
        model_path = model_path.replace('ADA_UC2_CDP/','UC2_trained_components/')
        model = joblib.load(model_path)
    
        # Model Prediction: Downtime Event
        predict = model.predict(df_features)
        classmap = {0:'Normal', 1:'Trip - Belt Drift', 2:'Operational - Blockage'}
        predict_class = pd.Series(predict).map(classmap)
        prediction = predict_class[0] 

        # Model Prediction: Probability 
        predict_proba = model.predict_proba(df_features)
        df_predict_proba = pd.DataFrame(predict_proba)
        df_predict_proba = df_predict_proba.rename(columns=classmap)
        
        # Downtime Duration Foreacast
        duration_median, duration_q1, duration_q3, duration_iqr = uc2_inference_downtime_duration.downtime_duration_forecast(belt, prediction)

        try:
            Belt_Drift_Proba = df_predict_proba['Trip - Belt Drift'][0]
        except: 
            Belt_Drift_Proba = 0

        try:
            Operational_Blockage_Proba = df_predict_proba['Operational - Blockage'][0]
        except: 
            Operational_Blockage_Proba = 0


        # Produce Output Dataframe
        dt_awst = dt + datetime.timedelta(hours=8)
        output = pd.DataFrame({'datetime_of_prediction':[dt_awst],'belt':[belt],'prediction': [prediction],\
                            'probability_normal':[round(df_predict_proba['Normal'][0],2)],\
                            'probability_belt_drift':[round(Belt_Drift_Proba,2)],\
                            'probability_operational_blockage':[round(Operational_Blockage_Proba,2)],\
                            'downtime_duration_median_mins':[round(duration_median,2)],\
                            'downtime_duration_q1_mins':[round(duration_q1,2)],\
                            'downtime_duration_q3_mins': [round(duration_q3,2)],\
                            'downtime_duration_iqr_mins': [round(duration_iqr,2)]})
          

    return output
# -*- coding: utf-8 -*-
"""
Created on 19/08/2022

@author: Ruoyu.Zhao
"""
import pandas as pd
import numpy as np
import datetime
from pandas.tseries.offsets import Minute
import scipy.stats as stats
import configparser
import os
from azureml.core import Workspace

def get_stats(x):
    return x.mean(), x.std(), stats.moment(x,3), stats.kurtosis(x)
    
def generate_training_data(data_ts, ranges, stats_lst, stats_func):
    cols = [stat+'_'+col for stat in stats_lst for col in data_ts.columns]
    observations = [pd.DataFrame(data_ts.loc[r].apply(stats_func).values.reshape(1,-1), columns=cols, index=r[-1:]) for r in ranges]
    return pd.concat(observations, ignore_index=False)

def create_sample_range(input_df,time_range,T,P,I,G,inference = False):
    if inference:
        sample_range = [pd.date_range(end=e, freq='T', periods=P) for e in time_range]
        
    else:
        sample_range = [pd.date_range(end=e-(G+T-i*I)*Minute(), freq='T', periods=P) for e in time_range for i in range(int(T/I)+1)]

    data_range = pd.concat([generate_training_data(input_df.iloc[:, :], sample_range,
                                                    ['mean','std', 'skew', 'kutosis'], get_stats)
                            ], axis=1)
    return data_range

def pivot_pcs_tags(df_tags):
    df_tags.drop_duplicates(subset=['time_rio','tagid'],keep='first',inplace=True)
    df_tags['time_rio'] = df_tags['time_rio'] + datetime.timedelta(hours=8) 
    df_tags['time_rio'] = [dt.tz_localize(None) for dt in df_tags['time_rio']]
    df_tags_pivot = df_tags.pivot(index='time_rio',columns = 'tagid',values='value_rio')
    df_tags_pivot = df_tags_pivot.sort_index().fillna(method='ffill')
    df_tags_pivot = df_tags_pivot.resample('T').last().fillna(method='ffill')
    # df_tags_pivot = df_tags_pivot.dropna(how='all')

    return df_tags_pivot

def weather_data_prep(df_weather):

    ## Align Data Type
    df_weather.forecast_at_time_utc = pd.to_datetime(df_weather.forecast_at_time_utc)
    df_weather.forecast_for_time_utc = pd.to_datetime(df_weather.forecast_for_time_utc)
    columns = ['temp_c','rel_humity_perc','rain_rate_mm_per_hour','wind_speed_kph','wind_dir_degrees']
    df_weather[columns] = df_weather[columns].apply(lambda x:pd.to_numeric(x))
    ## Drop Duplicates 
    df_weather = df_weather.sort_values(['forecast_for_time_utc','forecast_at_time_utc']).drop_duplicates(subset=['forecast_for_time_utc'],keep='last')
    # Convert to AWST Time zone
    df_weather['forecast_for_time_awst'] = df_weather['forecast_for_time_utc'] + datetime.timedelta(hours=8)
    df_weather.set_index('forecast_for_time_awst',inplace=True)
    ## Resample to 1 minute
    df_weather = df_weather[columns].resample('T').bfill()
    ## Feature New Variables
    df_weather = df_weather.assign(wind_speed_x= df_weather['wind_speed_kph']*np.cos(df_weather['wind_dir_degrees']*np.pi/180),
                                   wind_speed_y= df_weather['wind_speed_kph']*np.sin(df_weather['wind_dir_degrees']*np.pi/180))
    return df_weather

def tags_data_prep(df_tags_pivoted,belt,inference=False):
    # Convert UTC to AWST
    try:
        df_tags_pivoted.set_index('time_rio',inplace=True)
    except: 
        pass
    # Convert Data Type from Object to Numeric
    df_tags_pivoted= df_tags_pivoted.apply(pd.to_numeric, errors='coerce', axis=1)

    # Feature Engineering: Calculate Oversize% and Fine%
    if belt == 'CV0313':
        # Data Imputation 
        # df_tags_pivoted = df_tags_pivoted.fillna(method='bfill').fillna(0)
        # Correct scaling for Torque data
        torque_ts= datetime.datetime(2022,8,22,14) # Point of Change
        df_tags_pivoted.loc[df_tags_pivoted.index<torque_ts,'KD1.PPCS.CV0313VSD01_ACTDAT_TRQPERC']  = df_tags_pivoted.loc[df_tags_pivoted.index<torque_ts,'KD1.PPCS.CV0313VSD01_ACTDAT_TRQPERC']/10        
        # Look back 30mins 
        lag=30

        if inference: 
            df_tags_pivoted = df_tags_pivoted.sort_index().tail(lag+1) # keep only the last 31 mins of data 
            predict_ts = df_tags_pivoted.index.max()
            lag_ts = df_tags_pivoted.index.min()
            # Just calculate new features for the max timestamp (for inference pipeline, we are making prediction for one timestamp)
            df_tags_pivoted.loc[predict_ts,'KD1.PPCS.CV0313WT01_TOTNRST_prev30'] = df_tags_pivoted.loc[lag_ts,'KD1.PPCS.CV0313WT01_TOTNRST']
            df_tags_pivoted.loc[predict_ts,'KD1.PPCS.CV0316WT01_TOTNRST_prev30'] = df_tags_pivoted.loc[lag_ts,'KD1.PPCS.CV0316WT01_TOTNRST']
            df_tags_pivoted.loc[predict_ts,'KD1.PPCS.CV0211WT02_TOTNRST_prev30'] = df_tags_pivoted.loc[lag_ts,'KD1.PPCS.CV0211WT02_TOTNRST']
            df_tags_pivoted.loc[predict_ts,'KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST_prev30'] = df_tags_pivoted.loc[lag_ts,'KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST']
         
        else: # Training pipeline
            # df_tags_pivoted.dropna(inplace=True) # Drop the first 30mins 
            df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST_prev30'] = df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST'].shift(lag)
            df_tags_pivoted['KD1.PPCS.CV0316WT01_TOTNRST_prev30'] = df_tags_pivoted['KD1.PPCS.CV0316WT01_TOTNRST'].shift(lag)
            df_tags_pivoted['KD1.PPCS.CV0211WT02_TOTNRST_prev30'] = df_tags_pivoted['KD1.PPCS.CV0211WT02_TOTNRST'].shift(lag)
            df_tags_pivoted['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST_prev30'] = df_tags_pivoted['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST'].shift(lag)

        # Calculate Oversize%
        df_tags_pivoted['Oversize_Perct'] = (df_tags_pivoted['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST']-df_tags_pivoted['KD1.PPCS.CV0312WT01_ACTDAT_TOTNRST_prev30'])/(df_tags_pivoted['KD1.PPCS.CV0211WT02_TOTNRST']-df_tags_pivoted['KD1.PPCS.CV0211WT02_TOTNRST_prev30'])
        # Calculate Fine%
        df_tags_pivoted['Fine_Perct'] = (df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST']-df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST_prev30'])/(df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST']-df_tags_pivoted['KD1.PPCS.CV0313WT01_TOTNRST_prev30']+df_tags_pivoted['KD1.PPCS.CV0316WT01_TOTNRST']-df_tags_pivoted['KD1.PPCS.CV0316WT01_TOTNRST_prev30'])
        # df_tags_pivoted.fillna(0,inplace=True) # these Nan are caused by 0/0 
        # Correction to Oversize Percentage
        df_tags_pivoted.loc[(df_tags_pivoted['Oversize_Perct']<0)|(df_tags_pivoted['Oversize_Perct']>1),'Oversize_Perct']=np.NaN
        df_tags_pivoted['Oversize_Perct'].ffill(inplace=True)
    elif belt == 'CV0101':
        df_tags_pivoted.drop(columns='KD1.PPCS.CV0101VSD01_ACTDAT_TRQ',inplace=True) # Drop torque column
    elif belt == 'CV0316':
        torque_ts= datetime.datetime(2022,8,22,14) # Point of Change
        df_tags_pivoted.loc[df_tags_pivoted.index<torque_ts,'KD1.PPCS.CV0316VSD01_ACTDAT_TRQPERC']  = df_tags_pivoted.loc[df_tags_pivoted.index<torque_ts,'KD1.PPCS.CV0316VSD01_ACTDAT_TRQPERC']/10   
    else: 
        pass
    return df_tags_pivoted

# Get Config Locations and Paths
cfg_path = os.path.join(os.path.dirname(__file__), 'config-gd.ini')
cfg_path = cfg_path.replace('ADA_UC2_CDP/','config/')
config_obj = configparser.ConfigParser()
config_obj.read(cfg_path)

def get_workspace(env='dev'):
 
    # Get credentials information of environment
    cred_info = config_obj['credentials'+'_'+env]
    subscription_id = cred_info['subscription_id']
    resource_group = cred_info['resource_group']
    workspace_name = cred_info['workspace_name']
    # Define Workspace
    workspace = Workspace(subscription_id, resource_group, workspace_name)
    
    return workspace
    

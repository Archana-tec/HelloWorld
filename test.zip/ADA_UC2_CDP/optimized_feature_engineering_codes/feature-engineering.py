import pyspark
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import pandas as pd
from pyspark.sql import Window
from pyspark.sql import functions as f
from pyspark.sql.types import IntegerType, DoubleType,StructField, StructType, TimestampType, LongType, StringType
import numpy as np
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--top_level_folder")
parser.add_argument("--output_folder")
parser.add_argument("--input_file")
parser.add_argument("--tag")
args = parser.parse_args()

## Variables
top_level_folder = args.top_level_folder
output_folder = args.output_folder
input_file = args.input_file
tag = args.tag

lookback_min = ['30', '24', '15', '6', 'f15']


dev_client_id="128e82ef-d499-45af-8616-b302a4d2f547"
dev_client_secret="tOI8Q~KDIPaVQzts8amQScxN5BIbXlIAoKx6fbOp"
dev_tenant_id="4341df80-fbe6-41bf-89b0-e6e2379c9c23"

spark = SparkSession.builder \
                .appName('app_name') \
                .master('local[*]') \
                .config('spark.sql.execution.arrow.pyspark.enabled', True) \
                .config('spark.sql.session.timeZone', 'UTC') \
                .config('spark.driver.memory','32G') \
                .config('spark.ui.showConsoleProgress', True) \
                .config('spark.sql.repl.eagerEval.enabled', True) \
                .config('spark.driver.maxResultSize','0')\
                .getOrCreate()

spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.auth.type.srtdsdevrtioada02.dfs.core.windows.net", "OAuth"
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth.provider.type.srtdsdevrtioada02.dfs.core.windows.net",
    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.id.srtdsdevrtioada02.dfs.core.windows.net",
    dev_client_id,
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.secret.srtdsdevrtioada02.dfs.core.windows.net",
    dev_client_secret,
)
spark._jsc.hadoopConfiguration().set(
    "fs.azure.account.oauth2.client.endpoint.srtdsdevrtioada02.dfs.core.windows.net",
    "https://login.microsoftonline.com/" + dev_tenant_id + "/oauth2/token",
)


def aggregate_data(df, tag):
    print(f"Tag = {tag}")
    colName = tag.replace(".","_")
    df.createOrReplaceTempView('sdf')
    w_df = df.select('dt').toPandas()

    w_df['start_dt_30m'] = w_df['dt'] -  pd.to_timedelta(29,'m')
    w_df['start_dt_24m'] = w_df['dt'] -  pd.to_timedelta(23,'m')
    w_df['start_dt_15m'] = w_df['dt'] -  pd.to_timedelta(14,'m')
    w_df['start_dt_6m'] = w_df['dt'] -  pd.to_timedelta(5,'m')
    w_df['start_dt_f15m'] = w_df['dt'] -  pd.to_timedelta(29,'m')
    w_df['end_dt_f15m'] = w_df['dt'] - pd.to_timedelta(14,'m')

    w_df.reset_index(inplace=True)
    w_df.rename(columns={"index": "rn", "dt": "end_dt"}, inplace=True)

    max_rows = w_df['rn'].max()
    batch_size = 50000
    x = 0
    y =  batch_size

    idx = 0
    
    while x <= max_rows:
        w_sdf=spark.createDataFrame(w_df[x:y])
        w_sdf.createOrReplaceTempView('w')
        s1 = str(w_df[x:y]['start_dt_30m'].min() - pd.to_timedelta(30,'m'))
        s2 = str(w_df[x:y]['end_dt'].max() + pd.to_timedelta(10,'m'))
        print(f"+ Start Date = {s1}")
        print(f"  End Date = {s2}")
        
        spark.sql(f""" SELECT * FROM  sdf WHERE dt between '{s1}' and '{s2}' """).createOrReplaceTempView('t_sdf')

        for lm in lookback_min:
            print(f"  Lookback = {lm}")

            if lm == 'f15':
                spark.sql(f"""
                    select w.rn, `{tag}`, end_dt as dt
                    from w, t_sdf 
                    where dt between start_dt_{lm}m and end_dt_{lm}m
                """).createOrReplaceTempView('z')

                sdf_final = spark.sql(f"""
                    select distinct *
                    from (
                        select dt, 
                            rank() over(partition by rn ORDER BY dt desc ) as r,
                            mean(`{tag}`) over (partition by rn order by dt)  as `mean_{lm}_{colName}`
                        from z ) y
                        where r = 1
                """)
            else:
                spark.sql(f"""
                    select w.rn, dt, `{tag}` from w, t_sdf 
                    where dt between start_dt_{lm}m and end_dt
                """).createOrReplaceTempView('z')

                sdf_final = spark.sql(f"""
                    select *
                    from (
                        select dt, 
                            rank() over(partition by rn ORDER BY dt desc ) as r,
                            mean(`{tag}`) over (partition by rn order by dt)  as `mean_{lm}_{colName}`,
                            stddev_pop(`{tag}`) over (partition by rn order by dt)  as `std_{lm}_{colName}`,
                            min(`{tag}`) over (partition by rn order by dt)  as `min_{lm}_{colName}`,
                            max(`{tag}`) over (partition by rn order by dt)  as `max_{lm}_{colName}`,
                            percentile(`{tag}`, 0.25) over (partition by rn order by dt)  as `q1_{lm}_{colName}`,
                            percentile(`{tag}`, 0.50) over (partition by rn order by dt)  as `median_{lm}_{colName}`,
                            percentile(`{tag}`, 0.75) over (partition by rn order by dt)  as `q3_{lm}{colName}`,
                            percentile(`{tag}`, 0.75) over (partition by rn order by dt) - percentile(`{tag}`, 0.25) over (partition by rn order by dt)  as `iqr_{lm}_{colName}`,
                            first(`{tag}`) over (partition by rn order by dt) as `first_{lm}_{colName}`,
                            last(`{tag}`) over (partition by rn order by dt) as `last_{lm}_{colName}`,
                            max(`{tag}`) over (partition by rn order by dt)  - min(`{tag}`) over (partition by rn order by dt)  as `range_{lm}_{colName}` ,
                            sum(`{tag}`) over (partition by rn order by dt) as `sum_{lm}_{colName}`
                        from z ) y
                        where r = 1
                """)
            if idx == 0:
                sdf_final.drop('r').write.mode('overwrite').parquet(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/temp/{lm}_{tag}")
            else:
                sdf_final.drop('r').write.mode('append').parquet(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/temp/{lm}_{tag}")
        
        x += batch_size
        y += batch_size
        idx += 1

    print(f"Merging {tag} data ")
    idx = 0 
    sdf_master = df.select('dt')
    for lm in lookback_min:
        print(f'+ Lookback = {lm}')
        if idx > 0 :
            sdf_master = spark.read.parquet(f'abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/{tag}')
            
        sdf = spark.read.parquet(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/temp/{lm}_{tag}")
        sdf3 = sdf_master.join(sdf, on=["dt"], how='full')
        sdf3.write.format("parquet").mode("overwrite").save(f'abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/temp/{tag}')
        sdf_master = spark.read.parquet(f'abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/temp/{tag}')
        sdf_master.write.format("parquet").mode("overwrite").save(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/{tag}")
        idx += 1

    
    print(f"Appending ROC features ")
    df = spark.read.parquet(f'abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/temp/{tag}')
    df.createOrReplaceTempView('df')
    t = spark.sql(f"""
            select *, 
            `mean_15_{colName}` / `mean_30_{colName}` as `roc_santhosh_{colName}`,
            `mean_15_{colName}` - `mean_f15_{colName}` as `roc_awal_{colName}`,
            (`mean_15_{colName}` - `mean_f15_{colName}`) / `mean_f15_{colName}`  as `roc_mynka_{colName}`
            from df
        """)
    
    t.repartition(1).write.format("parquet").mode("overwrite").save(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/{top_level_folder}/{output_folder}/{tag}")

## Main Codes
df_combined_belt_running = spark.read.parquet(f"abfss://ada-temp-container@srtdsdevrtioada02.dfs.core.windows.net/uc2-feature-eng-data/{input_file}")
df = df_combined_belt_running.withColumnRenamed('__index_level_0__', 'dt').select(['dt',f'`{tag}`']).cache()

aggregate_data(df, tag)

print("DONE!")

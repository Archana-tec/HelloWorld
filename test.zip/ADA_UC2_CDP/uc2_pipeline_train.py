import os
from pathlib import Path
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from azureml.core import Run
import datetime
import pandas as pd
from pandas.tseries.offsets import Minute, Hour
import numpy as np
import shutil
import argparse
import ADA_UC2_CDP.uc2_utils as uc2_utils
import ADA_UC2_CDP.uc2_model as uc2_model
import ADA_UC2_CDP.uc2_utils_processing as uc2_utils_processing
from ADA_UC2_CDP.uc2_model_explainability import run_model_explainer
# ML Model Train Libraries
import sklearn.utils as skutils

from sklearn.model_selection import cross_val_predict, GridSearchCV,StratifiedKFold
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
import joblib

parser = argparse.ArgumentParser()
parser.add_argument("--data_prep_interim")
parser.add_argument("--model_folder")
parser.add_argument("--belt")
parser.add_argument("--period_start")
parser.add_argument("--period_end")
parser.add_argument("-t", "--hparam_tuning", required=False, default=False, action='store_false')
parser.add_argument("-c", "--cross_validation", required=False, default=False, action='store_false')
parser.add_argument("--train_start", type=pd.Timestamp, required=False, default=None)
parser.add_argument("--train_end", type=pd.Timestamp, required=False, default=None)
parser.add_argument("--test_start", type=pd.Timestamp, required=False, default=None)
parser.add_argument("--test_end", type=pd.Timestamp, required=False, default=None)
args = parser.parse_args()

# Set path variables
data_prep_interim = args.data_prep_interim
model_folder = args.model_folder
df_fptu_path = data_prep_interim+'/'+args.belt+'_FPTU_Processed'
df_combined_path = data_prep_interim+'/'+args.belt+'_tags_weather_processed'
uc2_tags_tqbs_path = 'ADA_UC2_CDP/uc2_tag_lists/UC2_Tags_TQBS.csv'
explainer_dir = Path(model_folder) / Path("UC2_trained_components/model_explainer")

# Create Output Directory
os.makedirs(model_folder, exist_ok=True)
os.makedirs(model_folder+'/UC2_trained_components', exist_ok=True)

# Connect to existing spark session and get run context
spark = uc2_utils_processing.create_spark_env(existing_session=True)
run = Run.get_context()

# Define Training Period
period_start_utc, period_end_utc = uc2_utils_processing.transform_dates(args.period_start, args.period_end)
dt_start_awst, dt_end_awst = uc2_utils_processing.dates_utc_to_awst(period_start_utc, period_end_utc)

"""
###
CREATE MODEL INPUT DATA
###
"""

print('Begin Loading Data for Model Input')

# Load preprocessed data
df_FPTU_processed = uc2_utils_processing.load_preprocesed_fptu(spark, df_fptu_path)
df_combined = uc2_utils_processing.load_preprocessed_combined(spark, df_combined_path)

# Get event labels for the time period
timestamp_info = uc2_utils_processing.label_timestamps(df_FPTU_processed, df_combined, args.belt)

# Get labels to use when modelling
# TODO: Add period arg as input to training pipeline rather than hard coding
y_labels = uc2_utils_processing.create_y_labels(timestamp_info, args.belt, period=3)

# Get the model data for training and testing
df_model_input = uc2_utils_processing.get_model_input_data(df_combined, y_labels, agg_stats=['mean','std'])


print('Finished Creating Data for Model')

"""
###
TRAIN BELT TRIPS CLASSIFIER ML MODEL 
###
"""

print('Begin training Belt Trip Classifier Model...')

# Set hyper paramter tuning and cross vaildation options
hparam_tuning = args.hparam_tuning
cross_validation = args.cross_validation

# Set options for manual train test split
if all(v is None for v in [args.train_start, args.train_end, args.test_start, args.test_end]):
        tt_split_dates = None
else:
        assert args.train_end is not None, "If using manual train/test split you must provide a date for train_end"

        # Set values to default if no value was provided
        train_start = args.train_start if args.train_start is not None else df_model_input.index.min()
        train_end = args.train_end
        test_start = args.test_start + pd.Timedelta(seconds=1) if args.test_start is not None else args.train_end + pd.Timedelta(seconds=1)
        test_end = args.test_end if args.test_end is not None else df_model_input.index.max()

        tt_split_dates = {
        "train_start": train_start,
        "train_end": train_end,
        "test_start": test_start,
        "test_end": test_end
        }

# Filter out cases where we don't want to make a prediction. 
# TODO: Probably refactor this to be done in a function with create_y_labels and get_model_input_data
df_model_input = df_model_input[
    (df_model_input['trip_type'] != 'belt stopped') &
    (df_model_input['trip_type'] != 'other event happening') &
    (df_model_input['trip_type'] != 'belt drift happening') &
    (df_model_input['trip_type'] != 'operational blockage happening')
    ]


# Instantiate models
rf_model = uc2_model.UC2_Model(
        df_model_input, 
        'rf', 
        tt_split_dates=tt_split_dates, 
        hparam_tuning=hparam_tuning, 
        cross_validation=cross_validation)

xgb_model = uc2_model.UC2_Model(
        df_model_input, 
        'xgb', 
        tt_split_dates=tt_split_dates, 
        hparam_tuning=hparam_tuning, 
        cross_validation=cross_validation)

# Model fit
rf_model.fit()
xgb_model.fit()

# Quick check to see if the data used between the models was the same.
assert rf_model.df_train.equals(xgb_model.df_train), "Training data between models is not the same"
assert rf_model.df_test.equals(xgb_model.df_test), "Test data between models is not the same"

# # Run Model Explainability
# run_model_explainer(explainer_dir, rf_model.df_test, rf_model.best_estimator_, 'rf')
# run_model_explainer(explainer_dir, xgb_model.df_test, xgb_model.best_estimator_, 'xgb')

# Save and log final results
model_list={'RandomForestClassifier':rf_model,'XGBoostClassifier':xgb_model}

df_model_input.to_csv(model_folder+'/UC2_trained_components/df_model_input.csv')

for classifier,fitted_model in model_list.items():
        # Save CV results
        fitted_model.cv_results.to_csv(model_folder+'/UC2_trained_components/cv_results_'+classifier+'.csv')

        # Get the model metrics we want to log
        train_results = uc2_utils_processing.get_results_training_pipeline(
                classifier, 
                fitted_model, 
                fitted_model.df_train)

        test_results = uc2_utils_processing.get_results_training_pipeline(
                classifier, 
                fitted_model, 
                fitted_model.df_test)

        # Save train and test data 
        train_results['df'].to_csv(model_folder+'/UC2_trained_components/training_set_all_df_'+classifier+'.csv')

        test_results['df_with_predictions'].to_csv(
                model_folder+'/UC2_trained_components/testing_set_all_df_'+classifier+'.csv')

        # Save the trained model
        joblib.dump(
                value=fitted_model.best_estimator_, 
                filename=model_folder+'/UC2_trained_components/'+args.belt+'_CDP_'+classifier+'_Model.pkl')

        # Write logs 
        run.parent.log_confusion_matrix(classifier+' - Confusion matrix - Training Set', train_results['cfmx_log'])
        run.parent.log_confusion_matrix(classifier+' - Confusion matrix - Testing Set', test_results['cfmx_log'])

        df_accuracy = test_results['df_accuracy']

        if 'normal' in df_accuracy.index:
                run.parent.log_table(
                        classifier + " Accuracy For Normal Events",
                        {
                                "Precision":[df_accuracy.loc['normal','Precision']],
                                "Recall":[df_accuracy.loc['normal','Recall']],
                                "F1":[df_accuracy.loc['normal','F1']]
                        }
                )

        if 'belt drift' in df_accuracy.index:
                run.parent.log_table(
                        classifier + " Accuracy For Belt Drift Events",
                        {
                                "Precision":[df_accuracy.loc['belt drift','Precision']],
                                "Recall":[df_accuracy.loc['belt drift','Recall']],
                                "F1":[df_accuracy.loc['belt drift','F1']]
                        }
                )

        if 'operational blockage' in df_accuracy.index:
                run.parent.log_table(
                        classifier + " Accuracy For Operational Blockage Events",
                        {
                                "Precision":[df_accuracy.loc['operational blockage','Precision']],
                                "Recall":[df_accuracy.loc['operational blockage','Recall']],
                                "F1":[df_accuracy.loc['operational blockage','F1']]
                        }
                )

# Copy code used to model folder
shutil.copytree('ADA_UC2_CDP',model_folder+'/ADA_UC2_CDP', dirs_exist_ok=True)
shutil.copytree('config',model_folder+'/config', dirs_exist_ok=True)
shutil.copy('load_ADA_data.py',model_folder)

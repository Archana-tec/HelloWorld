
# Import libraries
import argparse
import joblib
from azureml.core import Model, Run
import datetime

# Get parameters
parser = argparse.ArgumentParser()
parser.add_argument('--input_folder')
parser.add_argument('--belt')
parser.add_argument('--period_start')
parser.add_argument('--period_end')

args = parser.parse_args()
model_folder = args.input_folder 

if args.period_end == 'default':
    period_end_str = datetime.datetime.strftime(datetime.datetime.now() - datetime.timedelta(days=1), '%Y-%m-%d')
else:
    period_end_str = args.period_end

# Get the experiment run context
run = Run.get_context()

# Get run info
try: run_id = run._run_id 
except: run_id = ''
try: run_name = run._run_name
except: run_name = ''
try: run_details_url = run._run_details_url
except: run_details_url = ''

# Model registry description
description = f"Training dates: {args.period_start} to {period_end_str} for {args.belt}, Run Name: {run_name} Run ID: {run_id}, Run Details: {run_details_url}"

# Register model
Model.register( workspace = run.experiment.workspace,
                model_path = model_folder,
                model_name = 'ADA_UC2_CDP_'+args.belt +'_Model',
                description = description
                )

run.complete()
